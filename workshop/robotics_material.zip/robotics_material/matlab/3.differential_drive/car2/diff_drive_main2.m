%%% simulation of a robot car with a differential drive %%%
clc
clear 
close all

writeMovie = 0; %set to 1 to get a movie output
nameMovie = 'car.avi';

%%%%%%%% car parameters %%%%%%%
r = 0.01; %radius of wheels
b = 0.05; %width of the robot
R = 0.1; %length of the robot


%%%%%% initialize time and robot state %%%%%%% 
fps = 10; %adjust number of frames per second
delay = 0.01; %adjust the delay in the animation
z0 = [0 0 -pi/2]; %start position of the robot car

% %%%%%%%% initialize the left and right wheel controls %%%%%
% %t = linspace(0,tend,100*tend);
% speed  = 15*ones(length(t),1);
% direction = t-0.5*tend;
h = 0.1;

%%%%%%% writing letters %%%%%%%
t1 = 0:h:10;
speed1 = 20*ones(1,length(t1));
direction1 = zeros(1,length(t1)); 

t2 = 10+h:h:20;
speed2 = zeros(1,length(t2));
direction2 = pi/2*ones(1,length(t2)); 

t3 = 20+h:h:25;
speed3 = 20*ones(1,length(t3));
direction3 = zeros(1,length(t3)); 

t =[t1 t2 t3];
speed = [speed1 speed2 speed3];
direction = [direction1 direction2 direction3];


%%%%%%%%%% simulate %%%%%%%%%
z = z0;
for i=1:length(t)-1
    u = [speed(i) direction(i)];
    zz = euler_integration2([t(i) t(i+1)],z0,r,b,u);
    z0 = zz(end,:);
    z = [z; z0];
end

%%%%%% get coarse data for animation %%%%%%%%%%%
t_interp = linspace(0,t(end),fps*t(end));
[m,n] = size(z);
for i=1:n
    z_interp(:,i) = interp1(t,z(:,i),t_interp);
end

%%%%%% animate %%%%%
figure(1)
animation2(t_interp,z_interp,R,writeMovie, delay, nameMovie);



