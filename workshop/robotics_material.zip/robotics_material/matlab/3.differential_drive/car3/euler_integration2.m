function z1 = euler_integration(t,z0,r,b,u)


speed = u(1);
direction = u(2);
h = t(2)-t(1);

x0 = z0(1);
y0 = z0(2);
theta0 = z0(3);

R = [cos(theta0) -sin(theta0) 0; ...
     sin(theta0) cos(theta0) 0; ...
     0 0 1];
vel_local = [0.5*r*speed; ...
             0; ...
     0.5*(r/b)*direction];
vel_global = R*vel_local;

x1 = x0 + vel_global(1,1)*h;
y1 = y0 + vel_global(2,1)*h;
theta1 = theta0 + vel_global(3,1)*h;

z1 = [x1, y1, theta1];