clc
clear all
close all

%%%% define parameters for the pendulum %%%%%%
l1 = 1; l2 = 1;
theta1 = 0.5; theta2 = pi/2;

%%%%%%%% origin %%%%%%
x0 = 0; y0 = 0; 

%%%%% end of link1 %%%%
x1 = l1*cos(theta1); 
y1 = l1*sin(theta1);  

%%%% end of link 2 %%%%%%%
x2 = x1 + l2*cos(theta2); 
y2 = y1 + l2*sin(theta2); 

%Draw line from origin to end of link 1
line([x0 x1],[y0 y1],'LineWidth',5,'Color','red');

%Draw line from end of link 1 to end of link 2
line([x1 x2],[y1 y2],'LineWidth',5,'Color','blue');

xlabel('x'); ylabel('y');
grid on; %if you want the grid to show up.
axis('equal'); %make the axis equal, to avoid scaling effect
 
% These set the x and y limits for the axis (will need adjustment)
xlim([-2 2]);  
ylim([-2 2]);

