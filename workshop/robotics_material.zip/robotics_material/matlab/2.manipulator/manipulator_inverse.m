function manipulator_inverse

clc
clear all
close all

%%%% define parameters for the pendulum %%%%%%
l1 = 1; l2 = 1;

%Location where we want the end-effector to be, the reference value
x_ref = 0.5; y_ref = 0; 

%Try both these. They give different solutions. 
%theta1 = 0.5; theta2 = 0.5; %initial guess for angles 
theta1 = -0.5; theta2 = -0.5; %initial guess for angles
%theta1 = -pi/2; theta2 = -pi/2; %initial guess for angles
%theta1 = 0.1; theta2 = 0;

%%% Solve for the values of theta that give the required end-effector pose.
%fsolve solves for the roots for the equation x2-x_ref and y2-y_ref
theta = [theta1 theta2];
parameters = [l1 l2 x_ref y_ref];
options = optimoptions('fsolve','Display','iter','MaxIter',100,'MaxFunEval',300);
[X,FVAL,EXITFLAG] = fsolve(@fn_end_effector_position,theta,options,parameters);
theta1 = X(1);
theta2 = X(2);
disp(['Exitflag after running fsolve = ', num2str(EXITFLAG) ]) %Tells if fsolve converged or not
               %1 means converged else not converged
               %Type help fsolve to know more about what different 
               %EXITFLAG mean.
               
disp(['theta1 = ',num2str(theta1),'; theta2 = ',num2str(theta2)]);

%%%%%% plot %%%%%%%%%%
%%%%%%%% origin %%%%%%
x0 = 0; y0 = 0; 

%%%%% end of link1 %%%%
x1 = l1*cos(theta1); 
y1 = l1*sin(theta1);  

%%%% end of link 2 %%%%%%%
x2 = x1 + l2*cos(theta2); 
y2 = y1 + l2*sin(theta2); 

%Draw line from origin to end of link 1
line([x0 x1],[y0 y1],'LineWidth',5,'Color','red');

%Draw line from end of link 1 to end of link 2
line([x1 x2],[y1 y2],'LineWidth',5,'Color','blue');

xlabel('x'); ylabel('y');
grid on; %if you want the grid to show up.
axis('equal'); %make the axis equal, to avoid scaling effect
 
% These set the x and y limits for the axis (will need adjustment)
xlim([-2 2]);  
ylim([-2 2]);


function F = fn_end_effector_position(theta,parameters)
l1 = parameters(1); l2 = parameters(2);
x_ref = parameters(3); y_ref = parameters(4);

theta1 = theta(1); theta2 = theta(2);

x2 = l1*cos(theta1) + l2*cos(theta2); 
y2 = l1*sin(theta1) + l2*sin(theta2);
F = [x2-x_ref; y2-y_ref];
