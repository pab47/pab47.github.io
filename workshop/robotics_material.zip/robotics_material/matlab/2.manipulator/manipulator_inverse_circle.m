function manipulator_inverse_circle

clc
clear all
close all

%%%% define parameters for the pendulum %%%%%%
l1 = 1; l2 = 1;

%Location where we want the end-effector to be, the reference value
phi = linspace(0,2*pi,51);
x_ref = 1+0.5*cos(phi); y_ref = 0.5+0.5*sin(phi); 

%Try both these. They give different solutions. 
theta1 = 0.5; theta2 = 0.5; %initial guess for angles 
%theta1 = -0.5; theta2 = -0.5; %initial guess for angles
%theta1 = -pi/2; theta2 = -pi/2; %initial guess for angles
%theta1 = 0.1; theta2 = 0;

%%% Solve for the values of theta that give the required end-effector pose.
%fsolve solves for the roots for the equation x2-x_ref and y2-y_ref

theta1_all = zeros(length(phi),1); 
theta2_all = zeros(length(phi),1);
for i=1:length(phi)
    theta = [theta1 theta2];
    parameters = [l1 l2 x_ref(i) y_ref(i)];
    options = optimoptions('fsolve','Display','Off','MaxIter',100,'MaxFunEval',300);
    [X,FVAL,EXITFLAG] = fsolve(@fn_end_effector_position,theta,options,parameters);
    
    theta1 = X(1); theta2 = X(2); %reinitialize the guess based on previous solution
    
    theta1_all(i,1) = X(1);
    theta2_all(i,1) = X(2);
    % disp(['Exitflag after running fsolve = ', num2str(EXITFLAG) ]) %Tells if fsolve converged or not
    %                %1 means converged else not converged
    %                %Type help fsolve to know more about what different 
    %                %EXITFLAG mean.
    %                
    % disp(['theta1 = ',num2str(theta1),'; theta2 = ',num2str(theta2)]);
end


%%%%%% plot %%%%%%%%%%
for i=1:length(phi)
    x0 = 0; y0 = 0; 

    %%%%% end of link1 %%%%
    x1 = l1*cos(theta1_all(i,1)); 
    y1 = l1*sin(theta1_all(i,1));  

    %%%% end of link 2 %%%%%%%
    x2 = x1 + l2*cos(theta2_all(i,1)); 
    y2 = y1 + l2*sin(theta2_all(i,1)); 

    %%%%%% draw the curve on paper %%%
    plot(x2, y2, 'ko','Markersize',5,'MarkerEdgeColor','k','MarkerFaceColor','k'); hold on;
    
    %Draw line from origin to end of link 1
    h1 = line([x0 x1],[y0 y1],'LineWidth',5,'Color','red');

    %Draw line from end of link 1 to end of link 2
    h2 = line([x1 x2],[y1 y2],'LineWidth',5,'Color','blue');

    xlabel('x'); ylabel('y');
    grid on; %if you want the grid to show up.
    axis('equal'); %make the axis equal, to avoid scaling effect

    % These set the x and y limits for the axis (will need adjustment)
    xlim([-2 2]);  
    ylim([-2 2]);
    
    pause(0.1);
    delete(h1);
    delete(h2);
end


function F = fn_end_effector_position(theta,parameters)
l1 = parameters(1); l2 = parameters(2);
x_ref = parameters(3); y_ref = parameters(4);

theta1 = theta(1); theta2 = theta(2);

x2 = l1*cos(theta1) + l2*cos(theta2); 
y2 = l1*sin(theta1) + l2*sin(theta2);
F = [x2-x_ref; y2-y_ref];
