clc
clear all
close all

%%%%%% coordinates of moving rectangle 
x_rectangle =  [0 2 2 0];
y_rectangle =  [0 0 1 1];

%%%%%%%% coordinate of stationary circle of radius = r
t = linspace(0,5*pi);
r = 5;
x_center = r*cos(t); y_center = r*sin(t);
plot(x_center,y_center,'r:');  %plot the stationary circle
hold on;

%%%%% get the rectangle to turn along the circumference of the circle %%%
for i=1:length(t)
    x_moving = x_center(i) + x_rectangle;
    y_moving = y_center(i) + y_rectangle;
    h=patch(x_moving,y_moving,'b'); 
    axis('equal');
    axis([-r-1 r+1 -r-1 r+1]);
    pause(0.1);
    delete(h);
end