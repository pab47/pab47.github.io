function total_sum = my_sum(a)

total_sum = 0;
for i=1:length(a)
    total_sum = total_sum + a(i);
end

