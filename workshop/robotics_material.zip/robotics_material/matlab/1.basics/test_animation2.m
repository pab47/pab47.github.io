clc
clear all
close all

%%%%%%% draw a circle and animate %%%
theta = linspace(0,2*pi);
x_circle = sin(theta);
y_circle = cos(theta);
patch(x_circle,y_circle,'r'); hold on;
axis('equal');

%%%%%%% draw a rectangle and animate %%%
x_rectangle =  [1 3 3 1];
y_rectangle =  [1 1 2 2];
patch(x_rectangle,y_rectangle,'b'); hold on;
