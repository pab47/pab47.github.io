clc
clear all

a = [1 1 3 4];
b = [1 3 4 5 6];
c = [1 1 1 1 1 1 1 1 1 1 1];

my_sum(a)
my_sum(b)
my_sum(c)

