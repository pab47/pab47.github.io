clc %clear screen
clear all %clear all workspace variables.
close all %Close all figures.

x = linspace(0,2*pi); %Generate data
y = sin(x); 
plot(x,y); %plot sine curve
hold on; %prevent MATLAB from erasing the sine curve

for i=1:length(x)
    h=plot(x(i),y(i),'go','MarkerFacecolor','g','Markersize',10); %move the marker
    pause(0.1); %delay to give the effect of an animation
    delete(h); %delete the marker
end
