clc %clears the screen
clear all %clears all variables
close all %closes all figures

x = linspace(0,2*pi);
y = sin(x);

plot(x,y,'rx')