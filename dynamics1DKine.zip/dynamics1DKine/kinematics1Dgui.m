function varargout = kinematics1Dgui(varargin)
% KINEMATICS1DGUI MATLAB code for kinematics1Dgui.fig
%      KINEMATICS1DGUI, by itself, creates a new KINEMATICS1DGUI or raises the existing
%      singleton*.
%
%      H = KINEMATICS1DGUI returns the handle to a new KINEMATICS1DGUI or the handle to
%      the existing singleton*.
%
%      KINEMATICS1DGUI('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in KINEMATICS1DGUI.M with the given input arguments.
%
%      KINEMATICS1DGUI('Property','Value',...) creates a new KINEMATICS1DGUI or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before kinematics1Dgui_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to kinematics1Dgui_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help kinematics1Dgui

% Last Modified by GUIDE v2.5 03-Dec-2015 21:50:25

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @kinematics1Dgui_OpeningFcn, ...
                   'gui_OutputFcn',  @kinematics1Dgui_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before kinematics1Dgui is made visible.
function kinematics1Dgui_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to kinematics1Dgui (see VARARGIN)

% Choose default command line output for kinematics1Dgui
handles.output = hObject;

%set the initial conditions far away and run once
handles.fps = 5;
handles.slider_value = (handles.fps-3)/10;
handles.ships = [-5 0; -5 0; -5 0];
handles.you_kinematics = [-5; 0; 0]; 
handles.you_time = [1 2 3]';
handles.animation_running = 0;
set(handles.tag_you_kinematics, 'data', handles.you_kinematics);
set(handles.tag_you_time, 'data', handles.you_time);
set(handles.tag_ships, 'data', handles.ships);
set(handles.tag_slider,'Value',handles.slider_value); %3 is min value and 13 is max
handles.animation_running = 1;
kinematics1Dmain(handles);
handles.animation_running = 0;

handles.ships = [5 0.5; 4 0.75; 3 0.5];
%handles.ships = [5 0.5; 4 0; 3 0];
handles.you_kinematics = [4; 1; 0]; 
handles.you_time = [2 3 4.5]';

set(handles.tag_you_kinematics, 'data', handles.you_kinematics);
set(handles.tag_you_time, 'data', handles.you_time);
set(handles.tag_ships, 'data', handles.ships);

% Update handles structure
guidata(hObject, handles);

%kinematics1Dmain(handles);

% UIWAIT makes kinematics1Dgui wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = kinematics1Dgui_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes when entered data in editable cell(s) in tag_you_kinematics.
function tag_you_kinematics_CellEditCallback(hObject, eventdata, handles)
% hObject    handle to tag_you_kinematics (see GCBO)
% eventdata  structure with the following fields (see MATLAB.UI.CONTROL.TABLE)
%	Indices: row and column indices of the cell(s) edited
%	PreviousData: previous data for the cell(s) edited
%	EditData: string(s) entered by the user
%	NewData: EditData or its converted form set on the Data property. Empty if Data was not changed
%	Error: error string when failed to convert EditData to appropriate value for Data
% handles    structure with handles and user data (see GUIDATA)

handles.you_kinematics = get(hObject,'data');
%%% Need code that checks bounds %%%

set(handles.tag_you_kinematics, 'data', handles.you_kinematics);
%set(handles.tag_you_kinematics,'Data',get(hObject,'data'));
%disp(handles.you_kinematics)

% --- Executes when entered data in editable cell(s) in tag_you_time.
function tag_you_time_CellEditCallback(hObject, eventdata, handles)
% hObject    handle to tag_you_time (see GCBO)
% eventdata  structure with the following fields (see MATLAB.UI.CONTROL.TABLE)
%	Indices: row and column indices of the cell(s) edited
%	PreviousData: previous data for the cell(s) edited
%	EditData: string(s) entered by the user
%	NewData: EditData or its converted form set on the Data property. Empty if Data was not changed
%	Error: error string when failed to convert EditData to appropriate value for Data
% handles    structure with handles and user data (see GUIDATA)

handles.you_time = get(hObject,'data');
%%% Need code that checks bounds %%%

set(handles.tag_you_time, 'data', handles.you_time);

% --- Executes when entered data in editable cell(s) in tag_ships.
function tag_ships_CellEditCallback(hObject, eventdata, handles)
% hObject    handle to tag_ships (see GCBO)
% eventdata  structure with the following fields (see MATLAB.UI.CONTROL.TABLE)
%	Indices: row and column indices of the cell(s) edited
%	PreviousData: previous data for the cell(s) edited
%	EditData: string(s) entered by the user
%	NewData: EditData or its converted form set on the Data property. Empty if Data was not changed
%	Error: error string when failed to convert EditData to appropriate value for Data
% handles    structure with handles and user data (see GUIDATA)

handles.ships = get(hObject,'data');
%%% Need code that checks bounds %%%

set(handles.tag_ships, 'data', handles.ships);

% --- Executes on button press in tag_play.
function tag_play_Callback(hObject, eventdata, handles)
% hObject    handle to tag_play (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

pushbutton_value = get(handles.tag_pause,'Value');
if(pushbutton_value==0) %only run if toggle is NOT pressed
    handles.you_kinematics = get(handles.tag_you_kinematics,'data');
    handles.you_time =  get(handles.tag_you_time,'data');
    handles.ships =  get(handles.tag_ships,'data');
    kinematics1Dmain(handles);
end


% --- Executes on button press in tag_pause.
function tag_pause_Callback(hObject, eventdata, handles)
% hObject    handle to tag_pause (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of tag_pause


% --- Executes on slider movement.
function tag_slider_Callback(hObject, eventdata, handles)
% hObject    handle to tag_slider (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider

%handles.slider_value = get(hObject,'Value');
%disp(num2str(slider_value));

% --- Executes during object creation, after setting all properties.
function tag_slider_CreateFcn(hObject, eventdata, handles)
% hObject    handle to tag_slider (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end
