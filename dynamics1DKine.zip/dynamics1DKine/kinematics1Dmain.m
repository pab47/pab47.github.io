function kinematics1Dmain(handles)

%%%% things that need to be define to play the game %%%
parms.ne = 3; %number of enemies
set(handles.tag_play,'Enable','off'); %disable play button

for i=1:parms.ne
    enemy(i).y0 = handles.ships(i,1);
    enemy(i).vx0 = handles.ships(i,2);
    if (enemy(i).vx0 <= 0)
        enemy(i).vx0 = -2;
    end
end

bullet_times = handles.you_time;

parms.nb = parms.ne;
for i=1:parms.nb 
    bullet(i).ay0 = handles.you_kinematics(3);
    bullet(i).vy0 = handles.you_kinematics(2); %velocity of bullet. Need to set
    bullet(i).x0 = handles.you_kinematics(1);  %position of bullet is already set.
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%% parameters to tune
t0 = 0;
tend = 50; %put big enough time (this is end time)
dt = 0.1; %0.1
handles.slider_value = get(handles.tag_slider,'Value');
fps = round(handles.slider_value*10+3);
%fps = round(handles.fps); %value from 3 to 12
time_delay = 0.001; %delay between sim
parms.ylims = [0 5];
parms.xlims = [0 5];
parms.dist_collision = 0.01; %distance used to check collision
parms.location_after_collision_enemy = [-100,5]; %where the enemy should be after collision
parms.location_after_collision_bullet = [-100,-5]; %where the bullet should be after collision

ne = parms.ne;
nb = parms.nb;

xlims = parms.xlims;
ylims = parms.ylims;

for i=1:ne 
    %%%% things that do not change for enemy
    enemy(i).x0 = 0; enemy(i).vy0 = 0;
    
    enemy(i).x = []; enemy(i).vx = [];
    enemy(i).y = []; enemy(i).vy = [];
end

for i=1:nb 
    %%%% things that do not change for bullet %%%%
    bullet(i).vx0 = 0; bullet(i).y0 = 0; 
     
    bullet(i).x = []; bullet(i).vx = [];
    bullet(i).y = []; bullet(i).vy = [];
end


t = t0:dt:tend;
k = 1;
for i=1:ne 
    X0(k) = enemy(i).x0; k = k+1; 
    X0(k) = enemy(i).vx0; k = k+1;
    X0(k) = enemy(i).y0;  k = k+1;
    X0(k) = enemy(i).vy0; k = k+1;
end

for i=1:nb 
    X0(k) = bullet(i).x0;  k = k+1; 
    X0(k) = bullet(i).vx0; k = k+1;
    X0(k) = bullet(i).y0;  k = k+1;
    X0(k) = 0; k = k+1; %set to zero
end

if (length(bullet_times) ~= nb)
    error('bullet_times should be equal to nb');
end

array_hits = [];
total_hits = 0;
nb_current = 1; %current bullet in consideration
time = [];
for j=1:length(t)-1
    if (nb_current<=nb)
        if (bullet_times(nb_current)>=t(j) && bullet_times(nb_current)<=t(j))
            X0((ne+nb_current-1)*4+4) = bullet(nb_current).vy0;
            nb_current = nb_current+1;
        end
    end
    tspan = linspace(t(j),t(j+1),fps);
    time = [time; tspan(1:end)'];
    
    %X = ode4(@game,tspan,X0,parms,bullet); %integrate
    options = odeset('RelTol',1e-3,'AbsTol',1e-3);
    [T,X] = ode45(@game,tspan,X0,options,parms,bullet);
    
    [X0,hit] = collision_check(tspan(end),X(end,:),parms); %check collision. If there is a collision
                                                           %reset the position and set velocities to zero
    total_hits = total_hits + hit;
    
    
    k = 1;
    for i=1:ne 
        enemy(i).x = [enemy(i).x; X(2:end-1,k);X0(k)]; k = k+1; %add X0 because that resets position in case of collision
        enemy(i).vx = [enemy(i).vx; X(2:end-1,k);X0(k)]; k = k+1; 
        enemy(i).y = [enemy(i).y; X(2:end-1,k);X0(k)]; k = k+1;
        enemy(i).vy = [enemy(i).vy; X(2:end-1,k);X0(k)]; k = k+1; 
    end
    
    for i=1:nb 
        bullet(i).x = [bullet(i).x; X(2:end-1,k);X0(k)]; k = k+1;
        bullet(i).vx = [bullet(i).vx; X(2:end-1,k);X0(k)]; k = k+1; 
        bullet(i).y = [bullet(i).y; X(2:end-1,k);X0(k)]; k = k+1;
        bullet(i).vy = [bullet(i).vy; X(2:end-1,k);X0(k)]; k = k+1; 
    end
    
    array_hits = [array_hits; total_hits*ones(length(tspan)-1,1)];
    
    flag_stop = integration_stop_check(X0,parms); %stop integration if bullets and ships are out of bounds
    if (flag_stop==1) 
        break;
    end
   
end

%%%%%%%%%%%%%% plotting %%%%%%%%%
n = length(enemy(1).x);
axes(handles.tag_axes);
%reset(gcf);
%clf('reset');
hold on;
set(handles.tag_axes, 'YLim', ylims);
set(handles.tag_axes, 'XLim', xlims);
hh = animatedline('Marker','s','MarkerSize',15,'MarkerFaceColor','k','MarkerEdgeColor','k');
%pushbutton_value = 0;
for i=1:ne
    he(i) = animatedline('Marker','o','MarkerSize',10,'MarkerFaceColor','r','MarkerEdgeColor','r');
end
for i=1:nb
    hb(i) = animatedline('Marker','^','MarkerSize',10,'MarkerFaceColor','b','MarkerEdgeColor','b');
end

for i=1:n
    for j=1:ne
        clearpoints(he(j));
    end
    for j=1:nb
        clearpoints(hb(j));
    end
    
    addpoints(hh,bullet(1).x0,bullet(1).y0); %cannon
    for j=1:ne
        addpoints(he(j),enemy(j).x(i),enemy(j).y(i)); %ships
    end
    for j=1:nb
        addpoints(hb(j),bullet(j).x(i),bullet(j).y(i)); %bullets
    end
        set(handles.tag_score,'String',num2str(array_hits(i)));
        set(handles.tag_time,'String',num2str(sprintf('%1.2f',time(i))));
    grid on;
    if(i==n)
        clearpoints(hh);
        set(handles.tag_play,'Enable','on'); %disable play button
    end
    title('Ships (red circles) go left to right; Your bullets (blue arrows) go bottom to top','Fontsize',12);
    pause(time_delay);    
    
    %%%%% handling play/pause button %%%
    pushbutton_value = get(handles.tag_pause,'Value');
    if (pushbutton_value==1)
        while(1)
            pushbutton_value = get(handles.tag_pause,'Value');
            %play_value = get(handles.tag_play,'Value');
            %disp('play value');
            %disp(play_value);
            pause(0.1);
            
%             if (play_value==1) 
%                 clearpoints(hh);
%                 for j=1:ne
%                     clearpoints(he(j));
%                 end
%                 for j=1:nb
%                      clearpoints(hb(j));
%                 end
%                 break;
%             end
            
            if (pushbutton_value==0)
                break;
            end
        end
    end
     %disp(num2str(value));
end


   
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [X,hit] = collision_check(t,X,parms)

ne = parms.ne;
nb = parms.nb;

k = 1;
for i=1:ne 
    enemy(i).x = X(:,k); k = k+2; 
    enemy(i).y = X(:,k); k = k+2;
end


for i=1:nb 
    bullet(i).x = X(:,k); k = k+2; 
    bullet(i).y = X(:,k); k = k+2;
end

hit=0;
dist = ones(ne,nb);
for i=1:ne
    for j=1:nb
        dist(i,j) = sqrt((enemy(i).x - bullet(j).x)^2 + (enemy(i).y - bullet(j).y)^2);
        if (dist(i,j)<parms.dist_collision) %was a hit
            X((i-1)*4+1) = parms.location_after_collision_enemy(1); 
            X((i-1)*4+2) = 0; 
            X((i-1)*4+3) = parms.location_after_collision_enemy(2); 
            X((i-1)*4+4) = 0; 
            
            %bullet
            X((ne+j-1)*4+1) = parms.location_after_collision_bullet(1); 
            X((ne+j-1)*4+2) = 0; 
            X((ne+j-1)*4+3) = parms.location_after_collision_bullet(2); 
            X((ne+j-1)*4+4) = 0; 
            
            hit = hit+1;
    	
        end
    end
    
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function flag_stop = integration_stop_check(X,parms)

flag_stop = 1; %stop integration

k = 1;
for i=1:parms.ne
      xx(k) = X( (i-1)*4+1 ); %x position
      yy(k) = X( (i-1)*4+3 );
      k = k+1;
end

for i=1:parms.nb
      xx(k) = X( (parms.ne+i-1)*4+1 ); %x position
      yy(k) = X( (parms.ne+i-1)*4+3 );
      k = k+1;
end


for i=1:k-1
    if (xx(i)>=parms.xlims(1)-0.1 && ...
        xx(i)<=parms.xlims(2)+0.1 && ...
        yy(i)>=parms.ylims(1)-0.1 && ...
        yy(i)<=parms.ylims(2)+0.1) %inside the arena
    flag_stop = 0;
    return;
    end
end
    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%   
function Xdot=game(t,X,parms,bullet)       

ne = parms.ne;
nb = parms.nb;

k = 1;
for i=1:ne 
    Xdot(k) = X(k+1); k = k+1; 
    Xdot(k) = 0; k = k+1;
    Xdot(k) = X(k+1);  k = k+1;
    Xdot(k) = 0; k = k+1;
end

for i=1:nb 
    Xdot(k) = X(k+1);  k = k+1; 
    Xdot(k) = 0; k = k+1;
    Xdot(k) = X(k+1);  k = k+1;
    Xdot(k) = bullet(i).ay0; k = k+1;
end

Xdot = Xdot';
