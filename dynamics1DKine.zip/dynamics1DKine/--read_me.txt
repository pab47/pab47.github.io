Dec 5, 2015

Created by Pranav A. Bhounsule, pranav.bhounsule@utsa.edu tiny.cc/pranavb

A game-based approach to teach Engineering Dynamics. These files teaches about 1-dimensional kinematics. Specifically, motion with constant velocity and constant acceleration.

This software was tested on MATLAB 2015a and does not require any special toolboxes.

This file is distributed under a BSD license on a no-charge basis. The author does not hold responsibility for any errors in the program.

To run:
Open kinematics1Dgui.m in MATLAB editor and run. Click “New Game” button. 
