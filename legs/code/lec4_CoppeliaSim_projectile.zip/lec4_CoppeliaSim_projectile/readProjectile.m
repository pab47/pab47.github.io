clc
clear all
close all

data = readtable('projectile_plots.csv','Headerlines',2);
%data = readtable('projectile_plots.csv');
t = data{:,1};
x = data{:,2};
z = data{:,3};

figure(1) 
subplot(3,1,1)
plot(t,x);
subplot(3,1,2)
plot(t,z);
subplot(3,1,3)
plot(x,z);
