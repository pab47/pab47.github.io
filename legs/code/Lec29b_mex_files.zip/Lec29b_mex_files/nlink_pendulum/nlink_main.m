clc
clear all
close all

dof = 8;
method = 'zeroref';
%method = 'homogenous';
flagMEX = 1; %set to 1 for mex rhs

derive_nlink %derive equations


m(1:dof) = 1;
I(1:dof) = 0.1;
l(1:dof) = 1;
c = 0.5*l;

g = 9.81;
fps = 20;


parms.m = m; 
parms.I = I; 
parms.l = l; 
parms.c = c;
parms.g = g;

total_time = 10;
t = linspace(0,total_time,100*total_time); %time values
z0 = [pi/2 zeros(1,2*dof-1)];

disp('simulating');
options = odeset('Abstol',1e-12,'Reltol',1e-12);
tic
if (flagMEX==1)
    [t, z] = ode113(@nlink_rhsMEX,t,z0,options,parms); %integrate using ode45
else
    [t, z] = ode113(@nlink_rhs,t,z0,options,parms); %integrate using ode45
end
disp(['integration time is ',num2str(toc)])

disp('animating');
figure(1)
nlink_animate(t,z,parms,fps);

