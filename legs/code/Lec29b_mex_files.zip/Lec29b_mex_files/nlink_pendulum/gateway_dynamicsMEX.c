
#include <math.h>
#include "mex.h"
#include <stdio.h>
#include <stdlib.h>
#include "get_eom.c"

 
/* 
 *  Gateway routine
 */

void mexFunction(
  int nlhs, mxArray *plhs[],
  int nrhs, const mxArray *prhs[])
{
  unsigned int ms, ns, ns2;
  double t;
  double *z;
  double *params;
  double *M, *G, *C;

  // mexPrintf("Hello\n"); 
  
  /* Get the input argument, x, which is a vector */
  
  //[A,b] = dynamicsMEX(t,z0,params);
     t = mxGetScalar(prhs[0]);
     //mexPrintf("t = %f\n",t); 
     
     ms = mxGetM(prhs[1]); //Get Rows of prhs, prhs[1] is z0
     ns = mxGetN(prhs[1]); //Get Columns of prhs
     z = mxGetPr(prhs[1]); // Get data elements of prhs 
     //mexPrintf("%d %d \n",ms,ns);
     
     params = mxGetPr(prhs[2]); // Get data elements of prhs
     
//  /* Create a matrix for the return argument */
//  // Return is A, b 
   //ms2 = 2; //Get Rows of prhs, prhs[1] is z0
   ns2 = ns/2; //Get Columns of prhs
   plhs[0] = mxCreateDoubleMatrix(ns2, ns2, mxREAL); //M
   plhs[1] = mxCreateDoubleMatrix(ns2, 1, mxREAL); //C
   plhs[2] = mxCreateDoubleMatrix(ns2, 1, mxREAL); //G

        
  /* Dereference arguments */
   M = mxGetPr(plhs[0]);
   C = mxGetPr(plhs[1]);
   G = mxGetPr(plhs[2]);

   get_dynamics(M,C,G,z,params);
  /* call the computational routine */
 
}
