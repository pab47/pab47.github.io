% clc
% clear all
% close all
% 
% dof = 4;
%method = 'zeroref';
%method = 'homogenous';

% %%%%% symbolic quantities
q = sym('q',[1 dof],'real');
u = sym('u',[1 dof],'real');
a = sym('a',[1 dof],'real');


syms g real

m = sym('m',[1 dof],'real');
c = sym('c',[1 dof],'real');
l = sym('l',[1 dof],'real');
I = sym('I',[1 dof],'real');



if (strcmp(method,'zeroref'))
    %%% position vectors using zero reference model %%%
    r = [0 0 0]; %first joint at the origin
    pin = [0 0 1]; %axis along z
    T01 = revolute(q(1),r,pin);
    T0{1,:,:}  = T01;

    dist_joint = sym(0);
    for i=2:dof
        dist_joint = dist_joint-l(i-1);
        r = [0 dist_joint 0]; %joint i is at sum l(i) along -ive y-axis
        pin = [0 0 1]; %axis along z
        T_temp = revolute(q(i),r,pin);
        T0{i,:,:} = T0{i-1,:,:}*T_temp; %e.g., H02 = H01*H12
    end

    dist_joint = sym(0);
    for i=1:dof
       r_G(i,:)  = simplify(T0{i,:,:}*[0 dist_joint-c(i) 0 1]','Seconds',10);
       dist_joint = dist_joint-l(i);
       r_P(i,:)  = simplify(T0{i,:,:}*[0 dist_joint 0 1]','Seconds',10);

        disp(['simplified position vector no ',num2str(i)]);
    end
elseif (strcmp(method,'homogenous'))
    %%%%% position vectors using homogenous transformations %%%%
    H01 = homogeneous(3*pi/2 + q(1),0);
    H0{1,:,:}  = H01;
    for i=2:dof
        H_temp = homogeneous(q(i),l(i-1));
        H0{i,:,:} = H0{i-1,:,:}*H_temp; %e.g., H02 = H01*H12
    end

    for i=1:dof
       r_G(i,:)  = simplify(H0{i,:,:}*[c(i) 0 1]','Seconds',10);
       r_P(i,:)  = simplify(H0{i,:,:}*[l(i) 0 1]','Seconds',10);

    %     r_G(i,:)  = collect(H0{i,:,:}*[c(i) 0 1]');
    %     r_P(i,:)  = collect(H0{i,:,:}*[l(i) 0 1]'); 
        %%%%% this seems to work better for ndof of 10 or more %%
    %     r_G(i,:)  = H0{i,:,:}*[c(i) 0 1]';
    %     r_P(i,:)  = H0{i,:,:}*[l(i) 0 1]';
        disp(['simplified position vector no ',num2str(i)]);
    end
else
    error('method for derivation should be zeroref or homogenous');
end

%%%%% velocity vectors %%%%%%
for i=1:dof
    v_G(i,:) = jacobian(r_G(i,:),q)*u';
end

 om(1) = u(1);
 for i=2:dof
     om(i) = om(i-1) + u(i);
 end

%%%% lagrangian %%
T = 0;
V = 0;
for i=1:dof
    T = T + 0.5*m(i)*(v_G(i,:)*v_G(i,:)')+0.5*I(i)*om(i)^2;
    V = V + m(i)*g*r_G(i,2);
end 
L = T-V;
 
for ii=1:dof
    dLdqdot(ii) = diff(L,u(ii));
    sum = 0;
    for j=1:dof
        sum = sum +diff(dLdqdot(ii),q(j))*u(j) + diff(dLdqdot(ii),u(j))*a(j);
     end
    ddt_dLdqdot(ii) = sum;
    dLdq(ii) = diff(L,q(ii));

    EOM(ii) = ddt_dLdqdot(ii) - dLdq(ii);
    disp(['EOM (i = ',num2str(ii),') done']);
end

%%%%%%%%% collecting equations as A a = b
M = jacobian(EOM,a(1:dof));
disp('M done')
for i=1:dof
    N(i,1) = subs(EOM(i),a(1:dof),zeros(1,dof));
    G(i,1) = subs(N(i,1),u(1:dof),zeros(1,dof));
    C(i,1) = N(i,1) - G(i,1);
end
disp('N, G, C done');


disp('Now writing the required files');

if (flagMEX ==1)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
disp('Generating MEX rhs file');
fid=fopen( 'nlink_rhsMEX.m','w');

fprintf(fid, 'function zdot = nlink_rhsMEX(t,z,parms)\n\n');

for i=1:dof
    fprintf(fid,['m',num2str(i),' = parms.m(',num2str(i),');']);
    fprintf(fid,['I',num2str(i),' = parms.I(',num2str(i),');']);
    fprintf(fid,['c',num2str(i),' = parms.c(',num2str(i),');']);
    fprintf(fid,['l',num2str(i),' = parms.l(',num2str(i),'); \n']);
end
fprintf(fid, 'g = parms.g; \n\n');

fprintf(fid,'params = [g  ');
for i=1:dof
    fprintf(fid,['m',num2str(i),' I',num2str(i),' c',num2str(i),' l',num2str(i),' ']);
end
fprintf(fid,'];\n\n');

j = 1;
for i=1:dof
    fprintf(fid,['q',num2str(i),' = z(',num2str(j),');']); j = j+1;
    fprintf(fid,['u',num2str(i),' = z(',num2str(j),'); \n']); j = j+1;
end
fprintf(fid, '\n\n');

fprintf(fid,'[~,nn] = size(z);\n');
fprintf(fid,'if (nn==1) \n');
fprintf(fid,'    z = z'';\n');
fprintf(fid,'end\n\n');


fprintf(fid,'[M,C,G] = gateway_dynamicsMEX(t,z,params); \n\n');
fprintf(fid,'M = M''; \n\n');

fprintf(fid, 'a=M\\(-G-C); \n\n');

for i=1:dof
    fprintf(fid,['a',num2str(i),' = a(',num2str(i),');']); 
end
fprintf(fid, '\n\n');

fprintf(fid, 'zdot=[');
for i=1:dof
    fprintf(fid,['u',num2str(i),' a',num2str(i),' ']); 
end
fprintf(fid, ']'';\n\n');

fclose(fid);

disp('rhs MEX File written');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
disp('Writing M, G, C matrices to a C file');

fid=fopen( 'get_eom.c','w');

fprintf(fid,'void get_dynamics(double *ptr_M, double *CC, double *GG, double *z, double *params) \n\n');
fprintf(fid,'{\n\n');
fprintf(fid,'int i,j; \n\n');
fprintf(fid,['double M[',num2str(dof),'][',num2str(dof),']={0};\n']);
fprintf(fid,['double C[',num2str(dof),'][1]={0};\n']);
fprintf(fid,['double G[',num2str(dof),'][1]={0};\n\n']);

fprintf(fid,'double g; \n');
for i=1:dof
    fprintf(fid,'double ');
    fprintf(fid,['m',num2str(i),', ']);
    fprintf(fid,['I',num2str(i),', ']);
    fprintf(fid,['c',num2str(i),', ']);
    fprintf(fid,['l',num2str(i),';\n ']);
end
fprintf(fid,'\n');

for i=1:dof
    fprintf(fid,'double ');
    fprintf(fid,['q',num2str(i),',']); 
    fprintf(fid,['u',num2str(i),';\n']); 
end
fprintf(fid, '\n');
    
fprintf(fid,'i = 0;\n'); 
fprintf(fid,'g = params[i]; i=i+1;\n'); 
for i=1:dof
    fprintf(fid,['m',num2str(i),'= params[i]; i=i+1;\n']);
    fprintf(fid,['I',num2str(i),'= params[i]; i=i+1;\n']);
    fprintf(fid,['c',num2str(i),'= params[i]; i=i+1;\n']);
    fprintf(fid,['l',num2str(i),'= params[i]; i=i+1;\n']);
end
fprintf(fid,'\n');

fprintf(fid,'i = 0;\n'); 
j = 0;
for i=1:dof
    fprintf(fid,['q',num2str(i),' = z[',num2str(j),']; i=i+1;\n']); j = j+1;
    fprintf(fid,['u',num2str(i),' = z[',num2str(j),']; i=i+1;\n']); j = j+1;
end
fprintf(fid, '\n\n');

fprintf(fid,ccode(M));
fprintf(fid,'\n\n');
fprintf(fid,ccode(C));
fprintf(fid,'\n\n');
fprintf(fid,ccode(G));
fprintf(fid,'\n\n');


fprintf(fid,['for (i=0;i<',num2str(dof),';i++)\n']);
fprintf(fid,['for (j=0;j<',num2str(dof),';j++)\n']);
fprintf(fid,['*(ptr_M + i*',num2str(dof),'+j) = M[i][j];\n\n']);


fprintf(fid,['for (i=0;i<',num2str(dof),';i++)\n']);
fprintf(fid,'GG[i] = G[i][0];\n\n');

fprintf(fid,['for (i=0;i<',num2str(dof),';i++)\n']);
fprintf(fid,'CC[i] = C[i][0];\n\n');

fprintf(fid,'}\n\n');
fclose(fid);

disp('M, C, G written to a file');

disp('mexing gateway_dynamicsMEX.c');
mex gateway_dynamicsMEX.c
else
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
disp('Generating MATLAB rhs file');
fid=fopen( 'nlink_rhs.m','w');

fprintf(fid, 'function zdot = nlink_rhs(t,z,parms)\n\n');

for i=1:dof
    fprintf(fid,['m',num2str(i),' = parms.m(',num2str(i),');']);
    fprintf(fid,['I',num2str(i),' = parms.I(',num2str(i),');']);
    fprintf(fid,['c',num2str(i),' = parms.c(',num2str(i),');']);
    fprintf(fid,['l',num2str(i),' = parms.l(',num2str(i),'); \n']);
end
fprintf(fid, 'g = parms.g; \n\n');

j = 1;
for i=1:dof
    fprintf(fid,['q',num2str(i),' = z(',num2str(j),');']); j = j+1;
    fprintf(fid,['u',num2str(i),' = z(',num2str(j),'); \n']); j = j+1;
end
fprintf(fid, '\n\n');

for i=1:dof
    for j=1:dof
        fprintf(fid,['M(',num2str(i),',',num2str(j),')=',char(M(i,j)), ';\n\n']);
    end
end

for i=1:dof
    fprintf(fid,['C(',num2str(i),',1)=',char(C(i,1)), ';\n\n']);
end

for i=1:dof
    fprintf(fid,['G(',num2str(i),',1)=',char(G(i,1)), ';\n\n']);
end

fprintf(fid, 'a=M\\(-G-C); \n\n');

for i=1:dof
    fprintf(fid,['a',num2str(i),' = a(',num2str(i),');']); 
end
fprintf(fid, '\n\n');

fprintf(fid, 'zdot=[');
for i=1:dof
    fprintf(fid,['u',num2str(i),' a',num2str(i),' ']); 
end
fprintf(fid, ']'';\n\n');

fclose(fid);

disp('MATLAB rhs File written');

end
    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
disp('Generating animation file');

fid=fopen( 'nlink_animate.m','w');

fprintf(fid, 'function nlink_animate(t_all,z_all,parms,fps)\n\n');

fprintf(fid,'z_all_plot = [');
j = 1;
for i=1:dof
    fprintf(fid,['z_all(:,',num2str(j),') ']); j = j+2;
end
fprintf(fid,'];\n');
fprintf(fid,'nn = size(z_all_plot,2);\n');
fprintf(fid,'total_frames = round(t_all(end)*fps);\n');
fprintf(fid,'t = linspace(0,t_all(end),total_frames);\n');
fprintf(fid,'z = zeros(total_frames,nn);\n');
fprintf(fid,'for i=1:nn\n');
fprintf(fid,'    z(:,i) = interp1(t_all,z_all_plot(:,i),t);\n');
fprintf(fid,'end\n');

for i=1:dof
    fprintf(fid,['l',num2str(i),' = parms.l(',num2str(i),'); \n']);
end
fprintf(fid,'ll = sum(parms.l)+0.2;\n\n');

fprintf(fid,'mm = size(z,1); \n');
fprintf(fid,'for i=1:mm \n\n');
    
    for i=1:dof
        fprintf(fid,['q',num2str(i),' = z(i,',num2str(i),');\n']); 
    end
    fprintf(fid, '\n\n');

 
    fprintf(fid,'P0 = [0 0];\n');
    for i=1:dof
        fprintf(fid,['P',num2str(i),' = [',char(r_P(i,1)),', ',char(r_P(i,2)),']; \n']);
    end
    fprintf(fid, '\n\n');

    fprintf(fid,'plot(P0(1),P0(2),''ko'',''Markersize'',10,''MarkerFaceColor'',''k'');\n\n');

    
    colors = ['r' 'g' 'b' 'c' 'm' 'k' 'y']; 
    for i=1:dof
        j = randi(length(colors),1);
        fprintf(fid,['x=[P',num2str(i-1),'(1) P',num2str(i),'(1) ];\n']);
        fprintf(fid,['y=[P',num2str(i-1),'(2) P',num2str(i),'(2) ];\n']);
        fprintf(fid,['h(',num2str(i),') = line(x,y,''Color'',''',colors(j),''',''Linewidth'',2);\n\n']);
    end
    fprintf(fid, '\n\n');
    
    fprintf(fid,'axis(''equal'')\n');
    fprintf(fid,'axis([-ll ll -ll ll]);\n');
    fprintf(fid,'if (i==1)\n');
    fprintf(fid,'    pause(1)\n');
    fprintf(fid,'end\n\n');
    

    fprintf(fid,'pause(0.01);\n\n');
   
   fprintf(fid,'if (i~=mm)  \n');  
   for i=1:dof
        fprintf(fid,['delete(h(',num2str(i),'));\n']); 
   end
 fprintf(fid,'end\n');
fprintf(fid,'end\n');

disp('Animation File written');

disp('clearing symbolic variables q u a g m c l I');
clear q u a g m c l I
