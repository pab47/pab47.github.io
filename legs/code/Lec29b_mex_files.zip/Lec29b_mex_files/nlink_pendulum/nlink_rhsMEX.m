function zdot = nlink_rhsMEX(t,z,parms)

m1 = parms.m(1);I1 = parms.I(1);c1 = parms.c(1);l1 = parms.l(1); 
m2 = parms.m(2);I2 = parms.I(2);c2 = parms.c(2);l2 = parms.l(2); 
m3 = parms.m(3);I3 = parms.I(3);c3 = parms.c(3);l3 = parms.l(3); 
m4 = parms.m(4);I4 = parms.I(4);c4 = parms.c(4);l4 = parms.l(4); 
m5 = parms.m(5);I5 = parms.I(5);c5 = parms.c(5);l5 = parms.l(5); 
m6 = parms.m(6);I6 = parms.I(6);c6 = parms.c(6);l6 = parms.l(6); 
m7 = parms.m(7);I7 = parms.I(7);c7 = parms.c(7);l7 = parms.l(7); 
m8 = parms.m(8);I8 = parms.I(8);c8 = parms.c(8);l8 = parms.l(8); 
g = parms.g; 

params = [g  m1 I1 c1 l1 m2 I2 c2 l2 m3 I3 c3 l3 m4 I4 c4 l4 m5 I5 c5 l5 m6 I6 c6 l6 m7 I7 c7 l7 m8 I8 c8 l8 ];

q1 = z(1);u1 = z(2); 
q2 = z(3);u2 = z(4); 
q3 = z(5);u3 = z(6); 
q4 = z(7);u4 = z(8); 
q5 = z(9);u5 = z(10); 
q6 = z(11);u6 = z(12); 
q7 = z(13);u7 = z(14); 
q8 = z(15);u8 = z(16); 


[~,nn] = size(z);
if (nn==1) 
    z = z';
end

[M,C,G] = gateway_dynamicsMEX(t,z,params); 

M = M'; 

a=M\(-G-C); 

a1 = a(1);a2 = a(2);a3 = a(3);a4 = a(4);a5 = a(5);a6 = a(6);a7 = a(7);a8 = a(8);

zdot=[u1 a1 u2 a2 u3 a3 u4 a4 u5 a5 u6 a6 u7 a7 u8 a8 ]';

