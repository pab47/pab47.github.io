function nlink_animate(t_all,z_all,parms,fps)

z_all_plot = [z_all(:,1) z_all(:,3) z_all(:,5) z_all(:,7) z_all(:,9) z_all(:,11) z_all(:,13) z_all(:,15) ];
nn = size(z_all_plot,2);
total_frames = round(t_all(end)*fps);
t = linspace(0,t_all(end),total_frames);
z = zeros(total_frames,nn);
for i=1:nn
    z(:,i) = interp1(t_all,z_all_plot(:,i),t);
end
l1 = parms.l(1); 
l2 = parms.l(2); 
l3 = parms.l(3); 
l4 = parms.l(4); 
l5 = parms.l(5); 
l6 = parms.l(6); 
l7 = parms.l(7); 
l8 = parms.l(8); 
ll = sum(parms.l)+0.2;

mm = size(z,1); 
for i=1:mm 

q1 = z(i,1);
q2 = z(i,2);
q3 = z(i,3);
q4 = z(i,4);
q5 = z(i,5);
q6 = z(i,6);
q7 = z(i,7);
q8 = z(i,8);


P0 = [0 0];
P1 = [l1*sin(q1), -l1*cos(q1)]; 
P2 = [l2*sin(q1 + q2) + l1*sin(q1), - l2*cos(q1 + q2) - l1*cos(q1)]; 
P3 = [l2*sin(q1 + q2) + l1*sin(q1) + l3*sin(q1 + q2 + q3), - l2*cos(q1 + q2) - l1*cos(q1) - l3*cos(q1 + q2 + q3)]; 
P4 = [l4*sin(q1 + q2 + q3 + q4) + l2*sin(q1 + q2) + l1*sin(q1) + l3*sin(q1 + q2 + q3), - l4*cos(q1 + q2 + q3 + q4) - l2*cos(q1 + q2) - l1*cos(q1) - l3*cos(q1 + q2 + q3)]; 
P5 = [l4*sin(q1 + q2 + q3 + q4) + l2*sin(q1 + q2) + l1*sin(q1) + l5*sin(q1 + q2 + q3 + q4 + q5) + l3*sin(q1 + q2 + q3), - l4*cos(q1 + q2 + q3 + q4) - l2*cos(q1 + q2) - l1*cos(q1) - l5*cos(q1 + q2 + q3 + q4 + q5) - l3*cos(q1 + q2 + q3)]; 
P6 = [l6*sin(q1 + q2 + q3 + q4 + q5 + q6) + l4*sin(q1 + q2 + q3 + q4) + l2*sin(q1 + q2) + l1*sin(q1) + l5*sin(q1 + q2 + q3 + q4 + q5) + l3*sin(q1 + q2 + q3), - l6*cos(q1 + q2 + q3 + q4 + q5 + q6) - l4*cos(q1 + q2 + q3 + q4) - l2*cos(q1 + q2) - l1*cos(q1) - l5*cos(q1 + q2 + q3 + q4 + q5) - l3*cos(q1 + q2 + q3)]; 
P7 = [l6*sin(q1 + q2 + q3 + q4 + q5 + q6) + l4*sin(q1 + q2 + q3 + q4) + l2*sin(q1 + q2) + l1*sin(q1) + l7*sin(q1 + q2 + q3 + q4 + q5 + q6 + q7) + l5*sin(q1 + q2 + q3 + q4 + q5) + l3*sin(q1 + q2 + q3), - l6*cos(q1 + q2 + q3 + q4 + q5 + q6) - l4*cos(q1 + q2 + q3 + q4) - l2*cos(q1 + q2) - l1*cos(q1) - l7*cos(q1 + q2 + q3 + q4 + q5 + q6 + q7) - l5*cos(q1 + q2 + q3 + q4 + q5) - l3*cos(q1 + q2 + q3)]; 
P8 = [l8*sin(q1 + q2 + q3 + q4 + q5 + q6 + q7 + q8) + l6*sin(q1 + q2 + q3 + q4 + q5 + q6) + l4*sin(q1 + q2 + q3 + q4) + l2*sin(q1 + q2) + l1*sin(q1) + l7*sin(q1 + q2 + q3 + q4 + q5 + q6 + q7) + l5*sin(q1 + q2 + q3 + q4 + q5) + l3*sin(q1 + q2 + q3), - l8*cos(q1 + q2 + q3 + q4 + q5 + q6 + q7 + q8) - l6*cos(q1 + q2 + q3 + q4 + q5 + q6) - l4*cos(q1 + q2 + q3 + q4) - l2*cos(q1 + q2) - l1*cos(q1) - l7*cos(q1 + q2 + q3 + q4 + q5 + q6 + q7) - l5*cos(q1 + q2 + q3 + q4 + q5) - l3*cos(q1 + q2 + q3)]; 


plot(P0(1),P0(2),'ko','Markersize',10,'MarkerFaceColor','k');

x=[P0(1) P1(1) ];
y=[P0(2) P1(2) ];
h(1) = line(x,y,'Color','c','Linewidth',2);

x=[P1(1) P2(1) ];
y=[P1(2) P2(2) ];
h(2) = line(x,y,'Color','b','Linewidth',2);

x=[P2(1) P3(1) ];
y=[P2(2) P3(2) ];
h(3) = line(x,y,'Color','k','Linewidth',2);

x=[P3(1) P4(1) ];
y=[P3(2) P4(2) ];
h(4) = line(x,y,'Color','m','Linewidth',2);

x=[P4(1) P5(1) ];
y=[P4(2) P5(2) ];
h(5) = line(x,y,'Color','c','Linewidth',2);

x=[P5(1) P6(1) ];
y=[P5(2) P6(2) ];
h(6) = line(x,y,'Color','y','Linewidth',2);

x=[P6(1) P7(1) ];
y=[P6(2) P7(2) ];
h(7) = line(x,y,'Color','b','Linewidth',2);

x=[P7(1) P8(1) ];
y=[P7(2) P8(2) ];
h(8) = line(x,y,'Color','k','Linewidth',2);



axis('equal')
axis([-ll ll -ll ll]);
if (i==1)
    pause(1)
end

pause(0.01);

if (i~=mm)  
delete(h(1));
delete(h(2));
delete(h(3));
delete(h(4));
delete(h(5));
delete(h(6));
delete(h(7));
delete(h(8));
end
end
