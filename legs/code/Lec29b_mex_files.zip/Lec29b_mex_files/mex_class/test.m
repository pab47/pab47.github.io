clc
close all
clear all

% mex hello.c
% hello

% A = rand(3,3)
% mex manipulateMatrix.c
% manipulateMatrix(A)

A = rand(3,3);
b = rand(3,1);
%x = A*b
mex MatrixVecMult.c
x = MatrixVecMult(A,b)