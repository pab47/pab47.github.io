
#include "mex.h"

//nlhs is the number of output arguments
//plhs is the pointer to the output argument
//nrhs is the number of input arguments
//prhs is the pointer to the input argument
void mexFunction( int nlhs, mxArray *plhs[],
                  int nrhs, const mxArray *prhs[] )
{
    mwSize mrows1, ncols1;
    double *ptr_A, A[3][3]={0};
    int i,j;
    
    mrows1 = mxGetM(prhs[0]); //rows
    ncols1 = mxGetN(prhs[0]); //columns
    ptr_A = mxGetPr(prhs[0]); //actual matrix
    //printf("%d %d \n",mrows1,ncols1);
    
    for (i=0;i<mrows1;i++)
        for (j=0;j<ncols1;j++)
            A[j][i] = *(ptr_A+i*ncols1+j);
    
    for (i=0;i<mrows1;i++)
    {
        for (j=0;j<ncols1;j++)
        {
            printf("%1.14f \t",A[i][j]);
        }
        printf("\n");
    }
}
