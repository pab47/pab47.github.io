
#include "mex.h"

//nlhs is the number of output arguments
//plhs is the pointer to the output argument
//nrhs is the number of input arguments
//prhs is the pointer to the input argument
void mexFunction( int nlhs, mxArray *plhs[],
                  int nrhs, const mxArray *prhs[] )
{
    mwSize mrows1, ncols1;
    mwSize mrows2, ncols2;
    double *ptr_A, A[3][3]={0}, *b, sum, *x;
    int i,j;
    
    mrows1 = mxGetM(prhs[0]); //rows
    ncols1 = mxGetN(prhs[0]); //columns
    ptr_A = mxGetPr(prhs[0]); //actual matrix
    //printf("%d %d \n",mrows1,ncols1);
    
    mrows2 = mxGetM(prhs[1]); //rows
    ncols2 = mxGetN(prhs[1]); //columns
    b = mxGetPr(prhs[1]); //actual matrix
    
    if (ncols1 != mrows2)
        mexErrMsgTxt("number of columns of A should be equal to rows of b \n");
    
    plhs[0] = mxCreateDoubleMatrix(mrows2,ncols2,mxREAL);
    x = mxGetPr(plhs[0]);
    
    for (i=0;i<mrows1;i++)
        for (j=0;j<ncols1;j++)
            A[j][i] = *(ptr_A+i*ncols1+j);
    
    for (i=0;i<mrows1;i++)
    { 
        sum = 0.0;
        for (j=0;j<ncols1;j++)
        {
            sum = sum + A[i][j]*b[j];
        }
        
        *(x+i) = sum;
    }
    
//     for (i=0;i<mrows2;i++)
//         printf("%1.14f \n",b[i]);
    
//     for (i=0;i<mrows1;i++)
//     {
//         for (j=0;j<ncols1;j++)
//         {
//             printf("%1.14f \t",A[i][j]);
//         }
//         printf("\n");
//     }
}
