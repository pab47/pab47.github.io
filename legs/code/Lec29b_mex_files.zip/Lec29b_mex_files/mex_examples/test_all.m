clc
clear all
close all
format long

disp('test hello world');
mex hello.c
hello

disp('test matrix multiplication with vector');
mex matrixMult.c
A = rand(3,3);
b = rand(3,1);
x1=A*b;
x2=matrixMult(A,b);
x1
x2

disp('test matrix inverse multiplication with vector');
mex matrixInvMult.c
n = 3;
A = rand(n,n);
b = rand(n,1);
x1=A\b;
x2=matrixInvMult(A,b);
x1
x2