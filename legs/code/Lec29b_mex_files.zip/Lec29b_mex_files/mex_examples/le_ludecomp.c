/*
  solve a linear equation Ax = b 
  by a LU decomposition PA = LU (with partial pivoting), 
  where L is a lower triangular matrix, 
  U is a upper triangular matrix and 
  P is a permutation matrix, 
  and estimate the condition number of A 
  by Natori-Tsukamoto's method
  
  copyright : Hidenori Ogata, 6 April 2004, ver.1
                             12 April 2004, ver.1.01
  
  (revisions)
  ver.1.01: Mistakes in the comment here are corrected.
  
  (usage)
  solve_ludecomp(nmat, a, b, x);
  ... if the condition number is not needed
  solve_cond_ludecomp(nmat, a, b, x, &cond);
  ... if the condition number is needed
  
  The parameters are as follows.
  (input)
  nmat    int             : the matrix size (must be < NMAT)
  a       double [][NMAT] : the coefficient matrix
  b       double []       : the r.h.s. vector
  (output)
  x       double []       : the solution
  cond    double *        : the condition number of A
  (remark)
  After the computation, 
  the elements of L are stored in the lower triangular part of the array 
  a[i][j], i > j, and 
  the elements of U are stored in the upper triangular part of the array 
  a[i][j], i <= j. 
  
*/
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#define NMAT 100
void solve_ludecomp(int, double [][NMAT], double [], double []);
void solve_cond_ludecomp(int, double [][NMAT], double [], double [], double *);
double mat_norm(int, double [][NMAT]);
void ludecomp(int, double [][NMAT], int []);
void solve(int, double [][NMAT], double [], double [], int []);
double mat_cond(int, double [][NMAT], double, int []);

/*
  solve a linear equation Ax = b by the Gauss elimination method 
  with partial pivotting
  (input)
  nmat    int             : the matrix size (must be < NMAT)
  a       double [][NMAT] : the coefficient matrix
  b       double []       : the r.h.s. vector
  (output)
  x       double []       : the solution
  (remark)
  After the computation by the function "ludecomp", 
  the elements of L are stored in the lower triangular part of the array 
  a[i][j], i > j, and 
  the elements of U are stored in the upper triangular part of the array 
  a[i][j], i <= j. 
*/
void solve_ludecomp(int nmat, double a[][NMAT], double b[], double x[])
{
  int i, j;
  int p[NMAT];	/* index vector for partial pivotting */
  double a0[NMAT][NMAT];
  
  if (nmat >= NMAT)
    {
      printf("nmat (the matrix size)=%d\n", nmat);
      printf("nmat must be <= %d\n", NMAT-1);
      exit(0);
    }
  
  ludecomp(nmat, a, p);
  
  solve(nmat, a, b, x, p);
}
/*
  solve a linear equation Ax = b by the LU decomposition with partial pivotting 
  and estimate the condition number of A by the Natori-Tsukamoto method
  (input)
  nmat    int             : the matrix size (must be < NMAT)
  a       double [][NMAT] : the coefficient matrix
  b       double []       : the r.h.s. vector
  (output)
  x       double []       : the solution
  cond    double *        : the condition number of A
  (remark)
  After the computation by the function "ludecomp", 
  the elements of L are stored in the lower triangular part of the array 
  a[i][j], i > j, and 
  the elements of U are stored in the upper triangular part of the array 
  a[i][j], i <= j. 
*/
void solve_cond_ludecomp(int nmat, double a[][NMAT], double b[], double x[], double *cond)
{
  int i, j;
  int p[NMAT];	/* index vector for partial pivotting */
  double a0[NMAT][NMAT], anorm, ainorm;
  
  if (nmat >= NMAT)
    {
      printf("nmat (the matrix size)=%d\n", nmat);
      printf("nmat must be <= %d\n", NMAT-1);
      exit(0);
    }
  
  anorm = mat_norm(nmat, a);
  ludecomp(nmat, a, p);
  
  solve(nmat, a, b, x, p);
  
  *cond = mat_cond(nmat, a, anorm, p);
}
/*
  compute the L1-norm of the matrix A
*/
double mat_norm(int nmat, double a[][NMAT])
{
  double anorm, ajsum;
  int i, j;
  
  anorm = 0.0;
  for (j=1; j<=nmat; ++j)
    {
      ajsum = 0.0;
      for (i=1; i<=nmat; ++i)
	ajsum += fabs(a[i][j]);
      if (ajsum > anorm) anorm = ajsum;
    }
  
  return anorm;
}
/*
  LU decomposition of the matrix A
  with partial pivotting
  
  (remark)
  After the computation by the function "ludecomp", 
  the elements of L are stored in the lower triangular part of the array 
  a[p[i]][j], i > j, and 
  the elements of U are stored in the upper triangular part of the array 
  a[p[i]][j], i <= j. 
*/
void ludecomp(int nmat, double a[][NMAT], int p[])
{
  int i, j, k, k1, l, kk;
  double akmax;
  
  for (i=1; i<=nmat; ++i)
    p[i] = i;
	
  /*
    the Gauss elimination 
  */
  for (k=1; k<=nmat-1; ++k)
    {
      k1 = k + 1;
      /*
	partial pivotting
      */
      l = k;
      akmax = fabs(a[p[k]][k]);
      for (i=k1; i<=nmat; ++i)
	if (fabs(a[p[i]][k]) > akmax)
	  {
	    l = i;
	    akmax = fabs(a[p[i]][k]);
	  }
      if (l > k)
	{
	  kk = p[k];
	  p[k] = p[l];
	  p[l] = kk;
	}
      
      for (i=k1; i<=nmat; ++i)
	{
	  if (a[p[k]][k] != 0.0)
	    {
	      a[p[i]][k] /= a[p[k]][k];
	      for (j=k1; j<=nmat; ++j)
		a[p[i]][j] -= a[p[i]][k] * a[p[k]][j];
	    }
	  else
	    {
	      printf("Step %2d\n", k);
	      printf("The (%2d,%2d)-element of the matrix is zero.\n", k, k);
	      exit(0);
	    }
	}
    }
}

/*
  solve the equation Ax = b 
  by solving the simultaneous linear equations 
  Ly = Pb, Ux = y.
*/
void solve(int nmat, double a[][NMAT], double b[], double x[], int p[])
{
  double y[NMAT];
  int i, j;
  /*
    solve Ly = Pb by forward substitution
  */
  for (i=1; i<=nmat; ++i)
    {
      y[i] = b[p[i]];
      for (j=1; j<=i-1; ++j)
	y[i] -= a[p[i]][j] * y[j];
    }
  /*
    solve Ux = y by backward substitution 
  */
  for (i=nmat; i>=1; --i)
    {
      x[i] = y[i];
      for (j=nmat; j>=i+1; --j)
	x[i] -= a[p[i]][j] * x[j];
      x[i] /= a[p[i]][i];
    }
}
/*
  compute the L1-condition number of the matrix A
  by Natori-Tsukamoto's method
  (input)
  nmat   int             : the matrix size
  a      double [][NMAT] : the matrix A
  anorm  double          : the L1-norm of A
  p      int []          : the index vector used in the LU decomposition
*/
double mat_cond(int nmat, double a[][NMAT], double anorm, int p[])
{
  double y[NMAT], z[NMAT], s, gk, ainorm, yy, acond;
  int i, k;
  
  for (k=1; k<=nmat; ++k)
    {
      s = 0.0;
      for (i=1; i<=k-1; ++i)
	s += a[p[i]][k] * z[i];
      if (s >= 0.0) {
	gk = - 1.0;
      } else {
	gk = 1.0;
      }
      z[k] = (gk - s) / a[p[k]][k];
    }
  for (k=nmat; k>=1; --k)
    {
      y[p[k]] = z[k];
      for (i=nmat; i>=k+1; --i)
	y[p[k]] -= a[p[i]][k] * y[p[i]];
    }
  ainorm = 0.0;
  for (i=1; i<=nmat; ++i)
    {
      yy = fabs(y[i]);
      if (yy > ainorm)
	ainorm = yy;
    }
  
  acond = anorm * ainorm;
  return acond;
}
