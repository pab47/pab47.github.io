#include "mex.h"
#include <string.h>
#include "le_ludecomp.c"
#include "useful.c"

const int sizeA=3;

//nlhs is the number of output arguments
//plhs is the pointer to the output argument
//nrhs is the number of input arguments
//prhs is the pointer to the input argument
void mexFunction( int nlhs, mxArray *plhs[],
                  int nrhs, const mxArray *prhs[] )
{ 
  mwSize mrows1,ncols1,mrows2,ncols2;
  double *ptr_A, A[sizeA][sizeA], Ainv[sizeA][sizeA], *b, *x, sum;
  int i,j;
  
  /* Check for proper number of arguments. */
  if(nrhs!=2) 
  {
    mexErrMsgTxt("Two inputs required.");
  } 
  
  /*if(nlhs>0) 
  {
    mexErrMsgTxt("This function has no outputs");
  }*/
  
  if( !mxIsDouble(prhs[0]) || mxIsComplex(prhs[0]) ) 
  {
    mexErrMsgTxt("Input must be a noncomplex scalar double.");
  }
  
  /* Create matrix for the return argument. */
  mrows1 = mxGetM(prhs[0]);
  ncols1 = mxGetN(prhs[0]);
  ptr_A = mxGetPr(prhs[0]);
  
  mrows2 = mxGetM(prhs[1]);
  ncols2 = mxGetN(prhs[1]);
  b = mxGetPr(prhs[1]);
  
  plhs[0] = mxCreateDoubleMatrix(mrows2,ncols2, mxREAL);
  x = mxGetPr(plhs[0]);
   
  if (mrows1 != sizeA)
  {
      mexPrintf("First inputs needs to be %d x %d size matrix \n",sizeA,sizeA);
      mexErrMsgTxt("");
  }
  
  if (mrows1 != ncols1)
      mexErrMsgTxt("First inputs needs to be a square matrix");
  
  if (ncols2!=1)
      mexErrMsgTxt("Second input needs to be a column matrix");
  
  if (ncols1 != mrows2)
      mexErrMsgTxt("Columns of first input should be the same size as rows of second input");
  
  for (i=0;i<mrows1;i++)
		for (j=0;j<ncols1;j++)
			A[j][i] = *(ptr_A + i*ncols1+j); //get the transpose 
  
  inverse(mrows1,mrows1,&A[0][0],&Ainv[0][0]);
  
//    for (i=0;i<mrows1;i++)
//    {
// 		for (j=0;j<ncols1;j++)
//         {mexPrintf("%1.14f ",Ainv[i][j]);}
//         mexPrintf("\n");
//    }
    
  
//   {
//   mexPrintf("first input \n\n");
//   for (i=0;i<mrows1;i++)
//   {
//      for (j=0;j<ncols1;j++)
//      {
//          mexPrintf("%1.14f ",A[i][j]);
//      }
//      mexPrintf("\n");
//   }
//   
//   mexPrintf("second input \n\n");
//   for (i=0;i<mrows2;i++)
//     mexPrintf("%1.14f \n",b[i]);
//  


  for (i=0;i<mrows1;i++)
	{
		sum = 0.0;
		for (j=0;j<ncols1;j++)
			sum = sum + Ainv[i][j]*b[j];
		
        //mexPrintf("%1.14f \n",sum);
		*(x + i) = sum;
    }
   
}
