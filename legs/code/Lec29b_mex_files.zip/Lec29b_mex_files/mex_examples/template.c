#include "mex.h"

//nlhs is the number of output arguments
//plhs is the pointer to the output argument
//nrhs is the number of input arguments
//prhs is the pointer to the input argument
void mexFunction( int nlhs, mxArray *plhs[],
                  int nrhs, const mxArray *prhs[] )
{
    
  
}
