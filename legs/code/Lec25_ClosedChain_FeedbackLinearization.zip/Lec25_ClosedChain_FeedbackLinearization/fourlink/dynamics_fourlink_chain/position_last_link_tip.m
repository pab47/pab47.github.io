function F = position_last_link_tip(z,parms)

lx = parms.lx; ly = parms.ly;  
l1=parms.l1; l2=parms.l2; l3=parms.l3; l4=parms.l4;  

q1 = z(1);
q2 = z(2);
q3 = z(3);
q4 = z(4);


del_x = l2*sin(q1 + q2) - lx - l4*sin(q3 + q4) + l1*sin(q1) - l3*sin(q3);
del_y = l4*cos(q3 + q4) - l2*cos(q1 + q2) - ly - l1*cos(q1) + l3*cos(q3);

F = [del_x; del_y];