clc
clear all
close all

%%%%% this is used in position_kinematics.m and position_last_link_tip


%%%%% symbolic quantities
syms q1 q2 q3 q4 real
syms u1 u2 u3 u4 real
syms a1 a2 a3 a4 real
syms m1 m2 m3 m4 real
syms I1 I2 I3 I4 real
syms l1 l2 l3 l4 real
syms T1 T2 T3 T4 real
syms lx ly real
syms g real

%%%%% position vectors %%%%
H01 = homogeneous(3*pi/2 + q1,0,0);
H12 = homogeneous(q2,l1,0);
H02 = H01*H12;

H03 = homogeneous(3*pi/2 + q3,lx,ly);
H34 = homogeneous(q4,l3,0);
H04 = H03*H34;

G1 = simplify(H01*[0.5*l1 0 1]');
G2 = simplify(H02*[0.5*l2 0 1]');
G3 = simplify(H03*[0.5*l3 0 1]');
G4 = simplify(H04*[0.5*l4 0 1]');

x_G1 = G1(1); y_G1 = G1(2);
x_G2 = G2(1); y_G2 = G2(2);
x_G3 = G3(1); y_G3 = G3(2);
x_G4 = G4(1); y_G4 = G4(2);

%%%%%% end of last link is P2 and P4 (say) then position and velocity is %%%%
P2 = simplify(H02*[l2 0 1]');
P4 = simplify(H04*[l4 0 1]');
del_x = simplify(P2(1)-P4(1)); del_y = simplify(P2(2)-P4(2));
leg_length = sqrt(P2(2)^2+P2(1)^2);
leg_angle = 0.5*(q1+q3); 
disp(' ');
disp(['del_x = ', char(del_x), ';']);
disp(['del_y = ', char(del_y), ';']);
disp(['leg_length = ', char(leg_length), ';']);
disp(['leg_angle = ', char(0.5*(q1+q3)), ';']);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%