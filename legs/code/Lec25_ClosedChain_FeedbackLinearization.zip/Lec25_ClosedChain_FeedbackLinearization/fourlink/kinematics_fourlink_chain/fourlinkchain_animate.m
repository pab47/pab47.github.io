%===================================================================
function fourlinkchain_animate(t_all,z_all,parms,fps)
%===================================================================

lx = parms.lx; ly = parms.ly;

[mmm,nnn] = size(t_all);

if (mmm>1)
    %%%% Interpolate linearly using fps %%%%%
    z_all_plot = [z_all(:,1) z_all(:,3) z_all(:,5) z_all(:,7)];
    nn = size(z_all_plot,2);
    total_frames = round(t_all(end)*fps);
    t = linspace(0,t_all(end),total_frames);
    z = zeros(total_frames,nn);
    for i=1:nn
        z(:,i) = interp1(t_all,z_all_plot(:,i),t);
    end
else
    z = [z_all(:,1) z_all(:,3) z_all(:,5) z_all(:,7)];
    t = t_all;
end

%%%%% Now animate the results %%%%%%% 
l1 = parms.l1;
l2 = parms.l2;
l3 = parms.l3;
l4 = parms.l4;
ll = 1.5*(l1+l2)+0.2;

mm = size(z,1);
for i=1:mm
    
    q1 = z(i,1); 
    q2 = z(i,2);
    q3 = z(i,3);
    q4 = z(i,4);
    
    O1 = [0 0];
    P1= [l1*sin(q1) -l1*cos(q1)];
    P2 = [  (l2*sin(q1 + q2)) + l1*sin(q1)
            - (l2*cos(q1 + q2)) - l1*cos(q1)];
        
    O2 = [lx ly];
    P3 = [lx + (l3*sin(q3))
          ly - (l3*cos(q3))];
    P4 = [ lx + (l4*sin(q3 + q4)) + l3*sin(q3)
            ly - (l4*cos(q3 + q4)) - l3*cos(q3)];
       
    h1 = line([O1(1) P1(1)],[O1(2) P1(2)],'Color','r','Linewidth',2);
    h2 = line([P1(1) P2(1)],[P1(2) P2(2)],'Color','m','Linewidth',2);
    h3 = line([O2(1) P3(1)],[O2(2) P3(2)],'Color','b','Linewidth',2);
    h4 = line([P3(1) P4(1)],[P3(2) P4(2)],'Color','c','Linewidth',2);
    
    axis('equal')
    axis([-ll ll -ll ll]);
    if (i==1)
        pause(1)
    end
    
    %delay to create animation
    pause(0.01);
   
   if (i~=mm)     %delete all but not the last entry
       delete(h1);
       delete(h2);
       delete(h3);
       delete(h4);
   end
end