clc
clear all
close all

lx = 0; ly = 0;
g = 9.81;
fps = 30;

%%%%%%%% minitaur leg %%%%%%%%
%l1 = 1; l2 = 2; l3 = 1; l4 = 2;

%%%%%% atrias/digit leg %%%%%
l1 = 1; l2 = 2; l3 = 2; l4 = 1;

parms.l1 = l1; parms.l2 = l2; parms.l3 = l3; parms.l4 = l4;
parms.lx = lx; parms.ly = ly;


%%%%%%%%%% Solve for  q's %%%%
q1 = -pi/3; q2 = pi/2; q3 = 0; q4 = 0; 

%%%%% initial configuration %%%%%%
l = 0.9*(l1+l2);
alpha = -0.5;
z0 = [q1 q2 q3 q4]; 
options = optimoptions('fsolve','Display','iter','Algorithm','Levenberg-Marquardt');
[q_init,FVAL,EXITFLAG] = fsolve(@position_kinematics,z0,options,parms,l,alpha);
if (EXITFLAG ~=1)
    error('cannot solve for close chain, try new guess');
end
FVAL
q_init'

%%%%% middle configuration %%%%%%
l = 0.75*(l1+l2);
alpha = 0;
z0 = [q1 q2 q3 q4]; 
options = optimoptions('fsolve','Display','iter','Algorithm','Levenberg-Marquardt');
[q_mid,FVAL,EXITFLAG] = fsolve(@position_kinematics,z0,options,parms,l,alpha);
if (EXITFLAG ~=1)
    error('cannot solve for close chain, try new guess');
end
FVAL
q_mid'


%%%%% final configuration %%%%%%
l = 0.9*(l1+l2);
alpha = 0.5;
z0 = [q1 q2 q3 q4]; 
options = optimoptions('fsolve','Display','iter','Algorithm','Levenberg-Marquardt');
[q_final,FVAL,EXITFLAG] = fsolve(@position_kinematics,z0,options,parms,l,alpha);
if (EXITFLAG ~=1)
    error('cannot solve for close chain, try new guess');
end
FVAL
q_final'

i =1;
if (0)
%%%%%%%% animate all configurations %%%
q_temp = q_init;
q1 = q_temp(1); q2 = q_temp(2); q3 = q_temp(3); q4 = q_temp(4);
z = [q1 0 q2 0 q3 0 q4 0];
figure(i); i=i+1;
fourlinkchain_animate(0,z,parms,fps);
title('initial configuration');

q_temp = q_mid;
q1 = q_temp(1); q2 = q_temp(2); q3 = q_temp(3); q4 = q_temp(4);
z = [q1 0 q2 0 q3 0 q4 0];
figure(i); i=i+1;
fourlinkchain_animate(0,z,parms,fps);
title('mid configuration');

q_temp = q_final;
q1 = q_temp(1); q2 = q_temp(2); q3 = q_temp(3); q4 = q_temp(4);
z = [q1 0 q2 0 q3 0 q4 0];
figure(i); i=i+1;
fourlinkchain_animate(0,z,parms,fps);
title('final configuration');
end

[q_init' q_mid' q_final']

tend = 2;
dt = 0.01;
qpts1 = [q_init(1) q_mid(1) q_final(1)];
qpts3 = [q_init(3) q_mid(3) q_final(3)];
tpts = tend*[0 0.5 1];
tvec = 0:dt:tpts(end); %finer grid
[q1_ref, q1d_ref, q1dd_ref, pp1] = quinticpolytraj(qpts1, tpts, tvec);
[q3_ref, q3d_ref, q3dd_ref, pp3] = quinticpolytraj(qpts3, tpts, tvec);

%%%%%%%%%
figure(i); i=i+1;
subplot(3,1,1)
plot(tvec, q1_ref,'r'); hold on
plot(tvec, q3_ref,'b-.');
plot(tpts, qpts1, 'x');
plot(tpts, qpts3, 'o')
legend('q1','q3','q1data','q3data');
ylabel('Position')
subplot(3,1,2)
plot(tvec, q1d_ref,'r'); hold on
plot(tvec, q3d_ref,'b-.'); 
ylabel('Velocity')
subplot(3,1,3)
plot(tvec, q1dd_ref,'r'); hold on
plot(tvec, q3dd_ref,'b-.'); 
ylabel('Acceleration');
xlabel('time')

q2_ref = zeros(length(q1_ref));
q4_ref = zeros(length(q1_ref));
q2 = 0.5; q4 = -0.5;
z0 = [q2 q4];
for j=1:length(q1_ref) 
    options = optimoptions('fsolve','Display','off','Algorithm','Levenberg-Marquardt');
    [q_sol,FVAL,EXITFLAG] = fsolve(@position_last_link_tip,z0,options,parms,q1_ref(j),q3_ref(j));
    if (EXITFLAG ~=1)
        error('cannot solve for close chain, try new guess');
    end
    q2_ref(j) = q_sol(1); q4_ref(j) = q_sol(2);
    z_all(j,:) = [q1_ref(j) 0 q2_ref(j) 0 q3_ref(j) 0 q4_ref(j) 0];
end

figure(i); i=i+1;
fourlinkchain_animate(tvec,z_all,parms,fps)

figure(i); i=i+1;
subplot(2,2,1);
plot(tvec,z_all(:,1),'r'); hold on
ylabel('q1');
subplot(2,2,2);
plot(tvec,z_all(:,3),'m');
ylabel('q2');
subplot(2,2,3);
plot(tvec,z_all(:,5),'b');
ylabel('q3');
subplot(2,2,4);
plot(tvec,z_all(:,7),'c');
ylabel('q4');