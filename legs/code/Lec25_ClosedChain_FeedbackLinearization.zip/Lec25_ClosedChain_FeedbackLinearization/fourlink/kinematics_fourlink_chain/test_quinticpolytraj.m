%%%% modifed exampe code from 
clc
close all
clear all

wpts = [0 4 0];
tpts = [0 0.1 0.2];
tvec = 0:0.001:tpts(end); %finer grid
[q, qd, qdd, pp] = quinticpolytraj(wpts, tpts, tvec);
subplot(3,1,1)
plot(tvec, q)
hold all
plot(tpts, wpts, 'x')
ylabel('Position')
subplot(3,1,2)
plot(tvec, qd)
ylabel('Velocity')
subplot(3,1,3)
plot(tvec, qdd)
ylabel('Acceleration')
xlabel('t')
