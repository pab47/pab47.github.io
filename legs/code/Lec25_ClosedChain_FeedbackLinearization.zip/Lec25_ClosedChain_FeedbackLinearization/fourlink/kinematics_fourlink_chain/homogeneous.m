function H = homogeneous(theta,ax,ay)
O = [ax; ay];  
R = [cos(theta) -sin(theta); sin(theta) cos(theta)]; 
H = [R, O; 0 0 1];
H = simplify(H);