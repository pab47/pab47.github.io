function zdot = fourlinkchain_rhs(t,z,parms)

q1 = z(1); u1 = z(2); 
q2 = z(3); u2 = z(4); 
q3 = z(5); u3 = z(6); 
q4 = z(7); u4 = z(8);  

[M,C,G,J,Jdot] = fourlinkchain_dynamics(z,parms);

[T1,T3] = controller(t,z,parms); 

qdot = [u1 u3 u2 u4]; 

T = [T1; T3; 0; 0]; 

a=[M -J'; J zeros(2,2)]\[-G-C+T; -Jdot*qdot']; 

a1 = a(1); a3 = a(2); a2 = a(3); a4 = a(4); 

zdot=[u1 a1 u2 a2 u3 a3 u4 a4]';  

