function [q_init,tvec,theta1_ref, theta1dot_ref, theta1ddot_ref,...
                      theta2_ref, theta2dot_ref, theta2ddot_ref] = get_reference(parms)

tend = parms.tend;
l_init = parms.l_init;
alpha_init = parms.alpha_init;
l_mid = parms.l_mid;
alpha_mid = parms.alpha_mid;
l_final = parms.l_final;
alpha_final = parms.alpha_final;
index_theta1 = parms.index_theta1;
index_theta2 = parms.index_theta2;

dt = 0.01;


%%%%%%%%% Solve for  q's %%%%
q1 = -pi/3; q2 = pi/2; q3 = 0; q4 = 0; 

%%%%% initial configuration %%%%%%

z0 = [q1 q2 q3 q4]; 
options = optimoptions('fsolve','Display','off','Algorithm','Levenberg-Marquardt');
[q_init,FVAL,EXITFLAG] = fsolve(@position_kinematics,z0,options,parms,l_init,alpha_init);
if (EXITFLAG ~=1)
    error('cannot solve for close chain, try new guess');
end
FVAL
q_init'

%%%%% middle configuration %%%%%%

z0 = [q1 q2 q3 q4]; 
options = optimoptions('fsolve','Display','off','Algorithm','Levenberg-Marquardt');
[q_mid,FVAL,EXITFLAG] = fsolve(@position_kinematics,z0,options,parms,l_mid,alpha_mid);
if (EXITFLAG ~=1)
    error('cannot solve for close chain, try new guess');
end
FVAL
q_mid'


%%%%% final configuration %%%%%%

z0 = [q1 q2 q3 q4]; 
options = optimoptions('fsolve','Display','off','Algorithm','Levenberg-Marquardt');
[q_final,FVAL,EXITFLAG] = fsolve(@position_kinematics,z0,options,parms,l_final,alpha_final);
if (EXITFLAG ~=1)
    error('cannot solve for close chain, try new guess');
end
FVAL
q_final'

theta1pts = [q_init(index_theta1) q_mid(index_theta1) q_final(index_theta1)];
theta2pts = [q_init(index_theta2) q_mid(index_theta2) q_final(index_theta2)];
tpts = tend*[0 0.5 1];
tvec = 0:dt:tpts(end); %finer grid
[theta1_ref, theta1dot_ref, theta1ddot_ref, pp1] = quinticpolytraj(theta1pts, tpts, tvec);
[theta2_ref, theta2dot_ref, theta2ddot_ref, pp2] = quinticpolytraj(theta2pts, tpts, tvec);

