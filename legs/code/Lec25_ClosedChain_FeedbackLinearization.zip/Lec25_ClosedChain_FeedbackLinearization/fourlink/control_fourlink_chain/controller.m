function [T1,T2] = controller(t,z,parms)

leg = parms.leg;

q1 = z(1); u1 = z(2); 
q2 = z(3); u2 = z(4); 
q3 = z(5); u3 = z(6); 
q4 = z(7); u4 = z(8); 

Kp1 = parms.control.Kp1;
Kd1 = parms.control.Kd1;
Kp2 = parms.control.Kp2;
Kd2 = parms.control.Kd2;


[M,C,G,J,Jdot] = fourlinkchain_dynamics(z,parms);


%%%% atrias and minitaur
if (strcmp(leg,'minitaur') || strcmp(leg,'atrias'))
    qdot = [u1 u3 u2 u4];
    theta = [q1 q3]';
    thetadot = [u1 u3]';
end

%%%% digit %%%
if (strcmp(leg,'digit'))
    qdot = [u1 u4 u2 u3];
    theta = [q1 q4]';
    thetadot = [u1 u4]';
end

AA = [M -J'; J zeros(2,2)];
bb = [-G-C; -Jdot*qdot']; 

theta1_ref = interp1(parms.t,parms.control.theta1_ref,t);
theta1dot_ref = interp1(parms.t,parms.control.theta1dot_ref,t);
theta1ddot_ref = interp1(parms.t,parms.control.theta1ddot_ref,t);

theta2_ref = interp1(parms.t,parms.control.theta2_ref,t);
theta2dot_ref = interp1(parms.t,parms.control.theta2dot_ref,t);
theta2ddot_ref = interp1(parms.t,parms.control.theta2ddot_ref,t);

%the controller
theta_ref = [theta1_ref theta2_ref]';
thetadot_ref = [theta1dot_ref theta2dot_ref]';

thetaddot_ref = [theta1ddot_ref theta2ddot_ref]';

Kp = [Kp1 0; 0 Kp2];
Kd = [Kd1 0; 0 Kd2];

A11 = AA(1:2,1:2);
A21 = AA(3:end,1:2);
A12 = AA(1:2,3:end);
A22 = AA(3:end,3:end);
b1 = bb(1:2);
b2 = bb(3:end);

invA22 = A22\eye(length(A22));
Atil = A11-A12*invA22*A21;
btil = b1-A12*invA22*b2;

T = Atil*(thetaddot_ref-Kp*(theta-theta_ref)-Kd*(thetadot-thetadot_ref))-btil;%feedback linearization

T1 = T(1);
T2 = T(2);
