function F = velocity_last_link_tip(z,parms)

%lx = parms.lx; ly = parms.ly;  
l1=parms.l1; l2=parms.l2; l3=parms.l3; l4=parms.l4;  


q1 = parms.q_all(1);
q2 = parms.q_all(2);
q3 = parms.q_all(3);
q4 = parms.q_all(4);

u1 = z(1);
u2 = z(2);
u3 = z(3);
u4 = z(4);

del_vx = u1*(l2*cos(q1 + q2) + l1*cos(q1)) - u3*(l4*cos(q3 + q4) + l3*cos(q3)) + l2*u2*cos(q1 + q2) - l4*u4*cos(q3 + q4);
del_vy = u1*(l2*sin(q1 + q2) + l1*sin(q1)) - u3*(l4*sin(q3 + q4) + l3*sin(q3)) + l2*u2*sin(q1 + q2) - l4*u4*sin(q3 + q4);

F = [del_vx; del_vy];