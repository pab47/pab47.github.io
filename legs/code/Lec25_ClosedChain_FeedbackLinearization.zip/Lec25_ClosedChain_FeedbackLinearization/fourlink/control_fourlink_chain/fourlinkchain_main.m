clc
clear all
close all

%choose the leg 
leg = 'atrias'; 
%leg = 'minitaur';
%leg = 'digit';
parms.leg = leg;

derive_fourlinkchain; %derive equation based on the leg considered.     
                      %the equation need to be rearranged to help with the
                      %controller design. Specifically, the actuated dofs
                      %are made as the first two dofs.


%%%%%%%%%% leg parameters %%%%%
m1 = 1; m2 = 1; m3 = 1; m4 = 1;
I1 = 0.1; I2 = 0.1; I3 = 0.1; I4 = 0.1;
lx = 0; ly = 0;
g = 9.81;
fps = 200;


%%%%% minitaur leg parameters %%%%
if (strcmp(leg,'minitaur'))
     l1 = 1; l2 = 2; l3 = 1; l4 = 2;
end

%%%%% atrias and digit parameters %%%%
if (strcmp(leg,'atrias') || strcmp(leg,'digit'))
    l1 = 1; l2 = 2; l3 = 2; l4 = 1;
end


%%% trajectory parameters %%%%%
parms.tend = 1;
parms.l_init = 0.9*(l1+l2); %init leg length
parms.alpha_init = -0.5; %init absolute angle with horizontal
parms.l_mid = 0.6*(l1+l2); %mid leg length
parms.alpha_mid = 0; %mid absolute angle with horizontal
parms.l_final = 0.9*(l1+l2); %final leg length
parms.alpha_final = 0.5; %final absolute angle with horizontal
%%%%%%%%%%%%

%%%% atrias and minitaur
if (strcmp(leg,'minitaur') || strcmp(leg,'atrias'))
    index_state_theta1 = 1; index_state_theta1dot = 2; %index in 8d state space, [q1 u1 q2 u2 q3 u3 q4 u4]
    index_state_theta2 = 5; index_state_theta2dot = 6;
    index_theta1 = 1; index_theta2 = 3; %index in 4d q's, [q1 q2 q3 q4]
end

%%%% digit %%%
if (strcmp(leg,'digit'))
    index_state_theta1 = 1; index_state_theta1dot = 2;%index in 8d state space, [q1 u1 q2 u2 q3 u3 q4 u4]
    index_state_theta2 = 7; index_state_theta2dot = 8;
    index_theta1 = 1; index_theta2 = 4; %index in 4d q's, [q1 q2 q3 q4]
end
parms.index_theta1 = index_theta1;
parms.index_theta2 = index_theta2;




parms.m1 = m1; parms.m2 = m2; parms.m3 = m3; parms.m4 = m4;
parms.I1 = I1; parms.I2 = I2; parms.I3 = I3; parms.I4 = I4;
parms.l1 = l1; parms.l2 = l2; parms.l3 = l3; parms.l4 = l4;
parms.g = g; parms.lx = lx; parms.ly = ly;

parms.control.Kp1 = 0*100;
parms.control.Kd1 = 2*sqrt(parms.control.Kp1); %0.1*parms.control.Kp1;
parms.control.Kp2 = 0*100;
parms.control.Kd2 = 2*sqrt(parms.control.Kp2); %0.1*parms.control.Kp2;

[q_init,t_ref,theta1_ref, theta1d_ref, theta1dd_ref,theta2_ref, theta2d_ref, theta2dd_ref] = get_reference(parms);

parms.t = t_ref;
parms.control.theta1_ref = theta1_ref;
parms.control.theta1dot_ref = theta1d_ref;
parms.control.theta1ddot_ref = theta1dd_ref;
parms.control.theta2_ref = theta2_ref;
parms.control.theta2dot_ref = theta2d_ref;
parms.control.theta2ddot_ref = theta2dd_ref;


%%%%%%%%% Now use ode45 to do simulation %%%%%%
q1 = q_init(1); q2 = q_init(2); q3 = q_init(3); q4 = q_init(4);
u1 = 0; u2 = 0; u3 = 0; u4 = 0;
z0 = [q1 u1 q2 u2 q3 u3 q4 u4];
total_time = t_ref(end);
t = linspace(0,total_time,100*total_time); %time values
options = odeset('Abstol',1e-9,'Reltol',1e-9);
[t, z] = ode45(@fourlinkchain_rhs,t,z0,options,parms); %integrate using ode45


%%%%%% plots and animate %%%%%%%
figure(1)
fourlinkchain_animate(t,z,parms,fps);

figure(2)
subplot(2,1,1)
plot(t,z(:,1),'r','Linewidth',2); hold on
plot(t,z(:,3),'m','Linewidth',2);
plot(t,z(:,5),'b','Linewidth',2);
plot(t,z(:,7),'c','Linewidth',2);
ylabel('position','Fontsize',12);
title('Pendulum position and velocity as a function of time','Fontsize',12);
legend('\theta_1','\theta_2','\theta_3','\theta_4','Location','best','Fontsize',12);
subplot(2,1,2)
plot(t,z(:,2),'r','Linewidth',2); hold on
plot(t,z(:,4),'m','Linewidth',2);
plot(t,z(:,6),'b','Linewidth',2);
plot(t,z(:,8),'c','Linewidth',2);
ylabel('velocity','Fontsize',12);
xlabel('time','Fontsize',12);

figure(3)
subplot(2,1,1)
plot(t_ref,theta1_ref,'k-.','Linewidth',2); hold on
plot(t,z(:,index_state_theta1),'r','Linewidth',1); 
plot(t_ref,theta2_ref,'k-.','Linewidth',2);
plot(t,z(:,index_state_theta2),'b','Linewidth',1); 
legend('theta1-ref','theta1','theta2-ref','theta2');
ylabel('angle')
subplot(2,1,2)
plot(t_ref,theta1d_ref,'k-.','Linewidth',2); hold on
plot(t,z(:,index_state_theta1dot),'r','Linewidth',1); 
plot(t_ref,theta2d_ref,'k-.','Linewidth',2);
plot(t,z(:,index_state_theta2dot),'b','Linewidth',1); 
ylabel('velocity')
legend('theta1dot-ref','theta1dot','theta2dot-ref','theta2dot');
xlabel('time');

