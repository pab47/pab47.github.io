function zdot = two_doublependulum_rhs(t,z,parms)

g = parms.g; lx = parms.lx; ly = parms.ly;  

m1=parms.m1; m2=parms.m2; m3=parms.m3; m4=parms.m4;  

I1=parms.I1; I2=parms.I2; I3=parms.I3; I4=parms.I4;  

l1=parms.l1; l2=parms.l2; l3=parms.l3; l4=parms.l4;  

q1 = z(1); u1 = z(2); 
q2 = z(3); u2 = z(4); 
q3 = z(5); u3 = z(6); 
q4 = z(7); u4 = z(8); 
;

M(1,1)=I1 + I2 + (m2*(2*((l2*cos(q1 + q2))/2 + l1*cos(q1))^2 + 2*((l2*sin(q1 + q2))/2 + l1*sin(q1))^2))/2 + (m1*((l1^2*cos(q1)^2)/2 + (l1^2*sin(q1)^2)/2))/2;

M(1,2)=I2 + (m2*(l2*sin(q1 + q2)*((l2*sin(q1 + q2))/2 + l1*sin(q1)) + l2*cos(q1 + q2)*((l2*cos(q1 + q2))/2 + l1*cos(q1))))/2;

M(1,3)=0;

M(1,4)=0;

M(2,1)=I2 + (m2*(l2*sin(q1 + q2)*((l2*sin(q1 + q2))/2 + l1*sin(q1)) + l2*cos(q1 + q2)*((l2*cos(q1 + q2))/2 + l1*cos(q1))))/2;

M(2,2)=I2 + (m2*((l2^2*cos(q1 + q2)^2)/2 + (l2^2*sin(q1 + q2)^2)/2))/2;

M(2,3)=0;

M(2,4)=0;

M(3,1)=0;

M(3,2)=0;

M(3,3)=I3 + I4 + (m4*(2*((l4*cos(q3 + q4))/2 + l3*cos(q3))^2 + 2*((l4*sin(q3 + q4))/2 + l3*sin(q3))^2))/2 + (m3*((l3^2*cos(q3)^2)/2 + (l3^2*sin(q3)^2)/2))/2;

M(3,4)=I4 + (m4*(l4*sin(q3 + q4)*((l4*sin(q3 + q4))/2 + l3*sin(q3)) + l4*cos(q3 + q4)*((l4*cos(q3 + q4))/2 + l3*cos(q3))))/2;

M(4,1)=0;

M(4,2)=0;

M(4,3)=I4 + (m4*(l4*sin(q3 + q4)*((l4*sin(q3 + q4))/2 + l3*sin(q3)) + l4*cos(q3 + q4)*((l4*cos(q3 + q4))/2 + l3*cos(q3))))/2;

M(4,4)=I4 + (m4*((l4^2*cos(q3 + q4)^2)/2 + (l4^2*sin(q3 + q4)^2)/2))/2;

C(1,1)=(m2*u2*(2*((l2*u1*cos(q1 + q2))/2 + (l2*u2*cos(q1 + q2))/2)*((l2*sin(q1 + q2))/2 + l1*sin(q1)) - 2*((l2*u1*sin(q1 + q2))/2 + (l2*u2*sin(q1 + q2))/2)*((l2*cos(q1 + q2))/2 + l1*cos(q1)) - l2*sin(q1 + q2)*(u1*((l2*cos(q1 + q2))/2 + l1*cos(q1)) + (l2*u2*cos(q1 + q2))/2) + l2*cos(q1 + q2)*(u1*((l2*sin(q1 + q2))/2 + l1*sin(q1)) + (l2*u2*sin(q1 + q2))/2)))/2;

C(2,1)=(m2*(2*((l2*u1*sin(q1 + q2))/2 + (l2*u2*sin(q1 + q2))/2)*(u1*((l2*cos(q1 + q2))/2 + l1*cos(q1)) + (l2*u2*cos(q1 + q2))/2) - 2*((l2*u1*cos(q1 + q2))/2 + (l2*u2*cos(q1 + q2))/2)*(u1*((l2*sin(q1 + q2))/2 + l1*sin(q1)) + (l2*u2*sin(q1 + q2))/2)))/2 - (m2*u2*(l2*sin(q1 + q2)*(u1*((l2*cos(q1 + q2))/2 + l1*cos(q1)) + (l2*u2*cos(q1 + q2))/2) - l2*cos(q1 + q2)*(u1*((l2*sin(q1 + q2))/2 + l1*sin(q1)) + (l2*u2*sin(q1 + q2))/2) - l2*sin(q1 + q2)*((l2*u1*cos(q1 + q2))/2 + (l2*u2*cos(q1 + q2))/2) + l2*cos(q1 + q2)*((l2*u1*sin(q1 + q2))/2 + (l2*u2*sin(q1 + q2))/2)))/2;

C(3,1)=(m4*u4*(2*((l4*u3*cos(q3 + q4))/2 + (l4*u4*cos(q3 + q4))/2)*((l4*sin(q3 + q4))/2 + l3*sin(q3)) - 2*((l4*u3*sin(q3 + q4))/2 + (l4*u4*sin(q3 + q4))/2)*((l4*cos(q3 + q4))/2 + l3*cos(q3)) - l4*sin(q3 + q4)*(u3*((l4*cos(q3 + q4))/2 + l3*cos(q3)) + (l4*u4*cos(q3 + q4))/2) + l4*cos(q3 + q4)*(u3*((l4*sin(q3 + q4))/2 + l3*sin(q3)) + (l4*u4*sin(q3 + q4))/2)))/2;

C(4,1)=(m4*(2*((l4*u3*sin(q3 + q4))/2 + (l4*u4*sin(q3 + q4))/2)*(u3*((l4*cos(q3 + q4))/2 + l3*cos(q3)) + (l4*u4*cos(q3 + q4))/2) - 2*((l4*u3*cos(q3 + q4))/2 + (l4*u4*cos(q3 + q4))/2)*(u3*((l4*sin(q3 + q4))/2 + l3*sin(q3)) + (l4*u4*sin(q3 + q4))/2)))/2 - (m4*u4*(l4*sin(q3 + q4)*(u3*((l4*cos(q3 + q4))/2 + l3*cos(q3)) + (l4*u4*cos(q3 + q4))/2) - l4*cos(q3 + q4)*(u3*((l4*sin(q3 + q4))/2 + l3*sin(q3)) + (l4*u4*sin(q3 + q4))/2) - l4*sin(q3 + q4)*((l4*u3*cos(q3 + q4))/2 + (l4*u4*cos(q3 + q4))/2) + l4*cos(q3 + q4)*((l4*u3*sin(q3 + q4))/2 + (l4*u4*sin(q3 + q4))/2)))/2;

G(1,1)=g*m2*((l2*sin(q1 + q2))/2 + l1*sin(q1)) + (g*l1*m1*sin(q1))/2;

G(2,1)=(g*l2*m2*sin(q1 + q2))/2;

G(3,1)=g*m4*((l4*sin(q3 + q4))/2 + l3*sin(q3)) + (g*l3*m3*sin(q3))/2;

G(4,1)=(g*l4*m4*sin(q3 + q4))/2;

a=M\(-G-C); 

a1 = a(1); a2 = a(2); a3 = a(3); a4 = a(4); 

zdot=[u1 a1 u2 a2 u3 a3 u4 a4]';  

