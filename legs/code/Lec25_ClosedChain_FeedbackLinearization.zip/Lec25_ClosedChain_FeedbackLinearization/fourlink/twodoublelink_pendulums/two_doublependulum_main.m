clc
clear all
close all

m1 = 1; m2 = 1; m3 = 1; m4 = 1;
l1 = 1; l2 = 1; l3 = 1; l4 = 1;
I1 = 0.1; I2 = 0.1; I3 = 0.1; I4 = 0.1;
lx = 2; ly = 0;
g = 9.81;
fps = 30;

parms.m1 = m1; parms.m2 = m2; parms.m3 = m3; parms.m4 = m4;
parms.I1 = I1; parms.I2 = I2; parms.I3 = I3; parms.I4 = I4;
parms.l1 = l1; parms.l2 = l2; parms.l3 = l3; parms.l4 = l4;
parms.g = g; parms.lx = 2; parms.ly = 0;

total_time = 20;
t = linspace(0,total_time,100*total_time); %time values
z0 = [pi/2+0.01 0 0 0 pi/2 0 0 0];
options = odeset('Abstol',1e-12,'Reltol',1e-12);
[t, z] = ode45(@two_doublependulum_rhs,t,z0,options,parms); %integrate using ode45

figure(1)
two_doublependulum_animate(t,z,parms,fps);

figure(2)
subplot(2,1,1)
plot(t,z(:,1),'r','Linewidth',2); hold on
plot(t,z(:,3),'m','Linewidth',2);
plot(t,z(:,5),'b','Linewidth',2);
plot(t,z(:,7),'c','Linewidth',2);
ylabel('position','Fontsize',12);
title('Pendulum position and velocity as a function of time','Fontsize',12);
legend('\theta_1','\theta_2','\theta_3','\theta_4','Location','best','Fontsize',12);
subplot(2,1,2)
plot(t,z(:,2),'r','Linewidth',2); hold on
plot(t,z(:,4),'m','Linewidth',2);
plot(t,z(:,6),'b','Linewidth',2);
plot(t,z(:,8),'c','Linewidth',2);
ylabel('velocity','Fontsize',12);
xlabel('time','Fontsize',12);
