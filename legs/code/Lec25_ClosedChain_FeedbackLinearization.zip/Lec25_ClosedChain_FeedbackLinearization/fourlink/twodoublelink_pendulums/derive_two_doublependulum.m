%function derive_fivelink

clc
clear all
close all

%%%%% symbolic quantities
syms q1 q2 q3 q4 real
syms u1 u2 u3 u4 real
syms a1 a2 a3 a4 real
syms m1 m2 m3 m4 real
syms I1 I2 I3 I4 real
syms l1 l2 l3 l4 real
syms lx ly real
syms g real

q = [q1 q2 q3 q4];
qdot = [u1 u2 u3 u4];
qddot = [a1 a2 a3 a4];

%%%%% position vectors %%%%
H01 = homogeneous(3*pi/2 + q1,0,0);
H12 = homogeneous(q2,l1,0);
H02 = H01*H12;

H03 = homogeneous(3*pi/2 + q3,lx,ly);
H34 = homogeneous(q4,l3,0);
H04 = H03*H34;

G1 = simplify(H01*[0.5*l1 0 1]');
G2 = simplify(H02*[0.5*l2 0 1]');
G3 = simplify(H03*[0.5*l3 0 1]');
G4 = simplify(H04*[0.5*l4 0 1]');

x_G1 = G1(1); y_G1 = G1(2);
x_G2 = G2(1); y_G2 = G2(2);
x_G3 = G3(1); y_G3 = G3(2);
x_G4 = G4(1); y_G4 = G4(2);

hi
%%%%% velocity vectors %%%%%%
v_G1 = [jacobian(x_G1,q)*qdot'; jacobian(y_G1,q)*qdot']; 
v_G2 = [jacobian(x_G2,q)*qdot'; jacobian(y_G2,q)*qdot'];
v_G3 = [jacobian(x_G3,q)*qdot'; jacobian(y_G3,q)*qdot']; 
v_G4 = [jacobian(x_G4,q)*qdot'; jacobian(y_G4,q)*qdot'];

 om1 = u1;
 om2 = om1 + u2;
 om3 = u3;
 om4 = om3 + u4;

%%%% lagrangian %%
T = 0.5*m1*(v_G1'*v_G1) + ...
    0.5*m2*(v_G2'*v_G2) + ...
    0.5*m3*(v_G3'*v_G3) + ...
    0.5*m4*(v_G4'*v_G4) + ...
    0.5*I1*om1^2 + ...
    0.5*I2*om2^2 + ... 
    0.5*I3*om3^2 + ...
    0.5*I4*om4^2;

V = m1*g*y_G1 + m2*g*y_G2 + m3*g*y_G3 + m4*g*y_G4;
L = T-V;

nn = 4;
for ii=1:nn
    dLdqdot(ii) = diff(L,qdot(ii));
    sum = 0;
    for j=1:nn
        sum = sum +diff(dLdqdot(ii),q(j))*qdot(j) + diff(dLdqdot(ii),qdot(j))*qddot(j);
     end
    ddt_dLdqdot(ii) = sum;
    dLdq(ii) = diff(L,q(ii));

    EOM(ii) = ddt_dLdqdot(ii) - dLdq(ii);
    disp(['EOM (i = ',num2str(ii),') done']);
end

%%%%%%%%% collecting equations as A a = b
M = jacobian(EOM,qddot(1:nn));
disp('M done')
for i=1:nn
    N(i,1) = subs(EOM(i),qddot(1:nn),zeros(1,nn));
    G(i,1) = subs(N(i,1),qdot(1:nn),zeros(1,nn));
    C(i,1) = N(i,1) - G(i,1);
end
disp('N, G, C done');

disp('Generating rhs file');


fid=fopen( 'two_doublependulum_rhs.m','w');

fprintf(fid, 'function zdot = two_doublependulum_rhs(t,z,parms)\n\n');

fprintf(fid, 'g = parms.g; lx = parms.lx; ly = parms.ly;  \n\n');
fprintf(fid, 'm1=parms.m1; m2=parms.m2; m3=parms.m3; m4=parms.m4;  \n\n');
fprintf(fid, 'I1=parms.I1; I2=parms.I2; I3=parms.I3; I4=parms.I4;  \n\n');
fprintf(fid, 'l1=parms.l1; l2=parms.l2; l3=parms.l3; l4=parms.l4;  \n\n');

fprintf(fid, 'q1 = z(1); u1 = z(2); \n');
fprintf(fid, 'q2 = z(3); u2 = z(4); \n');
fprintf(fid, 'q3 = z(5); u3 = z(6); \n');
fprintf(fid, 'q4 = z(7); u4 = z(8); \n');

fprintf(fid,'\n\n');
for i=1:nn
    for j=1:nn
        fprintf(fid,['M(',num2str(i),',',num2str(j),')=',char(M(i,j)), ';\n\n']);
    end
end

for i=1:nn
    fprintf(fid,['C(',num2str(i),',1)=',char(C(i,1)), ';\n\n']);
end

for i=1:nn
    fprintf(fid,['G(',num2str(i),',1)=',char(G(i,1)), ';\n\n']);
end

fprintf(fid, 'a=M\\(-G-C); \n\n');
fprintf(fid, 'a1 = a(1); a2 = a(2); a3 = a(3); a4 = a(4); \n\n');
fprintf(fid, 'zdot=[u1 a1 u2 a2 u3 a3 u4 a4]'';  \n\n');

fclose(fid);

