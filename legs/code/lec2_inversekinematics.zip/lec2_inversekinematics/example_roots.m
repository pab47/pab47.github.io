function example_roots
clc %clear screen
close all %closes figures 

x = linspace(-6,6);
for i=1:length(x)
    f(i) = fn(x(i));
end
plot(x,f,'Linewidth',2); %plot the function to get idea of the roots
title('f(x) = x^2 - x - 2');
xlabel('x','fontsize',12);
ylabel('f(x)','fontsize',12);
grid on;

%%% solving the equation %%
x0 = -2; %Try different initial guesses, e.g., 3, -3, 0
options = optimoptions('fsolve','Display','iter','MaxIter',100,'MaxFunEval',300);
[x,fval,exitflag] = fsolve(@fn,x0,options);

%options = optimset('Display','iter');
%X = fzero(@fn,x0,options) 
fval
exitflag

function f = fn(x)
f = x^2 - x - 2;

