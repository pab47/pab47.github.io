%function derive_fivelink

clc
clear all
close all

%%%%% symbolic quantities
syms q1 q2 q3 q4 q5 q6 q7 q8 q9 q10 real
syms u1 u2 u3 u4 u5 u6 u7 u8 u9 u10 real
syms a1 a2 a3 a4 a5 a6 a7 a8 a9 a10 real
syms m I g c l lx ly real
%lx and ly are attachment points wrt to origin link

c = 0.5*l;

m1 = m; m2 = m; m3 = m; m4 = m; m5 = m; 
I1 = I; I2 = I; I3 = I; I4 = I; I5 = I; 
c1 = c; c2 = c; c3 = c; c4 = c; c5 = c; 
nn = 5;

q = [q1 q2 q3 q4 q5];
qdot = [u1 u2 u3 u4 u5];
qddot = [a1 a2 a3 a4 a5];



%%%%% position vectors %%%%
H01 = homogeneous(3*pi/2 + q1,0);
H12 = homogeneous(q2,l);
H23 = homogeneous(q3,l);
H34 = homogeneous(q4,l);
H45 = homogeneous(q5,l);

H02 = H01*H12;
H03 = H02*H23;
H04 = H03*H34;
H05 = H04*H45;

G1 = simplify(H01*[c1 0 1]');
G2 = simplify(H02*[c2 0 1]');
G3 = simplify(H03*[c3 0 1]');
G4 = simplify(H04*[c4 0 1]');
G5 = simplify(H05*[c5 0 1]');


x_G1 = G1(1); y_G1 = G1(2);
x_G2 = G2(1); y_G2 = G2(2);
x_G3 = G3(1); y_G3 = G3(2);
x_G4 = G4(1); y_G4 = G4(2);
x_G5 = G5(1); y_G5 = G5(2);


%%%%% velocity vectors %%%%%%
v_G1 = [jacobian(x_G1,q)*qdot'; jacobian(y_G1,q)*qdot']; 
v_G2 = [jacobian(x_G2,q)*qdot'; jacobian(y_G2,q)*qdot'];
v_G3 = [jacobian(x_G3,q)*qdot'; jacobian(y_G3,q)*qdot']; 
v_G4 = [jacobian(x_G4,q)*qdot'; jacobian(y_G4,q)*qdot'];
v_G5 = [jacobian(x_G5,q)*qdot'; jacobian(y_G5,q)*qdot'];

%%%%%% end of last link is P (say) then position and velocity is %%%%
P = H05*[l 0 1]'; %P Is B in the notes
x_P = simplify(P(1)); y_P = simplify(P(2));
disp(' ');
disp(['x_P = ', char(x_P), ';']);
disp(['y_P = ', char(y_P), ';']);
v_P = [jacobian(x_P,q)*qdot'; jacobian(y_P,q)*qdot'];
disp(' ');
disp(['vx_P = ', char(simplify(v_P(1,1))), ';']);
disp(['vy_P = ', char(simplify(v_P(2,1))), ';']);

 om1 = u1;
 om2 = om1 + u2;
 om3 = om2 + u3;
 om4 = om3 + u4;
 om5 = om4 + u5;

%%%% lagrangian %%
T = 0.5*m1*(v_G1'*v_G1) + ...
    0.5*m2*(v_G2'*v_G2) + ...
    0.5*m3*(v_G3'*v_G3) + ...
    0.5*m4*(v_G4'*v_G4) + ...
    0.5*m5*(v_G5'*v_G5) + ...
    0.5*I1*om1^2 + ...
    0.5*I2*om2^2 + ... 
    0.5*I3*om3^2 + ...
    0.5*I4*om4^2 + ...
    0.5*I5*om5^2;

V = m1*g*y_G1 + m2*g*y_G2 + m3*g*y_G3 + m4*g*y_G4  + m5*g*y_G5;
L = T-V;

for ii=1:nn
    dLdqdot(ii) = diff(L,qdot(ii));
    sum = 0;
    for j=1:nn
        sum = sum +diff(dLdqdot(ii),q(j))*qdot(j) + diff(dLdqdot(ii),qdot(j))*qddot(j);
     end
    ddt_dLdqdot(ii) = sum;
    dLdq(ii) = diff(L,q(ii));

    EOM(ii) = ddt_dLdqdot(ii) - dLdq(ii);
    disp(['EOM (i = ',num2str(ii),') done']);
end

%%%%%%%%% collecting equations as A a = b
M = jacobian(EOM,qddot(1:nn));
disp('M done')
for i=1:nn
    N(i,1) = subs(EOM(i),qddot(1:nn),zeros(1,nn));
    G(i,1) = subs(N(i,1),qdot(1:nn),zeros(1,nn));
    C(i,1) = N(i,1) - G(i,1);
end
disp('N, G, C done');

%%%%%%% contact condition %%%%
J = jacobian([x_P y_P],q);
for i=1:2
    for j=1:nn
        Jdot(i,j) = jacobian(J(i,j),q)*qdot';
    end
end

disp('Generating rhs file');


fid=fopen( 'fivelinkchain_rhs.m','w');

fprintf(fid, 'function zdot = fivelinkchain_rhs(t,z,parms)\n\n');

fprintf(fid, 'm=parms.m; I = parms.I; g = parms.g; l = parms.l;  \n\n');
fprintf(fid, 'q1 = z(1); u1 = z(2); \n');
fprintf(fid, 'q2 = z(3); u2 = z(4); \n');
fprintf(fid, 'q3 = z(5); u3 = z(6); \n');
fprintf(fid, 'q4 = z(7); u4 = z(8); \n');
fprintf(fid, 'q5 = z(9); u5 = z(10); \n\n');



for i=1:nn
    for j=1:nn
        fprintf(fid,['M(',num2str(i),',',num2str(j),')=',char(M(i,j)), ';\n\n']);
    end
end

for i=1:nn
    fprintf(fid,['C(',num2str(i),',1)=',char(C(i,1)), ';\n\n']);
end

for i=1:nn
    fprintf(fid,['G(',num2str(i),',1)=',char(G(i,1)), ';\n\n']);
end

for i=1:2
    for j=1:nn
        fprintf(fid,['J(',num2str(i),',',num2str(j),')=',char(J(i,j)), ';\n\n']);
    end
end

for i=1:2
    for j=1:nn
        fprintf(fid,['Jdot(',num2str(i),',',num2str(j),')=',char(Jdot(i,j)), ';\n\n']);
    end
end

fprintf(fid,'qdot = [u1 u2 u3 u4 u5]; \n\n');
fprintf(fid, 'a=[M -J''; J zeros(2,2)]\\[-G-C; -Jdot*qdot'']; \n\n');
fprintf(fid, 'a1 = a(1); a2 = a(2); a3 = a(3); a4 = a(4); a5 = a(5); \n\n');
fprintf(fid, 'zdot=[u1 a1 u2 a2 u3 a3 u4 a4 u5 a5]'';  \n\n');

fclose(fid);

