function F = position_last_link_tip(z,parms)
l = parms.l;
lx = parms.lx; ly = parms.ly;


q1 = z(1);
q2 = z(2);
q3 = z(3);
q4 = z(4);
q5 = z(5);

x_P = l*(sin(q1 + q2 + q3 + q4 + q5) + sin(q1 + q2 + q3) + sin(q1 + q2 + q3 + q4) + sin(q1 + q2) + sin(q1));
y_P = -l*(cos(q1 + q2 + q3) + cos(q1 + q2 + q3 + q4) + cos(q1 + q2) + cos(q1) + cos(q1 + q2 + q3 + q4 + q5));

F = [x_P-lx; y_P-ly];