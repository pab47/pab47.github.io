function F = velocity_last_link_tip(z,parms)
l = parms.l;

q1 = parms.q_all(1);
q2 = parms.q_all(2);
q3 = parms.q_all(3);
q4 = parms.q_all(4);
q5 = parms.q_all(5);

u1 = z(1);
u2 = z(2);
u3 = z(3);
u4 = z(4);
u5 = z(5);

vx_P = l*u4*(cos(q1 + q2 + q3 + q4) + cos(q1 + q2 + q3 + q4 + q5)) + l*u3*(cos(q1 + q2 + q3) + cos(q1 + q2 + q3 + q4) + cos(q1 + q2 + q3 + q4 + q5)) + l*u5*cos(q1 + q2 + q3 + q4 + q5) + l*u1*(cos(q1 + q2 + q3) + cos(q1 + q2 + q3 + q4) + cos(q1 + q2) + cos(q1) + cos(q1 + q2 + q3 + q4 + q5)) + l*u2*(cos(q1 + q2 + q3) + cos(q1 + q2 + q3 + q4) + cos(q1 + q2) + cos(q1 + q2 + q3 + q4 + q5));
vy_P = l*u2*(sin(q1 + q2 + q3 + q4 + q5) + sin(q1 + q2 + q3) + sin(q1 + q2 + q3 + q4) + sin(q1 + q2)) + l*u4*(sin(q1 + q2 + q3 + q4 + q5) + sin(q1 + q2 + q3 + q4)) + l*u5*sin(q1 + q2 + q3 + q4 + q5) + l*u3*(sin(q1 + q2 + q3 + q4 + q5) + sin(q1 + q2 + q3) + sin(q1 + q2 + q3 + q4)) + l*u1*(sin(q1 + q2 + q3 + q4 + q5) + sin(q1 + q2 + q3) + sin(q1 + q2 + q3 + q4) + sin(q1 + q2) + sin(q1));

F = [vx_P; vy_P];