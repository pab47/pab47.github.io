clc
clear all
close all

m = 5; I = 0.1;
l = 1; g = 9.81;
lx = 3; ly =0;
fps = 50;

parms.m = m; 
parms.I = I; 
parms.l = l; parms.g = g;
parms.lx = lx; parms.ly = ly;

%%%%%%%%%% Solve q's such that end of final link is at lx,ly %%%%%%%
q1 = pi/8; q2 = -pi/8; q3 = 0; q4 = 0; q5 = 0;
z0 = [q1 q2 q3 q4 q5]; 
options = optimoptions('fsolve','Display','iter','Algorithm','Levenberg-Marquardt');
[q_all,FVAL,EXITFLAG] = fsolve(@position_last_link_tip,z0,options,parms);
q1 = q_all(1); q2 = q_all(2); q3 = q_all(3); q4 = q_all(4); q5 = q_all(5);
if (EXITFLAG ~=1)
    error('cannot solve for close chain, try new guess');
end
FVAL

%%%%%%%%% animate the initial configuration %%%
% z = [q1 0 q2 0 q3 0 q4 0 q5 0];
% figure(1)
% fivelinkchain_animate(0,z,parms,fps);
% title('initial configuration');
% 
% pause(1)
% close all


%%%%%%%%%% Solve u's such that end of final link is linear velocity 0,0 %%%%%%%
u1 = 0; u2 = 0; u3 = 0; u4 = 0; u5 = 0;
z0 = [u1 u2 u3 u4 u5];
parms.q_all = q_all;
options = optimoptions('fsolve','Display','iter','MaxIter',100,'MaxFunEval',300);
[u_all,FVAL,EXITFLAG] = fsolve(@velocity_last_link_tip,z0,options,parms);
u1 = u_all(1); u2 = u_all(2); u3 = u_all(3); u4 = u_all(4); u5 = u_all(5);
FVAL

%%%%%%%%% Now use ode45 to do simulation %%%%%%
z0 = [q1 u1 q2 u2 q3 u3 q4 u4 q5 u5];
total_time = 20;
t = linspace(0,total_time,100*total_time); %time values
options = odeset('Abstol',1e-9,'Reltol',1e-9);
[t, z] = ode45(@fivelinkchain_rhs,t,z0,options,parms); %integrate using ode45

%%%%%%% display velocity of end of link post simulation (verification) %%
% p_all = [];
% v_all = [];
% for i=1:length(t)
%     parms.q_all = [z(i,1) z(i,3) z(i,5) z(i,7) z(i,9)];
%     q0 = parms.q_all;
%     p_all = [p_all; position_last_link_tip(q0,parms)'];
%     u0 = [z(i,2) z(i,4) z(i,6) z(i,8) z(i,10)];
%     v_all = [v_all; velocity_last_link_tip(u0,parms)'];
% end
% p_all
% v_all

%%%%%% plots and animate %%%%%%%
figure(1)
fivelinkchain_animate(t,z,parms,fps);

figure(2)
subplot(2,1,1)
plot(t,z(:,1),'r','Linewidth',2); hold on
plot(t,z(:,3),'g','Linewidth',2);
plot(t,z(:,5),'b','Linewidth',2);
plot(t,z(:,7),'c','Linewidth',2);
plot(t,z(:,9),'m','Linewidth',2);
ylabel('position','Fontsize',12);
title('Pendulum position and velocity as a function of time','Fontsize',12);
legend('\theta_1','\theta_2','\theta_3','\theta_4','\theta_5','Location','best','Fontsize',12);
subplot(2,1,2)
plot(t,z(:,2),'r','Linewidth',2); hold on
plot(t,z(:,4),'g','Linewidth',2);
plot(t,z(:,6),'b','Linewidth',2);
plot(t,z(:,8),'c','Linewidth',2);
plot(t,z(:,10),'m','Linewidth',2);
ylabel('velocity','Fontsize',12);
xlabel('time','Fontsize',12);


