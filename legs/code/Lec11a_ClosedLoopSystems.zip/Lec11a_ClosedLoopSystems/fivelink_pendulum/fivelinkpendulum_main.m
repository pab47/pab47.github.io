clc
clear all
close all

m1 = 1; I = 0.1;
l = 1; g = 9.81;
fps = 20;

parms.m = m1; 
parms.I = I; 
parms.l = l; parms.g = g;

total_time = 20;
t = linspace(0,total_time,100*total_time); %time values
z0 = [pi/2 zeros(1,9)];
options = odeset('Abstol',1e-12,'Reltol',1e-12);
[t, z] = ode45(@fivelinkpendulum_rhs,t,z0,options,parms); %integrate using ode45

figure(1)
fivelinkpendulum_animate(t,z,parms,fps);

figure(2)
subplot(2,1,1)
plot(t,z(:,1),'r','Linewidth',2); hold on
plot(t,z(:,3),'g','Linewidth',2);
plot(t,z(:,5),'b','Linewidth',2);
plot(t,z(:,7),'c','Linewidth',2);
plot(t,z(:,9),'m','Linewidth',2);
ylabel('position','Fontsize',12);
title('Pendulum position and velocity as a function of time','Fontsize',12);
legend('\theta_1','\theta_2','\theta_3','\theta_4','\theta_5','Location','best','Fontsize',12);
subplot(2,1,2)
plot(t,z(:,2),'r','Linewidth',2); hold on
plot(t,z(:,4),'g','Linewidth',2);
plot(t,z(:,6),'b','Linewidth',2);
plot(t,z(:,8),'c','Linewidth',2);
plot(t,z(:,10),'m','Linewidth',2);
ylabel('velocity','Fontsize',12);
xlabel('time','Fontsize',12);


