%===================================================================
function fivelink_animate(t_all,z_all,parms,fps)
%===================================================================

%%%% Interpolate linearly using fps %%%%%
z_all_plot = [z_all(:,1) z_all(:,3) z_all(:,5) z_all(:,7) z_all(:,9)];
nn = size(z_all_plot,2);
total_frames = round(t_all(end)*fps);
t = linspace(0,t_all(end),total_frames);
z = zeros(total_frames,nn);
for i=1:nn
    z(:,i) = interp1(t_all,z_all_plot(:,i),t);
end

%%%%% Now animate the results %%%%%%% 
l = parms.l;
% c1 = parms.c1;
% c2 = parms.c2;
ll = 5*l+0.2;

mm = size(z,1);
for i=1:mm
    
    theta1 = z(i,1); 
    theta2 = z(i,2);
    theta3 = z(i,3);
    theta4 = z(i,4);
    theta5 = z(i,5);
    
    O = [0 0];
    P1 = [l*sin(theta1) -l*cos(theta1)]; 
    P2 = P1 + l*[sin(theta1+theta2) -cos(theta1+theta2)];
    P3 = P2 + l*[sin(theta1+theta2+theta3) -cos(theta1+theta2+theta3)];
    P4 = P3 + l*[sin(theta1+theta2+theta3+theta4) -cos(theta1+theta2+theta3+theta4)];
    P5 = P4 + l*[sin(theta1+theta2+theta3+theta4+theta5) -cos(theta1+theta2+theta3+theta4+theta5)];
    
    h1 = line([O(1) P1(1)],[O(2) P1(2)],'Color','r','Linewidth',2);
    h2 = line([P1(1) P2(1)],[P1(2) P2(2)],'Color','g','Linewidth',2);
    h3 = line([P2(1) P3(1)],[P2(2) P3(2)],'Color','b','Linewidth',2);
    h4 = line([P3(1) P4(1)],[P3(2) P4(2)],'Color','c','Linewidth',2);
    h5 = line([P4(1) P5(1)],[P4(2) P5(2)],'Color','m','Linewidth',2);
    
    axis('equal')
    axis([-ll ll -ll ll]);
    if (i==1)
        pause(1)
    end
    
    %delay to create animation
    pause(0.01);
   
   if (i~=mm)     %delete all but not the last entry
       delete(h1);
       delete(h2);
       delete(h3);
       delete(h4);
       delete(h5);
   end
end