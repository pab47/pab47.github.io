function H = homogeneous(theta,L)
O = [L; 0];  
R = [cos(theta) -sin(theta); sin(theta) cos(theta)]; 
H = [R, O; 0 0 1];
H = simplify(H);