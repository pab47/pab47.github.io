clc
clear all
close all

figure(1)
rotation_of_a_box_xy
rotation_of_a_box_yx
sgtitle('top: x-90, y-90; bottom: y-90, x-90');