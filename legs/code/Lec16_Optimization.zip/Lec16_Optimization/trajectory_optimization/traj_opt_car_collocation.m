clc
clear all
close all

rng(1); %random number generator to get repeatable u_opt
D = 5; %total distance
N = 5; %grid points

T_min = 1; T_max = 3;
pos_min = 0; pos_max = D;
vel_min = -10; vel_max = 10;
u_min = -5; u_max = 5;

T_opt = 1;
pos_opt = zeros(1,N+1);
vel_opt = zeros(1,N+1);
u_opt = zeros(1,N+1);


FUN = @cost;
X0 = [T_opt pos_opt vel_opt u_opt];
A = []; B = []; Aeq = []; Beq = [];
LB = [T_min pos_min*ones(1,N+1) vel_min*ones(1,N+1) u_min*ones(1,N+1)];
UB = [T_max pos_max*ones(1,N+1) vel_max*ones(1,N+1) u_max*ones(1,N+1)];
NONLCON = @(x)constraints(x,N,D);
OPTIONS = optimoptions('fmincon','Display','iter','Algorithm','sqp','MaxFunctionEvaluations',90000);
[X,FVAL,EXITFLAG] = fmincon(FUN,X0,A,B,Aeq,Beq,LB,UB,NONLCON,OPTIONS);

%X
FVAL

T = X(1);
pos = X(1+1:1+N+1);
vel = X(1+(N+1)+1:1+(N+1)+N+1);
u = X(1+2*(N+1)+1:1+2*(N+1)+N+1);
t = linspace(0,T,N+1);

subplot(3,1,1);
plot(t,pos); ylabel('position');
subplot(3,1,2);
plot(t,vel); ylabel('velocity');
subplot(3,1,3);
plot(t,u); ylabel('control');

function T = cost(x)
    T = x(1);
end

function [c,ceq] = constraints(x,N,D)
      T = x(1);
      t = linspace(0,T,N+1);
      dt = t(2)-t(1);
      pos = x(1+1:1+N+1);
      vel = x(1+(N+1)+1:1+(N+1)+N+1);
      u = x(1+2*(N+1)+1:1+2*(N+1)+N+1);
      for i=1:N
        defect_pos(i) = pos(i+1) - pos(i) - vel(i)*dt;
        defect_vel(i) = vel(i+1) - vel(i) - 0.5*(u(i)+u(i+1))*dt;
      end
      c = [];
      ceq = [defect_pos defect_vel pos(1) vel(1) pos(N+1)-D vel(N+1)];
end

