function test_fminunc

clc
clear all
close all

%%%%%%%%% optimization %%%%%%%
x0 = [1,2];
options = optimoptions('fminunc','Display','iter',...
                   'MaxFunEvals',1000,'MaxIter',200);
[x,fval,extiflag] = fminunc(@fun,x0,options)

%%%%%%% plot the function
x1 = linspace(-5,5);
x2 = linspace(-5,5);
[X1,X2] = meshgrid(x1,x2);
[m,n] = size(X1);
for i=1:m
    for j=1:n
        x = [X1(i,j) X2(i,j)];
        Z(i,j) = fun(x);
    end
end
%contourf(X1,X2,Z,'ShowText','on');
surf(X1,X2,Z);

function F = fun(x)
x1 = x(1); x2 = x(2);
F = 100*(x2-x1^2)^2 + (1-x1)^2;
