function test_fmincon
clc
clear all
close all

%%%%%%%%% optimization %%%%%%%
%x0 = [1; 1; 1; 2; 1]; % initial guess 
x0 = rand(5,1)+10*ones(5,1);
A = []; 
b = [];  % no linear inequality constraints
Aeq = [1 1 1 0 0]; 
beq = 5;  % linear equality constraints
lb = [0.3; -Inf; -Inf; -Inf; -Inf];  % lower bound on the variables
ub = [Inf; Inf; 5; Inf; Inf];  % upper bound on the variables
options = optimoptions('fmincon','Display','iter',...
                   'MaxFunEvals',1000,'MaxIter',200);

[x,fval,exitflag] = fmincon(@fun,x0,A,b,Aeq,beq,lb,ub,@nonlcon,options)

function cost = fun(x)
cost = x(1)^2+x(2)^2+x(3)^2+x(4)^2+x(5)^2;


function [c,ceq] = nonlcon(x)
c = x(4)^2+x(5)^2-5;
ceq = x(3)^2+x(4)-2;

