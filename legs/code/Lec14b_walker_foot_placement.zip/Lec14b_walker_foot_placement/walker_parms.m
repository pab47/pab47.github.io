function walker = walker_parms

walker.M = 1.0; walker.I = 0; walker.l = 1.0; 
walker.g = 10.0; walker.gam = 0.1;