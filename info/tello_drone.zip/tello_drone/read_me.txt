How to use

1) Connect the robot to your computer’s wifi. Turn the drone on. Go to your computer's Wi-Fi and connect to the wifi that says TELLO or similar
2) Run the robot and control with April Tag:
python3 tello_video_april_tag.py  (you might have to install packages using pip install) 
3) To land the drone: tello_emergency.py