

const int nBody = 2;
int index_rBody[nBody] = {9, 10};
double data_rBody[nBody][7] = {};

double counter = 0;

#include "SampleClient.cpp"

int main(int argc, char* argv[] )
{
  int i,j,k;

  init_SampleClient(argc,argv);

  //run_SampleClient();

  while (1)
  {
  for (i=0;i<nBody;i++)
    {
      printf("Body ID = %d; Data = ",index_rBody[i]);
      for (j=0;j<7;j++)
      {
        printf("%1.3f ", data_rBody[i][j]);
      }
      printf("\n");
    }
    printf("***************************************************************\n");

     counter += 1e-6;
     //printf("%f \n",counter);
      if (counter>=5)
        break;
  }

    cleanup_SampleClient();

  return 0;
}
