#pragma once

// Standing posture parameters
double q_init[29] = {0.0,0.0,0.0, //left hip:pitch,roll,yaw
                    0.0,0.0,0.0, //knee pitch and foot pitch,roll
                    0.0,0.0,0.0, //right hip:pitch,roll,yaw
                    0.0,0.0,0.0, //knee pitch and foot pitch,roll
                    0.0,0.0,0.0, //waist: yaw, roll,pitch
                    0.0,0.0,0.0, //left shoulder:pitch,roll,yaw
                    0.0,0.0,0.0,0.0, //elbow: shoulder:roll,pitch,yaw
                    0.0,0.0,0.0, //right shoulder:pitch,roll,yaw
                    0.0,0.0,0.0,0.0, //elbow: shoulder:roll,pitch,yaw
                    };

