This is the OpenGL graphics from ODE (www.ode.com)
libdrawstuff.a is compiled for linux 32 bit.
libdrawstuff64.a is compiled for linux 64 bit.
Feel free to get a new version by downloading
source from www.ode.org and recompiling.



