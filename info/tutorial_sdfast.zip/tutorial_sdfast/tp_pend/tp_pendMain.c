#include <stdio.h>
#include <math.h>

#define PI 3.14159265
///* Body numbers (from the tp_pend_i file). */
#define GROUND	(-1)
#define BODY1	0
#define BODY2	1
#define BODY3	2

#define JOINT_B0_TO_B1 0
#define JOINT_B1_TO_B2 1
#define JOINT_B2_TO_B3 2

/* State variables.  The state variable corresponding to
 * a particular joint axis can be obtained from the 
 * tp_pend_i file or by using the sdindx() routine.
 */
#define NQ 3
#define NU 3
#define NSTATE (NQ+NU)


#define CTOL		0.0	/* constraint tolerance */
#define INT_TOL		1e-12	/* integration tolerance */
#define DT          0.02  /* Step size */
#define NSTEPS		500 /* Number of time steps */


int
main()
{
    
    double t=0, q[NQ], u[NU], qdot[NQ], udot[NU], tau[NU];
	double state[NSTATE], dstate[NSTATE];
	double pos_com[3] = {0,0,0}, pos1[3], pos2[3], vel[3], angvel[3], acc[3], angacc[3], diff[3];
	double pos_links[4][3] = { {0,0,0}, {0,-0.5,0},{0,-1.5,0},{0,-2.5,0} }; //position of geometric COM in reference configuration
	double pos_link1[3], pos_link2[3], pos_link3[3]; //Change the name to pos_joint1 ans so on...
	double pos_jt0[3], pos_jt1[3], pos_jt2[3], pos_jt3[3]; 
	int i,j;
	int flag=1, err;
	FILE *fid;
	
    tp_pendinit(); /* initialize sd/fast model */

//	/**** First get locations of geomeric com wrt body reference frame ***/
	q[0]= 0; q[1] = 0; q[2] = 0;
	u[0] = 0; u[1] = 0; u[2] = 0;
	tp_pendstate(t,q,u); //Pass the state 
	
	tp_pendpos(BODY1,pos_com,pos1);
	i = 1; 
	pos2[0] = pos_links[i][0]; pos2[1] = pos_links[i][1]; pos2[0] = pos_links[i][2];
	tp_pendvsub(pos2,pos1,diff); 
	pos_link1[0] = diff[0]; pos_link1[1] = diff[1]; pos_link1[2] = diff[2];

	tp_pendpos(BODY2,pos_com,pos1);
	i = 2; 
	pos2[0] = pos_links[i][0]; pos2[1] = pos_links[i][1]; pos2[0] = pos_links[i][2];
	tp_pendvsub(pos2,pos1,diff);
	pos_link2[0] = diff[0]; pos_link2[1] = diff[1]; pos_link2[2] = diff[2]; 

	tp_pendpos(BODY3,pos_com,pos1);
	i = 3; 
	pos2[0] = pos_links[i][0]; pos2[1] = pos_links[i][1]; pos2[0] = pos_links[i][2];
	tp_pendvsub(pos2,pos1,diff);
	pos_link3[0] = diff[0]; pos_link3[1] = diff[1]; pos_link3[2] = diff[2]; 

	//Set initial state 
	q[0]= PI/2; q[1] = 0; q[2] = 0;
	u[0] = 0; u[1] = 0; u[2] = 0;
	
	for(i=0;i<NQ;i++)
		state[i] = q[i];

	for(i=0;i<NU;i++)
		state[i+NQ] = u[i];

    tp_pendstate(t,q,u); //Pass the state 	

	fid = fopen("data_for_animation.txt","w");
	for(i = 0; i < (NSTEPS+1);i++)
	{
		/* Write to terminal and screen */
		printf("%f\t %f\t %f\t",state[0],state[1],state[2]);
		fprintf(fid,"%f\t %f\t %f\t",state[0],state[1],state[2]);
		tp_pendpos(BODY1,pos_link1,pos1); printf("%f\t %f\t",pos1[0],pos1[1]); fprintf(fid,"%f\t %f\t",pos1[0],pos1[1]);
		tp_pendpos(BODY2,pos_link2,pos1); printf("%f\t %f\t",pos1[0],pos1[1]); fprintf(fid,"%f\t %f\t",pos1[0],pos1[1]);
		tp_pendpos(BODY3,pos_link3,pos1); printf("%f\t %f\t",pos1[0],pos1[1]); fprintf(fid,"%f\t %f\t",pos1[0],pos1[1]);
        printf(" \n"); fprintf(fid,"\n");

		tp_pendmotion(&t,state,dstate,DT,CTOL,INT_TOL,&flag,&err);
			if (err) printf("*** at t=%g got err=%d\n", t, err);
    }
	fclose(fid);
		
    /* Always call sdprinterr to check for errors */
    tp_pendprinterr(stderr);
	
    return 0;
}


void
tp_penduforce(double t, double *q, double *u)
{
    //double body_torque[3] = {0,0, 9.81*10*1.5};
    //  sdhinget(JOINT_GND_PEND, 0, 50*q[0]); %spring force
    //sdhinget(JOINT_GND_PEND, 0, -25*u[0]); %damping
    //sdhinget(JOINT_GND_PEND, 0,-1000*(q[0]-0.5)-25*u[0]); //proportional-derivative controller
    //sdbodyt(BODY_PEND, body_torque); //? Need to figure this out.
    
}
