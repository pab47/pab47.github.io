/*****************************************************************************/
/*
  animate.c: animate a data file.
*/
/*****************************************************************************/
#define XX 0
#define YY 1
#define ZZ 2
#define PI 3.14159
#define XXFLIP -
/*****************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

#include "drawstuff.h" /* ODE Graphics stuff */
#include "drawstuff-cga.h" /* CGA stuff to make things clearer */

/*****************************************************************************/
#define LENGTH 1.0f // length of link
#define HEIGHT 0.05f // height of link
#define WIDTH 0.05f    // width of link

/*****************************************************************************/

// ************ Change this as per the problem being solved *********//
#define DATA_PTS 9 //Set this based on columns in data file
float data[5000][DATA_PTS]; //Structure that will store the data.
char DATA_FILE[] = "data_for_animation.txt"; //Data file to read
float STEPS;
int COUNTER;
// **************************************************************** //


static void read_data()
{
    int i, j;
    FILE *fid;
    
	fid = fopen(DATA_FILE,"r");
    
	/* Read file */
    i = 0;
    while(!feof(fid))
    {
        for (j=0;j<DATA_PTS;j++)
            fscanf(fid, "%f", &data[i][j]);
        i = i+1;
    }
    fclose(fid);
    STEPS = i-1;
    
	/* For Display only */
    /*for (i=0;i<steps;i++)
    {
        for (j=0;j<DATA_PTS;j++)
            printf("%f ",data[i][j]);
        printf("\n");
    }*/	
}



/*****************************************************************************/

static void start()
{
  // set up view point
  static float xyz[3] = {0.5f,-5.8f,1.0f};
	static float hpr[3] = {91.5000f,4.0f,0.0000f};
	dsSetViewpoint (xyz,hpr);
}

/********************************************************************/
// called when a key pressed

static void command (int cmd)
{
  // don't handle user input yet.
  dsPrint ("received command %d (`%c')\n",cmd,cmd);
}

/*****************************************************************************/



static void display (int pause)
{
  float center[3];
  float R[12];
  float sides[3] = { WIDTH, HEIGHT, LENGTH };
  int i;
	float angle, c, s;
	float translate = 3.0;
  //float f;

	/******  First pendulum ******/ 
	angle =  data[COUNTER][0];
	center[XX] = data[COUNTER][3];
	center[YY] = 0;
	center[ZZ] = data[COUNTER][4]+translate;
	
	for ( i = 0; i < 12; i++ )
		R[i] = 0;

	c = cos(angle); s = sin(angle);
	R[0] = c; R[2] = -s;
	R[5] = 1;
	R[8] = -R[2]; R[10] = R[0];
	
	/* NOTE: The R matrix is as follows 
	 R = [ R[0] R[1] R[2]  R[3];
	 R[4] R[5] R[6]  R[7];
	 R[8] R[9] R[10] R[11]];
	 The elements R[3], R[7] and R[11] are not used */

	/* Draw a box */
	dsSetTexture (DS_WOOD);
	dsSetColor (0,0,1);
	dsDrawBox( center, R, sides );
	
	/******  Second pendulum ******/ 
	angle =  data[COUNTER][0] + data[COUNTER][1];
	center[XX] = data[COUNTER][5];
	center[YY] = 0;
	center[ZZ] = data[COUNTER][6]+translate;
	
	for ( i = 0; i < 12; i++ )
		R[i] = 0;
	
	c = cos(angle); s = sin(angle);
	R[0] = c; R[2] = -s;
	R[5] = 1;
	R[8] = -R[2]; R[10] = R[0];
		
	/* Draw a box */
	dsSetTexture (DS_WOOD);
	dsSetColor (0,1,0);
	dsDrawBox( center, R, sides );
	
	/******  Third pendulum ******/ 
	angle =  data[COUNTER][0] + data[COUNTER][1] + data[COUNTER][2];
	center[XX] = data[COUNTER][7];
	center[YY] = 0;
	center[ZZ] = data[COUNTER][8]+translate;
	
	for ( i = 0; i < 12; i++ )
		R[i] = 0;
	
	c = cos(angle); s = sin(angle);
	R[0] = c; R[2] = -s;
	R[5] = 1;
	R[8] = -R[2]; R[10] = R[0];
	
	/* Draw a box */
	dsSetTexture (DS_WOOD);
	dsSetColor (1,0,0);
	dsDrawBox( center, R, sides);


	
	COUNTER+=1;
	
	if(COUNTER>=STEPS)
		COUNTER = 0; //reset counter
	

	/* Delay */
	//for( f = 0.0; f < 2000000.0; f += 1.0 );



}

/*****************************************************************************/
/********************************************************************/

int main (int argc, char **argv)
{
	
	// Read data and load this into memory
	read_data();
	
    dsFunctions fn; 
 
  // setup pointers to drawstuff callback functions
  fn.version = DS_VERSION; 
  fn.start = &start; 
  fn.step = &display; 
  fn.command = &command; 
  fn.stop = 0; 
#ifdef WIN32
  fn.path_to_textures = "C:/cga/kdc/sim5/useful/drawstuff-windows/textures";
#else
  //Change to this appropriately
  //fn.path_to_textures = "/Users/pab47/Documents/DISK/template_files/template_C/animation-drawstuff/home_comp/useful/drawstuff-linux/textures";
  //fn.path_to_textures = "/Users/pranavb/Documents/pab-macbook/documents/DISK/template_files/template_C/animation-drawstuff/all_geometries/drawstuff/textures";
  fn.path_to_textures = "/Users/pranavb/Desktop/sdfast-info/tutorial_sdfast/tp_pend/drawstuff/textures";
#endif


  // do display
  dsSimulationLoop( argc, argv, /* command line arguments */
                   352, 288, /* window size */
                    &fn ); /* callback info */
    

  return 0;
}

/********************************************************************/
