/*
Generated 25-Jun-2008 22:33:16 by SD/FAST, Kane's formulation
(sdfast B.2.8 #30123) on machine ID unknown
Copyright (c) 1990-1997 Symbolic Dynamics, Inc.
Copyright (c) 1990-1997 Parametric Technology Corp.
RESTRICTED RIGHTS LEGEND: Use, duplication, or disclosure by the U.S.
Government is subject to restrictions as set forth in subparagraph
(c)(1)(ii) of the Rights in Technical Data and Computer Software
clause at DFARS 52.227-7013 and similar clauses in the FAR and NASA
FAR Supplement.  Symbolic Dynamics, Inc., Mountain View, CA 94041
*/
#include <math.h>

/* These routines are passed to tp_pendroot. */

void tp_pendposfunc(double vars[3],
    double param[1],
    double resid[1])
{
    int i;
    double pos[3],vel[3];

    for (i = 0; i < 3; i++) {
        vel[i] = 0.;
    }
    tp_pendang2st(vars,pos);
    tp_pendstate(param[0],pos,vel);
    tp_pendperr(resid);
}

void tp_pendvelfunc(double vars[3],
    double param[4],
    double resid[1])
{

    tp_pendstate(param[3],param,vars);
    tp_pendverr(resid);
}

void tp_pendstatfunc(double vars[3],
    double param[4],
    double resid[3])
{
    double pos[3],qdotdum[3];

    tp_pendang2st(vars,pos);
    tp_pendstate(param[3],pos,param);
    tp_penduforce(param[3],pos,param);
    tp_pendperr(resid);
    tp_pendderiv(qdotdum,&resid[0]);
}

void tp_pendstdyfunc(double vars[6],
    double param[1],
    double resid[3])
{
    double pos[3],qdotdum[3];

    tp_pendang2st(vars,pos);
    tp_pendstate(param[0],pos,&vars[3]);
    tp_penduforce(param[0],pos,&vars[3]);
    tp_pendperr(resid);
    tp_pendverr(&resid[0]);
    tp_pendderiv(qdotdum,&resid[0]);
}

/* This routine is passed to the integrator. */

void tp_pendmotfunc(double time,
    double state[6],
    double dstate[6],
    double param[1],
    int *status)
{

    tp_pendstate(time,state,&state[3]);
    tp_penduforce(time,state,&state[3]);
    tp_pendderiv(dstate,&dstate[3]);
    *status = 0;
}

/* This routine performs assembly analysis. */

void tp_pendassemble(double time,
    double state[6],
    int lock[3],
    double tol,
    int maxevals,
    int *fcnt,
    int *err)
{
    double perrs[1],param[1];
    int i;

    tp_pendgentime(&i);
    if (i != 223316) {
        tp_pendseterr(50,42);
    }
    param[0] = time;
    *err = 0;
    *fcnt = 0;
    tp_pendposfunc(state,param,perrs);
    *fcnt = *fcnt+1;
}

/* This routine performs initial velocity analysis. */

void tp_pendinitvel(double time,
    double state[6],
    int lock[3],
    double tol,
    int maxevals,
    int *fcnt,
    int *err)
{
    double verrs[1],param[4];
    int i;

    tp_pendgentime(&i);
    if (i != 223316) {
        tp_pendseterr(51,42);
    }
    for (i = 0; i < 3; i++) {
        param[i] = state[i];
    }
    param[3] = time;
    *err = 0;
    *fcnt = 0;
    tp_pendvelfunc(&state[3],param,verrs);
    *fcnt = *fcnt+1;
}

/* This routine performs static analysis. */

void tp_pendstatic(double time,
    double state[6],
    int lock[3],
    double ctol,
    double tol,
    int maxevals,
    int *fcnt,
    int *err)
{
    double resid[3],param[4],jw[9],dw[72],rw[48];
    int iw[24],rooterr,i;

    tp_pendgentime(&i);
    if (i != 223316) {
        tp_pendseterr(52,42);
    }
    for (i = 0; i < 3; i++) {
        param[i] = state[3+i];
    }
    param[3] = time;
    tp_pendroot(tp_pendstatfunc,state,param,3,3,3,lock,
      ctol,tol,maxevals,jw,dw,rw,iw,resid,fcnt,&rooterr);
    tp_pendstatfunc(state,param,resid);
    *fcnt = *fcnt+1;
    if (rooterr == 0) {
        *err = 0;
    } else {
        if (*fcnt >= maxevals) {
            *err = 2;
        } else {
            *err = 1;
        }
    }
}

/* This routine performs steady motion analysis. */

void tp_pendsteady(double time,
    double state[6],
    int lock[6],
    double ctol,
    double tol,
    int maxevals,
    int *fcnt,
    int *err)
{
    double resid[3],param[1];
    double jw[18],dw[162],rw[75];
    int iw[36],rooterr,i;

    tp_pendgentime(&i);
    if (i != 223316) {
        tp_pendseterr(53,42);
    }
    param[0] = time;
    tp_pendroot(tp_pendstdyfunc,state,param,3,6,3,lock,
      ctol,tol,maxevals,jw,dw,rw,iw,resid,fcnt,&rooterr);
    tp_pendstdyfunc(state,param,resid);
    *fcnt = *fcnt+1;
    if (rooterr == 0) {
        *err = 0;
    } else {
        if (*fcnt >= maxevals) {
            *err = 2;
        } else {
            *err = 1;
        }
    }
}

/* This routine performs state integration. */

void tp_pendmotion(double *time,
    double state[6],
    double dstate[6],
    double dt,
    double ctol,
    double tol,
    int *flag,
    int *err)
{
    static double step;
    double work[36],ttime,param[1];
    int vintgerr,which,ferr,i;

    tp_pendgentime(&i);
    if (i != 223316) {
        tp_pendseterr(54,42);
    }
    param[0] = ctol;
    ttime = *time;
    if (*flag != 0) {
        tp_pendmotfunc(ttime,state,dstate,param,&ferr);
        step = dt;
        *flag = 0;
    }
    if (step <= 0.) {
        step = dt;
    }
    tp_pendvinteg(tp_pendmotfunc,&ttime,state,dstate,param,dt,&step,6,tol,work,&
      vintgerr,&which);
    *time = ttime;
    *err = vintgerr;
}

/* This routine performs state integration with a fixed-step integrator. */

void tp_pendfmotion(double *time,
    double state[6],
    double dstate[6],
    double dt,
    double ctol,
    int *flag,
    double *errest,
    int *err)
{
    double work[24],ttime,param[1];
    int ferr,i;

    tp_pendgentime(&i);
    if (i != 223316) {
        tp_pendseterr(55,42);
    }
    param[0] = ctol;
    *err = 0;
    ttime = *time;
    if (*flag != 0) {
        tp_pendmotfunc(ttime,state,dstate,param,&ferr);
        *flag = 0;
    }
    tp_pendfinteg(tp_pendmotfunc,&ttime,state,dstate,param,dt,6,work,errest,&
      ferr);
    if (ferr != 0) {
        *err = 1;
    }
    *time = ttime;
}
