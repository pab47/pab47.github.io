/*
 *   Plane.h
 *
 *   Author: ROBOTIS
 *
 */

#ifndef _PLANE_H_
#define _PLANE_H_


namespace Robot
{
	class Plane3D
	{
	private:

	protected:

	public:
		Plane3D();
		~Plane3D();
	};
}

#endif