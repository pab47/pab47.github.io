/*
 *   minIni.h
 *
 *   Author: ROBOTIS
 *
 */

#ifndef _INC_MININI_H_
#define _INC_MININI_H_

#include "../src/minIni/minIni.h"

#endif