/*
 *   mjpg_streamer.h
 *
 *   Author: ROBOTIS
 *
 */

#ifndef _MJPG_STREAMER_H_
#define _MJPG_STREAMER_H_

#include "../build/streamer/mjpg_streamer.h"

#endif