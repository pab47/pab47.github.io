#include <stdio.h>
#include <math.h>
#include "params.h"

#include <string.h>
#include "le_ludecomp.c"
#include "useful.c"

int save_date_for_animation();
FILE *fid;
int HEAD_HEIGHT = 1; //If HEAD_YAW is set to (Lf+L5+L4+Lty+Lh) in MATLAB then do this, we assume that the height is


int main()
{
    
	double t=0, q[NQ] = {0}, u[NU] = {0}; q[NQ-1] = 1;
	int i;

	
	double tend = 10*60;
	double dt = 0.1;
	
	fid = fopen("data.txt","w");
    
	
    double temp_pos[3];
    
    sdinit(); sdprinterr(stderr);
    //sdstate(t,q,u); sdprinterr(stderr);
    
    ///////// modify the head joint location %%%
    if (HEAD_HEIGHT==1) //Takes the height to (Lf+L5+L4+Lty+Lh/2) instead of (Lf+L5+L4+Lty+Lh) (in MATLAB)
    {
        sdgetbtj(HEAD_YAW,temp_pos); temp_pos[2] = temp_pos[2]-Lh/2;
        sdbtj(HEAD_YAW,temp_pos);
        
        sdgetitj(HEAD_PITCH,temp_pos); temp_pos[2] = temp_pos[2]-Lh/2;
        sditj(HEAD_PITCH,temp_pos);
        sdgetbtj(HEAD_PITCH,temp_pos); temp_pos[2] = temp_pos[2]-Lh/2;
        sdbtj(HEAD_PITCH,temp_pos);
    }
    
    
    sdinit(); sdprinterr(stderr);
    sdstate(t,q,u); sdprinterr(stderr);
	
	while (1)
	{
	
		int k=0;
		for (i=6;i<NQ-1;i++)
		{
            double tt = 0.1*t;
            
            //if (i==BT2 || i==BS2 || i== BF2 || i==BSR || i==BSL)
            //{//do nothing
            //}
            //else
            //{
                //printf("%d \n",k);
                q[i] = joint_limits_rad[k][1] + (sin(tt)+1)*( (joint_limits_rad[k][0]-joint_limits_rad[k][1])/2.0);
                //q[i] =  0.5*(-sin(tt)+1)*joint_limits_rad[k][0] + 0.5*(sin(tt)+1)*joint_limits_rad[k][1];
                //q[i] = joint_limits_rad[k][0] ;
                //q[i] = joint_limits_rad[k][1] ;
                //q[i] = (joint_limits_rad[k][0]+joint_limits_rad[k][1])/2.0;
            
                
                //if (k==LSS || k==RSS)
                    //printf("%f ",q[k]);
                k +=1;
                
                
            //}
            //printf("\n");
		}
		
		sdstate(t,q,u); sdprinterr(stderr);
   
        //save data to a file
        save_data_for_animation();
        
		if (t>tend)
			break;
		
		t += dt;
		
	}
	
	//close file 
	fclose(fid);
	
    // check for errors 
    sdprinterr(stderr); 
	
    return 0;
}


void
sduforce(double t, double *q, double *u)
{}

int save_data_for_animation()
{
    double pos1[3],pos2[3];
    int info[50], slider[6];
    int inb_body_no,outb_body_no;
    double inb_to_joint[3], body_to_joint[3];
    double pos_end_effector[3] = {0};
    int ii,jj,i;
    
    
    
    
    //Handle the torso first
    sdgetbtj(TORSO,body_to_joint); sdprinterr(stderr);
    sdpos(TORSO,body_to_joint,pos1); sdprinterr(stderr);
    sdgetitj(HEAD_YAW,inb_to_joint); sdprinterr(stderr);
    sdpos(TORSO,inb_to_joint,pos2);
    fprintf(fid,"%f %f %f ",pos1[0],pos1[1],pos1[2]);
    fprintf(fid,"%f %f %f ",pos2[0],pos2[1],pos2[2]);
    
    printf("%f %f %f ",pos1[0],pos1[1],pos1[2]);
    printf("%f %f %f ",pos2[0],pos2[1],pos2[2]);
    printf("\n");
    
    // All joints except the TORSO joint
    for (ii=1;ii<NBOD;ii++) //cycle through info file
    {
        //      (body=outb_body_no) - body_to_joint - (joint=outb_body_no) - inb_to_joint - (body=inb_body_no)
        // sdjnt(joint,info,slider);
        // where info[2] info[3] is
        // inboard outboard (from _i file)
        
        //This loop finds the start position of all joints except the TORSO
        for (jj=1;jj<NBOD;jj++)
        {
            sdjnt(jj,info,slider); sdprinterr(stderr);
            //inb_body_no = info[2]; //inboard body number = inboard joint number
            outb_body_no = info[3]; //outboard body number = outboard joint number
            if (outb_body_no==ii)
            {
                sdgetbtj(outb_body_no,body_to_joint); sdprinterr(stderr);
                sdpos(outb_body_no,body_to_joint,pos1); sdprinterr(stderr);
            }
        }
        
        //This find the end position of all joints except the TORSO
        //Need to handle end-effectors differently
        if (ii == R_ELBOW_YAW)
        {
            pos_end_effector[0] = 0; pos_end_effector[1] = -LH; pos_end_effector[2] = 0; //position of end-effector wrt last joint (see Darwin kinematics figure from ASME paper)
            for (i=0;i<3;i++)
                pos_end_effector[i] += body_to_joint[i]; //position of end-effector wrt to com, as com = 0,0,0
            sdpos(ii,pos_end_effector,pos2);
            
        }
        else if (ii == L_ELBOW_YAW)
        {
            pos_end_effector[0] = 0; pos_end_effector[1] = LH; pos_end_effector[2] = 0; //position of end-effector wrt last joint (see Darwin kinematics figure from ASME paper)
            for (i=0;i<3;i++)
                pos_end_effector[i] += body_to_joint[i]; //position of end-effector wrt to com, as com = 0,0,0
            sdpos(ii,pos_end_effector,pos2);
        }
        else if (ii==R_ANKLE_ROLL)
        {
            pos_end_effector[0] = 0; pos_end_effector[1] = 0; pos_end_effector[2] = -LF; //position of end-effector wrt last joint (see Darwin kinematics figure from ASME paper)
            for (i=0;i<3;i++)
                pos_end_effector[i] += body_to_joint[i]; //position of end-effector wrt to com, as com = 0,0,0
            sdpos(ii,pos_end_effector,pos2);
        }
        else if (ii==L_ANKLE_ROLL)
        {
            pos_end_effector[0] = 0; pos_end_effector[1] = 0; pos_end_effector[2] = -LF; //position of end-effector wrt last joint (see Darwin kinematics figure from ASME paper)
            for (i=0;i<3;i++)
                pos_end_effector[i] += body_to_joint[i]; //position of end-effector wrt to com, as com = 0,0,0
            sdpos(ii,pos_end_effector,pos2);
        }
        else if (ii==HEAD_PITCH)
        {
            pos_end_effector[0] = 0; pos_end_effector[1] = 0; //position of end-effector wrt last joint (see Darwin kinematics figure from ASME paper)
            if (HEAD_HEIGHT == 1)
                pos_end_effector[2] = Lh/2+HY;
            else
                pos_end_effector[2] = HY;
            for (i=0;i<3;i++)
                pos_end_effector[i] += body_to_joint[i]; //position of end-effector wrt to com, as com = 0,0,0
            sdpos(ii,pos_end_effector,pos2);
        }
        else
        {
            //This loop tries to find inboard body joint number attached
            for (jj=1;jj<NBOD;jj++)
            {
                sdjnt(jj,info,slider);
                inb_body_no = info[2]; //inboard body number = inboard joint number
                outb_body_no = info[3]; //outboard body number = outboard joint number
                if (inb_body_no==ii)
                {
                    sdgetitj(outb_body_no,inb_to_joint);
                    sdpos(inb_body_no,inb_to_joint,pos2);
                }
            }
        }
        
        fprintf(fid,"%f %f %f ",pos1[0],pos1[1],pos1[2]);
        fprintf(fid,"%f %f %f ",pos2[0],pos2[1],pos2[2]);
        //count=count+6;
        
        
        printf("%f %f %f ",pos1[0],pos1[1],pos1[2]);
        printf("%f %f %f ",pos2[0],pos2[1],pos2[2]);
        printf("\n");
        //
        
        //            fprintf(fid,"\n");
        
    }
    return 0;
}






