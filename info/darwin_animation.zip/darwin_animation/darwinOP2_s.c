/*
Generated 01-Mar-2006 15:25:51 by SD/FAST, Kane's formulation
(sdfast B.2.8 #30123) on machine ID unknown
Copyright (c) 1990-1997 Symbolic Dynamics, Inc.
Copyright (c) 1990-1997 Parametric Technology Corp.
RESTRICTED RIGHTS LEGEND: Use, duplication, or disclosure by the U.S.
Government is subject to restrictions as set forth in subparagraph
(c)(1)(ii) of the Rights in Technical Data and Computer Software
clause at DFARS 52.227-7013 and similar clauses in the FAR and NASA
FAR Supplement.  Symbolic Dynamics, Inc., Mountain View, CA 94041
*/
#include <math.h>

/* These routines are passed to sdroot. */

void sdposfunc(double vars[26],
    double param[1],
    double resid[1])
{
    int i;
    double pos[27],vel[26];

    for (i = 0; i < 26; i++) {
        vel[i] = 0.;
    }
    sdang2st(vars,pos);
    sdstate(param[0],pos,vel);
    sdperr(resid);
}

void sdvelfunc(double vars[26],
    double param[28],
    double resid[1])
{

    sdstate(param[27],param,vars);
    sdverr(resid);
}

void sdstatfunc(double vars[26],
    double param[27],
    double resid[26])
{
    double pos[27],qdotdum[27];

    sdang2st(vars,pos);
    sdstate(param[26],pos,param);
    sduforce(param[26],pos,param);
    sdperr(resid);
    sdderiv(qdotdum,&resid[0]);
}

void sdstdyfunc(double vars[52],
    double param[1],
    double resid[26])
{
    double pos[27],qdotdum[27];

    sdang2st(vars,pos);
    sdstate(param[0],pos,&vars[26]);
    sduforce(param[0],pos,&vars[26]);
    sdperr(resid);
    sdverr(&resid[0]);
    sdderiv(qdotdum,&resid[0]);
}

/* This routine is passed to the integrator. */

void sdmotfunc(double time,
    double state[53],
    double dstate[53],
    double param[1],
    int *status)
{

    sdstate(time,state,&state[27]);
    sduforce(time,state,&state[27]);
    sdderiv(dstate,&dstate[27]);
    *status = 0;
}

/* This routine performs assembly analysis. */

void sdassemble(double time,
    double state[53],
    int lock[26],
    double tol,
    int maxevals,
    int *fcnt,
    int *err)
{
    double perrs[1],param[1];
    int i;

    sdgentime(&i);
    if (i != 152551) {
        sdseterr(50,42);
    }
    param[0] = time;
    sdst2ang(state,state);
    *err = 0;
    *fcnt = 0;
    sdposfunc(state,param,perrs);
    *fcnt = *fcnt+1;
    sdang2st(state,state);
}

/* This routine performs initial velocity analysis. */

void sdinitvel(double time,
    double state[53],
    int lock[26],
    double tol,
    int maxevals,
    int *fcnt,
    int *err)
{
    double verrs[1],param[28];
    int i;

    sdgentime(&i);
    if (i != 152551) {
        sdseterr(51,42);
    }
    for (i = 0; i < 27; i++) {
        param[i] = state[i];
    }
    param[27] = time;
    *err = 0;
    *fcnt = 0;
    sdvelfunc(&state[27],param,verrs);
    *fcnt = *fcnt+1;
}

/* This routine performs static analysis. */

void sdstatic(double time,
    double state[53],
    int lock[26],
    double ctol,
    double tol,
    int maxevals,
    int *fcnt,
    int *err)
{
    double resid[26],param[27],jw[676],dw[5408],rw[416];
    int iw[208],rooterr,i;

    sdgentime(&i);
    if (i != 152551) {
        sdseterr(52,42);
    }
    for (i = 0; i < 26; i++) {
        param[i] = state[27+i];
    }
    param[26] = time;
    sdst2ang(state,state);
    sdroot(sdstatfunc,state,param,26,26,26,lock,
      ctol,tol,maxevals,jw,dw,rw,iw,resid,fcnt,&rooterr);
    sdstatfunc(state,param,resid);
    *fcnt = *fcnt+1;
    sdang2st(state,state);
    if (rooterr == 0) {
        *err = 0;
    } else {
        if (*fcnt >= maxevals) {
            *err = 2;
        } else {
            *err = 1;
        }
    }
}

/* This routine performs steady motion analysis. */

void sdsteady(double time,
    double state[53],
    int lock[52],
    double ctol,
    double tol,
    int maxevals,
    int *fcnt,
    int *err)
{
    double resid[26],param[1],vars[52];
    double jw[1352],dw[12168],rw[650];
    int iw[312],rooterr,i;

    sdgentime(&i);
    if (i != 152551) {
        sdseterr(53,42);
    }
    param[0] = time;
    sdst2ang(state,vars);
    for (i = 0; i < 26; i++) {
        vars[26+i] = state[27+i];
    }
    sdroot(sdstdyfunc,vars,param,26,52,26,lock,
      ctol,tol,maxevals,jw,dw,rw,iw,resid,fcnt,&rooterr);
    sdstdyfunc(vars,param,resid);
    *fcnt = *fcnt+1;
    sdang2st(vars,state);
    for (i = 0; i < 26; i++) {
        state[27+i] = vars[26+i];
    }
    if (rooterr == 0) {
        *err = 0;
    } else {
        if (*fcnt >= maxevals) {
            *err = 2;
        } else {
            *err = 1;
        }
    }
}

/* This routine performs state integration. */

void sdmotion(double *time,
    double state[53],
    double dstate[53],
    double dt,
    double ctol,
    double tol,
    int *flag,
    int *err)
{
    static double step;
    double work[318],ttime,param[1];
    int vintgerr,which,ferr,i;

    sdgentime(&i);
    if (i != 152551) {
        sdseterr(54,42);
    }
    param[0] = ctol;
    ttime = *time;
    if (*flag != 0) {
        sdmotfunc(ttime,state,dstate,param,&ferr);
        step = dt;
        *flag = 0;
    }
    if (step <= 0.) {
        step = dt;
    }
    sdvinteg(sdmotfunc,&ttime,state,dstate,param,dt,&step,53,tol,work,&vintgerr,
      &which);
    *time = ttime;
    *err = vintgerr;
}

/* This routine performs state integration with a fixed-step integrator. */

void sdfmotion(double *time,
    double state[53],
    double dstate[53],
    double dt,
    double ctol,
    int *flag,
    double *errest,
    int *err)
{
    double work[212],ttime,param[1];
    int ferr,i;

    sdgentime(&i);
    if (i != 152551) {
        sdseterr(55,42);
    }
    param[0] = ctol;
    *err = 0;
    ttime = *time;
    if (*flag != 0) {
        sdmotfunc(ttime,state,dstate,param,&ferr);
        *flag = 0;
    }
    sdfinteg(sdmotfunc,&ttime,state,dstate,param,dt,53,work,errest,&ferr);
    if (ferr != 0) {
        *err = 1;
    }
    *time = ttime;
}
