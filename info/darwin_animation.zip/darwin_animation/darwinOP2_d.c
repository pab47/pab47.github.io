/*
Generated 01-Mar-2006 15:25:51 by SD/FAST, Kane's formulation
(sdfast B.2.8 #30123) on machine ID unknown
Copyright (c) 1990-1997 Symbolic Dynamics, Inc.
Copyright (c) 1990-1997 Parametric Technology Corp.
RESTRICTED RIGHTS LEGEND: Use, duplication, or disclosure by the U.S.
Government is subject to restrictions as set forth in subparagraph
(c)(1)(ii) of the Rights in Technical Data and Computer Software
clause at DFARS 52.227-7013 and similar clauses in the FAR and NASA
FAR Supplement.  Symbolic Dynamics, Inc., Mountain View, CA 94041


ROADMAP (darwinOP2.sd)

Bodies              Inb
No  Name            body Joint type  Coords q
--- --------------- ---- ----------- ----------------
 -1 $ground                                          
  0 TORSO            -1  Sixdof        0   1   2 
                         ...           3   4   5  26 
  1 R_SHOULDER_PITCH                                  
                      0  Pin           6             
  2 L_SHOULDER_PITCH                                  
                      0  Pin           7             
  3 R_SHOULDER_ROLL   1  Pin           8             
  4 L_SHOULDER_ROLL   2  Pin           9             
  5 R_ELBOW_YAW       3  Pin          10             
  6 L_ELBOW_YAW       4  Pin          11             
  7 R_HIP_YAW         0  Pin          12             
  8 L_HIP_YAW         0  Pin          13             
  9 R_HIP_ROLL        7  Pin          14             
 10 L_HIP_ROLL        8  Pin          15             
 11 R_HIP_PITCH       9  Pin          16             
 12 L_HIP_PITCH      10  Pin          17             
 13 R_KNEE_PITCH     11  Pin          18             
 14 L_KNEE_PITCH     12  Pin          19             
 15 R_ANKLE_PITCH    13  Pin          20             
 16 L_ANKLE_PITCH    14  Pin          21             
 17 R_ANKLE_ROLL     15  Pin          22             
 18 L_ANKLE_ROLL     16  Pin          23             
 19 HEAD_YAW          0  Pin          24             
 20 HEAD_PITCH       19  Pin          25             

*/
#include <math.h>
#include <stdio.h>

typedef struct {
    int ground_,nbod_,ndof_,ncons_,nloop_,nldof_,nloopc_,nball_,nlball_,npres_,
      nuser_;
    int jtype_[21],inb_[21],outb_[21],njntdof_[21],njntc_[21],njntp_[21],firstq_
      [21],ballq_[21],firstm_[21],firstp_[21];
    int trans_[26];
} sdgtopo_t;
#define ground (sdgtopo.ground_)
#define nbod (sdgtopo.nbod_)
#define ndof (sdgtopo.ndof_)
#define ncons (sdgtopo.ncons_)
#define nloop (sdgtopo.nloop_)
#define nldof (sdgtopo.nldof_)
#define nloopc (sdgtopo.nloopc_)
#define nball (sdgtopo.nball_)
#define nlball (sdgtopo.nlball_)
#define npres (sdgtopo.npres_)
#define nuser (sdgtopo.nuser_)
#define jtype (sdgtopo.jtype_)
#define inb (sdgtopo.inb_)
#define outb (sdgtopo.outb_)
#define njntdof (sdgtopo.njntdof_)
#define njntc (sdgtopo.njntc_)
#define njntp (sdgtopo.njntp_)
#define firstq (sdgtopo.firstq_)
#define ballq (sdgtopo.ballq_)
#define firstm (sdgtopo.firstm_)
#define firstp (sdgtopo.firstp_)
#define trans (sdgtopo.trans_)

typedef struct {
    double grav_[3],mk_[21],ik_[21][3][3],pin_[26][3];
    double rk_[21][3],ri_[21][3],pres_[26],stabvel_,stabpos_;
    int mfrcflg_,roustate_,vpkflg_,inerflg_,mmflg_,mmlduflg_,wwflg_,ltauflg_,
      fs0flg_,ii_,mmap_[26];
    int gravq_[3],mkq_[21],ikq_[21][3][3],pinq_[26][3],rkq_[21][3],riq_[21][3],
      presq_[26],stabvelq_,stabposq_;
    double mtot_,psmkg_,rhead_[21][3],rcom_[21][3],mkrcomt_[21][3][3],psikg_[3][
      3],psrcomg_[3],psrkg_[3],psrig_[3],psmk_[26],psik_[26][3][3],psrcom_[26][3
      ],psrk_[26][3],psri_[26][3];
} sdginput_t;
#define grav (sdginput.grav_)
#define mk (sdginput.mk_)
#define ik (sdginput.ik_)
#define pin (sdginput.pin_)
#define rk (sdginput.rk_)
#define ri (sdginput.ri_)
#define pres (sdginput.pres_)
#define stabvel (sdginput.stabvel_)
#define stabpos (sdginput.stabpos_)
#define rhead (sdginput.rhead_)
#define rcom (sdginput.rcom_)
#define psrcomg (sdginput.psrcomg_)
#define psrcom (sdginput.psrcom_)
#define mkrcomt (sdginput.mkrcomt_)
#define psmk (sdginput.psmk_)
#define psik (sdginput.psik_)
#define psrk (sdginput.psrk_)
#define psri (sdginput.psri_)
#define psmkg (sdginput.psmkg_)
#define psikg (sdginput.psikg_)
#define psrkg (sdginput.psrkg_)
#define psrig (sdginput.psrig_)
#define mtot (sdginput.mtot_)
#define mfrcflg (sdginput.mfrcflg_)
#define roustate (sdginput.roustate_)
#define vpkflg (sdginput.vpkflg_)
#define inerflg (sdginput.inerflg_)
#define mmflg (sdginput.mmflg_)
#define mmlduflg (sdginput.mmlduflg_)
#define wwflg (sdginput.wwflg_)
#define ltauflg (sdginput.ltauflg_)
#define fs0flg (sdginput.fs0flg_)
#define ii (sdginput.ii_)
#define mmap (sdginput.mmap_)
#define gravq (sdginput.gravq_)
#define mkq (sdginput.mkq_)
#define ikq (sdginput.ikq_)
#define pinq (sdginput.pinq_)
#define rkq (sdginput.rkq_)
#define riq (sdginput.riq_)
#define presq (sdginput.presq_)
#define stabvelq (sdginput.stabvelq_)
#define stabposq (sdginput.stabposq_)

typedef struct {
    double curtim_,q_[27],qn_[27],u_[26],cnk_[26][3][3],cnb_[21][3][3];
    double rnk_[26][3],vnk_[26][3],wk_[26][3],rnb_[21][3],vnb_[21][3],wb_[21][3]
      ,wbrcom_[21][3],com_[3],rnkg_[3];
    double Cik_[26][3][3],rikt_[26][3][3],Iko_[26][3][3],mkrk_[26][3][3],Cib_[21
      ][3][3];
    double Wkk_[26][3],Vkk_[26][3],dik_[26][3],rpp_[26][3],rpk_[26][3],rik_[26][
      3],rik2_[26][3];
    double rpri_[26][3],Wik_[26][3],Vik_[26][3],Wirk_[26][3],rkWkk_[26][3],
      Wkrpk_[26][3],VikWkr_[26][3];
    double perr_[1],verr_[1],aerr_[1],mult_[1],ufk_[21][3],utk_[21][3],mfk_[21][
      3],mtk_[21][3];
    double utau_[26],mtau_[26],uacc_[26],uvel_[26],upos_[27];
    double s6_,c6_,s7_,c7_,s8_,c8_,s9_,c9_,s10_,c10_,s11_,c11_,s12_,c12_,s13_,
      c13_,s14_,c14_,s15_,c15_,s16_,c16_,s17_,c17_,s18_,c18_,s19_,c19_,s20_,c20_
      ,s21_,c21_,s22_,c22_,s23_,c23_,s24_,c24_,s25_,c25_;
} sdgstate_t;
#define curtim (sdgstate.curtim_)
#define q (sdgstate.q_)
#define qn (sdgstate.qn_)
#define u (sdgstate.u_)
#define cnk (sdgstate.cnk_)
#define cnb (sdgstate.cnb_)
#define rnkg (sdgstate.rnkg_)
#define rnk (sdgstate.rnk_)
#define rnb (sdgstate.rnb_)
#define vnk (sdgstate.vnk_)
#define vnb (sdgstate.vnb_)
#define wk (sdgstate.wk_)
#define wb (sdgstate.wb_)
#define com (sdgstate.com_)
#define Cik (sdgstate.Cik_)
#define Cib (sdgstate.Cib_)
#define rikt (sdgstate.rikt_)
#define Iko (sdgstate.Iko_)
#define mkrk (sdgstate.mkrk_)
#define Wkk (sdgstate.Wkk_)
#define Vkk (sdgstate.Vkk_)
#define dik (sdgstate.dik_)
#define rpp (sdgstate.rpp_)
#define rpk (sdgstate.rpk_)
#define rik (sdgstate.rik_)
#define rik2 (sdgstate.rik2_)
#define rpri (sdgstate.rpri_)
#define Wik (sdgstate.Wik_)
#define Vik (sdgstate.Vik_)
#define Wirk (sdgstate.Wirk_)
#define rkWkk (sdgstate.rkWkk_)
#define Wkrpk (sdgstate.Wkrpk_)
#define VikWkr (sdgstate.VikWkr_)
#define wbrcom (sdgstate.wbrcom_)
#define perr (sdgstate.perr_)
#define verr (sdgstate.verr_)
#define aerr (sdgstate.aerr_)
#define mult (sdgstate.mult_)
#define ufk (sdgstate.ufk_)
#define utk (sdgstate.utk_)
#define utau (sdgstate.utau_)
#define mfk (sdgstate.mfk_)
#define mtk (sdgstate.mtk_)
#define mtau (sdgstate.mtau_)
#define uacc (sdgstate.uacc_)
#define uvel (sdgstate.uvel_)
#define upos (sdgstate.upos_)
#define s6 (sdgstate.s6_)
#define c6 (sdgstate.c6_)
#define s7 (sdgstate.s7_)
#define c7 (sdgstate.c7_)
#define s8 (sdgstate.s8_)
#define c8 (sdgstate.c8_)
#define s9 (sdgstate.s9_)
#define c9 (sdgstate.c9_)
#define s10 (sdgstate.s10_)
#define c10 (sdgstate.c10_)
#define s11 (sdgstate.s11_)
#define c11 (sdgstate.c11_)
#define s12 (sdgstate.s12_)
#define c12 (sdgstate.c12_)
#define s13 (sdgstate.s13_)
#define c13 (sdgstate.c13_)
#define s14 (sdgstate.s14_)
#define c14 (sdgstate.c14_)
#define s15 (sdgstate.s15_)
#define c15 (sdgstate.c15_)
#define s16 (sdgstate.s16_)
#define c16 (sdgstate.c16_)
#define s17 (sdgstate.s17_)
#define c17 (sdgstate.c17_)
#define s18 (sdgstate.s18_)
#define c18 (sdgstate.c18_)
#define s19 (sdgstate.s19_)
#define c19 (sdgstate.c19_)
#define s20 (sdgstate.s20_)
#define c20 (sdgstate.c20_)
#define s21 (sdgstate.s21_)
#define c21 (sdgstate.c21_)
#define s22 (sdgstate.s22_)
#define c22 (sdgstate.c22_)
#define s23 (sdgstate.s23_)
#define c23 (sdgstate.c23_)
#define s24 (sdgstate.s24_)
#define c24 (sdgstate.c24_)
#define s25 (sdgstate.s25_)
#define c25 (sdgstate.c25_)

typedef struct {
    double fs0_[26],qdot_[27],Otk_[26][3],Atk_[26][3],AiOiWi_[26][3],Fstar_[26][
      3];
    double Tstar_[26][3],Fstark_[26][3],Tstark_[26][3],IkWk_[26][3],WkIkWk_[26][
      3],gk_[26][3],IkbWk_[21][3],WkIkbWk_[21][3];
    double w0w0_[21],w1w1_[21],w2w2_[21],w0w1_[21],w0w2_[21],w1w2_[21];
    double w00w11_[21],w00w22_[21],w11w22_[21],ww_[1][1],qraux_[1];
    double mm_[26][26],mlo_[26][26],mdi_[26],IkWpk_[26][26][3],works_[26],
      workss_[26][26];
    double Wpk_[26][26][3],Vpk_[26][26][3],VWri_[26][26][3];
    int wmap_[1],multmap_[1],jpvt_[1],wsiz_,wrank_;
} sdglhs_t;
#define qdot (sdglhs.qdot_)
#define Otk (sdglhs.Otk_)
#define Atk (sdglhs.Atk_)
#define AiOiWi (sdglhs.AiOiWi_)
#define Fstar (sdglhs.Fstar_)
#define Tstar (sdglhs.Tstar_)
#define fs0 (sdglhs.fs0_)
#define Fstark (sdglhs.Fstark_)
#define Tstark (sdglhs.Tstark_)
#define IkWk (sdglhs.IkWk_)
#define IkbWk (sdglhs.IkbWk_)
#define WkIkWk (sdglhs.WkIkWk_)
#define WkIkbWk (sdglhs.WkIkbWk_)
#define gk (sdglhs.gk_)
#define w0w0 (sdglhs.w0w0_)
#define w1w1 (sdglhs.w1w1_)
#define w2w2 (sdglhs.w2w2_)
#define w0w1 (sdglhs.w0w1_)
#define w0w2 (sdglhs.w0w2_)
#define w1w2 (sdglhs.w1w2_)
#define w00w11 (sdglhs.w00w11_)
#define w00w22 (sdglhs.w00w22_)
#define w11w22 (sdglhs.w11w22_)
#define ww (sdglhs.ww_)
#define qraux (sdglhs.qraux_)
#define mm (sdglhs.mm_)
#define mlo (sdglhs.mlo_)
#define mdi (sdglhs.mdi_)
#define IkWpk (sdglhs.IkWpk_)
#define works (sdglhs.works_)
#define workss (sdglhs.workss_)
#define Wpk (sdglhs.Wpk_)
#define Vpk (sdglhs.Vpk_)
#define VWri (sdglhs.VWri_)
#define wmap (sdglhs.wmap_)
#define multmap (sdglhs.multmap_)
#define jpvt (sdglhs.jpvt_)
#define wsiz (sdglhs.wsiz_)
#define wrank (sdglhs.wrank_)

typedef struct {
    double fs_[26],udot_[26],tauc_[26],dyad_[21][3][3],fc_[26][3],tc_[26][3];
    double ank_[26][3],onk_[26][3],Onkb_[26][3],AOnkri_[26][3],Ankb_[26][3],
      AnkAtk_[26][3],anb_[21][3],onb_[21][3],dyrcom_[21][3];
    double ffk_[26][3],ttk_[26][3],fccikt_[26][3],ffkb_[21][3],ttkb_[21][3];
} sdgrhs_t;
#define fs (sdgrhs.fs_)
#define udot (sdgrhs.udot_)
#define ank (sdgrhs.ank_)
#define anb (sdgrhs.anb_)
#define onk (sdgrhs.onk_)
#define onb (sdgrhs.onb_)
#define Onkb (sdgrhs.Onkb_)
#define AOnkri (sdgrhs.AOnkri_)
#define Ankb (sdgrhs.Ankb_)
#define AnkAtk (sdgrhs.AnkAtk_)
#define dyrcom (sdgrhs.dyrcom_)
#define ffk (sdgrhs.ffk_)
#define ttk (sdgrhs.ttk_)
#define fccikt (sdgrhs.fccikt_)
#define ffkb (sdgrhs.ffkb_)
#define ttkb (sdgrhs.ttkb_)
#define dyad (sdgrhs.dyad_)
#define fc (sdgrhs.fc_)
#define tc (sdgrhs.tc_)
#define tauc (sdgrhs.tauc_)

typedef struct {
    double temp_[3000],tmat1_[3][3],tmat2_[3][3],tvec1_[3],tvec2_[3],tvec3_[3],
      tvec4_[3],tvec5_[3];
    double tsc1_,tsc2_,tsc3_;
} sdgtemp_t;
#define temp (sdgtemp.temp_)
#define tmat1 (sdgtemp.tmat1_)
#define tmat2 (sdgtemp.tmat2_)
#define tvec1 (sdgtemp.tvec1_)
#define tvec2 (sdgtemp.tvec2_)
#define tvec3 (sdgtemp.tvec3_)
#define tvec4 (sdgtemp.tvec4_)
#define tvec5 (sdgtemp.tvec5_)
#define tsc1 (sdgtemp.tsc1_)
#define tsc2 (sdgtemp.tsc2_)
#define tsc3 (sdgtemp.tsc3_)

sdgtopo_t sdgtopo = {
/*  Topological information
*/
    /* ground */ 1,
    /* nbod */ 21,
    /* ndof */ 26,
    /* ncons */ 0,
    /* nloop */ 0,
    /* nldof */ 0,
    /* nloopc */ 0,
    /* nball */ 1,
    /* nlball */ 0,
    /* npres */ 0,
    /* nuser */ 0,
    /* jtype[0] */ 6,
    /* jtype[1] */ 1,
    /* jtype[2] */ 1,
    /* jtype[3] */ 1,
    /* jtype[4] */ 1,
    /* jtype[5] */ 1,
    /* jtype[6] */ 1,
    /* jtype[7] */ 1,
    /* jtype[8] */ 1,
    /* jtype[9] */ 1,
    /* jtype[10] */ 1,
    /* jtype[11] */ 1,
    /* jtype[12] */ 1,
    /* jtype[13] */ 1,
    /* jtype[14] */ 1,
    /* jtype[15] */ 1,
    /* jtype[16] */ 1,
    /* jtype[17] */ 1,
    /* jtype[18] */ 1,
    /* jtype[19] */ 1,
    /* jtype[20] */ 1,
    /* inb[0] */ -1,
    /* inb[1] */ 0,
    /* inb[2] */ 0,
    /* inb[3] */ 1,
    /* inb[4] */ 2,
    /* inb[5] */ 3,
    /* inb[6] */ 4,
    /* inb[7] */ 0,
    /* inb[8] */ 0,
    /* inb[9] */ 7,
    /* inb[10] */ 8,
    /* inb[11] */ 9,
    /* inb[12] */ 10,
    /* inb[13] */ 11,
    /* inb[14] */ 12,
    /* inb[15] */ 13,
    /* inb[16] */ 14,
    /* inb[17] */ 15,
    /* inb[18] */ 16,
    /* inb[19] */ 0,
    /* inb[20] */ 19,
    /* outb[0] */ 0,
    /* outb[1] */ 1,
    /* outb[2] */ 2,
    /* outb[3] */ 3,
    /* outb[4] */ 4,
    /* outb[5] */ 5,
    /* outb[6] */ 6,
    /* outb[7] */ 7,
    /* outb[8] */ 8,
    /* outb[9] */ 9,
    /* outb[10] */ 10,
    /* outb[11] */ 11,
    /* outb[12] */ 12,
    /* outb[13] */ 13,
    /* outb[14] */ 14,
    /* outb[15] */ 15,
    /* outb[16] */ 16,
    /* outb[17] */ 17,
    /* outb[18] */ 18,
    /* outb[19] */ 19,
    /* outb[20] */ 20,
    /* njntdof[0] */ 6,
    /* njntdof[1] */ 1,
    /* njntdof[2] */ 1,
    /* njntdof[3] */ 1,
    /* njntdof[4] */ 1,
    /* njntdof[5] */ 1,
    /* njntdof[6] */ 1,
    /* njntdof[7] */ 1,
    /* njntdof[8] */ 1,
    /* njntdof[9] */ 1,
    /* njntdof[10] */ 1,
    /* njntdof[11] */ 1,
    /* njntdof[12] */ 1,
    /* njntdof[13] */ 1,
    /* njntdof[14] */ 1,
    /* njntdof[15] */ 1,
    /* njntdof[16] */ 1,
    /* njntdof[17] */ 1,
    /* njntdof[18] */ 1,
    /* njntdof[19] */ 1,
    /* njntdof[20] */ 1,
    /* njntc[0] */ 0,
    /* njntc[1] */ 0,
    /* njntc[2] */ 0,
    /* njntc[3] */ 0,
    /* njntc[4] */ 0,
    /* njntc[5] */ 0,
    /* njntc[6] */ 0,
    /* njntc[7] */ 0,
    /* njntc[8] */ 0,
    /* njntc[9] */ 0,
    /* njntc[10] */ 0,
    /* njntc[11] */ 0,
    /* njntc[12] */ 0,
    /* njntc[13] */ 0,
    /* njntc[14] */ 0,
    /* njntc[15] */ 0,
    /* njntc[16] */ 0,
    /* njntc[17] */ 0,
    /* njntc[18] */ 0,
    /* njntc[19] */ 0,
    /* njntc[20] */ 0,
    /* njntp[0] */ 0,
    /* njntp[1] */ 0,
    /* njntp[2] */ 0,
    /* njntp[3] */ 0,
    /* njntp[4] */ 0,
    /* njntp[5] */ 0,
    /* njntp[6] */ 0,
    /* njntp[7] */ 0,
    /* njntp[8] */ 0,
    /* njntp[9] */ 0,
    /* njntp[10] */ 0,
    /* njntp[11] */ 0,
    /* njntp[12] */ 0,
    /* njntp[13] */ 0,
    /* njntp[14] */ 0,
    /* njntp[15] */ 0,
    /* njntp[16] */ 0,
    /* njntp[17] */ 0,
    /* njntp[18] */ 0,
    /* njntp[19] */ 0,
    /* njntp[20] */ 0,
    /* firstq[0] */ 0,
    /* firstq[1] */ 6,
    /* firstq[2] */ 7,
    /* firstq[3] */ 8,
    /* firstq[4] */ 9,
    /* firstq[5] */ 10,
    /* firstq[6] */ 11,
    /* firstq[7] */ 12,
    /* firstq[8] */ 13,
    /* firstq[9] */ 14,
    /* firstq[10] */ 15,
    /* firstq[11] */ 16,
    /* firstq[12] */ 17,
    /* firstq[13] */ 18,
    /* firstq[14] */ 19,
    /* firstq[15] */ 20,
    /* firstq[16] */ 21,
    /* firstq[17] */ 22,
    /* firstq[18] */ 23,
    /* firstq[19] */ 24,
    /* firstq[20] */ 25,
    /* ballq[0] */ 26,
    /* ballq[1] */ -104,
    /* ballq[2] */ -104,
    /* ballq[3] */ -104,
    /* ballq[4] */ -104,
    /* ballq[5] */ -104,
    /* ballq[6] */ -104,
    /* ballq[7] */ -104,
    /* ballq[8] */ -104,
    /* ballq[9] */ -104,
    /* ballq[10] */ -104,
    /* ballq[11] */ -104,
    /* ballq[12] */ -104,
    /* ballq[13] */ -104,
    /* ballq[14] */ -104,
    /* ballq[15] */ -104,
    /* ballq[16] */ -104,
    /* ballq[17] */ -104,
    /* ballq[18] */ -104,
    /* ballq[19] */ -104,
    /* ballq[20] */ -104,
    /* firstm[0] */ -1,
    /* firstm[1] */ -1,
    /* firstm[2] */ -1,
    /* firstm[3] */ -1,
    /* firstm[4] */ -1,
    /* firstm[5] */ -1,
    /* firstm[6] */ -1,
    /* firstm[7] */ -1,
    /* firstm[8] */ -1,
    /* firstm[9] */ -1,
    /* firstm[10] */ -1,
    /* firstm[11] */ -1,
    /* firstm[12] */ -1,
    /* firstm[13] */ -1,
    /* firstm[14] */ -1,
    /* firstm[15] */ -1,
    /* firstm[16] */ -1,
    /* firstm[17] */ -1,
    /* firstm[18] */ -1,
    /* firstm[19] */ -1,
    /* firstm[20] */ -1,
    /* firstp[0] */ -1,
    /* firstp[1] */ -1,
    /* firstp[2] */ -1,
    /* firstp[3] */ -1,
    /* firstp[4] */ -1,
    /* firstp[5] */ -1,
    /* firstp[6] */ -1,
    /* firstp[7] */ -1,
    /* firstp[8] */ -1,
    /* firstp[9] */ -1,
    /* firstp[10] */ -1,
    /* firstp[11] */ -1,
    /* firstp[12] */ -1,
    /* firstp[13] */ -1,
    /* firstp[14] */ -1,
    /* firstp[15] */ -1,
    /* firstp[16] */ -1,
    /* firstp[17] */ -1,
    /* firstp[18] */ -1,
    /* firstp[19] */ -1,
    /* firstp[20] */ -1,
    /* trans[0] */ 1,
    /* trans[1] */ 1,
    /* trans[2] */ 1,
    /* trans[3] */ 0,
    /* trans[4] */ 0,
    /* trans[5] */ 0,
    /* trans[6] */ 0,
    /* trans[7] */ 0,
    /* trans[8] */ 0,
    /* trans[9] */ 0,
    /* trans[10] */ 0,
    /* trans[11] */ 0,
    /* trans[12] */ 0,
    /* trans[13] */ 0,
    /* trans[14] */ 0,
    /* trans[15] */ 0,
    /* trans[16] */ 0,
    /* trans[17] */ 0,
    /* trans[18] */ 0,
    /* trans[19] */ 0,
    /* trans[20] */ 0,
    /* trans[21] */ 0,
    /* trans[22] */ 0,
    /* trans[23] */ 0,
    /* trans[24] */ 0,
    /* trans[25] */ 0,
};
sdginput_t sdginput = {
/* Model parameters from the input file */

/* gravity */
    /* grav[0] */ 0.,
    /* grav[1] */ 0.,
    /* grav[2] */ -9.8,

/* mass */
    /* mk[0] */ .97559947,
    /* mk[1] */ .025913024,
    /* mk[2] */ .025913024,
    /* mk[3] */ .16837715,
    /* mk[4] */ .16837715,
    /* mk[5] */ .059288504,
    /* mk[6] */ .059288504,
    /* mk[7] */ .027069195,
    /* mk[8] */ .027069195,
    /* mk[9] */ .16710792,
    /* mk[10] */ .16710792,
    /* mk[11] */ .11904336,
    /* mk[12] */ .11904336,
    /* mk[13] */ .070309794,
    /* mk[14] */ .070309794,
    /* mk[15] */ .16710792,
    /* mk[16] */ .16710792,
    /* mk[17] */ .079446226,
    /* mk[18] */ .079446226,
    /* mk[19] */ .024357719,
    /* mk[20] */ .15804192,

/* inertia */
    /* ik[0][0][0] */ .0053316425,
    /* ik[0][0][1] */ .0020318174,
    /* ik[0][0][2] */ .00016417863,
    /* ik[0][1][0] */ .0020318174,
    /* ik[0][1][1] */ .00310818,
    /* ik[0][1][2] */ -.00025460189,
    /* ik[0][2][0] */ .00016417863,
    /* ik[0][2][1] */ -.00025460189,
    /* ik[0][2][2] */ .0063787776,
    /* ik[1][0][0] */ 5.476798e-6,
    /* ik[1][0][1] */ -4.51743e-7,
    /* ik[1][0][2] */ 3.3407e-7,
    /* ik[1][1][0] */ -4.51743e-7,
    /* ik[1][1][1] */ 9.775817e-6,
    /* ik[1][1][2] */ 1.691184e-6,
    /* ik[1][2][0] */ 3.3407e-7,
    /* ik[1][2][1] */ 1.691184e-6,
    /* ik[1][2][2] */ 1.0511104e-5,
    /* ik[2][0][0] */ 5.476798e-6,
    /* ik[2][0][1] */ -4.51743e-7,
    /* ik[2][0][2] */ 3.3407e-7,
    /* ik[2][1][0] */ -4.51743e-7,
    /* ik[2][1][1] */ 9.775817e-6,
    /* ik[2][1][2] */ 1.691184e-6,
    /* ik[2][2][0] */ 3.3407e-7,
    /* ik[2][2][1] */ 1.691184e-6,
    /* ik[2][2][2] */ 1.0511104e-5,
    /* ik[3][0][0] */ .0001134083,
    /* ik[3][0][1] */ -1.825145e-6,
    /* ik[3][0][2] */ -8.81434e-7,
    /* ik[3][1][0] */ -1.825145e-6,
    /* ik[3][1][1] */ 3.8088441e-5,
    /* ik[3][1][2] */ 2.081263e-6,
    /* ik[3][2][0] */ -8.81434e-7,
    /* ik[3][2][1] */ 2.081263e-6,
    /* ik[3][2][2] */ .00012202839,
    /* ik[4][0][0] */ .0001134083,
    /* ik[4][0][1] */ -1.825145e-6,
    /* ik[4][0][2] */ -8.81434e-7,
    /* ik[4][1][0] */ -1.825145e-6,
    /* ik[4][1][1] */ 3.8088441e-5,
    /* ik[4][1][2] */ 2.081263e-6,
    /* ik[4][2][0] */ -8.81434e-7,
    /* ik[4][2][1] */ 2.081263e-6,
    /* ik[4][2][2] */ .00012202839,
    /* ik[5][0][0] */ 8.684545e-5,
    /* ik[5][0][1] */ 6.485593e-6,
    /* ik[5][0][2] */ 4.36361e-7,
    /* ik[5][1][0] */ 6.485593e-6,
    /* ik[5][1][1] */ 2.1192085e-5,
    /* ik[5][1][2] */ -5.302031e-6,
    /* ik[5][2][0] */ 4.36361e-7,
    /* ik[5][2][1] */ -5.302031e-6,
    /* ik[5][2][2] */ 8.6855267e-5,
    /* ik[6][0][0] */ 8.684545e-5,
    /* ik[6][0][1] */ 6.485593e-6,
    /* ik[6][0][2] */ 4.36361e-7,
    /* ik[6][1][0] */ 6.485593e-6,
    /* ik[6][1][1] */ 2.1192085e-5,
    /* ik[6][1][2] */ -5.302031e-6,
    /* ik[6][2][0] */ 4.36361e-7,
    /* ik[6][2][1] */ -5.302031e-6,
    /* ik[6][2][2] */ 8.6855267e-5,
    /* ik[7][0][0] */ 6.182553e-6,
    /* ik[7][0][1] */ 0.,
    /* ik[7][0][2] */ -7.335e-7,
    /* ik[7][1][0] */ 0.,
    /* ik[7][1][1] */ 1.5019148e-5,
    /* ik[7][1][2] */ 0.,
    /* ik[7][2][0] */ -7.335e-7,
    /* ik[7][2][1] */ 0.,
    /* ik[7][2][2] */ 1.1328768e-5,
    /* ik[8][0][0] */ 6.182553e-6,
    /* ik[8][0][1] */ 0.,
    /* ik[8][0][2] */ -7.335e-7,
    /* ik[8][1][0] */ 0.,
    /* ik[8][1][1] */ 1.5019148e-5,
    /* ik[8][1][2] */ 0.,
    /* ik[8][2][0] */ -7.335e-7,
    /* ik[8][2][1] */ 0.,
    /* ik[8][2][2] */ 1.1328768e-5,
    /* ik[9][0][0] */ 4.1877668e-5,
    /* ik[9][0][1] */ 8.11439e-7,
    /* ik[9][0][2] */ -7.163548e-6,
    /* ik[9][1][0] */ 8.11439e-7,
    /* ik[9][1][1] */ .00012259691,
    /* ik[9][1][2] */ 7.11275e-7,
    /* ik[9][2][0] */ -7.163548e-6,
    /* ik[9][2][1] */ 7.11275e-7,
    /* ik[9][2][2] */ .00011066637,
    /* ik[10][0][0] */ 4.1877668e-5,
    /* ik[10][0][1] */ 8.11439e-7,
    /* ik[10][0][2] */ -7.163548e-6,
    /* ik[10][1][0] */ 8.11439e-7,
    /* ik[10][1][1] */ .00012259691,
    /* ik[10][1][2] */ 7.11275e-7,
    /* ik[10][2][0] */ -7.163548e-6,
    /* ik[10][2][1] */ 7.11275e-7,
    /* ik[10][2][2] */ .00011066637,
    /* ik[11][0][0] */ .00011493509,
    /* ik[11][0][1] */ -2.1223e-7,
    /* ik[11][0][2] */ -1.947402e-6,
    /* ik[11][1][0] */ -2.1223e-7,
    /* ik[11][1][1] */ 9.7950272e-5,
    /* ik[11][1][2] */ 1.211937e-6,
    /* ik[11][2][0] */ -1.947402e-6,
    /* ik[11][2][1] */ 1.211937e-6,
    /* ik[11][2][2] */ 3.2848287e-5,
    /* ik[12][0][0] */ .00011493509,
    /* ik[12][0][1] */ -2.1223e-7,
    /* ik[12][0][2] */ -1.947402e-6,
    /* ik[12][1][0] */ -2.1223e-7,
    /* ik[12][1][1] */ 9.7950272e-5,
    /* ik[12][1][2] */ 1.211937e-6,
    /* ik[12][2][0] */ -1.947402e-6,
    /* ik[12][2][1] */ 1.211937e-6,
    /* ik[12][2][2] */ 3.2848287e-5,
    /* ik[13][0][0] */ .00011351516,
    /* ik[13][0][1] */ -2.39921e-7,
    /* ik[13][0][2] */ -1.2858493e-5,
    /* ik[13][1][0] */ -2.39921e-7,
    /* ik[13][1][1] */ 9.3369608e-5,
    /* ik[13][1][2] */ -9.35674e-7,
    /* ik[13][2][0] */ -1.2858493e-5,
    /* ik[13][2][1] */ -9.35674e-7,
    /* ik[13][2][2] */ 4.6295534e-5,
    /* ik[14][0][0] */ .00011351516,
    /* ik[14][0][1] */ -2.39921e-7,
    /* ik[14][0][2] */ -1.2858493e-5,
    /* ik[14][1][0] */ -2.39921e-7,
    /* ik[14][1][1] */ 9.3369608e-5,
    /* ik[14][1][2] */ -9.35674e-7,
    /* ik[14][2][0] */ -1.2858493e-5,
    /* ik[14][2][1] */ -9.35674e-7,
    /* ik[14][2][2] */ 4.6295534e-5,
    /* ik[15][0][0] */ 4.1871103e-5,
    /* ik[15][0][1] */ -3.93222e-7,
    /* ik[15][0][2] */ 7.077012e-6,
    /* ik[15][1][0] */ -3.93222e-7,
    /* ik[15][1][1] */ .00012079175,
    /* ik[15][1][2] */ -7.97811e-7,
    /* ik[15][2][0] */ 7.077012e-6,
    /* ik[15][2][1] */ -7.97811e-7,
    /* ik[15][2][2] */ .00010885465,
    /* ik[16][0][0] */ 4.1871103e-5,
    /* ik[16][0][1] */ -3.93222e-7,
    /* ik[16][0][2] */ 7.077012e-6,
    /* ik[16][1][0] */ -3.93222e-7,
    /* ik[16][1][1] */ .00012079175,
    /* ik[16][1][2] */ -7.97811e-7,
    /* ik[16][2][0] */ 7.077012e-6,
    /* ik[16][2][1] */ -7.97811e-7,
    /* ik[16][2][2] */ .00010885465,
    /* ik[17][0][0] */ 3.5840758e-5,
    /* ik[17][0][1] */ 2.18696e-7,
    /* ik[17][0][2] */ 9.76205e-7,
    /* ik[17][1][0] */ 2.18696e-7,
    /* ik[17][1][1] */ 6.8325629e-5,
    /* ik[17][1][2] */ 2.533046e-6,
    /* ik[17][2][0] */ 9.76205e-7,
    /* ik[17][2][1] */ 2.533046e-6,
    /* ik[17][2][2] */ 8.7890505e-5,
    /* ik[18][0][0] */ 3.5840758e-5,
    /* ik[18][0][1] */ 2.18696e-7,
    /* ik[18][0][2] */ 9.76205e-7,
    /* ik[18][1][0] */ 2.18696e-7,
    /* ik[18][1][1] */ 6.8325629e-5,
    /* ik[18][1][2] */ 2.533046e-6,
    /* ik[18][2][0] */ 9.76205e-7,
    /* ik[18][2][1] */ 2.533046e-6,
    /* ik[18][2][2] */ 8.7890505e-5,
    /* ik[19][0][0] */ 1.1379812e-5,
    /* ik[19][0][1] */ -2.4729e-8,
    /* ik[19][0][2] */ -1.92231e-7,
    /* ik[19][1][0] */ -2.4729e-8,
    /* ik[19][1][1] */ 5.141112e-6,
    /* ik[19][1][2] */ -5.75303e-7,
    /* ik[19][2][0] */ -1.92231e-7,
    /* ik[19][2][1] */ -5.75303e-7,
    /* ik[19][2][2] */ 8.191574e-6,
    /* ik[20][0][0] */ .00011583601,
    /* ik[20][0][1] */ -7.646e-8,
    /* ik[20][0][2] */ 1.2199205e-5,
    /* ik[20][1][0] */ -7.646e-8,
    /* ik[20][1][1] */ .0001239683,
    /* ik[20][1][2] */ 7.84944e-7,
    /* ik[20][2][0] */ 1.2199205e-5,
    /* ik[20][2][1] */ 7.84944e-7,
    /* ik[20][2][2] */ .00011783781,

/* tree hinge axis vectors */
    /* pin[0][0] */ 1.,
    /* pin[0][1] */ 0.,
    /* pin[0][2] */ 0.,
    /* pin[1][0] */ 0.,
    /* pin[1][1] */ 1.,
    /* pin[1][2] */ 0.,
    /* pin[2][0] */ 0.,
    /* pin[2][1] */ 0.,
    /* pin[2][2] */ 1.,
    /* pin[3][0] */ 0.,
    /* pin[3][1] */ 0.,
    /* pin[3][2] */ 0.,
    /* pin[4][0] */ 0.,
    /* pin[4][1] */ 0.,
    /* pin[4][2] */ 0.,
    /* pin[5][0] */ 0.,
    /* pin[5][1] */ 0.,
    /* pin[5][2] */ 0.,
    /* pin[6][0] */ 0.,
    /* pin[6][1] */ -1.,
    /* pin[6][2] */ 0.,
    /* pin[7][0] */ 0.,
    /* pin[7][1] */ -1.,
    /* pin[7][2] */ 0.,
    /* pin[8][0] */ -1.,
    /* pin[8][1] */ 0.,
    /* pin[8][2] */ 0.,
    /* pin[9][0] */ 1.,
    /* pin[9][1] */ 0.,
    /* pin[9][2] */ 0.,
    /* pin[10][0] */ 0.,
    /* pin[10][1] */ 0.,
    /* pin[10][2] */ -1.,
    /* pin[11][0] */ 0.,
    /* pin[11][1] */ 0.,
    /* pin[11][2] */ 1.,
    /* pin[12][0] */ 0.,
    /* pin[12][1] */ 0.,
    /* pin[12][2] */ -1.,
    /* pin[13][0] */ 0.,
    /* pin[13][1] */ 0.,
    /* pin[13][2] */ 1.,
    /* pin[14][0] */ -1.,
    /* pin[14][1] */ 0.,
    /* pin[14][2] */ 0.,
    /* pin[15][0] */ 1.,
    /* pin[15][1] */ 0.,
    /* pin[15][2] */ 0.,
    /* pin[16][0] */ 0.,
    /* pin[16][1] */ -1.,
    /* pin[16][2] */ 0.,
    /* pin[17][0] */ 0.,
    /* pin[17][1] */ -1.,
    /* pin[17][2] */ 0.,
    /* pin[18][0] */ 0.,
    /* pin[18][1] */ -1.,
    /* pin[18][2] */ 0.,
    /* pin[19][0] */ 0.,
    /* pin[19][1] */ -1.,
    /* pin[19][2] */ 0.,
    /* pin[20][0] */ 0.,
    /* pin[20][1] */ -1.,
    /* pin[20][2] */ 0.,
    /* pin[21][0] */ 0.,
    /* pin[21][1] */ -1.,
    /* pin[21][2] */ 0.,
    /* pin[22][0] */ -1.,
    /* pin[22][1] */ 0.,
    /* pin[22][2] */ 0.,
    /* pin[23][0] */ 1.,
    /* pin[23][1] */ 0.,
    /* pin[23][2] */ 0.,
    /* pin[24][0] */ 0.,
    /* pin[24][1] */ 0.,
    /* pin[24][2] */ 1.,
    /* pin[25][0] */ 0.,
    /* pin[25][1] */ -1.,
    /* pin[25][2] */ 0.,

/* tree bodytojoint vectors */
    /* rk[0][0] */ .014663084,
    /* rk[0][1] */ .0031158909,
    /* rk[0][2] */ -.082756305,
    /* rk[1][0] */ -.0013935747,
    /* rk[1][1] */ -.013522619,
    /* rk[1][2] */ .00573595,
    /* rk[2][0] */ -.0013935747,
    /* rk[2][1] */ .013522619,
    /* rk[2][2] */ .00573595,
    /* rk[3][0] */ -.00073406497,
    /* rk[3][1] */ .036239046,
    /* rk[3][2] */ -.00065978663,
    /* rk[4][0] */ -.00073406497,
    /* rk[4][1] */ -.036239046,
    /* rk[4][2] */ -.00065978663,
    /* rk[5][0] */ .01349008,
    /* rk[5][1] */ .045838199,
    /* rk[5][2] */ -.0066656445,
    /* rk[6][0] */ .01349008,
    /* rk[6][1] */ -.045838199,
    /* rk[6][2] */ -.0066656445,
    /* rk[7][0] */ -.00048013477,
    /* rk[7][1] */ 0.,
    /* rk[7][2] */ -.018437244,
    /* rk[8][0] */ -.00048013477,
    /* rk[8][1] */ 0.,
    /* rk[8][2] */ -.018437244,
    /* rk[9][0] */ .018242402,
    /* rk[9][1] */ 7.9982774e-5,
    /* rk[9][2] */ .013873116,
    /* rk[10][0] */ .018242402,
    /* rk[10][1] */ -7.9982774e-5,
    /* rk[10][2] */ .013873116,
    /* rk[11][0] */ -.00069190565,
    /* rk[11][1] */ -.00032263469,
    /* rk[11][2] */ .062965549,
    /* rk[12][0] */ -.00069190565,
    /* rk[12][1] */ .00032263469,
    /* rk[12][2] */ .062965549,
    /* rk[13][0] */ -.0065476317,
    /* rk[13][1] */ -.00059246918,
    /* rk[13][2] */ .039045468,
    /* rk[14][0] */ -.0065476317,
    /* rk[14][1] */ .00059246918,
    /* rk[14][2] */ .039045468,
    /* rk[15][0] */ .018536116,
    /* rk[15][1] */ -.00021373151,
    /* rk[15][2] */ -.013873116,
    /* rk[16][0] */ .018536116,
    /* rk[16][1] */ .00021373151,
    /* rk[16][2] */ -.013873116,
    /* rk[17][0] */ .00050287706,
    /* rk[17][1] */ .0095058847,
    /* rk[17][2] */ .025995316,
    /* rk[18][0] */ .00050287706,
    /* rk[18][1] */ -.0095058847,
    /* rk[18][2] */ .025995316,
    /* rk[19][0] */ .00071281068,
    /* rk[19][1] */ -.0014242818,
    /* rk[19][2] */ .016567586,
    /* rk[20][0] */ -.0076666217,
    /* rk[20][1] */ -6.3919849e-5,
    /* rk[20][2] */ -.018564541,

/* tree inbtojoint vectors */
    /* ri[0][0] */ 0.,
    /* ri[0][1] */ 0.,
    /* ri[0][2] */ 0.,
    /* ri[1][0] */ .019663084,
    /* ri[1][1] */ -.0851158909,
    /* ri[1][2] */ .039443695,
    /* ri[2][0] */ .019663084,
    /* ri[2][1] */ .0851158909,
    /* ri[2][2] */ .039443695,
    /* ri[3][0] */ -.0013935747,
    /* ri[3][1] */ -.013522619,
    /* ri[3][2] */ -.01026405,
    /* ri[4][0] */ -.0013935747,
    /* ri[4][1] */ .013522619,
    /* ri[4][2] */ -.01026405,
    /* ri[5][0] */ -.00073406497,
    /* ri[5][1] */ -.023760954,
    /* ri[5][2] */ -.00065978663,
    /* ri[6][0] */ -.00073406497,
    /* ri[6][1] */ .023760954,
    /* ri[6][2] */ -.00065978663,
    /* ri[7][0] */ .014663084,
    /* ri[7][1] */ -.0401158909,
    /* ri[7][2] */ -.082756305,
    /* ri[8][0] */ .014663084,
    /* ri[8][1] */ .0401158909,
    /* ri[8][2] */ -.082756305,
    /* ri[9][0] */ -.00048013477,
    /* ri[9][1] */ 0.,
    /* ri[9][2] */ -.018437244,
    /* ri[10][0] */ -.00048013477,
    /* ri[10][1] */ 0.,
    /* ri[10][2] */ -.018437244,
    /* ri[11][0] */ .018242402,
    /* ri[11][1] */ 7.9982774e-5,
    /* ri[11][2] */ .013873116,
    /* ri[12][0] */ .018242402,
    /* ri[12][1] */ -7.9982774e-5,
    /* ri[12][2] */ .013873116,
    /* ri[13][0] */ -.00069190565,
    /* ri[13][1] */ -.00032263469,
    /* ri[13][2] */ -.030034451,
    /* ri[14][0] */ -.00069190565,
    /* ri[14][1] */ .00032263469,
    /* ri[14][2] */ -.030034451,
    /* ri[15][0] */ -.0065476317,
    /* ri[15][1] */ -.00059246918,
    /* ri[15][2] */ -.053954532,
    /* ri[16][0] */ -.0065476317,
    /* ri[16][1] */ .00059246918,
    /* ri[16][2] */ -.053954532,
    /* ri[17][0] */ .018536116,
    /* ri[17][1] */ -.00021373151,
    /* ri[17][2] */ -.013873116,
    /* ri[18][0] */ .018536116,
    /* ri[18][1] */ .00021373151,
    /* ri[18][2] */ -.013873116,
    /* ri[19][0] */ .019663084,
    /* ri[19][1] */ .0031158909,
    /* ri[19][2] */ .089943695,
    /* ri[20][0] */ .00071281068,
    /* ri[20][1] */ -.0014242818,
    /* ri[20][2] */ .016567586,

/* tree prescribed motion */
    /* pres[0] */ 0.,
    /* pres[1] */ 0.,
    /* pres[2] */ 0.,
    /* pres[3] */ 0.,
    /* pres[4] */ 0.,
    /* pres[5] */ 0.,
    /* pres[6] */ 0.,
    /* pres[7] */ 0.,
    /* pres[8] */ 0.,
    /* pres[9] */ 0.,
    /* pres[10] */ 0.,
    /* pres[11] */ 0.,
    /* pres[12] */ 0.,
    /* pres[13] */ 0.,
    /* pres[14] */ 0.,
    /* pres[15] */ 0.,
    /* pres[16] */ 0.,
    /* pres[17] */ 0.,
    /* pres[18] */ 0.,
    /* pres[19] */ 0.,
    /* pres[20] */ 0.,
    /* pres[21] */ 0.,
    /* pres[22] */ 0.,
    /* pres[23] */ 0.,
    /* pres[24] */ 0.,
    /* pres[25] */ 0.,

/* stabilization parameters */
    /* stabvel */ 0.,
    /* stabpos */ 0.,

/* miscellaneous */
    /* mfrcflg */ 0,
    /* roustate */ 0,
    /* vpkflg */ 0,
    /* inerflg */ 0,
    /* mmflg */ 0,
    /* mmlduflg */ 0,
    /* wwflg */ 0,
    /* ltauflg */ 0,
    /* fs0flg */ 0,
    /* ii */ 0,
    /* mmap[0] */ 0,
    /* mmap[1] */ 1,
    /* mmap[2] */ 2,
    /* mmap[3] */ 3,
    /* mmap[4] */ 4,
    /* mmap[5] */ 5,
    /* mmap[6] */ 6,
    /* mmap[7] */ 7,
    /* mmap[8] */ 8,
    /* mmap[9] */ 9,
    /* mmap[10] */ 10,
    /* mmap[11] */ 11,
    /* mmap[12] */ 12,
    /* mmap[13] */ 13,
    /* mmap[14] */ 14,
    /* mmap[15] */ 15,
    /* mmap[16] */ 16,
    /* mmap[17] */ 17,
    /* mmap[18] */ 18,
    /* mmap[19] */ 19,
    /* mmap[20] */ 20,
    /* mmap[21] */ 21,
    /* mmap[22] */ 22,
    /* mmap[23] */ 23,
    /* mmap[24] */ 24,
    /* mmap[25] */ 25,

/* Which parameters were "?" (1) or "<nominal>?" (3) */
    /* gravq[0] */ 3,
    /* gravq[1] */ 3,
    /* gravq[2] */ 3,
    /* mkq[0] */ 3,
    /* mkq[1] */ 3,
    /* mkq[2] */ 3,
    /* mkq[3] */ 3,
    /* mkq[4] */ 3,
    /* mkq[5] */ 3,
    /* mkq[6] */ 3,
    /* mkq[7] */ 3,
    /* mkq[8] */ 3,
    /* mkq[9] */ 3,
    /* mkq[10] */ 3,
    /* mkq[11] */ 3,
    /* mkq[12] */ 3,
    /* mkq[13] */ 3,
    /* mkq[14] */ 3,
    /* mkq[15] */ 3,
    /* mkq[16] */ 3,
    /* mkq[17] */ 3,
    /* mkq[18] */ 3,
    /* mkq[19] */ 3,
    /* mkq[20] */ 3,
    /* ikq[0][0][0] */ 3,
    /* ikq[0][0][1] */ 3,
    /* ikq[0][0][2] */ 3,
    /* ikq[0][1][0] */ 3,
    /* ikq[0][1][1] */ 3,
    /* ikq[0][1][2] */ 3,
    /* ikq[0][2][0] */ 3,
    /* ikq[0][2][1] */ 3,
    /* ikq[0][2][2] */ 3,
    /* ikq[1][0][0] */ 3,
    /* ikq[1][0][1] */ 3,
    /* ikq[1][0][2] */ 3,
    /* ikq[1][1][0] */ 3,
    /* ikq[1][1][1] */ 3,
    /* ikq[1][1][2] */ 3,
    /* ikq[1][2][0] */ 3,
    /* ikq[1][2][1] */ 3,
    /* ikq[1][2][2] */ 3,
    /* ikq[2][0][0] */ 3,
    /* ikq[2][0][1] */ 3,
    /* ikq[2][0][2] */ 3,
    /* ikq[2][1][0] */ 3,
    /* ikq[2][1][1] */ 3,
    /* ikq[2][1][2] */ 3,
    /* ikq[2][2][0] */ 3,
    /* ikq[2][2][1] */ 3,
    /* ikq[2][2][2] */ 3,
    /* ikq[3][0][0] */ 3,
    /* ikq[3][0][1] */ 3,
    /* ikq[3][0][2] */ 3,
    /* ikq[3][1][0] */ 3,
    /* ikq[3][1][1] */ 3,
    /* ikq[3][1][2] */ 3,
    /* ikq[3][2][0] */ 3,
    /* ikq[3][2][1] */ 3,
    /* ikq[3][2][2] */ 3,
    /* ikq[4][0][0] */ 3,
    /* ikq[4][0][1] */ 3,
    /* ikq[4][0][2] */ 3,
    /* ikq[4][1][0] */ 3,
    /* ikq[4][1][1] */ 3,
    /* ikq[4][1][2] */ 3,
    /* ikq[4][2][0] */ 3,
    /* ikq[4][2][1] */ 3,
    /* ikq[4][2][2] */ 3,
    /* ikq[5][0][0] */ 3,
    /* ikq[5][0][1] */ 3,
    /* ikq[5][0][2] */ 3,
    /* ikq[5][1][0] */ 3,
    /* ikq[5][1][1] */ 3,
    /* ikq[5][1][2] */ 3,
    /* ikq[5][2][0] */ 3,
    /* ikq[5][2][1] */ 3,
    /* ikq[5][2][2] */ 3,
    /* ikq[6][0][0] */ 3,
    /* ikq[6][0][1] */ 3,
    /* ikq[6][0][2] */ 3,
    /* ikq[6][1][0] */ 3,
    /* ikq[6][1][1] */ 3,
    /* ikq[6][1][2] */ 3,
    /* ikq[6][2][0] */ 3,
    /* ikq[6][2][1] */ 3,
    /* ikq[6][2][2] */ 3,
    /* ikq[7][0][0] */ 3,
    /* ikq[7][0][1] */ 3,
    /* ikq[7][0][2] */ 3,
    /* ikq[7][1][0] */ 3,
    /* ikq[7][1][1] */ 3,
    /* ikq[7][1][2] */ 3,
    /* ikq[7][2][0] */ 3,
    /* ikq[7][2][1] */ 3,
    /* ikq[7][2][2] */ 3,
    /* ikq[8][0][0] */ 3,
    /* ikq[8][0][1] */ 3,
    /* ikq[8][0][2] */ 3,
    /* ikq[8][1][0] */ 3,
    /* ikq[8][1][1] */ 3,
    /* ikq[8][1][2] */ 3,
    /* ikq[8][2][0] */ 3,
    /* ikq[8][2][1] */ 3,
    /* ikq[8][2][2] */ 3,
    /* ikq[9][0][0] */ 3,
    /* ikq[9][0][1] */ 3,
    /* ikq[9][0][2] */ 3,
    /* ikq[9][1][0] */ 3,
    /* ikq[9][1][1] */ 3,
    /* ikq[9][1][2] */ 3,
    /* ikq[9][2][0] */ 3,
    /* ikq[9][2][1] */ 3,
    /* ikq[9][2][2] */ 3,
    /* ikq[10][0][0] */ 3,
    /* ikq[10][0][1] */ 3,
    /* ikq[10][0][2] */ 3,
    /* ikq[10][1][0] */ 3,
    /* ikq[10][1][1] */ 3,
    /* ikq[10][1][2] */ 3,
    /* ikq[10][2][0] */ 3,
    /* ikq[10][2][1] */ 3,
    /* ikq[10][2][2] */ 3,
    /* ikq[11][0][0] */ 3,
    /* ikq[11][0][1] */ 3,
    /* ikq[11][0][2] */ 3,
    /* ikq[11][1][0] */ 3,
    /* ikq[11][1][1] */ 3,
    /* ikq[11][1][2] */ 3,
    /* ikq[11][2][0] */ 3,
    /* ikq[11][2][1] */ 3,
    /* ikq[11][2][2] */ 3,
    /* ikq[12][0][0] */ 3,
    /* ikq[12][0][1] */ 3,
    /* ikq[12][0][2] */ 3,
    /* ikq[12][1][0] */ 3,
    /* ikq[12][1][1] */ 3,
    /* ikq[12][1][2] */ 3,
    /* ikq[12][2][0] */ 3,
    /* ikq[12][2][1] */ 3,
    /* ikq[12][2][2] */ 3,
    /* ikq[13][0][0] */ 3,
    /* ikq[13][0][1] */ 3,
    /* ikq[13][0][2] */ 3,
    /* ikq[13][1][0] */ 3,
    /* ikq[13][1][1] */ 3,
    /* ikq[13][1][2] */ 3,
    /* ikq[13][2][0] */ 3,
    /* ikq[13][2][1] */ 3,
    /* ikq[13][2][2] */ 3,
    /* ikq[14][0][0] */ 3,
    /* ikq[14][0][1] */ 3,
    /* ikq[14][0][2] */ 3,
    /* ikq[14][1][0] */ 3,
    /* ikq[14][1][1] */ 3,
    /* ikq[14][1][2] */ 3,
    /* ikq[14][2][0] */ 3,
    /* ikq[14][2][1] */ 3,
    /* ikq[14][2][2] */ 3,
    /* ikq[15][0][0] */ 3,
    /* ikq[15][0][1] */ 3,
    /* ikq[15][0][2] */ 3,
    /* ikq[15][1][0] */ 3,
    /* ikq[15][1][1] */ 3,
    /* ikq[15][1][2] */ 3,
    /* ikq[15][2][0] */ 3,
    /* ikq[15][2][1] */ 3,
    /* ikq[15][2][2] */ 3,
    /* ikq[16][0][0] */ 3,
    /* ikq[16][0][1] */ 3,
    /* ikq[16][0][2] */ 3,
    /* ikq[16][1][0] */ 3,
    /* ikq[16][1][1] */ 3,
    /* ikq[16][1][2] */ 3,
    /* ikq[16][2][0] */ 3,
    /* ikq[16][2][1] */ 3,
    /* ikq[16][2][2] */ 3,
    /* ikq[17][0][0] */ 3,
    /* ikq[17][0][1] */ 3,
    /* ikq[17][0][2] */ 3,
    /* ikq[17][1][0] */ 3,
    /* ikq[17][1][1] */ 3,
    /* ikq[17][1][2] */ 3,
    /* ikq[17][2][0] */ 3,
    /* ikq[17][2][1] */ 3,
    /* ikq[17][2][2] */ 3,
    /* ikq[18][0][0] */ 3,
    /* ikq[18][0][1] */ 3,
    /* ikq[18][0][2] */ 3,
    /* ikq[18][1][0] */ 3,
    /* ikq[18][1][1] */ 3,
    /* ikq[18][1][2] */ 3,
    /* ikq[18][2][0] */ 3,
    /* ikq[18][2][1] */ 3,
    /* ikq[18][2][2] */ 3,
    /* ikq[19][0][0] */ 3,
    /* ikq[19][0][1] */ 3,
    /* ikq[19][0][2] */ 3,
    /* ikq[19][1][0] */ 3,
    /* ikq[19][1][1] */ 3,
    /* ikq[19][1][2] */ 3,
    /* ikq[19][2][0] */ 3,
    /* ikq[19][2][1] */ 3,
    /* ikq[19][2][2] */ 3,
    /* ikq[20][0][0] */ 3,
    /* ikq[20][0][1] */ 3,
    /* ikq[20][0][2] */ 3,
    /* ikq[20][1][0] */ 3,
    /* ikq[20][1][1] */ 3,
    /* ikq[20][1][2] */ 3,
    /* ikq[20][2][0] */ 3,
    /* ikq[20][2][1] */ 3,
    /* ikq[20][2][2] */ 3,
    /* pinq[0][0] */ 0,
    /* pinq[0][1] */ 0,
    /* pinq[0][2] */ 0,
    /* pinq[1][0] */ 0,
    /* pinq[1][1] */ 0,
    /* pinq[1][2] */ 0,
    /* pinq[2][0] */ 0,
    /* pinq[2][1] */ 0,
    /* pinq[2][2] */ 0,
    /* pinq[3][0] */ 0,
    /* pinq[3][1] */ 0,
    /* pinq[3][2] */ 0,
    /* pinq[4][0] */ 0,
    /* pinq[4][1] */ 0,
    /* pinq[4][2] */ 0,
    /* pinq[5][0] */ 0,
    /* pinq[5][1] */ 0,
    /* pinq[5][2] */ 0,
    /* pinq[6][0] */ 0,
    /* pinq[6][1] */ 0,
    /* pinq[6][2] */ 0,
    /* pinq[7][0] */ 0,
    /* pinq[7][1] */ 0,
    /* pinq[7][2] */ 0,
    /* pinq[8][0] */ 0,
    /* pinq[8][1] */ 0,
    /* pinq[8][2] */ 0,
    /* pinq[9][0] */ 0,
    /* pinq[9][1] */ 0,
    /* pinq[9][2] */ 0,
    /* pinq[10][0] */ 0,
    /* pinq[10][1] */ 0,
    /* pinq[10][2] */ 0,
    /* pinq[11][0] */ 0,
    /* pinq[11][1] */ 0,
    /* pinq[11][2] */ 0,
    /* pinq[12][0] */ 0,
    /* pinq[12][1] */ 0,
    /* pinq[12][2] */ 0,
    /* pinq[13][0] */ 0,
    /* pinq[13][1] */ 0,
    /* pinq[13][2] */ 0,
    /* pinq[14][0] */ 0,
    /* pinq[14][1] */ 0,
    /* pinq[14][2] */ 0,
    /* pinq[15][0] */ 0,
    /* pinq[15][1] */ 0,
    /* pinq[15][2] */ 0,
    /* pinq[16][0] */ 0,
    /* pinq[16][1] */ 0,
    /* pinq[16][2] */ 0,
    /* pinq[17][0] */ 0,
    /* pinq[17][1] */ 0,
    /* pinq[17][2] */ 0,
    /* pinq[18][0] */ 0,
    /* pinq[18][1] */ 0,
    /* pinq[18][2] */ 0,
    /* pinq[19][0] */ 0,
    /* pinq[19][1] */ 0,
    /* pinq[19][2] */ 0,
    /* pinq[20][0] */ 0,
    /* pinq[20][1] */ 0,
    /* pinq[20][2] */ 0,
    /* pinq[21][0] */ 0,
    /* pinq[21][1] */ 0,
    /* pinq[21][2] */ 0,
    /* pinq[22][0] */ 0,
    /* pinq[22][1] */ 0,
    /* pinq[22][2] */ 0,
    /* pinq[23][0] */ 0,
    /* pinq[23][1] */ 0,
    /* pinq[23][2] */ 0,
    /* pinq[24][0] */ 0,
    /* pinq[24][1] */ 0,
    /* pinq[24][2] */ 0,
    /* pinq[25][0] */ 0,
    /* pinq[25][1] */ 0,
    /* pinq[25][2] */ 0,
    /* rkq[0][0] */ 3,
    /* rkq[0][1] */ 3,
    /* rkq[0][2] */ 3,
    /* rkq[1][0] */ 3,
    /* rkq[1][1] */ 3,
    /* rkq[1][2] */ 3,
    /* rkq[2][0] */ 3,
    /* rkq[2][1] */ 3,
    /* rkq[2][2] */ 3,
    /* rkq[3][0] */ 3,
    /* rkq[3][1] */ 3,
    /* rkq[3][2] */ 3,
    /* rkq[4][0] */ 3,
    /* rkq[4][1] */ 3,
    /* rkq[4][2] */ 3,
    /* rkq[5][0] */ 3,
    /* rkq[5][1] */ 3,
    /* rkq[5][2] */ 3,
    /* rkq[6][0] */ 3,
    /* rkq[6][1] */ 3,
    /* rkq[6][2] */ 3,
    /* rkq[7][0] */ 3,
    /* rkq[7][1] */ 3,
    /* rkq[7][2] */ 3,
    /* rkq[8][0] */ 3,
    /* rkq[8][1] */ 3,
    /* rkq[8][2] */ 3,
    /* rkq[9][0] */ 3,
    /* rkq[9][1] */ 3,
    /* rkq[9][2] */ 3,
    /* rkq[10][0] */ 3,
    /* rkq[10][1] */ 3,
    /* rkq[10][2] */ 3,
    /* rkq[11][0] */ 3,
    /* rkq[11][1] */ 3,
    /* rkq[11][2] */ 3,
    /* rkq[12][0] */ 3,
    /* rkq[12][1] */ 3,
    /* rkq[12][2] */ 3,
    /* rkq[13][0] */ 3,
    /* rkq[13][1] */ 3,
    /* rkq[13][2] */ 3,
    /* rkq[14][0] */ 3,
    /* rkq[14][1] */ 3,
    /* rkq[14][2] */ 3,
    /* rkq[15][0] */ 3,
    /* rkq[15][1] */ 3,
    /* rkq[15][2] */ 3,
    /* rkq[16][0] */ 3,
    /* rkq[16][1] */ 3,
    /* rkq[16][2] */ 3,
    /* rkq[17][0] */ 3,
    /* rkq[17][1] */ 3,
    /* rkq[17][2] */ 3,
    /* rkq[18][0] */ 3,
    /* rkq[18][1] */ 3,
    /* rkq[18][2] */ 3,
    /* rkq[19][0] */ 3,
    /* rkq[19][1] */ 3,
    /* rkq[19][2] */ 3,
    /* rkq[20][0] */ 3,
    /* rkq[20][1] */ 3,
    /* rkq[20][2] */ 3,
    /* riq[0][0] */ 3,
    /* riq[0][1] */ 3,
    /* riq[0][2] */ 3,
    /* riq[1][0] */ 3,
    /* riq[1][1] */ 3,
    /* riq[1][2] */ 3,
    /* riq[2][0] */ 3,
    /* riq[2][1] */ 3,
    /* riq[2][2] */ 3,
    /* riq[3][0] */ 3,
    /* riq[3][1] */ 3,
    /* riq[3][2] */ 3,
    /* riq[4][0] */ 3,
    /* riq[4][1] */ 3,
    /* riq[4][2] */ 3,
    /* riq[5][0] */ 3,
    /* riq[5][1] */ 3,
    /* riq[5][2] */ 3,
    /* riq[6][0] */ 3,
    /* riq[6][1] */ 3,
    /* riq[6][2] */ 3,
    /* riq[7][0] */ 3,
    /* riq[7][1] */ 3,
    /* riq[7][2] */ 3,
    /* riq[8][0] */ 3,
    /* riq[8][1] */ 3,
    /* riq[8][2] */ 3,
    /* riq[9][0] */ 3,
    /* riq[9][1] */ 3,
    /* riq[9][2] */ 3,
    /* riq[10][0] */ 3,
    /* riq[10][1] */ 3,
    /* riq[10][2] */ 3,
    /* riq[11][0] */ 3,
    /* riq[11][1] */ 3,
    /* riq[11][2] */ 3,
    /* riq[12][0] */ 3,
    /* riq[12][1] */ 3,
    /* riq[12][2] */ 3,
    /* riq[13][0] */ 3,
    /* riq[13][1] */ 3,
    /* riq[13][2] */ 3,
    /* riq[14][0] */ 3,
    /* riq[14][1] */ 3,
    /* riq[14][2] */ 3,
    /* riq[15][0] */ 3,
    /* riq[15][1] */ 3,
    /* riq[15][2] */ 3,
    /* riq[16][0] */ 3,
    /* riq[16][1] */ 3,
    /* riq[16][2] */ 3,
    /* riq[17][0] */ 3,
    /* riq[17][1] */ 3,
    /* riq[17][2] */ 3,
    /* riq[18][0] */ 3,
    /* riq[18][1] */ 3,
    /* riq[18][2] */ 3,
    /* riq[19][0] */ 3,
    /* riq[19][1] */ 3,
    /* riq[19][2] */ 3,
    /* riq[20][0] */ 3,
    /* riq[20][1] */ 3,
    /* riq[20][2] */ 3,
    /* presq[0] */ 0,
    /* presq[1] */ 0,
    /* presq[2] */ 0,
    /* presq[3] */ 0,
    /* presq[4] */ 0,
    /* presq[5] */ 0,
    /* presq[6] */ 0,
    /* presq[7] */ 0,
    /* presq[8] */ 0,
    /* presq[9] */ 0,
    /* presq[10] */ 0,
    /* presq[11] */ 0,
    /* presq[12] */ 0,
    /* presq[13] */ 0,
    /* presq[14] */ 0,
    /* presq[15] */ 0,
    /* presq[16] */ 0,
    /* presq[17] */ 0,
    /* presq[18] */ 0,
    /* presq[19] */ 0,
    /* presq[20] */ 0,
    /* presq[21] */ 0,
    /* presq[22] */ 0,
    /* presq[23] */ 0,
    /* presq[24] */ 0,
    /* presq[25] */ 0,
    /* stabvelq */ 3,
    /* stabposq */ 3,

/* End of values from input file */

};
sdgstate_t sdgstate;
sdglhs_t sdglhs;
sdgrhs_t sdgrhs;
sdgtemp_t sdgtemp;


void sdinit(void)
{
/*
Initialization routine


 This routine must be called before the first call to sdstate(), after
 supplying values for any `?' parameters in the input.
*/
    double sumsq,norminv;
    int i,j,k;


/* Check that all `?' parameters have been assigned values */

    for (k = 0; k < 3; k++) {
        if (gravq[k] == 1) {
            sdseterr(7,25);
        }
    }
    for (k = 0; k < 21; k++) {
        if (mkq[k] == 1) {
            sdseterr(7,26);
        }
        for (i = 0; i < 3; i++) {
            if (rkq[k][i] == 1) {
                sdseterr(7,29);
            }
            if (riq[k][i] == 1) {
                sdseterr(7,30);
            }
            for (j = 0; j < 3; j++) {
                if (ikq[k][i][j] == 1) {
                    sdseterr(7,27);
                }
            }
        }
    }
    for (k = 0; k < 26; k++) {
        for (i = 0; i < 3; i++) {
            if (pinq[k][i] == 1) {
                sdseterr(7,28);
            }
        }
    }

/* Normalize pin vectors if necessary */


/* Zero out Vpk and Wpk */

    for (i = 0; i < 26; i++) {
        for (j = i; j <= 25; j++) {
            for (k = 0; k < 3; k++) {
                Vpk[i][j][k] = 0.;
                Wpk[i][j][k] = 0.;
            }
        }
    }

/* Compute pseudobody-related constants */

    rcom[0][0] = 0.;
    rcom[0][1] = 0.;
    rcom[0][2] = 0.;
    rcom[1][0] = 0.;
    rcom[1][1] = 0.;
    rcom[1][2] = 0.;
    rcom[2][0] = 0.;
    rcom[2][1] = 0.;
    rcom[2][2] = 0.;
    rcom[3][0] = 0.;
    rcom[3][1] = 0.;
    rcom[3][2] = 0.;
    rcom[4][0] = 0.;
    rcom[4][1] = 0.;
    rcom[4][2] = 0.;
    rcom[5][0] = 0.;
    rcom[5][1] = 0.;
    rcom[5][2] = 0.;
    rcom[6][0] = 0.;
    rcom[6][1] = 0.;
    rcom[6][2] = 0.;
    rcom[7][0] = 0.;
    rcom[7][1] = 0.;
    rcom[7][2] = 0.;
    rcom[8][0] = 0.;
    rcom[8][1] = 0.;
    rcom[8][2] = 0.;
    rcom[9][0] = 0.;
    rcom[9][1] = 0.;
    rcom[9][2] = 0.;
    rcom[10][0] = 0.;
    rcom[10][1] = 0.;
    rcom[10][2] = 0.;
    rcom[11][0] = 0.;
    rcom[11][1] = 0.;
    rcom[11][2] = 0.;
    rcom[12][0] = 0.;
    rcom[12][1] = 0.;
    rcom[12][2] = 0.;
    rcom[13][0] = 0.;
    rcom[13][1] = 0.;
    rcom[13][2] = 0.;
    rcom[14][0] = 0.;
    rcom[14][1] = 0.;
    rcom[14][2] = 0.;
    rcom[15][0] = 0.;
    rcom[15][1] = 0.;
    rcom[15][2] = 0.;
    rcom[16][0] = 0.;
    rcom[16][1] = 0.;
    rcom[16][2] = 0.;
    rcom[17][0] = 0.;
    rcom[17][1] = 0.;
    rcom[17][2] = 0.;
    rcom[18][0] = 0.;
    rcom[18][1] = 0.;
    rcom[18][2] = 0.;
    rcom[19][0] = 0.;
    rcom[19][1] = 0.;
    rcom[19][2] = 0.;
    rcom[20][0] = 0.;
    rcom[20][1] = 0.;
    rcom[20][2] = 0.;
    dik[6][0] = (ri[1][0]-rk[0][0]);
    dik[6][1] = (ri[1][1]-rk[0][1]);
    dik[6][2] = (ri[1][2]-rk[0][2]);
    dik[7][0] = (ri[2][0]-rk[0][0]);
    dik[7][1] = (ri[2][1]-rk[0][1]);
    dik[7][2] = (ri[2][2]-rk[0][2]);
    dik[8][0] = (ri[3][0]-rk[1][0]);
    dik[8][1] = (ri[3][1]-rk[1][1]);
    dik[8][2] = (ri[3][2]-rk[1][2]);
    dik[9][0] = (ri[4][0]-rk[2][0]);
    dik[9][1] = (ri[4][1]-rk[2][1]);
    dik[9][2] = (ri[4][2]-rk[2][2]);
    dik[10][0] = (ri[5][0]-rk[3][0]);
    dik[10][1] = (ri[5][1]-rk[3][1]);
    dik[10][2] = (ri[5][2]-rk[3][2]);
    dik[11][0] = (ri[6][0]-rk[4][0]);
    dik[11][1] = (ri[6][1]-rk[4][1]);
    dik[11][2] = (ri[6][2]-rk[4][2]);
    dik[12][0] = (ri[7][0]-rk[0][0]);
    dik[12][1] = (ri[7][1]-rk[0][1]);
    dik[12][2] = (ri[7][2]-rk[0][2]);
    dik[13][0] = (ri[8][0]-rk[0][0]);
    dik[13][1] = (ri[8][1]-rk[0][1]);
    dik[13][2] = (ri[8][2]-rk[0][2]);
    dik[14][0] = (ri[9][0]-rk[7][0]);
    dik[14][1] = (ri[9][1]-rk[7][1]);
    dik[14][2] = (ri[9][2]-rk[7][2]);
    dik[15][0] = (ri[10][0]-rk[8][0]);
    dik[15][1] = (ri[10][1]-rk[8][1]);
    dik[15][2] = (ri[10][2]-rk[8][2]);
    dik[16][0] = (ri[11][0]-rk[9][0]);
    dik[16][1] = (ri[11][1]-rk[9][1]);
    dik[16][2] = (ri[11][2]-rk[9][2]);
    dik[17][0] = (ri[12][0]-rk[10][0]);
    dik[17][1] = (ri[12][1]-rk[10][1]);
    dik[17][2] = (ri[12][2]-rk[10][2]);
    dik[18][0] = (ri[13][0]-rk[11][0]);
    dik[18][1] = (ri[13][1]-rk[11][1]);
    dik[18][2] = (ri[13][2]-rk[11][2]);
    dik[19][0] = (ri[14][0]-rk[12][0]);
    dik[19][1] = (ri[14][1]-rk[12][1]);
    dik[19][2] = (ri[14][2]-rk[12][2]);
    dik[20][0] = (ri[15][0]-rk[13][0]);
    dik[20][1] = (ri[15][1]-rk[13][1]);
    dik[20][2] = (ri[15][2]-rk[13][2]);
    dik[21][0] = (ri[16][0]-rk[14][0]);
    dik[21][1] = (ri[16][1]-rk[14][1]);
    dik[21][2] = (ri[16][2]-rk[14][2]);
    dik[22][0] = (ri[17][0]-rk[15][0]);
    dik[22][1] = (ri[17][1]-rk[15][1]);
    dik[22][2] = (ri[17][2]-rk[15][2]);
    dik[23][0] = (ri[18][0]-rk[16][0]);
    dik[23][1] = (ri[18][1]-rk[16][1]);
    dik[23][2] = (ri[18][2]-rk[16][2]);
    dik[24][0] = (ri[19][0]-rk[0][0]);
    dik[24][1] = (ri[19][1]-rk[0][1]);
    dik[24][2] = (ri[19][2]-rk[0][2]);
    dik[25][0] = (ri[20][0]-rk[19][0]);
    dik[25][1] = (ri[20][1]-rk[19][1]);
    dik[25][2] = (ri[20][2]-rk[19][2]);

/* Compute mass properties-related constants */

    mtot = (mk[20]+(mk[19]+(mk[18]+(mk[17]+(mk[16]+(mk[15]+(mk[14]+(mk[13]+(
      mk[12]+(mk[11]+(mk[10]+(mk[9]+(mk[8]+(mk[7]+(mk[6]+(mk[5]+(mk[4]+(mk[3]+(
      mk[2]+(mk[0]+mk[1]))))))))))))))))))));
    mkrk[5][0][1] = -(mk[0]*rk[0][2]);
    mkrk[5][0][2] = (mk[0]*rk[0][1]);
    mkrk[5][1][0] = (mk[0]*rk[0][2]);
    mkrk[5][1][2] = -(mk[0]*rk[0][0]);
    mkrk[5][2][0] = -(mk[0]*rk[0][1]);
    mkrk[5][2][1] = (mk[0]*rk[0][0]);
    mkrk[6][0][1] = -(mk[1]*rk[1][2]);
    mkrk[6][0][2] = (mk[1]*rk[1][1]);
    mkrk[6][1][0] = (mk[1]*rk[1][2]);
    mkrk[6][1][2] = -(mk[1]*rk[1][0]);
    mkrk[6][2][0] = -(mk[1]*rk[1][1]);
    mkrk[6][2][1] = (mk[1]*rk[1][0]);
    mkrk[7][0][1] = -(mk[2]*rk[2][2]);
    mkrk[7][0][2] = (mk[2]*rk[2][1]);
    mkrk[7][1][0] = (mk[2]*rk[2][2]);
    mkrk[7][1][2] = -(mk[2]*rk[2][0]);
    mkrk[7][2][0] = -(mk[2]*rk[2][1]);
    mkrk[7][2][1] = (mk[2]*rk[2][0]);
    mkrk[8][0][1] = -(mk[3]*rk[3][2]);
    mkrk[8][0][2] = (mk[3]*rk[3][1]);
    mkrk[8][1][0] = (mk[3]*rk[3][2]);
    mkrk[8][1][2] = -(mk[3]*rk[3][0]);
    mkrk[8][2][0] = -(mk[3]*rk[3][1]);
    mkrk[8][2][1] = (mk[3]*rk[3][0]);
    mkrk[9][0][1] = -(mk[4]*rk[4][2]);
    mkrk[9][0][2] = (mk[4]*rk[4][1]);
    mkrk[9][1][0] = (mk[4]*rk[4][2]);
    mkrk[9][1][2] = -(mk[4]*rk[4][0]);
    mkrk[9][2][0] = -(mk[4]*rk[4][1]);
    mkrk[9][2][1] = (mk[4]*rk[4][0]);
    mkrk[10][0][1] = -(mk[5]*rk[5][2]);
    mkrk[10][0][2] = (mk[5]*rk[5][1]);
    mkrk[10][1][0] = (mk[5]*rk[5][2]);
    mkrk[10][1][2] = -(mk[5]*rk[5][0]);
    mkrk[10][2][0] = -(mk[5]*rk[5][1]);
    mkrk[10][2][1] = (mk[5]*rk[5][0]);
    mkrk[11][0][1] = -(mk[6]*rk[6][2]);
    mkrk[11][0][2] = (mk[6]*rk[6][1]);
    mkrk[11][1][0] = (mk[6]*rk[6][2]);
    mkrk[11][1][2] = -(mk[6]*rk[6][0]);
    mkrk[11][2][0] = -(mk[6]*rk[6][1]);
    mkrk[11][2][1] = (mk[6]*rk[6][0]);
    mkrk[12][0][1] = -(mk[7]*rk[7][2]);
    mkrk[12][0][2] = (mk[7]*rk[7][1]);
    mkrk[12][1][0] = (mk[7]*rk[7][2]);
    mkrk[12][1][2] = -(mk[7]*rk[7][0]);
    mkrk[12][2][0] = -(mk[7]*rk[7][1]);
    mkrk[12][2][1] = (mk[7]*rk[7][0]);
    mkrk[13][0][1] = -(mk[8]*rk[8][2]);
    mkrk[13][0][2] = (mk[8]*rk[8][1]);
    mkrk[13][1][0] = (mk[8]*rk[8][2]);
    mkrk[13][1][2] = -(mk[8]*rk[8][0]);
    mkrk[13][2][0] = -(mk[8]*rk[8][1]);
    mkrk[13][2][1] = (mk[8]*rk[8][0]);
    mkrk[14][0][1] = -(mk[9]*rk[9][2]);
    mkrk[14][0][2] = (mk[9]*rk[9][1]);
    mkrk[14][1][0] = (mk[9]*rk[9][2]);
    mkrk[14][1][2] = -(mk[9]*rk[9][0]);
    mkrk[14][2][0] = -(mk[9]*rk[9][1]);
    mkrk[14][2][1] = (mk[9]*rk[9][0]);
    mkrk[15][0][1] = -(mk[10]*rk[10][2]);
    mkrk[15][0][2] = (mk[10]*rk[10][1]);
    mkrk[15][1][0] = (mk[10]*rk[10][2]);
    mkrk[15][1][2] = -(mk[10]*rk[10][0]);
    mkrk[15][2][0] = -(mk[10]*rk[10][1]);
    mkrk[15][2][1] = (mk[10]*rk[10][0]);
    mkrk[16][0][1] = -(mk[11]*rk[11][2]);
    mkrk[16][0][2] = (mk[11]*rk[11][1]);
    mkrk[16][1][0] = (mk[11]*rk[11][2]);
    mkrk[16][1][2] = -(mk[11]*rk[11][0]);
    mkrk[16][2][0] = -(mk[11]*rk[11][1]);
    mkrk[16][2][1] = (mk[11]*rk[11][0]);
    mkrk[17][0][1] = -(mk[12]*rk[12][2]);
    mkrk[17][0][2] = (mk[12]*rk[12][1]);
    mkrk[17][1][0] = (mk[12]*rk[12][2]);
    mkrk[17][1][2] = -(mk[12]*rk[12][0]);
    mkrk[17][2][0] = -(mk[12]*rk[12][1]);
    mkrk[17][2][1] = (mk[12]*rk[12][0]);
    mkrk[18][0][1] = -(mk[13]*rk[13][2]);
    mkrk[18][0][2] = (mk[13]*rk[13][1]);
    mkrk[18][1][0] = (mk[13]*rk[13][2]);
    mkrk[18][1][2] = -(mk[13]*rk[13][0]);
    mkrk[18][2][0] = -(mk[13]*rk[13][1]);
    mkrk[18][2][1] = (mk[13]*rk[13][0]);
    mkrk[19][0][1] = -(mk[14]*rk[14][2]);
    mkrk[19][0][2] = (mk[14]*rk[14][1]);
    mkrk[19][1][0] = (mk[14]*rk[14][2]);
    mkrk[19][1][2] = -(mk[14]*rk[14][0]);
    mkrk[19][2][0] = -(mk[14]*rk[14][1]);
    mkrk[19][2][1] = (mk[14]*rk[14][0]);
    mkrk[20][0][1] = -(mk[15]*rk[15][2]);
    mkrk[20][0][2] = (mk[15]*rk[15][1]);
    mkrk[20][1][0] = (mk[15]*rk[15][2]);
    mkrk[20][1][2] = -(mk[15]*rk[15][0]);
    mkrk[20][2][0] = -(mk[15]*rk[15][1]);
    mkrk[20][2][1] = (mk[15]*rk[15][0]);
    mkrk[21][0][1] = -(mk[16]*rk[16][2]);
    mkrk[21][0][2] = (mk[16]*rk[16][1]);
    mkrk[21][1][0] = (mk[16]*rk[16][2]);
    mkrk[21][1][2] = -(mk[16]*rk[16][0]);
    mkrk[21][2][0] = -(mk[16]*rk[16][1]);
    mkrk[21][2][1] = (mk[16]*rk[16][0]);
    mkrk[22][0][1] = -(mk[17]*rk[17][2]);
    mkrk[22][0][2] = (mk[17]*rk[17][1]);
    mkrk[22][1][0] = (mk[17]*rk[17][2]);
    mkrk[22][1][2] = -(mk[17]*rk[17][0]);
    mkrk[22][2][0] = -(mk[17]*rk[17][1]);
    mkrk[22][2][1] = (mk[17]*rk[17][0]);
    mkrk[23][0][1] = -(mk[18]*rk[18][2]);
    mkrk[23][0][2] = (mk[18]*rk[18][1]);
    mkrk[23][1][0] = (mk[18]*rk[18][2]);
    mkrk[23][1][2] = -(mk[18]*rk[18][0]);
    mkrk[23][2][0] = -(mk[18]*rk[18][1]);
    mkrk[23][2][1] = (mk[18]*rk[18][0]);
    mkrk[24][0][1] = -(mk[19]*rk[19][2]);
    mkrk[24][0][2] = (mk[19]*rk[19][1]);
    mkrk[24][1][0] = (mk[19]*rk[19][2]);
    mkrk[24][1][2] = -(mk[19]*rk[19][0]);
    mkrk[24][2][0] = -(mk[19]*rk[19][1]);
    mkrk[24][2][1] = (mk[19]*rk[19][0]);
    mkrk[25][0][1] = -(mk[20]*rk[20][2]);
    mkrk[25][0][2] = (mk[20]*rk[20][1]);
    mkrk[25][1][0] = (mk[20]*rk[20][2]);
    mkrk[25][1][2] = -(mk[20]*rk[20][0]);
    mkrk[25][2][0] = -(mk[20]*rk[20][1]);
    mkrk[25][2][1] = (mk[20]*rk[20][0]);
    Iko[5][0][0] = (ik[0][0][0]-((mkrk[5][0][1]*rk[0][2])-(mkrk[5][0][2]*
      rk[0][1])));
    Iko[5][0][1] = (ik[0][0][1]-(mkrk[5][0][2]*rk[0][0]));
    Iko[5][0][2] = (ik[0][0][2]+(mkrk[5][0][1]*rk[0][0]));
    Iko[5][1][0] = (ik[0][1][0]+(mkrk[5][1][2]*rk[0][1]));
    Iko[5][1][1] = (ik[0][1][1]-((mkrk[5][1][2]*rk[0][0])-(mkrk[5][1][0]*
      rk[0][2])));
    Iko[5][1][2] = (ik[0][1][2]-(mkrk[5][1][0]*rk[0][1]));
    Iko[5][2][0] = (ik[0][2][0]-(mkrk[5][2][1]*rk[0][2]));
    Iko[5][2][1] = (ik[0][2][1]+(mkrk[5][2][0]*rk[0][2]));
    Iko[5][2][2] = (ik[0][2][2]-((mkrk[5][2][0]*rk[0][1])-(mkrk[5][2][1]*
      rk[0][0])));
    Iko[6][0][0] = (ik[1][0][0]-((mkrk[6][0][1]*rk[1][2])-(mkrk[6][0][2]*
      rk[1][1])));
    Iko[6][0][1] = (ik[1][0][1]-(mkrk[6][0][2]*rk[1][0]));
    Iko[6][0][2] = (ik[1][0][2]+(mkrk[6][0][1]*rk[1][0]));
    Iko[6][1][0] = (ik[1][1][0]+(mkrk[6][1][2]*rk[1][1]));
    Iko[6][1][1] = (ik[1][1][1]-((mkrk[6][1][2]*rk[1][0])-(mkrk[6][1][0]*
      rk[1][2])));
    Iko[6][1][2] = (ik[1][1][2]-(mkrk[6][1][0]*rk[1][1]));
    Iko[6][2][0] = (ik[1][2][0]-(mkrk[6][2][1]*rk[1][2]));
    Iko[6][2][1] = (ik[1][2][1]+(mkrk[6][2][0]*rk[1][2]));
    Iko[6][2][2] = (ik[1][2][2]-((mkrk[6][2][0]*rk[1][1])-(mkrk[6][2][1]*
      rk[1][0])));
    Iko[7][0][0] = (ik[2][0][0]-((mkrk[7][0][1]*rk[2][2])-(mkrk[7][0][2]*
      rk[2][1])));
    Iko[7][0][1] = (ik[2][0][1]-(mkrk[7][0][2]*rk[2][0]));
    Iko[7][0][2] = (ik[2][0][2]+(mkrk[7][0][1]*rk[2][0]));
    Iko[7][1][0] = (ik[2][1][0]+(mkrk[7][1][2]*rk[2][1]));
    Iko[7][1][1] = (ik[2][1][1]-((mkrk[7][1][2]*rk[2][0])-(mkrk[7][1][0]*
      rk[2][2])));
    Iko[7][1][2] = (ik[2][1][2]-(mkrk[7][1][0]*rk[2][1]));
    Iko[7][2][0] = (ik[2][2][0]-(mkrk[7][2][1]*rk[2][2]));
    Iko[7][2][1] = (ik[2][2][1]+(mkrk[7][2][0]*rk[2][2]));
    Iko[7][2][2] = (ik[2][2][2]-((mkrk[7][2][0]*rk[2][1])-(mkrk[7][2][1]*
      rk[2][0])));
    Iko[8][0][0] = (ik[3][0][0]-((mkrk[8][0][1]*rk[3][2])-(mkrk[8][0][2]*
      rk[3][1])));
    Iko[8][0][1] = (ik[3][0][1]-(mkrk[8][0][2]*rk[3][0]));
    Iko[8][0][2] = (ik[3][0][2]+(mkrk[8][0][1]*rk[3][0]));
    Iko[8][1][0] = (ik[3][1][0]+(mkrk[8][1][2]*rk[3][1]));
    Iko[8][1][1] = (ik[3][1][1]-((mkrk[8][1][2]*rk[3][0])-(mkrk[8][1][0]*
      rk[3][2])));
    Iko[8][1][2] = (ik[3][1][2]-(mkrk[8][1][0]*rk[3][1]));
    Iko[8][2][0] = (ik[3][2][0]-(mkrk[8][2][1]*rk[3][2]));
    Iko[8][2][1] = (ik[3][2][1]+(mkrk[8][2][0]*rk[3][2]));
    Iko[8][2][2] = (ik[3][2][2]-((mkrk[8][2][0]*rk[3][1])-(mkrk[8][2][1]*
      rk[3][0])));
    Iko[9][0][0] = (ik[4][0][0]-((mkrk[9][0][1]*rk[4][2])-(mkrk[9][0][2]*
      rk[4][1])));
    Iko[9][0][1] = (ik[4][0][1]-(mkrk[9][0][2]*rk[4][0]));
    Iko[9][0][2] = (ik[4][0][2]+(mkrk[9][0][1]*rk[4][0]));
    Iko[9][1][0] = (ik[4][1][0]+(mkrk[9][1][2]*rk[4][1]));
    Iko[9][1][1] = (ik[4][1][1]-((mkrk[9][1][2]*rk[4][0])-(mkrk[9][1][0]*
      rk[4][2])));
    Iko[9][1][2] = (ik[4][1][2]-(mkrk[9][1][0]*rk[4][1]));
    Iko[9][2][0] = (ik[4][2][0]-(mkrk[9][2][1]*rk[4][2]));
    Iko[9][2][1] = (ik[4][2][1]+(mkrk[9][2][0]*rk[4][2]));
    Iko[9][2][2] = (ik[4][2][2]-((mkrk[9][2][0]*rk[4][1])-(mkrk[9][2][1]*
      rk[4][0])));
    Iko[10][0][0] = (ik[5][0][0]-((mkrk[10][0][1]*rk[5][2])-(mkrk[10][0][2]*
      rk[5][1])));
    Iko[10][0][1] = (ik[5][0][1]-(mkrk[10][0][2]*rk[5][0]));
    Iko[10][0][2] = (ik[5][0][2]+(mkrk[10][0][1]*rk[5][0]));
    Iko[10][1][0] = (ik[5][1][0]+(mkrk[10][1][2]*rk[5][1]));
    Iko[10][1][1] = (ik[5][1][1]-((mkrk[10][1][2]*rk[5][0])-(mkrk[10][1][0]*
      rk[5][2])));
    Iko[10][1][2] = (ik[5][1][2]-(mkrk[10][1][0]*rk[5][1]));
    Iko[10][2][0] = (ik[5][2][0]-(mkrk[10][2][1]*rk[5][2]));
    Iko[10][2][1] = (ik[5][2][1]+(mkrk[10][2][0]*rk[5][2]));
    Iko[10][2][2] = (ik[5][2][2]-((mkrk[10][2][0]*rk[5][1])-(mkrk[10][2][1]*
      rk[5][0])));
    Iko[11][0][0] = (ik[6][0][0]-((mkrk[11][0][1]*rk[6][2])-(mkrk[11][0][2]*
      rk[6][1])));
    Iko[11][0][1] = (ik[6][0][1]-(mkrk[11][0][2]*rk[6][0]));
    Iko[11][0][2] = (ik[6][0][2]+(mkrk[11][0][1]*rk[6][0]));
    Iko[11][1][0] = (ik[6][1][0]+(mkrk[11][1][2]*rk[6][1]));
    Iko[11][1][1] = (ik[6][1][1]-((mkrk[11][1][2]*rk[6][0])-(mkrk[11][1][0]*
      rk[6][2])));
    Iko[11][1][2] = (ik[6][1][2]-(mkrk[11][1][0]*rk[6][1]));
    Iko[11][2][0] = (ik[6][2][0]-(mkrk[11][2][1]*rk[6][2]));
    Iko[11][2][1] = (ik[6][2][1]+(mkrk[11][2][0]*rk[6][2]));
    Iko[11][2][2] = (ik[6][2][2]-((mkrk[11][2][0]*rk[6][1])-(mkrk[11][2][1]*
      rk[6][0])));
    Iko[12][0][0] = (ik[7][0][0]-((mkrk[12][0][1]*rk[7][2])-(mkrk[12][0][2]*
      rk[7][1])));
    Iko[12][0][1] = (ik[7][0][1]-(mkrk[12][0][2]*rk[7][0]));
    Iko[12][0][2] = (ik[7][0][2]+(mkrk[12][0][1]*rk[7][0]));
    Iko[12][1][0] = (ik[7][1][0]+(mkrk[12][1][2]*rk[7][1]));
    Iko[12][1][1] = (ik[7][1][1]-((mkrk[12][1][2]*rk[7][0])-(mkrk[12][1][0]*
      rk[7][2])));
    Iko[12][1][2] = (ik[7][1][2]-(mkrk[12][1][0]*rk[7][1]));
    Iko[12][2][0] = (ik[7][2][0]-(mkrk[12][2][1]*rk[7][2]));
    Iko[12][2][1] = (ik[7][2][1]+(mkrk[12][2][0]*rk[7][2]));
    Iko[12][2][2] = (ik[7][2][2]-((mkrk[12][2][0]*rk[7][1])-(mkrk[12][2][1]*
      rk[7][0])));
    Iko[13][0][0] = (ik[8][0][0]-((mkrk[13][0][1]*rk[8][2])-(mkrk[13][0][2]*
      rk[8][1])));
    Iko[13][0][1] = (ik[8][0][1]-(mkrk[13][0][2]*rk[8][0]));
    Iko[13][0][2] = (ik[8][0][2]+(mkrk[13][0][1]*rk[8][0]));
    Iko[13][1][0] = (ik[8][1][0]+(mkrk[13][1][2]*rk[8][1]));
    Iko[13][1][1] = (ik[8][1][1]-((mkrk[13][1][2]*rk[8][0])-(mkrk[13][1][0]*
      rk[8][2])));
    Iko[13][1][2] = (ik[8][1][2]-(mkrk[13][1][0]*rk[8][1]));
    Iko[13][2][0] = (ik[8][2][0]-(mkrk[13][2][1]*rk[8][2]));
    Iko[13][2][1] = (ik[8][2][1]+(mkrk[13][2][0]*rk[8][2]));
    Iko[13][2][2] = (ik[8][2][2]-((mkrk[13][2][0]*rk[8][1])-(mkrk[13][2][1]*
      rk[8][0])));
    Iko[14][0][0] = (ik[9][0][0]-((mkrk[14][0][1]*rk[9][2])-(mkrk[14][0][2]*
      rk[9][1])));
    Iko[14][0][1] = (ik[9][0][1]-(mkrk[14][0][2]*rk[9][0]));
    Iko[14][0][2] = (ik[9][0][2]+(mkrk[14][0][1]*rk[9][0]));
    Iko[14][1][0] = (ik[9][1][0]+(mkrk[14][1][2]*rk[9][1]));
    Iko[14][1][1] = (ik[9][1][1]-((mkrk[14][1][2]*rk[9][0])-(mkrk[14][1][0]*
      rk[9][2])));
    Iko[14][1][2] = (ik[9][1][2]-(mkrk[14][1][0]*rk[9][1]));
    Iko[14][2][0] = (ik[9][2][0]-(mkrk[14][2][1]*rk[9][2]));
    Iko[14][2][1] = (ik[9][2][1]+(mkrk[14][2][0]*rk[9][2]));
    Iko[14][2][2] = (ik[9][2][2]-((mkrk[14][2][0]*rk[9][1])-(mkrk[14][2][1]*
      rk[9][0])));
    Iko[15][0][0] = (ik[10][0][0]-((mkrk[15][0][1]*rk[10][2])-(mkrk[15][0][2]*
      rk[10][1])));
    Iko[15][0][1] = (ik[10][0][1]-(mkrk[15][0][2]*rk[10][0]));
    Iko[15][0][2] = (ik[10][0][2]+(mkrk[15][0][1]*rk[10][0]));
    Iko[15][1][0] = (ik[10][1][0]+(mkrk[15][1][2]*rk[10][1]));
    Iko[15][1][1] = (ik[10][1][1]-((mkrk[15][1][2]*rk[10][0])-(mkrk[15][1][0]*
      rk[10][2])));
    Iko[15][1][2] = (ik[10][1][2]-(mkrk[15][1][0]*rk[10][1]));
    Iko[15][2][0] = (ik[10][2][0]-(mkrk[15][2][1]*rk[10][2]));
    Iko[15][2][1] = (ik[10][2][1]+(mkrk[15][2][0]*rk[10][2]));
    Iko[15][2][2] = (ik[10][2][2]-((mkrk[15][2][0]*rk[10][1])-(mkrk[15][2][1]*
      rk[10][0])));
    Iko[16][0][0] = (ik[11][0][0]-((mkrk[16][0][1]*rk[11][2])-(mkrk[16][0][2]*
      rk[11][1])));
    Iko[16][0][1] = (ik[11][0][1]-(mkrk[16][0][2]*rk[11][0]));
    Iko[16][0][2] = (ik[11][0][2]+(mkrk[16][0][1]*rk[11][0]));
    Iko[16][1][0] = (ik[11][1][0]+(mkrk[16][1][2]*rk[11][1]));
    Iko[16][1][1] = (ik[11][1][1]-((mkrk[16][1][2]*rk[11][0])-(mkrk[16][1][0]*
      rk[11][2])));
    Iko[16][1][2] = (ik[11][1][2]-(mkrk[16][1][0]*rk[11][1]));
    Iko[16][2][0] = (ik[11][2][0]-(mkrk[16][2][1]*rk[11][2]));
    Iko[16][2][1] = (ik[11][2][1]+(mkrk[16][2][0]*rk[11][2]));
    Iko[16][2][2] = (ik[11][2][2]-((mkrk[16][2][0]*rk[11][1])-(mkrk[16][2][1]*
      rk[11][0])));
    Iko[17][0][0] = (ik[12][0][0]-((mkrk[17][0][1]*rk[12][2])-(mkrk[17][0][2]*
      rk[12][1])));
    Iko[17][0][1] = (ik[12][0][1]-(mkrk[17][0][2]*rk[12][0]));
    Iko[17][0][2] = (ik[12][0][2]+(mkrk[17][0][1]*rk[12][0]));
    Iko[17][1][0] = (ik[12][1][0]+(mkrk[17][1][2]*rk[12][1]));
    Iko[17][1][1] = (ik[12][1][1]-((mkrk[17][1][2]*rk[12][0])-(mkrk[17][1][0]*
      rk[12][2])));
    Iko[17][1][2] = (ik[12][1][2]-(mkrk[17][1][0]*rk[12][1]));
    Iko[17][2][0] = (ik[12][2][0]-(mkrk[17][2][1]*rk[12][2]));
    Iko[17][2][1] = (ik[12][2][1]+(mkrk[17][2][0]*rk[12][2]));
    Iko[17][2][2] = (ik[12][2][2]-((mkrk[17][2][0]*rk[12][1])-(mkrk[17][2][1]*
      rk[12][0])));
    Iko[18][0][0] = (ik[13][0][0]-((mkrk[18][0][1]*rk[13][2])-(mkrk[18][0][2]*
      rk[13][1])));
    Iko[18][0][1] = (ik[13][0][1]-(mkrk[18][0][2]*rk[13][0]));
    Iko[18][0][2] = (ik[13][0][2]+(mkrk[18][0][1]*rk[13][0]));
    Iko[18][1][0] = (ik[13][1][0]+(mkrk[18][1][2]*rk[13][1]));
    Iko[18][1][1] = (ik[13][1][1]-((mkrk[18][1][2]*rk[13][0])-(mkrk[18][1][0]*
      rk[13][2])));
    Iko[18][1][2] = (ik[13][1][2]-(mkrk[18][1][0]*rk[13][1]));
    Iko[18][2][0] = (ik[13][2][0]-(mkrk[18][2][1]*rk[13][2]));
    Iko[18][2][1] = (ik[13][2][1]+(mkrk[18][2][0]*rk[13][2]));
    Iko[18][2][2] = (ik[13][2][2]-((mkrk[18][2][0]*rk[13][1])-(mkrk[18][2][1]*
      rk[13][0])));
    Iko[19][0][0] = (ik[14][0][0]-((mkrk[19][0][1]*rk[14][2])-(mkrk[19][0][2]*
      rk[14][1])));
    Iko[19][0][1] = (ik[14][0][1]-(mkrk[19][0][2]*rk[14][0]));
    Iko[19][0][2] = (ik[14][0][2]+(mkrk[19][0][1]*rk[14][0]));
    Iko[19][1][0] = (ik[14][1][0]+(mkrk[19][1][2]*rk[14][1]));
    Iko[19][1][1] = (ik[14][1][1]-((mkrk[19][1][2]*rk[14][0])-(mkrk[19][1][0]*
      rk[14][2])));
    Iko[19][1][2] = (ik[14][1][2]-(mkrk[19][1][0]*rk[14][1]));
    Iko[19][2][0] = (ik[14][2][0]-(mkrk[19][2][1]*rk[14][2]));
    Iko[19][2][1] = (ik[14][2][1]+(mkrk[19][2][0]*rk[14][2]));
    Iko[19][2][2] = (ik[14][2][2]-((mkrk[19][2][0]*rk[14][1])-(mkrk[19][2][1]*
      rk[14][0])));
    Iko[20][0][0] = (ik[15][0][0]-((mkrk[20][0][1]*rk[15][2])-(mkrk[20][0][2]*
      rk[15][1])));
    Iko[20][0][1] = (ik[15][0][1]-(mkrk[20][0][2]*rk[15][0]));
    Iko[20][0][2] = (ik[15][0][2]+(mkrk[20][0][1]*rk[15][0]));
    Iko[20][1][0] = (ik[15][1][0]+(mkrk[20][1][2]*rk[15][1]));
    Iko[20][1][1] = (ik[15][1][1]-((mkrk[20][1][2]*rk[15][0])-(mkrk[20][1][0]*
      rk[15][2])));
    Iko[20][1][2] = (ik[15][1][2]-(mkrk[20][1][0]*rk[15][1]));
    Iko[20][2][0] = (ik[15][2][0]-(mkrk[20][2][1]*rk[15][2]));
    Iko[20][2][1] = (ik[15][2][1]+(mkrk[20][2][0]*rk[15][2]));
    Iko[20][2][2] = (ik[15][2][2]-((mkrk[20][2][0]*rk[15][1])-(mkrk[20][2][1]*
      rk[15][0])));
    Iko[21][0][0] = (ik[16][0][0]-((mkrk[21][0][1]*rk[16][2])-(mkrk[21][0][2]*
      rk[16][1])));
    Iko[21][0][1] = (ik[16][0][1]-(mkrk[21][0][2]*rk[16][0]));
    Iko[21][0][2] = (ik[16][0][2]+(mkrk[21][0][1]*rk[16][0]));
    Iko[21][1][0] = (ik[16][1][0]+(mkrk[21][1][2]*rk[16][1]));
    Iko[21][1][1] = (ik[16][1][1]-((mkrk[21][1][2]*rk[16][0])-(mkrk[21][1][0]*
      rk[16][2])));
    Iko[21][1][2] = (ik[16][1][2]-(mkrk[21][1][0]*rk[16][1]));
    Iko[21][2][0] = (ik[16][2][0]-(mkrk[21][2][1]*rk[16][2]));
    Iko[21][2][1] = (ik[16][2][1]+(mkrk[21][2][0]*rk[16][2]));
    Iko[21][2][2] = (ik[16][2][2]-((mkrk[21][2][0]*rk[16][1])-(mkrk[21][2][1]*
      rk[16][0])));
    Iko[22][0][0] = (ik[17][0][0]-((mkrk[22][0][1]*rk[17][2])-(mkrk[22][0][2]*
      rk[17][1])));
    Iko[22][0][1] = (ik[17][0][1]-(mkrk[22][0][2]*rk[17][0]));
    Iko[22][0][2] = (ik[17][0][2]+(mkrk[22][0][1]*rk[17][0]));
    Iko[22][1][0] = (ik[17][1][0]+(mkrk[22][1][2]*rk[17][1]));
    Iko[22][1][1] = (ik[17][1][1]-((mkrk[22][1][2]*rk[17][0])-(mkrk[22][1][0]*
      rk[17][2])));
    Iko[22][1][2] = (ik[17][1][2]-(mkrk[22][1][0]*rk[17][1]));
    Iko[22][2][0] = (ik[17][2][0]-(mkrk[22][2][1]*rk[17][2]));
    Iko[22][2][1] = (ik[17][2][1]+(mkrk[22][2][0]*rk[17][2]));
    Iko[22][2][2] = (ik[17][2][2]-((mkrk[22][2][0]*rk[17][1])-(mkrk[22][2][1]*
      rk[17][0])));
    Iko[23][0][0] = (ik[18][0][0]-((mkrk[23][0][1]*rk[18][2])-(mkrk[23][0][2]*
      rk[18][1])));
    Iko[23][0][1] = (ik[18][0][1]-(mkrk[23][0][2]*rk[18][0]));
    Iko[23][0][2] = (ik[18][0][2]+(mkrk[23][0][1]*rk[18][0]));
    Iko[23][1][0] = (ik[18][1][0]+(mkrk[23][1][2]*rk[18][1]));
    Iko[23][1][1] = (ik[18][1][1]-((mkrk[23][1][2]*rk[18][0])-(mkrk[23][1][0]*
      rk[18][2])));
    Iko[23][1][2] = (ik[18][1][2]-(mkrk[23][1][0]*rk[18][1]));
    Iko[23][2][0] = (ik[18][2][0]-(mkrk[23][2][1]*rk[18][2]));
    Iko[23][2][1] = (ik[18][2][1]+(mkrk[23][2][0]*rk[18][2]));
    Iko[23][2][2] = (ik[18][2][2]-((mkrk[23][2][0]*rk[18][1])-(mkrk[23][2][1]*
      rk[18][0])));
    Iko[24][0][0] = (ik[19][0][0]-((mkrk[24][0][1]*rk[19][2])-(mkrk[24][0][2]*
      rk[19][1])));
    Iko[24][0][1] = (ik[19][0][1]-(mkrk[24][0][2]*rk[19][0]));
    Iko[24][0][2] = (ik[19][0][2]+(mkrk[24][0][1]*rk[19][0]));
    Iko[24][1][0] = (ik[19][1][0]+(mkrk[24][1][2]*rk[19][1]));
    Iko[24][1][1] = (ik[19][1][1]-((mkrk[24][1][2]*rk[19][0])-(mkrk[24][1][0]*
      rk[19][2])));
    Iko[24][1][2] = (ik[19][1][2]-(mkrk[24][1][0]*rk[19][1]));
    Iko[24][2][0] = (ik[19][2][0]-(mkrk[24][2][1]*rk[19][2]));
    Iko[24][2][1] = (ik[19][2][1]+(mkrk[24][2][0]*rk[19][2]));
    Iko[24][2][2] = (ik[19][2][2]-((mkrk[24][2][0]*rk[19][1])-(mkrk[24][2][1]*
      rk[19][0])));
    Iko[25][0][0] = (ik[20][0][0]-((mkrk[25][0][1]*rk[20][2])-(mkrk[25][0][2]*
      rk[20][1])));
    Iko[25][0][1] = (ik[20][0][1]-(mkrk[25][0][2]*rk[20][0]));
    Iko[25][0][2] = (ik[20][0][2]+(mkrk[25][0][1]*rk[20][0]));
    Iko[25][1][0] = (ik[20][1][0]+(mkrk[25][1][2]*rk[20][1]));
    Iko[25][1][1] = (ik[20][1][1]-((mkrk[25][1][2]*rk[20][0])-(mkrk[25][1][0]*
      rk[20][2])));
    Iko[25][1][2] = (ik[20][1][2]-(mkrk[25][1][0]*rk[20][1]));
    Iko[25][2][0] = (ik[20][2][0]-(mkrk[25][2][1]*rk[20][2]));
    Iko[25][2][1] = (ik[20][2][1]+(mkrk[25][2][0]*rk[20][2]));
    Iko[25][2][2] = (ik[20][2][2]-((mkrk[25][2][0]*rk[20][1])-(mkrk[25][2][1]*
      rk[20][0])));
    sdserialno(&i);
    if (i != 30123) {
        sdseterr(7,41);
    }
    roustate = 1;
}

/* Convert state to form using 1-2-3 Euler angles for ball joints. */

void sdst2ang(double st[27],
    double stang[26])
{
    int i;
    double dc[3][3];

    for (i = 0; i < 26; i++) {
        stang[i] = st[i];
    }
    sdquat2dc(st[3],st[4],st[5],st[26],dc);
    sddc2ang(dc,&stang[3],&stang[4],&stang[5]);
}

/* Convert 1-2-3 form of state back to Euler parameters for ball joints. */

void sdang2st(double stang[26],
    double st[27])
{
    int i;
    double dc[3][3];

    for (i = 0; i < 26; i++) {
        st[i] = stang[i];
    }
    sdang2dc(stang[3],stang[4],stang[5],dc);
    sddc2quat(dc,&st[3],&st[4],&st[5],&st[26]);
}

/* Normalize Euler parameters in state. */

void sdnrmsterr(double st[27],
    double normst[27],
    int routine)
{
    int i;
    double norm;

    for (i = 0; i < 27; i++) {
        normst[i] = st[i];
    }
    norm = sqrt(st[3]*st[3]+st[4]*st[4]+st[5]*st[5]+st[26]*st[26]);
    if (routine != 0) {
        if ((norm < .9) || (norm > 1.1)) {
            sdseterr(routine,14);
        }
    }
    if (norm == 0.) {
        normst[26] = 1.;
        norm = 1.;
    }
    norm = 1./norm;
    normst[3] = normst[3]*norm;
    normst[4] = normst[4]*norm;
    normst[5] = normst[5]*norm;
    normst[26] = normst[26]*norm;
}

void sdnormst(double st[27],
    double normst[27])
{

    sdnrmsterr(st,normst,0);
}

void sdstate(double timein,
    double qin[27],
    double uin[26])
{
/*
Compute kinematic information and store it in sdgstate.

Generated 01-Mar-2006 15:25:51 by SD/FAST, Kane's formulation
(sdfast B.2.8 #30123) on machine ID unknown
Copyright (c) 1990-1997 Symbolic Dynamics, Inc.
Copyright (c) 1990-1997 Parametric Technology Corp.
RESTRICTED RIGHTS LEGEND: Use, duplication, or disclosure by the U.S.
Government is subject to restrictions as set forth in subparagraph
(c)(1)(ii) of the Rights in Technical Data and Computer Software
clause at DFARS 52.227-7013 and similar clauses in the FAR and NASA
FAR Supplement.  Symbolic Dynamics, Inc., Mountain View, CA 94041
*/
    int i,j,qchg,uchg;
    double ee,stab;

    if ((roustate != 1) && (roustate != 2) && (roustate != 3)) {
        sdseterr(8,22);
        return;
    }
    if (roustate == 1) {
        for (i = 0; i < 26; i++) {
            if (presq[i] == 1) {
                sdseterr(8,31);
            }
        }
    }
/*
See if time or any qs have changed since last call
*/
    if ((roustate != 1) && (timein == curtim)) {
        qchg = 0;
        for (i = 0; i < 27; i++) {
            if (qin[i] != q[i]) {
                qchg = 1;
                break;
            }
        }
    } else {
        qchg = 1;
    }
/*
If time and qs are unchanged, check us
*/
    if (qchg == 0) {
        uchg = 0;
        for (i = 0; i < 26; i++) {
            if (uin[i] != u[i]) {
                uchg = 1;
                break;
            }
        }
    } else {
        uchg = 1;
    }
    curtim = timein;
    roustate = 2;
    if (qchg == 0) {
        goto skipqs;
    }
/*
Position-related variables need to be computed
*/
    vpkflg = 0;
    mmflg = 0;
    mmlduflg = 0;
    wwflg = 0;
    for (i = 0; i < 27; i++) {
        q[i] = qin[i];
    }
/*
Normalize Euler parameters in state
*/
    sdnrmsterr(q,qn,8);
/*
Compute sines and cosines of q
*/
    s6 = sin(q[6]);
    c6 = cos(q[6]);
    s7 = sin(q[7]);
    c7 = cos(q[7]);
    s8 = sin(q[8]);
    c8 = cos(q[8]);
    s9 = sin(q[9]);
    c9 = cos(q[9]);
    s10 = sin(q[10]);
    c10 = cos(q[10]);
    s11 = sin(q[11]);
    c11 = cos(q[11]);
    s12 = sin(q[12]);
    c12 = cos(q[12]);
    s13 = sin(q[13]);
    c13 = cos(q[13]);
    s14 = sin(q[14]);
    c14 = cos(q[14]);
    s15 = sin(q[15]);
    c15 = cos(q[15]);
    s16 = sin(q[16]);
    c16 = cos(q[16]);
    s17 = sin(q[17]);
    c17 = cos(q[17]);
    s18 = sin(q[18]);
    c18 = cos(q[18]);
    s19 = sin(q[19]);
    c19 = cos(q[19]);
    s20 = sin(q[20]);
    c20 = cos(q[20]);
    s21 = sin(q[21]);
    c21 = cos(q[21]);
    s22 = sin(q[22]);
    c22 = cos(q[22]);
    s23 = sin(q[23]);
    c23 = cos(q[23]);
    s24 = sin(q[24]);
    c24 = cos(q[24]);
    s25 = sin(q[25]);
    c25 = cos(q[25]);
/*
Compute across-axis direction cosines Cik
*/
    Cik[3][0][0] = (1.-(2.*((qn[4]*qn[4])+(qn[5]*qn[5]))));
    Cik[3][0][1] = (2.*((qn[3]*qn[4])-(qn[5]*qn[26])));
    Cik[3][0][2] = (2.*((qn[3]*qn[5])+(qn[4]*qn[26])));
    Cik[3][1][0] = (2.*((qn[3]*qn[4])+(qn[5]*qn[26])));
    Cik[3][1][1] = (1.-(2.*((qn[3]*qn[3])+(qn[5]*qn[5]))));
    Cik[3][1][2] = (2.*((qn[4]*qn[5])-(qn[3]*qn[26])));
    Cik[3][2][0] = (2.*((qn[3]*qn[5])-(qn[4]*qn[26])));
    Cik[3][2][1] = (2.*((qn[3]*qn[26])+(qn[4]*qn[5])));
    Cik[3][2][2] = (1.-(2.*((qn[3]*qn[3])+(qn[4]*qn[4]))));
/*
Compute across-joint direction cosines Cib
*/
/*
Compute gravity
*/
    gk[3][0] = ((Cik[3][2][0]*grav[2])+((Cik[3][0][0]*grav[0])+(Cik[3][1][0]*
      grav[1])));
    gk[3][1] = ((Cik[3][2][1]*grav[2])+((Cik[3][0][1]*grav[0])+(Cik[3][1][1]*
      grav[1])));
    gk[3][2] = ((Cik[3][2][2]*grav[2])+((Cik[3][0][2]*grav[0])+(Cik[3][1][2]*
      grav[1])));
    gk[6][0] = ((gk[3][0]*c6)+(gk[3][2]*s6));
    gk[6][2] = ((gk[3][2]*c6)-(gk[3][0]*s6));
    gk[7][0] = ((gk[3][0]*c7)+(gk[3][2]*s7));
    gk[7][2] = ((gk[3][2]*c7)-(gk[3][0]*s7));
    gk[8][1] = ((gk[3][1]*c8)-(gk[6][2]*s8));
    gk[8][2] = ((gk[3][1]*s8)+(gk[6][2]*c8));
    gk[9][1] = ((gk[3][1]*c9)+(gk[7][2]*s9));
    gk[9][2] = ((gk[7][2]*c9)-(gk[3][1]*s9));
    gk[10][0] = ((gk[6][0]*c10)-(gk[8][1]*s10));
    gk[10][1] = ((gk[6][0]*s10)+(gk[8][1]*c10));
    gk[11][0] = ((gk[7][0]*c11)+(gk[9][1]*s11));
    gk[11][1] = ((gk[9][1]*c11)-(gk[7][0]*s11));
    gk[12][0] = ((gk[3][0]*c12)-(gk[3][1]*s12));
    gk[12][1] = ((gk[3][0]*s12)+(gk[3][1]*c12));
    gk[13][0] = ((gk[3][0]*c13)+(gk[3][1]*s13));
    gk[13][1] = ((gk[3][1]*c13)-(gk[3][0]*s13));
    gk[14][1] = ((gk[12][1]*c14)-(gk[3][2]*s14));
    gk[14][2] = ((gk[3][2]*c14)+(gk[12][1]*s14));
    gk[15][1] = ((gk[3][2]*s15)+(gk[13][1]*c15));
    gk[15][2] = ((gk[3][2]*c15)-(gk[13][1]*s15));
    gk[16][0] = ((gk[12][0]*c16)+(gk[14][2]*s16));
    gk[16][2] = ((gk[14][2]*c16)-(gk[12][0]*s16));
    gk[17][0] = ((gk[13][0]*c17)+(gk[15][2]*s17));
    gk[17][2] = ((gk[15][2]*c17)-(gk[13][0]*s17));
    gk[18][0] = ((gk[16][0]*c18)+(gk[16][2]*s18));
    gk[18][2] = ((gk[16][2]*c18)-(gk[16][0]*s18));
    gk[19][0] = ((gk[17][0]*c19)+(gk[17][2]*s19));
    gk[19][2] = ((gk[17][2]*c19)-(gk[17][0]*s19));
    gk[20][0] = ((gk[18][0]*c20)+(gk[18][2]*s20));
    gk[20][2] = ((gk[18][2]*c20)-(gk[18][0]*s20));
    gk[21][0] = ((gk[19][0]*c21)+(gk[19][2]*s21));
    gk[21][2] = ((gk[19][2]*c21)-(gk[19][0]*s21));
    gk[22][1] = ((gk[14][1]*c22)-(gk[20][2]*s22));
    gk[22][2] = ((gk[14][1]*s22)+(gk[20][2]*c22));
    gk[23][1] = ((gk[15][1]*c23)+(gk[21][2]*s23));
    gk[23][2] = ((gk[21][2]*c23)-(gk[15][1]*s23));
    gk[24][0] = ((gk[3][0]*c24)+(gk[3][1]*s24));
    gk[24][1] = ((gk[3][1]*c24)-(gk[3][0]*s24));
    gk[25][0] = ((gk[3][2]*s25)+(gk[24][0]*c25));
    gk[25][2] = ((gk[3][2]*c25)-(gk[24][0]*s25));
/*
Compute cnk & cnb (direction cosines in N)
*/
    cnk[6][0][0] = ((Cik[3][0][0]*c6)+(Cik[3][0][2]*s6));
    cnk[6][0][2] = ((Cik[3][0][2]*c6)-(Cik[3][0][0]*s6));
    cnk[6][1][0] = ((Cik[3][1][0]*c6)+(Cik[3][1][2]*s6));
    cnk[6][1][2] = ((Cik[3][1][2]*c6)-(Cik[3][1][0]*s6));
    cnk[6][2][0] = ((Cik[3][2][0]*c6)+(Cik[3][2][2]*s6));
    cnk[6][2][2] = ((Cik[3][2][2]*c6)-(Cik[3][2][0]*s6));
    cnk[7][0][0] = ((Cik[3][0][0]*c7)+(Cik[3][0][2]*s7));
    cnk[7][0][2] = ((Cik[3][0][2]*c7)-(Cik[3][0][0]*s7));
    cnk[7][1][0] = ((Cik[3][1][0]*c7)+(Cik[3][1][2]*s7));
    cnk[7][1][2] = ((Cik[3][1][2]*c7)-(Cik[3][1][0]*s7));
    cnk[7][2][0] = ((Cik[3][2][0]*c7)+(Cik[3][2][2]*s7));
    cnk[7][2][2] = ((Cik[3][2][2]*c7)-(Cik[3][2][0]*s7));
    cnk[8][0][1] = ((Cik[3][0][1]*c8)-(cnk[6][0][2]*s8));
    cnk[8][0][2] = ((Cik[3][0][1]*s8)+(cnk[6][0][2]*c8));
    cnk[8][1][1] = ((Cik[3][1][1]*c8)-(cnk[6][1][2]*s8));
    cnk[8][1][2] = ((Cik[3][1][1]*s8)+(cnk[6][1][2]*c8));
    cnk[8][2][1] = ((Cik[3][2][1]*c8)-(cnk[6][2][2]*s8));
    cnk[8][2][2] = ((Cik[3][2][1]*s8)+(cnk[6][2][2]*c8));
    cnk[9][0][1] = ((Cik[3][0][1]*c9)+(cnk[7][0][2]*s9));
    cnk[9][0][2] = ((cnk[7][0][2]*c9)-(Cik[3][0][1]*s9));
    cnk[9][1][1] = ((Cik[3][1][1]*c9)+(cnk[7][1][2]*s9));
    cnk[9][1][2] = ((cnk[7][1][2]*c9)-(Cik[3][1][1]*s9));
    cnk[9][2][1] = ((Cik[3][2][1]*c9)+(cnk[7][2][2]*s9));
    cnk[9][2][2] = ((cnk[7][2][2]*c9)-(Cik[3][2][1]*s9));
    cnk[10][0][0] = ((cnk[6][0][0]*c10)-(cnk[8][0][1]*s10));
    cnk[10][0][1] = ((cnk[6][0][0]*s10)+(cnk[8][0][1]*c10));
    cnk[10][1][0] = ((cnk[6][1][0]*c10)-(cnk[8][1][1]*s10));
    cnk[10][1][1] = ((cnk[6][1][0]*s10)+(cnk[8][1][1]*c10));
    cnk[10][2][0] = ((cnk[6][2][0]*c10)-(cnk[8][2][1]*s10));
    cnk[10][2][1] = ((cnk[6][2][0]*s10)+(cnk[8][2][1]*c10));
    cnk[11][0][0] = ((cnk[7][0][0]*c11)+(cnk[9][0][1]*s11));
    cnk[11][0][1] = ((cnk[9][0][1]*c11)-(cnk[7][0][0]*s11));
    cnk[11][1][0] = ((cnk[7][1][0]*c11)+(cnk[9][1][1]*s11));
    cnk[11][1][1] = ((cnk[9][1][1]*c11)-(cnk[7][1][0]*s11));
    cnk[11][2][0] = ((cnk[7][2][0]*c11)+(cnk[9][2][1]*s11));
    cnk[11][2][1] = ((cnk[9][2][1]*c11)-(cnk[7][2][0]*s11));
    cnk[12][0][0] = ((Cik[3][0][0]*c12)-(Cik[3][0][1]*s12));
    cnk[12][0][1] = ((Cik[3][0][0]*s12)+(Cik[3][0][1]*c12));
    cnk[12][1][0] = ((Cik[3][1][0]*c12)-(Cik[3][1][1]*s12));
    cnk[12][1][1] = ((Cik[3][1][0]*s12)+(Cik[3][1][1]*c12));
    cnk[12][2][0] = ((Cik[3][2][0]*c12)-(Cik[3][2][1]*s12));
    cnk[12][2][1] = ((Cik[3][2][0]*s12)+(Cik[3][2][1]*c12));
    cnk[13][0][0] = ((Cik[3][0][0]*c13)+(Cik[3][0][1]*s13));
    cnk[13][0][1] = ((Cik[3][0][1]*c13)-(Cik[3][0][0]*s13));
    cnk[13][1][0] = ((Cik[3][1][0]*c13)+(Cik[3][1][1]*s13));
    cnk[13][1][1] = ((Cik[3][1][1]*c13)-(Cik[3][1][0]*s13));
    cnk[13][2][0] = ((Cik[3][2][0]*c13)+(Cik[3][2][1]*s13));
    cnk[13][2][1] = ((Cik[3][2][1]*c13)-(Cik[3][2][0]*s13));
    cnk[14][0][1] = ((cnk[12][0][1]*c14)-(Cik[3][0][2]*s14));
    cnk[14][0][2] = ((Cik[3][0][2]*c14)+(cnk[12][0][1]*s14));
    cnk[14][1][1] = ((cnk[12][1][1]*c14)-(Cik[3][1][2]*s14));
    cnk[14][1][2] = ((Cik[3][1][2]*c14)+(cnk[12][1][1]*s14));
    cnk[14][2][1] = ((cnk[12][2][1]*c14)-(Cik[3][2][2]*s14));
    cnk[14][2][2] = ((Cik[3][2][2]*c14)+(cnk[12][2][1]*s14));
    cnk[15][0][1] = ((Cik[3][0][2]*s15)+(cnk[13][0][1]*c15));
    cnk[15][0][2] = ((Cik[3][0][2]*c15)-(cnk[13][0][1]*s15));
    cnk[15][1][1] = ((Cik[3][1][2]*s15)+(cnk[13][1][1]*c15));
    cnk[15][1][2] = ((Cik[3][1][2]*c15)-(cnk[13][1][1]*s15));
    cnk[15][2][1] = ((Cik[3][2][2]*s15)+(cnk[13][2][1]*c15));
    cnk[15][2][2] = ((Cik[3][2][2]*c15)-(cnk[13][2][1]*s15));
    cnk[16][0][0] = ((cnk[12][0][0]*c16)+(cnk[14][0][2]*s16));
    cnk[16][0][2] = ((cnk[14][0][2]*c16)-(cnk[12][0][0]*s16));
    cnk[16][1][0] = ((cnk[12][1][0]*c16)+(cnk[14][1][2]*s16));
    cnk[16][1][2] = ((cnk[14][1][2]*c16)-(cnk[12][1][0]*s16));
    cnk[16][2][0] = ((cnk[12][2][0]*c16)+(cnk[14][2][2]*s16));
    cnk[16][2][2] = ((cnk[14][2][2]*c16)-(cnk[12][2][0]*s16));
    cnk[17][0][0] = ((cnk[13][0][0]*c17)+(cnk[15][0][2]*s17));
    cnk[17][0][2] = ((cnk[15][0][2]*c17)-(cnk[13][0][0]*s17));
    cnk[17][1][0] = ((cnk[13][1][0]*c17)+(cnk[15][1][2]*s17));
    cnk[17][1][2] = ((cnk[15][1][2]*c17)-(cnk[13][1][0]*s17));
    cnk[17][2][0] = ((cnk[13][2][0]*c17)+(cnk[15][2][2]*s17));
    cnk[17][2][2] = ((cnk[15][2][2]*c17)-(cnk[13][2][0]*s17));
    cnk[18][0][0] = ((cnk[16][0][0]*c18)+(cnk[16][0][2]*s18));
    cnk[18][0][2] = ((cnk[16][0][2]*c18)-(cnk[16][0][0]*s18));
    cnk[18][1][0] = ((cnk[16][1][0]*c18)+(cnk[16][1][2]*s18));
    cnk[18][1][2] = ((cnk[16][1][2]*c18)-(cnk[16][1][0]*s18));
    cnk[18][2][0] = ((cnk[16][2][0]*c18)+(cnk[16][2][2]*s18));
    cnk[18][2][2] = ((cnk[16][2][2]*c18)-(cnk[16][2][0]*s18));
    cnk[19][0][0] = ((cnk[17][0][0]*c19)+(cnk[17][0][2]*s19));
    cnk[19][0][2] = ((cnk[17][0][2]*c19)-(cnk[17][0][0]*s19));
    cnk[19][1][0] = ((cnk[17][1][0]*c19)+(cnk[17][1][2]*s19));
    cnk[19][1][2] = ((cnk[17][1][2]*c19)-(cnk[17][1][0]*s19));
    cnk[19][2][0] = ((cnk[17][2][0]*c19)+(cnk[17][2][2]*s19));
    cnk[19][2][2] = ((cnk[17][2][2]*c19)-(cnk[17][2][0]*s19));
    cnk[20][0][0] = ((cnk[18][0][0]*c20)+(cnk[18][0][2]*s20));
    cnk[20][0][2] = ((cnk[18][0][2]*c20)-(cnk[18][0][0]*s20));
    cnk[20][1][0] = ((cnk[18][1][0]*c20)+(cnk[18][1][2]*s20));
    cnk[20][1][2] = ((cnk[18][1][2]*c20)-(cnk[18][1][0]*s20));
    cnk[20][2][0] = ((cnk[18][2][0]*c20)+(cnk[18][2][2]*s20));
    cnk[20][2][2] = ((cnk[18][2][2]*c20)-(cnk[18][2][0]*s20));
    cnk[21][0][0] = ((cnk[19][0][0]*c21)+(cnk[19][0][2]*s21));
    cnk[21][0][2] = ((cnk[19][0][2]*c21)-(cnk[19][0][0]*s21));
    cnk[21][1][0] = ((cnk[19][1][0]*c21)+(cnk[19][1][2]*s21));
    cnk[21][1][2] = ((cnk[19][1][2]*c21)-(cnk[19][1][0]*s21));
    cnk[21][2][0] = ((cnk[19][2][0]*c21)+(cnk[19][2][2]*s21));
    cnk[21][2][2] = ((cnk[19][2][2]*c21)-(cnk[19][2][0]*s21));
    cnk[22][0][1] = ((cnk[14][0][1]*c22)-(cnk[20][0][2]*s22));
    cnk[22][0][2] = ((cnk[14][0][1]*s22)+(cnk[20][0][2]*c22));
    cnk[22][1][1] = ((cnk[14][1][1]*c22)-(cnk[20][1][2]*s22));
    cnk[22][1][2] = ((cnk[14][1][1]*s22)+(cnk[20][1][2]*c22));
    cnk[22][2][1] = ((cnk[14][2][1]*c22)-(cnk[20][2][2]*s22));
    cnk[22][2][2] = ((cnk[14][2][1]*s22)+(cnk[20][2][2]*c22));
    cnk[23][0][1] = ((cnk[15][0][1]*c23)+(cnk[21][0][2]*s23));
    cnk[23][0][2] = ((cnk[21][0][2]*c23)-(cnk[15][0][1]*s23));
    cnk[23][1][1] = ((cnk[15][1][1]*c23)+(cnk[21][1][2]*s23));
    cnk[23][1][2] = ((cnk[21][1][2]*c23)-(cnk[15][1][1]*s23));
    cnk[23][2][1] = ((cnk[15][2][1]*c23)+(cnk[21][2][2]*s23));
    cnk[23][2][2] = ((cnk[21][2][2]*c23)-(cnk[15][2][1]*s23));
    cnk[24][0][0] = ((Cik[3][0][0]*c24)+(Cik[3][0][1]*s24));
    cnk[24][0][1] = ((Cik[3][0][1]*c24)-(Cik[3][0][0]*s24));
    cnk[24][1][0] = ((Cik[3][1][0]*c24)+(Cik[3][1][1]*s24));
    cnk[24][1][1] = ((Cik[3][1][1]*c24)-(Cik[3][1][0]*s24));
    cnk[24][2][0] = ((Cik[3][2][0]*c24)+(Cik[3][2][1]*s24));
    cnk[24][2][1] = ((Cik[3][2][1]*c24)-(Cik[3][2][0]*s24));
    cnk[25][0][0] = ((Cik[3][0][2]*s25)+(cnk[24][0][0]*c25));
    cnk[25][0][2] = ((Cik[3][0][2]*c25)-(cnk[24][0][0]*s25));
    cnk[25][1][0] = ((Cik[3][1][2]*s25)+(cnk[24][1][0]*c25));
    cnk[25][1][2] = ((Cik[3][1][2]*c25)-(cnk[24][1][0]*s25));
    cnk[25][2][0] = ((Cik[3][2][2]*s25)+(cnk[24][2][0]*c25));
    cnk[25][2][2] = ((Cik[3][2][2]*c25)-(cnk[24][2][0]*s25));
    cnb[0][0][0] = Cik[3][0][0];
    cnb[0][0][1] = Cik[3][0][1];
    cnb[0][0][2] = Cik[3][0][2];
    cnb[0][1][0] = Cik[3][1][0];
    cnb[0][1][1] = Cik[3][1][1];
    cnb[0][1][2] = Cik[3][1][2];
    cnb[0][2][0] = Cik[3][2][0];
    cnb[0][2][1] = Cik[3][2][1];
    cnb[0][2][2] = Cik[3][2][2];
    cnb[1][0][0] = cnk[6][0][0];
    cnb[1][0][1] = Cik[3][0][1];
    cnb[1][0][2] = cnk[6][0][2];
    cnb[1][1][0] = cnk[6][1][0];
    cnb[1][1][1] = Cik[3][1][1];
    cnb[1][1][2] = cnk[6][1][2];
    cnb[1][2][0] = cnk[6][2][0];
    cnb[1][2][1] = Cik[3][2][1];
    cnb[1][2][2] = cnk[6][2][2];
    cnb[2][0][0] = cnk[7][0][0];
    cnb[2][0][1] = Cik[3][0][1];
    cnb[2][0][2] = cnk[7][0][2];
    cnb[2][1][0] = cnk[7][1][0];
    cnb[2][1][1] = Cik[3][1][1];
    cnb[2][1][2] = cnk[7][1][2];
    cnb[2][2][0] = cnk[7][2][0];
    cnb[2][2][1] = Cik[3][2][1];
    cnb[2][2][2] = cnk[7][2][2];
    cnb[3][0][0] = cnk[6][0][0];
    cnb[3][0][1] = cnk[8][0][1];
    cnb[3][0][2] = cnk[8][0][2];
    cnb[3][1][0] = cnk[6][1][0];
    cnb[3][1][1] = cnk[8][1][1];
    cnb[3][1][2] = cnk[8][1][2];
    cnb[3][2][0] = cnk[6][2][0];
    cnb[3][2][1] = cnk[8][2][1];
    cnb[3][2][2] = cnk[8][2][2];
    cnb[4][0][0] = cnk[7][0][0];
    cnb[4][0][1] = cnk[9][0][1];
    cnb[4][0][2] = cnk[9][0][2];
    cnb[4][1][0] = cnk[7][1][0];
    cnb[4][1][1] = cnk[9][1][1];
    cnb[4][1][2] = cnk[9][1][2];
    cnb[4][2][0] = cnk[7][2][0];
    cnb[4][2][1] = cnk[9][2][1];
    cnb[4][2][2] = cnk[9][2][2];
    cnb[5][0][0] = cnk[10][0][0];
    cnb[5][0][1] = cnk[10][0][1];
    cnb[5][0][2] = cnk[8][0][2];
    cnb[5][1][0] = cnk[10][1][0];
    cnb[5][1][1] = cnk[10][1][1];
    cnb[5][1][2] = cnk[8][1][2];
    cnb[5][2][0] = cnk[10][2][0];
    cnb[5][2][1] = cnk[10][2][1];
    cnb[5][2][2] = cnk[8][2][2];
    cnb[6][0][0] = cnk[11][0][0];
    cnb[6][0][1] = cnk[11][0][1];
    cnb[6][0][2] = cnk[9][0][2];
    cnb[6][1][0] = cnk[11][1][0];
    cnb[6][1][1] = cnk[11][1][1];
    cnb[6][1][2] = cnk[9][1][2];
    cnb[6][2][0] = cnk[11][2][0];
    cnb[6][2][1] = cnk[11][2][1];
    cnb[6][2][2] = cnk[9][2][2];
    cnb[7][0][0] = cnk[12][0][0];
    cnb[7][0][1] = cnk[12][0][1];
    cnb[7][0][2] = Cik[3][0][2];
    cnb[7][1][0] = cnk[12][1][0];
    cnb[7][1][1] = cnk[12][1][1];
    cnb[7][1][2] = Cik[3][1][2];
    cnb[7][2][0] = cnk[12][2][0];
    cnb[7][2][1] = cnk[12][2][1];
    cnb[7][2][2] = Cik[3][2][2];
    cnb[8][0][0] = cnk[13][0][0];
    cnb[8][0][1] = cnk[13][0][1];
    cnb[8][0][2] = Cik[3][0][2];
    cnb[8][1][0] = cnk[13][1][0];
    cnb[8][1][1] = cnk[13][1][1];
    cnb[8][1][2] = Cik[3][1][2];
    cnb[8][2][0] = cnk[13][2][0];
    cnb[8][2][1] = cnk[13][2][1];
    cnb[8][2][2] = Cik[3][2][2];
    cnb[9][0][0] = cnk[12][0][0];
    cnb[9][0][1] = cnk[14][0][1];
    cnb[9][0][2] = cnk[14][0][2];
    cnb[9][1][0] = cnk[12][1][0];
    cnb[9][1][1] = cnk[14][1][1];
    cnb[9][1][2] = cnk[14][1][2];
    cnb[9][2][0] = cnk[12][2][0];
    cnb[9][2][1] = cnk[14][2][1];
    cnb[9][2][2] = cnk[14][2][2];
    cnb[10][0][0] = cnk[13][0][0];
    cnb[10][0][1] = cnk[15][0][1];
    cnb[10][0][2] = cnk[15][0][2];
    cnb[10][1][0] = cnk[13][1][0];
    cnb[10][1][1] = cnk[15][1][1];
    cnb[10][1][2] = cnk[15][1][2];
    cnb[10][2][0] = cnk[13][2][0];
    cnb[10][2][1] = cnk[15][2][1];
    cnb[10][2][2] = cnk[15][2][2];
    cnb[11][0][0] = cnk[16][0][0];
    cnb[11][0][1] = cnk[14][0][1];
    cnb[11][0][2] = cnk[16][0][2];
    cnb[11][1][0] = cnk[16][1][0];
    cnb[11][1][1] = cnk[14][1][1];
    cnb[11][1][2] = cnk[16][1][2];
    cnb[11][2][0] = cnk[16][2][0];
    cnb[11][2][1] = cnk[14][2][1];
    cnb[11][2][2] = cnk[16][2][2];
    cnb[12][0][0] = cnk[17][0][0];
    cnb[12][0][1] = cnk[15][0][1];
    cnb[12][0][2] = cnk[17][0][2];
    cnb[12][1][0] = cnk[17][1][0];
    cnb[12][1][1] = cnk[15][1][1];
    cnb[12][1][2] = cnk[17][1][2];
    cnb[12][2][0] = cnk[17][2][0];
    cnb[12][2][1] = cnk[15][2][1];
    cnb[12][2][2] = cnk[17][2][2];
    cnb[13][0][0] = cnk[18][0][0];
    cnb[13][0][1] = cnk[14][0][1];
    cnb[13][0][2] = cnk[18][0][2];
    cnb[13][1][0] = cnk[18][1][0];
    cnb[13][1][1] = cnk[14][1][1];
    cnb[13][1][2] = cnk[18][1][2];
    cnb[13][2][0] = cnk[18][2][0];
    cnb[13][2][1] = cnk[14][2][1];
    cnb[13][2][2] = cnk[18][2][2];
    cnb[14][0][0] = cnk[19][0][0];
    cnb[14][0][1] = cnk[15][0][1];
    cnb[14][0][2] = cnk[19][0][2];
    cnb[14][1][0] = cnk[19][1][0];
    cnb[14][1][1] = cnk[15][1][1];
    cnb[14][1][2] = cnk[19][1][2];
    cnb[14][2][0] = cnk[19][2][0];
    cnb[14][2][1] = cnk[15][2][1];
    cnb[14][2][2] = cnk[19][2][2];
    cnb[15][0][0] = cnk[20][0][0];
    cnb[15][0][1] = cnk[14][0][1];
    cnb[15][0][2] = cnk[20][0][2];
    cnb[15][1][0] = cnk[20][1][0];
    cnb[15][1][1] = cnk[14][1][1];
    cnb[15][1][2] = cnk[20][1][2];
    cnb[15][2][0] = cnk[20][2][0];
    cnb[15][2][1] = cnk[14][2][1];
    cnb[15][2][2] = cnk[20][2][2];
    cnb[16][0][0] = cnk[21][0][0];
    cnb[16][0][1] = cnk[15][0][1];
    cnb[16][0][2] = cnk[21][0][2];
    cnb[16][1][0] = cnk[21][1][0];
    cnb[16][1][1] = cnk[15][1][1];
    cnb[16][1][2] = cnk[21][1][2];
    cnb[16][2][0] = cnk[21][2][0];
    cnb[16][2][1] = cnk[15][2][1];
    cnb[16][2][2] = cnk[21][2][2];
    cnb[17][0][0] = cnk[20][0][0];
    cnb[17][0][1] = cnk[22][0][1];
    cnb[17][0][2] = cnk[22][0][2];
    cnb[17][1][0] = cnk[20][1][0];
    cnb[17][1][1] = cnk[22][1][1];
    cnb[17][1][2] = cnk[22][1][2];
    cnb[17][2][0] = cnk[20][2][0];
    cnb[17][2][1] = cnk[22][2][1];
    cnb[17][2][2] = cnk[22][2][2];
    cnb[18][0][0] = cnk[21][0][0];
    cnb[18][0][1] = cnk[23][0][1];
    cnb[18][0][2] = cnk[23][0][2];
    cnb[18][1][0] = cnk[21][1][0];
    cnb[18][1][1] = cnk[23][1][1];
    cnb[18][1][2] = cnk[23][1][2];
    cnb[18][2][0] = cnk[21][2][0];
    cnb[18][2][1] = cnk[23][2][1];
    cnb[18][2][2] = cnk[23][2][2];
    cnb[19][0][0] = cnk[24][0][0];
    cnb[19][0][1] = cnk[24][0][1];
    cnb[19][0][2] = Cik[3][0][2];
    cnb[19][1][0] = cnk[24][1][0];
    cnb[19][1][1] = cnk[24][1][1];
    cnb[19][1][2] = Cik[3][1][2];
    cnb[19][2][0] = cnk[24][2][0];
    cnb[19][2][1] = cnk[24][2][1];
    cnb[19][2][2] = Cik[3][2][2];
    cnb[20][0][0] = cnk[25][0][0];
    cnb[20][0][1] = cnk[24][0][1];
    cnb[20][0][2] = cnk[25][0][2];
    cnb[20][1][0] = cnk[25][1][0];
    cnb[20][1][1] = cnk[24][1][1];
    cnb[20][1][2] = cnk[25][1][2];
    cnb[20][2][0] = cnk[25][2][0];
    cnb[20][2][1] = cnk[24][2][1];
    cnb[20][2][2] = cnk[25][2][2];
/*
Compute q-related auxiliary variables
*/
    rpri[0][0] = (q[0]+ri[0][0]);
    rik[0][0] = (q[0]+ri[0][0]);
    rik[6][0] = (((ri[1][0]*c6)+(ri[1][2]*s6))-rk[1][0]);
    rik[6][1] = (ri[1][1]-rk[1][1]);
    rik[6][2] = (((ri[1][2]*c6)-(ri[1][0]*s6))-rk[1][2]);
    rik[7][0] = (((ri[2][0]*c7)+(ri[2][2]*s7))-rk[2][0]);
    rik[7][1] = (ri[2][1]-rk[2][1]);
    rik[7][2] = (((ri[2][2]*c7)-(ri[2][0]*s7))-rk[2][2]);
    rik[8][0] = (ri[3][0]-rk[3][0]);
    rik[8][1] = (((ri[3][1]*c8)-(ri[3][2]*s8))-rk[3][1]);
    rik[8][2] = (((ri[3][1]*s8)+(ri[3][2]*c8))-rk[3][2]);
    rik[9][0] = (ri[4][0]-rk[4][0]);
    rik[9][1] = (((ri[4][1]*c9)+(ri[4][2]*s9))-rk[4][1]);
    rik[9][2] = (((ri[4][2]*c9)-(ri[4][1]*s9))-rk[4][2]);
    rik[10][0] = (((ri[5][0]*c10)-(ri[5][1]*s10))-rk[5][0]);
    rik[10][1] = (((ri[5][0]*s10)+(ri[5][1]*c10))-rk[5][1]);
    rik[10][2] = (ri[5][2]-rk[5][2]);
    rik[11][0] = (((ri[6][0]*c11)+(ri[6][1]*s11))-rk[6][0]);
    rik[11][1] = (((ri[6][1]*c11)-(ri[6][0]*s11))-rk[6][1]);
    rik[11][2] = (ri[6][2]-rk[6][2]);
    rik[12][0] = (((ri[7][0]*c12)-(ri[7][1]*s12))-rk[7][0]);
    rik[12][1] = (((ri[7][0]*s12)+(ri[7][1]*c12))-rk[7][1]);
    rik[12][2] = (ri[7][2]-rk[7][2]);
    rik[13][0] = (((ri[8][0]*c13)+(ri[8][1]*s13))-rk[8][0]);
    rik[13][1] = (((ri[8][1]*c13)-(ri[8][0]*s13))-rk[8][1]);
    rik[13][2] = (ri[8][2]-rk[8][2]);
    rik[14][0] = (ri[9][0]-rk[9][0]);
    rik[14][1] = (((ri[9][1]*c14)-(ri[9][2]*s14))-rk[9][1]);
    rik[14][2] = (((ri[9][1]*s14)+(ri[9][2]*c14))-rk[9][2]);
    rik[15][0] = (ri[10][0]-rk[10][0]);
    rik[15][1] = (((ri[10][1]*c15)+(ri[10][2]*s15))-rk[10][1]);
    rik[15][2] = (((ri[10][2]*c15)-(ri[10][1]*s15))-rk[10][2]);
    rik[16][0] = (((ri[11][0]*c16)+(ri[11][2]*s16))-rk[11][0]);
    rik[16][1] = (ri[11][1]-rk[11][1]);
    rik[16][2] = (((ri[11][2]*c16)-(ri[11][0]*s16))-rk[11][2]);
    rik[17][0] = (((ri[12][0]*c17)+(ri[12][2]*s17))-rk[12][0]);
    rik[17][1] = (ri[12][1]-rk[12][1]);
    rik[17][2] = (((ri[12][2]*c17)-(ri[12][0]*s17))-rk[12][2]);
    rik[18][0] = (((ri[13][0]*c18)+(ri[13][2]*s18))-rk[13][0]);
    rik[18][1] = (ri[13][1]-rk[13][1]);
    rik[18][2] = (((ri[13][2]*c18)-(ri[13][0]*s18))-rk[13][2]);
    rik[19][0] = (((ri[14][0]*c19)+(ri[14][2]*s19))-rk[14][0]);
    rik[19][1] = (ri[14][1]-rk[14][1]);
    rik[19][2] = (((ri[14][2]*c19)-(ri[14][0]*s19))-rk[14][2]);
    rik[20][0] = (((ri[15][0]*c20)+(ri[15][2]*s20))-rk[15][0]);
    rik[20][1] = (ri[15][1]-rk[15][1]);
    rik[20][2] = (((ri[15][2]*c20)-(ri[15][0]*s20))-rk[15][2]);
    rik[21][0] = (((ri[16][0]*c21)+(ri[16][2]*s21))-rk[16][0]);
    rik[21][1] = (ri[16][1]-rk[16][1]);
    rik[21][2] = (((ri[16][2]*c21)-(ri[16][0]*s21))-rk[16][2]);
    rik[22][0] = (ri[17][0]-rk[17][0]);
    rik[22][1] = (((ri[17][1]*c22)-(ri[17][2]*s22))-rk[17][1]);
    rik[22][2] = (((ri[17][1]*s22)+(ri[17][2]*c22))-rk[17][2]);
    rik[23][0] = (ri[18][0]-rk[18][0]);
    rik[23][1] = (((ri[18][1]*c23)+(ri[18][2]*s23))-rk[18][1]);
    rik[23][2] = (((ri[18][2]*c23)-(ri[18][1]*s23))-rk[18][2]);
    rik[24][0] = (((ri[19][0]*c24)+(ri[19][1]*s24))-rk[19][0]);
    rik[24][1] = (((ri[19][1]*c24)-(ri[19][0]*s24))-rk[19][1]);
    rik[24][2] = (ri[19][2]-rk[19][2]);
    rik[25][0] = (((ri[20][0]*c25)+(ri[20][2]*s25))-rk[20][0]);
    rik[25][1] = (ri[20][1]-rk[20][1]);
    rik[25][2] = (((ri[20][2]*c25)-(ri[20][0]*s25))-rk[20][2]);
/*
Compute rnk & rnb (mass center locations in N)
*/
    rnk[0][0] = (q[0]+ri[0][0]);
    rnk[1][1] = (q[1]+ri[0][1]);
    rnk[2][2] = (q[2]+ri[0][2]);
    rnk[5][0] = (rnk[0][0]-((Cik[3][0][2]*rk[0][2])+((Cik[3][0][0]*rk[0][0])+(
      Cik[3][0][1]*rk[0][1]))));
    rnk[5][1] = (rnk[1][1]-((Cik[3][1][2]*rk[0][2])+((Cik[3][1][0]*rk[0][0])+(
      Cik[3][1][1]*rk[0][1]))));
    rnk[5][2] = (rnk[2][2]-((Cik[3][2][2]*rk[0][2])+((Cik[3][2][0]*rk[0][0])+(
      Cik[3][2][1]*rk[0][1]))));
    rnk[6][0] = ((rnk[5][0]+((Cik[3][0][2]*ri[1][2])+((Cik[3][0][0]*ri[1][0])+(
      Cik[3][0][1]*ri[1][1]))))-((cnk[6][0][2]*rk[1][2])+((Cik[3][0][1]*rk[1][1]
      )+(cnk[6][0][0]*rk[1][0]))));
    rnk[6][1] = ((rnk[5][1]+((Cik[3][1][2]*ri[1][2])+((Cik[3][1][0]*ri[1][0])+(
      Cik[3][1][1]*ri[1][1]))))-((cnk[6][1][2]*rk[1][2])+((Cik[3][1][1]*rk[1][1]
      )+(cnk[6][1][0]*rk[1][0]))));
    rnk[6][2] = ((rnk[5][2]+((Cik[3][2][2]*ri[1][2])+((Cik[3][2][0]*ri[1][0])+(
      Cik[3][2][1]*ri[1][1]))))-((cnk[6][2][2]*rk[1][2])+((Cik[3][2][1]*rk[1][1]
      )+(cnk[6][2][0]*rk[1][0]))));
    rnk[7][0] = ((rnk[5][0]+((Cik[3][0][2]*ri[2][2])+((Cik[3][0][0]*ri[2][0])+(
      Cik[3][0][1]*ri[2][1]))))-((cnk[7][0][2]*rk[2][2])+((Cik[3][0][1]*rk[2][1]
      )+(cnk[7][0][0]*rk[2][0]))));
    rnk[7][1] = ((rnk[5][1]+((Cik[3][1][2]*ri[2][2])+((Cik[3][1][0]*ri[2][0])+(
      Cik[3][1][1]*ri[2][1]))))-((cnk[7][1][2]*rk[2][2])+((Cik[3][1][1]*rk[2][1]
      )+(cnk[7][1][0]*rk[2][0]))));
    rnk[7][2] = ((rnk[5][2]+((Cik[3][2][2]*ri[2][2])+((Cik[3][2][0]*ri[2][0])+(
      Cik[3][2][1]*ri[2][1]))))-((cnk[7][2][2]*rk[2][2])+((Cik[3][2][1]*rk[2][1]
      )+(cnk[7][2][0]*rk[2][0]))));
    rnk[8][0] = ((rnk[6][0]+((cnk[6][0][2]*ri[3][2])+((Cik[3][0][1]*ri[3][1])+(
      cnk[6][0][0]*ri[3][0]))))-((cnk[8][0][2]*rk[3][2])+((cnk[6][0][0]*rk[3][0]
      )+(cnk[8][0][1]*rk[3][1]))));
    rnk[8][1] = ((rnk[6][1]+((cnk[6][1][2]*ri[3][2])+((Cik[3][1][1]*ri[3][1])+(
      cnk[6][1][0]*ri[3][0]))))-((cnk[8][1][2]*rk[3][2])+((cnk[6][1][0]*rk[3][0]
      )+(cnk[8][1][1]*rk[3][1]))));
    rnk[8][2] = ((rnk[6][2]+((cnk[6][2][2]*ri[3][2])+((Cik[3][2][1]*ri[3][1])+(
      cnk[6][2][0]*ri[3][0]))))-((cnk[8][2][2]*rk[3][2])+((cnk[6][2][0]*rk[3][0]
      )+(cnk[8][2][1]*rk[3][1]))));
    rnk[9][0] = ((rnk[7][0]+((cnk[7][0][2]*ri[4][2])+((Cik[3][0][1]*ri[4][1])+(
      cnk[7][0][0]*ri[4][0]))))-((cnk[9][0][2]*rk[4][2])+((cnk[7][0][0]*rk[4][0]
      )+(cnk[9][0][1]*rk[4][1]))));
    rnk[9][1] = ((rnk[7][1]+((cnk[7][1][2]*ri[4][2])+((Cik[3][1][1]*ri[4][1])+(
      cnk[7][1][0]*ri[4][0]))))-((cnk[9][1][2]*rk[4][2])+((cnk[7][1][0]*rk[4][0]
      )+(cnk[9][1][1]*rk[4][1]))));
    rnk[9][2] = ((rnk[7][2]+((cnk[7][2][2]*ri[4][2])+((Cik[3][2][1]*ri[4][1])+(
      cnk[7][2][0]*ri[4][0]))))-((cnk[9][2][2]*rk[4][2])+((cnk[7][2][0]*rk[4][0]
      )+(cnk[9][2][1]*rk[4][1]))));
    rnk[10][0] = ((rnk[8][0]+((cnk[8][0][2]*ri[5][2])+((cnk[6][0][0]*ri[5][0])+(
      cnk[8][0][1]*ri[5][1]))))-((cnk[8][0][2]*rk[5][2])+((cnk[10][0][0]*
      rk[5][0])+(cnk[10][0][1]*rk[5][1]))));
    rnk[10][1] = ((rnk[8][1]+((cnk[8][1][2]*ri[5][2])+((cnk[6][1][0]*ri[5][0])+(
      cnk[8][1][1]*ri[5][1]))))-((cnk[8][1][2]*rk[5][2])+((cnk[10][1][0]*
      rk[5][0])+(cnk[10][1][1]*rk[5][1]))));
    rnk[10][2] = ((rnk[8][2]+((cnk[8][2][2]*ri[5][2])+((cnk[6][2][0]*ri[5][0])+(
      cnk[8][2][1]*ri[5][1]))))-((cnk[8][2][2]*rk[5][2])+((cnk[10][2][0]*
      rk[5][0])+(cnk[10][2][1]*rk[5][1]))));
    rnk[11][0] = ((rnk[9][0]+((cnk[9][0][2]*ri[6][2])+((cnk[7][0][0]*ri[6][0])+(
      cnk[9][0][1]*ri[6][1]))))-((cnk[9][0][2]*rk[6][2])+((cnk[11][0][0]*
      rk[6][0])+(cnk[11][0][1]*rk[6][1]))));
    rnk[11][1] = ((rnk[9][1]+((cnk[9][1][2]*ri[6][2])+((cnk[7][1][0]*ri[6][0])+(
      cnk[9][1][1]*ri[6][1]))))-((cnk[9][1][2]*rk[6][2])+((cnk[11][1][0]*
      rk[6][0])+(cnk[11][1][1]*rk[6][1]))));
    rnk[11][2] = ((rnk[9][2]+((cnk[9][2][2]*ri[6][2])+((cnk[7][2][0]*ri[6][0])+(
      cnk[9][2][1]*ri[6][1]))))-((cnk[9][2][2]*rk[6][2])+((cnk[11][2][0]*
      rk[6][0])+(cnk[11][2][1]*rk[6][1]))));
    rnk[12][0] = ((rnk[5][0]+((Cik[3][0][2]*ri[7][2])+((Cik[3][0][0]*ri[7][0])+(
      Cik[3][0][1]*ri[7][1]))))-((Cik[3][0][2]*rk[7][2])+((cnk[12][0][0]*
      rk[7][0])+(cnk[12][0][1]*rk[7][1]))));
    rnk[12][1] = ((rnk[5][1]+((Cik[3][1][2]*ri[7][2])+((Cik[3][1][0]*ri[7][0])+(
      Cik[3][1][1]*ri[7][1]))))-((Cik[3][1][2]*rk[7][2])+((cnk[12][1][0]*
      rk[7][0])+(cnk[12][1][1]*rk[7][1]))));
    rnk[12][2] = ((rnk[5][2]+((Cik[3][2][2]*ri[7][2])+((Cik[3][2][0]*ri[7][0])+(
      Cik[3][2][1]*ri[7][1]))))-((Cik[3][2][2]*rk[7][2])+((cnk[12][2][0]*
      rk[7][0])+(cnk[12][2][1]*rk[7][1]))));
    rnk[13][0] = ((rnk[5][0]+((Cik[3][0][2]*ri[8][2])+((Cik[3][0][0]*ri[8][0])+(
      Cik[3][0][1]*ri[8][1]))))-((Cik[3][0][2]*rk[8][2])+((cnk[13][0][0]*
      rk[8][0])+(cnk[13][0][1]*rk[8][1]))));
    rnk[13][1] = ((rnk[5][1]+((Cik[3][1][2]*ri[8][2])+((Cik[3][1][0]*ri[8][0])+(
      Cik[3][1][1]*ri[8][1]))))-((Cik[3][1][2]*rk[8][2])+((cnk[13][1][0]*
      rk[8][0])+(cnk[13][1][1]*rk[8][1]))));
    rnk[13][2] = ((rnk[5][2]+((Cik[3][2][2]*ri[8][2])+((Cik[3][2][0]*ri[8][0])+(
      Cik[3][2][1]*ri[8][1]))))-((Cik[3][2][2]*rk[8][2])+((cnk[13][2][0]*
      rk[8][0])+(cnk[13][2][1]*rk[8][1]))));
    rnk[14][0] = ((rnk[12][0]+((Cik[3][0][2]*ri[9][2])+((cnk[12][0][0]*ri[9][0])
      +(cnk[12][0][1]*ri[9][1]))))-((cnk[14][0][2]*rk[9][2])+((cnk[12][0][0]*
      rk[9][0])+(cnk[14][0][1]*rk[9][1]))));
    rnk[14][1] = ((rnk[12][1]+((Cik[3][1][2]*ri[9][2])+((cnk[12][1][0]*ri[9][0])
      +(cnk[12][1][1]*ri[9][1]))))-((cnk[14][1][2]*rk[9][2])+((cnk[12][1][0]*
      rk[9][0])+(cnk[14][1][1]*rk[9][1]))));
    rnk[14][2] = ((rnk[12][2]+((Cik[3][2][2]*ri[9][2])+((cnk[12][2][0]*ri[9][0])
      +(cnk[12][2][1]*ri[9][1]))))-((cnk[14][2][2]*rk[9][2])+((cnk[12][2][0]*
      rk[9][0])+(cnk[14][2][1]*rk[9][1]))));
    rnk[15][0] = ((rnk[13][0]+((Cik[3][0][2]*ri[10][2])+((cnk[13][0][0]*
      ri[10][0])+(cnk[13][0][1]*ri[10][1]))))-((cnk[15][0][2]*rk[10][2])+((
      cnk[13][0][0]*rk[10][0])+(cnk[15][0][1]*rk[10][1]))));
    rnk[15][1] = ((rnk[13][1]+((Cik[3][1][2]*ri[10][2])+((cnk[13][1][0]*
      ri[10][0])+(cnk[13][1][1]*ri[10][1]))))-((cnk[15][1][2]*rk[10][2])+((
      cnk[13][1][0]*rk[10][0])+(cnk[15][1][1]*rk[10][1]))));
    rnk[15][2] = ((rnk[13][2]+((Cik[3][2][2]*ri[10][2])+((cnk[13][2][0]*
      ri[10][0])+(cnk[13][2][1]*ri[10][1]))))-((cnk[15][2][2]*rk[10][2])+((
      cnk[13][2][0]*rk[10][0])+(cnk[15][2][1]*rk[10][1]))));
    rnk[16][0] = ((rnk[14][0]+((cnk[14][0][2]*ri[11][2])+((cnk[12][0][0]*
      ri[11][0])+(cnk[14][0][1]*ri[11][1]))))-((cnk[16][0][2]*rk[11][2])+((
      cnk[14][0][1]*rk[11][1])+(cnk[16][0][0]*rk[11][0]))));
    rnk[16][1] = ((rnk[14][1]+((cnk[14][1][2]*ri[11][2])+((cnk[12][1][0]*
      ri[11][0])+(cnk[14][1][1]*ri[11][1]))))-((cnk[16][1][2]*rk[11][2])+((
      cnk[14][1][1]*rk[11][1])+(cnk[16][1][0]*rk[11][0]))));
    rnk[16][2] = ((rnk[14][2]+((cnk[14][2][2]*ri[11][2])+((cnk[12][2][0]*
      ri[11][0])+(cnk[14][2][1]*ri[11][1]))))-((cnk[16][2][2]*rk[11][2])+((
      cnk[14][2][1]*rk[11][1])+(cnk[16][2][0]*rk[11][0]))));
    rnk[17][0] = ((rnk[15][0]+((cnk[15][0][2]*ri[12][2])+((cnk[13][0][0]*
      ri[12][0])+(cnk[15][0][1]*ri[12][1]))))-((cnk[17][0][2]*rk[12][2])+((
      cnk[15][0][1]*rk[12][1])+(cnk[17][0][0]*rk[12][0]))));
    rnk[17][1] = ((rnk[15][1]+((cnk[15][1][2]*ri[12][2])+((cnk[13][1][0]*
      ri[12][0])+(cnk[15][1][1]*ri[12][1]))))-((cnk[17][1][2]*rk[12][2])+((
      cnk[15][1][1]*rk[12][1])+(cnk[17][1][0]*rk[12][0]))));
    rnk[17][2] = ((rnk[15][2]+((cnk[15][2][2]*ri[12][2])+((cnk[13][2][0]*
      ri[12][0])+(cnk[15][2][1]*ri[12][1]))))-((cnk[17][2][2]*rk[12][2])+((
      cnk[15][2][1]*rk[12][1])+(cnk[17][2][0]*rk[12][0]))));
    rnk[18][0] = ((rnk[16][0]+((cnk[16][0][2]*ri[13][2])+((cnk[14][0][1]*
      ri[13][1])+(cnk[16][0][0]*ri[13][0]))))-((cnk[18][0][2]*rk[13][2])+((
      cnk[14][0][1]*rk[13][1])+(cnk[18][0][0]*rk[13][0]))));
    rnk[18][1] = ((rnk[16][1]+((cnk[16][1][2]*ri[13][2])+((cnk[14][1][1]*
      ri[13][1])+(cnk[16][1][0]*ri[13][0]))))-((cnk[18][1][2]*rk[13][2])+((
      cnk[14][1][1]*rk[13][1])+(cnk[18][1][0]*rk[13][0]))));
    rnk[18][2] = ((rnk[16][2]+((cnk[16][2][2]*ri[13][2])+((cnk[14][2][1]*
      ri[13][1])+(cnk[16][2][0]*ri[13][0]))))-((cnk[18][2][2]*rk[13][2])+((
      cnk[14][2][1]*rk[13][1])+(cnk[18][2][0]*rk[13][0]))));
    rnk[19][0] = ((rnk[17][0]+((cnk[17][0][2]*ri[14][2])+((cnk[15][0][1]*
      ri[14][1])+(cnk[17][0][0]*ri[14][0]))))-((cnk[19][0][2]*rk[14][2])+((
      cnk[15][0][1]*rk[14][1])+(cnk[19][0][0]*rk[14][0]))));
    rnk[19][1] = ((rnk[17][1]+((cnk[17][1][2]*ri[14][2])+((cnk[15][1][1]*
      ri[14][1])+(cnk[17][1][0]*ri[14][0]))))-((cnk[19][1][2]*rk[14][2])+((
      cnk[15][1][1]*rk[14][1])+(cnk[19][1][0]*rk[14][0]))));
    rnk[19][2] = ((rnk[17][2]+((cnk[17][2][2]*ri[14][2])+((cnk[15][2][1]*
      ri[14][1])+(cnk[17][2][0]*ri[14][0]))))-((cnk[19][2][2]*rk[14][2])+((
      cnk[15][2][1]*rk[14][1])+(cnk[19][2][0]*rk[14][0]))));
    rnk[20][0] = ((rnk[18][0]+((cnk[18][0][2]*ri[15][2])+((cnk[14][0][1]*
      ri[15][1])+(cnk[18][0][0]*ri[15][0]))))-((cnk[20][0][2]*rk[15][2])+((
      cnk[14][0][1]*rk[15][1])+(cnk[20][0][0]*rk[15][0]))));
    rnk[20][1] = ((rnk[18][1]+((cnk[18][1][2]*ri[15][2])+((cnk[14][1][1]*
      ri[15][1])+(cnk[18][1][0]*ri[15][0]))))-((cnk[20][1][2]*rk[15][2])+((
      cnk[14][1][1]*rk[15][1])+(cnk[20][1][0]*rk[15][0]))));
    rnk[20][2] = ((rnk[18][2]+((cnk[18][2][2]*ri[15][2])+((cnk[14][2][1]*
      ri[15][1])+(cnk[18][2][0]*ri[15][0]))))-((cnk[20][2][2]*rk[15][2])+((
      cnk[14][2][1]*rk[15][1])+(cnk[20][2][0]*rk[15][0]))));
    rnk[21][0] = ((rnk[19][0]+((cnk[19][0][2]*ri[16][2])+((cnk[15][0][1]*
      ri[16][1])+(cnk[19][0][0]*ri[16][0]))))-((cnk[21][0][2]*rk[16][2])+((
      cnk[15][0][1]*rk[16][1])+(cnk[21][0][0]*rk[16][0]))));
    rnk[21][1] = ((rnk[19][1]+((cnk[19][1][2]*ri[16][2])+((cnk[15][1][1]*
      ri[16][1])+(cnk[19][1][0]*ri[16][0]))))-((cnk[21][1][2]*rk[16][2])+((
      cnk[15][1][1]*rk[16][1])+(cnk[21][1][0]*rk[16][0]))));
    rnk[21][2] = ((rnk[19][2]+((cnk[19][2][2]*ri[16][2])+((cnk[15][2][1]*
      ri[16][1])+(cnk[19][2][0]*ri[16][0]))))-((cnk[21][2][2]*rk[16][2])+((
      cnk[15][2][1]*rk[16][1])+(cnk[21][2][0]*rk[16][0]))));
    rnk[22][0] = ((rnk[20][0]+((cnk[20][0][2]*ri[17][2])+((cnk[14][0][1]*
      ri[17][1])+(cnk[20][0][0]*ri[17][0]))))-((cnk[22][0][2]*rk[17][2])+((
      cnk[20][0][0]*rk[17][0])+(cnk[22][0][1]*rk[17][1]))));
    rnk[22][1] = ((rnk[20][1]+((cnk[20][1][2]*ri[17][2])+((cnk[14][1][1]*
      ri[17][1])+(cnk[20][1][0]*ri[17][0]))))-((cnk[22][1][2]*rk[17][2])+((
      cnk[20][1][0]*rk[17][0])+(cnk[22][1][1]*rk[17][1]))));
    rnk[22][2] = ((rnk[20][2]+((cnk[20][2][2]*ri[17][2])+((cnk[14][2][1]*
      ri[17][1])+(cnk[20][2][0]*ri[17][0]))))-((cnk[22][2][2]*rk[17][2])+((
      cnk[20][2][0]*rk[17][0])+(cnk[22][2][1]*rk[17][1]))));
    rnk[23][0] = ((rnk[21][0]+((cnk[21][0][2]*ri[18][2])+((cnk[15][0][1]*
      ri[18][1])+(cnk[21][0][0]*ri[18][0]))))-((cnk[23][0][2]*rk[18][2])+((
      cnk[21][0][0]*rk[18][0])+(cnk[23][0][1]*rk[18][1]))));
    rnk[23][1] = ((rnk[21][1]+((cnk[21][1][2]*ri[18][2])+((cnk[15][1][1]*
      ri[18][1])+(cnk[21][1][0]*ri[18][0]))))-((cnk[23][1][2]*rk[18][2])+((
      cnk[21][1][0]*rk[18][0])+(cnk[23][1][1]*rk[18][1]))));
    rnk[23][2] = ((rnk[21][2]+((cnk[21][2][2]*ri[18][2])+((cnk[15][2][1]*
      ri[18][1])+(cnk[21][2][0]*ri[18][0]))))-((cnk[23][2][2]*rk[18][2])+((
      cnk[21][2][0]*rk[18][0])+(cnk[23][2][1]*rk[18][1]))));
    rnk[24][0] = ((rnk[5][0]+((Cik[3][0][2]*ri[19][2])+((Cik[3][0][0]*ri[19][0])
      +(Cik[3][0][1]*ri[19][1]))))-((Cik[3][0][2]*rk[19][2])+((cnk[24][0][0]*
      rk[19][0])+(cnk[24][0][1]*rk[19][1]))));
    rnk[24][1] = ((rnk[5][1]+((Cik[3][1][2]*ri[19][2])+((Cik[3][1][0]*ri[19][0])
      +(Cik[3][1][1]*ri[19][1]))))-((Cik[3][1][2]*rk[19][2])+((cnk[24][1][0]*
      rk[19][0])+(cnk[24][1][1]*rk[19][1]))));
    rnk[24][2] = ((rnk[5][2]+((Cik[3][2][2]*ri[19][2])+((Cik[3][2][0]*ri[19][0])
      +(Cik[3][2][1]*ri[19][1]))))-((Cik[3][2][2]*rk[19][2])+((cnk[24][2][0]*
      rk[19][0])+(cnk[24][2][1]*rk[19][1]))));
    rnk[25][0] = ((rnk[24][0]+((Cik[3][0][2]*ri[20][2])+((cnk[24][0][0]*
      ri[20][0])+(cnk[24][0][1]*ri[20][1]))))-((cnk[25][0][2]*rk[20][2])+((
      cnk[24][0][1]*rk[20][1])+(cnk[25][0][0]*rk[20][0]))));
    rnk[25][1] = ((rnk[24][1]+((Cik[3][1][2]*ri[20][2])+((cnk[24][1][0]*
      ri[20][0])+(cnk[24][1][1]*ri[20][1]))))-((cnk[25][1][2]*rk[20][2])+((
      cnk[24][1][1]*rk[20][1])+(cnk[25][1][0]*rk[20][0]))));
    rnk[25][2] = ((rnk[24][2]+((Cik[3][2][2]*ri[20][2])+((cnk[24][2][0]*
      ri[20][0])+(cnk[24][2][1]*ri[20][1]))))-((cnk[25][2][2]*rk[20][2])+((
      cnk[24][2][1]*rk[20][1])+(cnk[25][2][0]*rk[20][0]))));
    rnb[0][0] = rnk[5][0];
    rnb[0][1] = rnk[5][1];
    rnb[0][2] = rnk[5][2];
    rnb[1][0] = rnk[6][0];
    rnb[1][1] = rnk[6][1];
    rnb[1][2] = rnk[6][2];
    rnb[2][0] = rnk[7][0];
    rnb[2][1] = rnk[7][1];
    rnb[2][2] = rnk[7][2];
    rnb[3][0] = rnk[8][0];
    rnb[3][1] = rnk[8][1];
    rnb[3][2] = rnk[8][2];
    rnb[4][0] = rnk[9][0];
    rnb[4][1] = rnk[9][1];
    rnb[4][2] = rnk[9][2];
    rnb[5][0] = rnk[10][0];
    rnb[5][1] = rnk[10][1];
    rnb[5][2] = rnk[10][2];
    rnb[6][0] = rnk[11][0];
    rnb[6][1] = rnk[11][1];
    rnb[6][2] = rnk[11][2];
    rnb[7][0] = rnk[12][0];
    rnb[7][1] = rnk[12][1];
    rnb[7][2] = rnk[12][2];
    rnb[8][0] = rnk[13][0];
    rnb[8][1] = rnk[13][1];
    rnb[8][2] = rnk[13][2];
    rnb[9][0] = rnk[14][0];
    rnb[9][1] = rnk[14][1];
    rnb[9][2] = rnk[14][2];
    rnb[10][0] = rnk[15][0];
    rnb[10][1] = rnk[15][1];
    rnb[10][2] = rnk[15][2];
    rnb[11][0] = rnk[16][0];
    rnb[11][1] = rnk[16][1];
    rnb[11][2] = rnk[16][2];
    rnb[12][0] = rnk[17][0];
    rnb[12][1] = rnk[17][1];
    rnb[12][2] = rnk[17][2];
    rnb[13][0] = rnk[18][0];
    rnb[13][1] = rnk[18][1];
    rnb[13][2] = rnk[18][2];
    rnb[14][0] = rnk[19][0];
    rnb[14][1] = rnk[19][1];
    rnb[14][2] = rnk[19][2];
    rnb[15][0] = rnk[20][0];
    rnb[15][1] = rnk[20][1];
    rnb[15][2] = rnk[20][2];
    rnb[16][0] = rnk[21][0];
    rnb[16][1] = rnk[21][1];
    rnb[16][2] = rnk[21][2];
    rnb[17][0] = rnk[22][0];
    rnb[17][1] = rnk[22][1];
    rnb[17][2] = rnk[22][2];
    rnb[18][0] = rnk[23][0];
    rnb[18][1] = rnk[23][1];
    rnb[18][2] = rnk[23][2];
    rnb[19][0] = rnk[24][0];
    rnb[19][1] = rnk[24][1];
    rnb[19][2] = rnk[24][2];
    rnb[20][0] = rnk[25][0];
    rnb[20][1] = rnk[25][1];
    rnb[20][2] = rnk[25][2];
/*
Compute com (system mass center location in N)
*/
    temp[0] = ((mk[19]*rnk[24][0])+((mk[18]*rnk[23][0])+((mk[17]*rnk[22][0])+((
      mk[16]*rnk[21][0])+((mk[15]*rnk[20][0])+((mk[14]*rnk[19][0])+((mk[13]*
      rnk[18][0])+((mk[12]*rnk[17][0])+((mk[11]*rnk[16][0])+((mk[10]*rnk[15][0])
      +((mk[9]*rnk[14][0])+((mk[8]*rnk[13][0])+((mk[7]*rnk[12][0])+((mk[6]*
      rnk[11][0])+((mk[5]*rnk[10][0])+((mk[4]*rnk[9][0])+((mk[3]*rnk[8][0])+((
      mk[2]*rnk[7][0])+((mk[0]*rnk[5][0])+(mk[1]*rnk[6][0]))))))))))))))))))));
    com[0] = ((1./mtot)*((mk[20]*rnk[25][0])+temp[0]));
    temp[0] = ((mk[19]*rnk[24][1])+((mk[18]*rnk[23][1])+((mk[17]*rnk[22][1])+((
      mk[16]*rnk[21][1])+((mk[15]*rnk[20][1])+((mk[14]*rnk[19][1])+((mk[13]*
      rnk[18][1])+((mk[12]*rnk[17][1])+((mk[11]*rnk[16][1])+((mk[10]*rnk[15][1])
      +((mk[9]*rnk[14][1])+((mk[8]*rnk[13][1])+((mk[7]*rnk[12][1])+((mk[6]*
      rnk[11][1])+((mk[5]*rnk[10][1])+((mk[4]*rnk[9][1])+((mk[3]*rnk[8][1])+((
      mk[2]*rnk[7][1])+((mk[0]*rnk[5][1])+(mk[1]*rnk[6][1]))))))))))))))))))));
    com[1] = ((1./mtot)*((mk[20]*rnk[25][1])+temp[0]));
    temp[0] = ((mk[19]*rnk[24][2])+((mk[18]*rnk[23][2])+((mk[17]*rnk[22][2])+((
      mk[16]*rnk[21][2])+((mk[15]*rnk[20][2])+((mk[14]*rnk[19][2])+((mk[13]*
      rnk[18][2])+((mk[12]*rnk[17][2])+((mk[11]*rnk[16][2])+((mk[10]*rnk[15][2])
      +((mk[9]*rnk[14][2])+((mk[8]*rnk[13][2])+((mk[7]*rnk[12][2])+((mk[6]*
      rnk[11][2])+((mk[5]*rnk[10][2])+((mk[4]*rnk[9][2])+((mk[3]*rnk[8][2])+((
      mk[2]*rnk[7][2])+((mk[0]*rnk[5][2])+(mk[1]*rnk[6][2]))))))))))))))))))));
    com[2] = ((1./mtot)*((mk[20]*rnk[25][2])+temp[0]));
    skipqs: ;
    if (uchg == 0) {
        goto skipus;
    }
/*
Velocity-related variables need to be computed
*/
    inerflg = 0;
    for (i = 0; i < 26; i++) {
        u[i] = uin[i];
    }
/*
Compute u-related auxiliary variables
*/
/*
Compute wk & wb (angular velocities)
*/
    wk[6][0] = ((u[3]*c6)+(u[5]*s6));
    wk[6][1] = (u[4]-u[6]);
    wk[6][2] = ((u[5]*c6)-(u[3]*s6));
    wk[7][0] = ((u[3]*c7)+(u[5]*s7));
    wk[7][1] = (u[4]-u[7]);
    wk[7][2] = ((u[5]*c7)-(u[3]*s7));
    wk[8][0] = (wk[6][0]-u[8]);
    wk[8][1] = ((wk[6][1]*c8)-(wk[6][2]*s8));
    wk[8][2] = ((wk[6][1]*s8)+(wk[6][2]*c8));
    wk[9][0] = (u[9]+wk[7][0]);
    wk[9][1] = ((wk[7][1]*c9)+(wk[7][2]*s9));
    wk[9][2] = ((wk[7][2]*c9)-(wk[7][1]*s9));
    wk[10][0] = ((wk[8][0]*c10)-(wk[8][1]*s10));
    wk[10][1] = ((wk[8][0]*s10)+(wk[8][1]*c10));
    wk[10][2] = (wk[8][2]-u[10]);
    wk[11][0] = ((wk[9][0]*c11)+(wk[9][1]*s11));
    wk[11][1] = ((wk[9][1]*c11)-(wk[9][0]*s11));
    wk[11][2] = (u[11]+wk[9][2]);
    wk[12][0] = ((u[3]*c12)-(u[4]*s12));
    wk[12][1] = ((u[3]*s12)+(u[4]*c12));
    wk[12][2] = (u[5]-u[12]);
    wk[13][0] = ((u[3]*c13)+(u[4]*s13));
    wk[13][1] = ((u[4]*c13)-(u[3]*s13));
    wk[13][2] = (u[5]+u[13]);
    wk[14][0] = (wk[12][0]-u[14]);
    wk[14][1] = ((wk[12][1]*c14)-(wk[12][2]*s14));
    wk[14][2] = ((wk[12][1]*s14)+(wk[12][2]*c14));
    wk[15][0] = (u[15]+wk[13][0]);
    wk[15][1] = ((wk[13][1]*c15)+(wk[13][2]*s15));
    wk[15][2] = ((wk[13][2]*c15)-(wk[13][1]*s15));
    wk[16][0] = ((wk[14][0]*c16)+(wk[14][2]*s16));
    wk[16][1] = (wk[14][1]-u[16]);
    wk[16][2] = ((wk[14][2]*c16)-(wk[14][0]*s16));
    wk[17][0] = ((wk[15][0]*c17)+(wk[15][2]*s17));
    wk[17][1] = (wk[15][1]-u[17]);
    wk[17][2] = ((wk[15][2]*c17)-(wk[15][0]*s17));
    wk[18][0] = ((wk[16][0]*c18)+(wk[16][2]*s18));
    wk[18][1] = (wk[16][1]-u[18]);
    wk[18][2] = ((wk[16][2]*c18)-(wk[16][0]*s18));
    wk[19][0] = ((wk[17][0]*c19)+(wk[17][2]*s19));
    wk[19][1] = (wk[17][1]-u[19]);
    wk[19][2] = ((wk[17][2]*c19)-(wk[17][0]*s19));
    wk[20][0] = ((wk[18][0]*c20)+(wk[18][2]*s20));
    wk[20][1] = (wk[18][1]-u[20]);
    wk[20][2] = ((wk[18][2]*c20)-(wk[18][0]*s20));
    wk[21][0] = ((wk[19][0]*c21)+(wk[19][2]*s21));
    wk[21][1] = (wk[19][1]-u[21]);
    wk[21][2] = ((wk[19][2]*c21)-(wk[19][0]*s21));
    wk[22][0] = (wk[20][0]-u[22]);
    wk[22][1] = ((wk[20][1]*c22)-(wk[20][2]*s22));
    wk[22][2] = ((wk[20][1]*s22)+(wk[20][2]*c22));
    wk[23][0] = (u[23]+wk[21][0]);
    wk[23][1] = ((wk[21][1]*c23)+(wk[21][2]*s23));
    wk[23][2] = ((wk[21][2]*c23)-(wk[21][1]*s23));
    wk[24][0] = ((u[3]*c24)+(u[4]*s24));
    wk[24][1] = ((u[4]*c24)-(u[3]*s24));
    wk[24][2] = (u[5]+u[24]);
    wk[25][0] = ((wk[24][0]*c25)+(wk[24][2]*s25));
    wk[25][1] = (wk[24][1]-u[25]);
    wk[25][2] = ((wk[24][2]*c25)-(wk[24][0]*s25));
    wb[0][0] = u[3];
    wb[0][1] = u[4];
    wb[0][2] = u[5];
    wb[1][0] = wk[6][0];
    wb[1][1] = wk[6][1];
    wb[1][2] = wk[6][2];
    wb[2][0] = wk[7][0];
    wb[2][1] = wk[7][1];
    wb[2][2] = wk[7][2];
    wb[3][0] = wk[8][0];
    wb[3][1] = wk[8][1];
    wb[3][2] = wk[8][2];
    wb[4][0] = wk[9][0];
    wb[4][1] = wk[9][1];
    wb[4][2] = wk[9][2];
    wb[5][0] = wk[10][0];
    wb[5][1] = wk[10][1];
    wb[5][2] = wk[10][2];
    wb[6][0] = wk[11][0];
    wb[6][1] = wk[11][1];
    wb[6][2] = wk[11][2];
    wb[7][0] = wk[12][0];
    wb[7][1] = wk[12][1];
    wb[7][2] = wk[12][2];
    wb[8][0] = wk[13][0];
    wb[8][1] = wk[13][1];
    wb[8][2] = wk[13][2];
    wb[9][0] = wk[14][0];
    wb[9][1] = wk[14][1];
    wb[9][2] = wk[14][2];
    wb[10][0] = wk[15][0];
    wb[10][1] = wk[15][1];
    wb[10][2] = wk[15][2];
    wb[11][0] = wk[16][0];
    wb[11][1] = wk[16][1];
    wb[11][2] = wk[16][2];
    wb[12][0] = wk[17][0];
    wb[12][1] = wk[17][1];
    wb[12][2] = wk[17][2];
    wb[13][0] = wk[18][0];
    wb[13][1] = wk[18][1];
    wb[13][2] = wk[18][2];
    wb[14][0] = wk[19][0];
    wb[14][1] = wk[19][1];
    wb[14][2] = wk[19][2];
    wb[15][0] = wk[20][0];
    wb[15][1] = wk[20][1];
    wb[15][2] = wk[20][2];
    wb[16][0] = wk[21][0];
    wb[16][1] = wk[21][1];
    wb[16][2] = wk[21][2];
    wb[17][0] = wk[22][0];
    wb[17][1] = wk[22][1];
    wb[17][2] = wk[22][2];
    wb[18][0] = wk[23][0];
    wb[18][1] = wk[23][1];
    wb[18][2] = wk[23][2];
    wb[19][0] = wk[24][0];
    wb[19][1] = wk[24][1];
    wb[19][2] = wk[24][2];
    wb[20][0] = wk[25][0];
    wb[20][1] = wk[25][1];
    wb[20][2] = wk[25][2];
/*
Compute auxiliary variables involving wk
*/
    Wirk[6][0] = ((ri[1][2]*u[4])-(ri[1][1]*u[5]));
    Wirk[6][1] = ((ri[1][0]*u[5])-(ri[1][2]*u[3]));
    Wirk[6][2] = ((ri[1][1]*u[3])-(ri[1][0]*u[4]));
    Wirk[7][0] = ((ri[2][2]*u[4])-(ri[2][1]*u[5]));
    Wirk[7][1] = ((ri[2][0]*u[5])-(ri[2][2]*u[3]));
    Wirk[7][2] = ((ri[2][1]*u[3])-(ri[2][0]*u[4]));
    Wirk[8][0] = ((ri[3][2]*wk[6][1])-(ri[3][1]*wk[6][2]));
    Wirk[8][1] = ((ri[3][0]*wk[6][2])-(ri[3][2]*wk[6][0]));
    Wirk[8][2] = ((ri[3][1]*wk[6][0])-(ri[3][0]*wk[6][1]));
    Wirk[9][0] = ((ri[4][2]*wk[7][1])-(ri[4][1]*wk[7][2]));
    Wirk[9][1] = ((ri[4][0]*wk[7][2])-(ri[4][2]*wk[7][0]));
    Wirk[9][2] = ((ri[4][1]*wk[7][0])-(ri[4][0]*wk[7][1]));
    Wirk[10][0] = ((ri[5][2]*wk[8][1])-(ri[5][1]*wk[8][2]));
    Wirk[10][1] = ((ri[5][0]*wk[8][2])-(ri[5][2]*wk[8][0]));
    Wirk[10][2] = ((ri[5][1]*wk[8][0])-(ri[5][0]*wk[8][1]));
    Wirk[11][0] = ((ri[6][2]*wk[9][1])-(ri[6][1]*wk[9][2]));
    Wirk[11][1] = ((ri[6][0]*wk[9][2])-(ri[6][2]*wk[9][0]));
    Wirk[11][2] = ((ri[6][1]*wk[9][0])-(ri[6][0]*wk[9][1]));
    Wirk[12][0] = ((ri[7][2]*u[4])-(ri[7][1]*u[5]));
    Wirk[12][1] = ((ri[7][0]*u[5])-(ri[7][2]*u[3]));
    Wirk[12][2] = ((ri[7][1]*u[3])-(ri[7][0]*u[4]));
    Wirk[13][0] = ((ri[8][2]*u[4])-(ri[8][1]*u[5]));
    Wirk[13][1] = ((ri[8][0]*u[5])-(ri[8][2]*u[3]));
    Wirk[13][2] = ((ri[8][1]*u[3])-(ri[8][0]*u[4]));
    Wirk[14][0] = ((ri[9][2]*wk[12][1])-(ri[9][1]*wk[12][2]));
    Wirk[14][1] = ((ri[9][0]*wk[12][2])-(ri[9][2]*wk[12][0]));
    Wirk[14][2] = ((ri[9][1]*wk[12][0])-(ri[9][0]*wk[12][1]));
    Wirk[15][0] = ((ri[10][2]*wk[13][1])-(ri[10][1]*wk[13][2]));
    Wirk[15][1] = ((ri[10][0]*wk[13][2])-(ri[10][2]*wk[13][0]));
    Wirk[15][2] = ((ri[10][1]*wk[13][0])-(ri[10][0]*wk[13][1]));
    Wirk[16][0] = ((ri[11][2]*wk[14][1])-(ri[11][1]*wk[14][2]));
    Wirk[16][1] = ((ri[11][0]*wk[14][2])-(ri[11][2]*wk[14][0]));
    Wirk[16][2] = ((ri[11][1]*wk[14][0])-(ri[11][0]*wk[14][1]));
    Wirk[17][0] = ((ri[12][2]*wk[15][1])-(ri[12][1]*wk[15][2]));
    Wirk[17][1] = ((ri[12][0]*wk[15][2])-(ri[12][2]*wk[15][0]));
    Wirk[17][2] = ((ri[12][1]*wk[15][0])-(ri[12][0]*wk[15][1]));
    Wirk[18][0] = ((ri[13][2]*wk[16][1])-(ri[13][1]*wk[16][2]));
    Wirk[18][1] = ((ri[13][0]*wk[16][2])-(ri[13][2]*wk[16][0]));
    Wirk[18][2] = ((ri[13][1]*wk[16][0])-(ri[13][0]*wk[16][1]));
    Wirk[19][0] = ((ri[14][2]*wk[17][1])-(ri[14][1]*wk[17][2]));
    Wirk[19][1] = ((ri[14][0]*wk[17][2])-(ri[14][2]*wk[17][0]));
    Wirk[19][2] = ((ri[14][1]*wk[17][0])-(ri[14][0]*wk[17][1]));
    Wirk[20][0] = ((ri[15][2]*wk[18][1])-(ri[15][1]*wk[18][2]));
    Wirk[20][1] = ((ri[15][0]*wk[18][2])-(ri[15][2]*wk[18][0]));
    Wirk[20][2] = ((ri[15][1]*wk[18][0])-(ri[15][0]*wk[18][1]));
    Wirk[21][0] = ((ri[16][2]*wk[19][1])-(ri[16][1]*wk[19][2]));
    Wirk[21][1] = ((ri[16][0]*wk[19][2])-(ri[16][2]*wk[19][0]));
    Wirk[21][2] = ((ri[16][1]*wk[19][0])-(ri[16][0]*wk[19][1]));
    Wirk[22][0] = ((ri[17][2]*wk[20][1])-(ri[17][1]*wk[20][2]));
    Wirk[22][1] = ((ri[17][0]*wk[20][2])-(ri[17][2]*wk[20][0]));
    Wirk[22][2] = ((ri[17][1]*wk[20][0])-(ri[17][0]*wk[20][1]));
    Wirk[23][0] = ((ri[18][2]*wk[21][1])-(ri[18][1]*wk[21][2]));
    Wirk[23][1] = ((ri[18][0]*wk[21][2])-(ri[18][2]*wk[21][0]));
    Wirk[23][2] = ((ri[18][1]*wk[21][0])-(ri[18][0]*wk[21][1]));
    Wirk[24][0] = ((ri[19][2]*u[4])-(ri[19][1]*u[5]));
    Wirk[24][1] = ((ri[19][0]*u[5])-(ri[19][2]*u[3]));
    Wirk[24][2] = ((ri[19][1]*u[3])-(ri[19][0]*u[4]));
    Wirk[25][0] = ((ri[20][2]*wk[24][1])-(ri[20][1]*wk[24][2]));
    Wirk[25][1] = ((ri[20][0]*wk[24][2])-(ri[20][2]*wk[24][0]));
    Wirk[25][2] = ((ri[20][1]*wk[24][0])-(ri[20][0]*wk[24][1]));
    Wkrpk[5][0] = ((rk[0][1]*u[5])-(rk[0][2]*u[4]));
    Wkrpk[5][1] = ((rk[0][2]*u[3])-(rk[0][0]*u[5]));
    Wkrpk[5][2] = ((rk[0][0]*u[4])-(rk[0][1]*u[3]));
    Wkrpk[6][0] = ((rk[1][1]*wk[6][2])-(rk[1][2]*wk[6][1]));
    Wkrpk[6][1] = ((rk[1][2]*wk[6][0])-(rk[1][0]*wk[6][2]));
    Wkrpk[6][2] = ((rk[1][0]*wk[6][1])-(rk[1][1]*wk[6][0]));
    Wkrpk[7][0] = ((rk[2][1]*wk[7][2])-(rk[2][2]*wk[7][1]));
    Wkrpk[7][1] = ((rk[2][2]*wk[7][0])-(rk[2][0]*wk[7][2]));
    Wkrpk[7][2] = ((rk[2][0]*wk[7][1])-(rk[2][1]*wk[7][0]));
    Wkrpk[8][0] = ((rk[3][1]*wk[8][2])-(rk[3][2]*wk[8][1]));
    Wkrpk[8][1] = ((rk[3][2]*wk[8][0])-(rk[3][0]*wk[8][2]));
    Wkrpk[8][2] = ((rk[3][0]*wk[8][1])-(rk[3][1]*wk[8][0]));
    Wkrpk[9][0] = ((rk[4][1]*wk[9][2])-(rk[4][2]*wk[9][1]));
    Wkrpk[9][1] = ((rk[4][2]*wk[9][0])-(rk[4][0]*wk[9][2]));
    Wkrpk[9][2] = ((rk[4][0]*wk[9][1])-(rk[4][1]*wk[9][0]));
    Wkrpk[10][0] = ((rk[5][1]*wk[10][2])-(rk[5][2]*wk[10][1]));
    Wkrpk[10][1] = ((rk[5][2]*wk[10][0])-(rk[5][0]*wk[10][2]));
    Wkrpk[10][2] = ((rk[5][0]*wk[10][1])-(rk[5][1]*wk[10][0]));
    Wkrpk[11][0] = ((rk[6][1]*wk[11][2])-(rk[6][2]*wk[11][1]));
    Wkrpk[11][1] = ((rk[6][2]*wk[11][0])-(rk[6][0]*wk[11][2]));
    Wkrpk[11][2] = ((rk[6][0]*wk[11][1])-(rk[6][1]*wk[11][0]));
    Wkrpk[12][0] = ((rk[7][1]*wk[12][2])-(rk[7][2]*wk[12][1]));
    Wkrpk[12][1] = ((rk[7][2]*wk[12][0])-(rk[7][0]*wk[12][2]));
    Wkrpk[12][2] = ((rk[7][0]*wk[12][1])-(rk[7][1]*wk[12][0]));
    Wkrpk[13][0] = ((rk[8][1]*wk[13][2])-(rk[8][2]*wk[13][1]));
    Wkrpk[13][1] = ((rk[8][2]*wk[13][0])-(rk[8][0]*wk[13][2]));
    Wkrpk[13][2] = ((rk[8][0]*wk[13][1])-(rk[8][1]*wk[13][0]));
    Wkrpk[14][0] = ((rk[9][1]*wk[14][2])-(rk[9][2]*wk[14][1]));
    Wkrpk[14][1] = ((rk[9][2]*wk[14][0])-(rk[9][0]*wk[14][2]));
    Wkrpk[14][2] = ((rk[9][0]*wk[14][1])-(rk[9][1]*wk[14][0]));
    Wkrpk[15][0] = ((rk[10][1]*wk[15][2])-(rk[10][2]*wk[15][1]));
    Wkrpk[15][1] = ((rk[10][2]*wk[15][0])-(rk[10][0]*wk[15][2]));
    Wkrpk[15][2] = ((rk[10][0]*wk[15][1])-(rk[10][1]*wk[15][0]));
    Wkrpk[16][0] = ((rk[11][1]*wk[16][2])-(rk[11][2]*wk[16][1]));
    Wkrpk[16][1] = ((rk[11][2]*wk[16][0])-(rk[11][0]*wk[16][2]));
    Wkrpk[16][2] = ((rk[11][0]*wk[16][1])-(rk[11][1]*wk[16][0]));
    Wkrpk[17][0] = ((rk[12][1]*wk[17][2])-(rk[12][2]*wk[17][1]));
    Wkrpk[17][1] = ((rk[12][2]*wk[17][0])-(rk[12][0]*wk[17][2]));
    Wkrpk[17][2] = ((rk[12][0]*wk[17][1])-(rk[12][1]*wk[17][0]));
    Wkrpk[18][0] = ((rk[13][1]*wk[18][2])-(rk[13][2]*wk[18][1]));
    Wkrpk[18][1] = ((rk[13][2]*wk[18][0])-(rk[13][0]*wk[18][2]));
    Wkrpk[18][2] = ((rk[13][0]*wk[18][1])-(rk[13][1]*wk[18][0]));
    Wkrpk[19][0] = ((rk[14][1]*wk[19][2])-(rk[14][2]*wk[19][1]));
    Wkrpk[19][1] = ((rk[14][2]*wk[19][0])-(rk[14][0]*wk[19][2]));
    Wkrpk[19][2] = ((rk[14][0]*wk[19][1])-(rk[14][1]*wk[19][0]));
    Wkrpk[20][0] = ((rk[15][1]*wk[20][2])-(rk[15][2]*wk[20][1]));
    Wkrpk[20][1] = ((rk[15][2]*wk[20][0])-(rk[15][0]*wk[20][2]));
    Wkrpk[20][2] = ((rk[15][0]*wk[20][1])-(rk[15][1]*wk[20][0]));
    Wkrpk[21][0] = ((rk[16][1]*wk[21][2])-(rk[16][2]*wk[21][1]));
    Wkrpk[21][1] = ((rk[16][2]*wk[21][0])-(rk[16][0]*wk[21][2]));
    Wkrpk[21][2] = ((rk[16][0]*wk[21][1])-(rk[16][1]*wk[21][0]));
    Wkrpk[22][0] = ((rk[17][1]*wk[22][2])-(rk[17][2]*wk[22][1]));
    Wkrpk[22][1] = ((rk[17][2]*wk[22][0])-(rk[17][0]*wk[22][2]));
    Wkrpk[22][2] = ((rk[17][0]*wk[22][1])-(rk[17][1]*wk[22][0]));
    Wkrpk[23][0] = ((rk[18][1]*wk[23][2])-(rk[18][2]*wk[23][1]));
    Wkrpk[23][1] = ((rk[18][2]*wk[23][0])-(rk[18][0]*wk[23][2]));
    Wkrpk[23][2] = ((rk[18][0]*wk[23][1])-(rk[18][1]*wk[23][0]));
    Wkrpk[24][0] = ((rk[19][1]*wk[24][2])-(rk[19][2]*wk[24][1]));
    Wkrpk[24][1] = ((rk[19][2]*wk[24][0])-(rk[19][0]*wk[24][2]));
    Wkrpk[24][2] = ((rk[19][0]*wk[24][1])-(rk[19][1]*wk[24][0]));
    Wkrpk[25][0] = ((rk[20][1]*wk[25][2])-(rk[20][2]*wk[25][1]));
    Wkrpk[25][1] = ((rk[20][2]*wk[25][0])-(rk[20][0]*wk[25][2]));
    Wkrpk[25][2] = ((rk[20][0]*wk[25][1])-(rk[20][1]*wk[25][0]));
    IkWk[5][0] = ((ik[0][0][2]*u[5])+((ik[0][0][0]*u[3])+(ik[0][0][1]*u[4])));
    IkWk[5][1] = ((ik[0][1][2]*u[5])+((ik[0][1][0]*u[3])+(ik[0][1][1]*u[4])));
    IkWk[5][2] = ((ik[0][2][2]*u[5])+((ik[0][2][0]*u[3])+(ik[0][2][1]*u[4])));
    WkIkWk[5][0] = ((IkWk[5][2]*u[4])-(IkWk[5][1]*u[5]));
    WkIkWk[5][1] = ((IkWk[5][0]*u[5])-(IkWk[5][2]*u[3]));
    WkIkWk[5][2] = ((IkWk[5][1]*u[3])-(IkWk[5][0]*u[4]));
    IkWk[6][0] = ((ik[1][0][2]*wk[6][2])+((ik[1][0][0]*wk[6][0])+(ik[1][0][1]*
      wk[6][1])));
    IkWk[6][1] = ((ik[1][1][2]*wk[6][2])+((ik[1][1][0]*wk[6][0])+(ik[1][1][1]*
      wk[6][1])));
    IkWk[6][2] = ((ik[1][2][2]*wk[6][2])+((ik[1][2][0]*wk[6][0])+(ik[1][2][1]*
      wk[6][1])));
    WkIkWk[6][0] = ((IkWk[6][2]*wk[6][1])-(IkWk[6][1]*wk[6][2]));
    WkIkWk[6][1] = ((IkWk[6][0]*wk[6][2])-(IkWk[6][2]*wk[6][0]));
    WkIkWk[6][2] = ((IkWk[6][1]*wk[6][0])-(IkWk[6][0]*wk[6][1]));
    IkWk[7][0] = ((ik[2][0][2]*wk[7][2])+((ik[2][0][0]*wk[7][0])+(ik[2][0][1]*
      wk[7][1])));
    IkWk[7][1] = ((ik[2][1][2]*wk[7][2])+((ik[2][1][0]*wk[7][0])+(ik[2][1][1]*
      wk[7][1])));
    IkWk[7][2] = ((ik[2][2][2]*wk[7][2])+((ik[2][2][0]*wk[7][0])+(ik[2][2][1]*
      wk[7][1])));
    WkIkWk[7][0] = ((IkWk[7][2]*wk[7][1])-(IkWk[7][1]*wk[7][2]));
    WkIkWk[7][1] = ((IkWk[7][0]*wk[7][2])-(IkWk[7][2]*wk[7][0]));
    WkIkWk[7][2] = ((IkWk[7][1]*wk[7][0])-(IkWk[7][0]*wk[7][1]));
    IkWk[8][0] = ((ik[3][0][2]*wk[8][2])+((ik[3][0][0]*wk[8][0])+(ik[3][0][1]*
      wk[8][1])));
    IkWk[8][1] = ((ik[3][1][2]*wk[8][2])+((ik[3][1][0]*wk[8][0])+(ik[3][1][1]*
      wk[8][1])));
    IkWk[8][2] = ((ik[3][2][2]*wk[8][2])+((ik[3][2][0]*wk[8][0])+(ik[3][2][1]*
      wk[8][1])));
    WkIkWk[8][0] = ((IkWk[8][2]*wk[8][1])-(IkWk[8][1]*wk[8][2]));
    WkIkWk[8][1] = ((IkWk[8][0]*wk[8][2])-(IkWk[8][2]*wk[8][0]));
    WkIkWk[8][2] = ((IkWk[8][1]*wk[8][0])-(IkWk[8][0]*wk[8][1]));
    IkWk[9][0] = ((ik[4][0][2]*wk[9][2])+((ik[4][0][0]*wk[9][0])+(ik[4][0][1]*
      wk[9][1])));
    IkWk[9][1] = ((ik[4][1][2]*wk[9][2])+((ik[4][1][0]*wk[9][0])+(ik[4][1][1]*
      wk[9][1])));
    IkWk[9][2] = ((ik[4][2][2]*wk[9][2])+((ik[4][2][0]*wk[9][0])+(ik[4][2][1]*
      wk[9][1])));
    WkIkWk[9][0] = ((IkWk[9][2]*wk[9][1])-(IkWk[9][1]*wk[9][2]));
    WkIkWk[9][1] = ((IkWk[9][0]*wk[9][2])-(IkWk[9][2]*wk[9][0]));
    WkIkWk[9][2] = ((IkWk[9][1]*wk[9][0])-(IkWk[9][0]*wk[9][1]));
    IkWk[10][0] = ((ik[5][0][2]*wk[10][2])+((ik[5][0][0]*wk[10][0])+(ik[5][0][1]
      *wk[10][1])));
    IkWk[10][1] = ((ik[5][1][2]*wk[10][2])+((ik[5][1][0]*wk[10][0])+(ik[5][1][1]
      *wk[10][1])));
    IkWk[10][2] = ((ik[5][2][2]*wk[10][2])+((ik[5][2][0]*wk[10][0])+(ik[5][2][1]
      *wk[10][1])));
    WkIkWk[10][0] = ((IkWk[10][2]*wk[10][1])-(IkWk[10][1]*wk[10][2]));
    WkIkWk[10][1] = ((IkWk[10][0]*wk[10][2])-(IkWk[10][2]*wk[10][0]));
    WkIkWk[10][2] = ((IkWk[10][1]*wk[10][0])-(IkWk[10][0]*wk[10][1]));
    IkWk[11][0] = ((ik[6][0][2]*wk[11][2])+((ik[6][0][0]*wk[11][0])+(ik[6][0][1]
      *wk[11][1])));
    IkWk[11][1] = ((ik[6][1][2]*wk[11][2])+((ik[6][1][0]*wk[11][0])+(ik[6][1][1]
      *wk[11][1])));
    IkWk[11][2] = ((ik[6][2][2]*wk[11][2])+((ik[6][2][0]*wk[11][0])+(ik[6][2][1]
      *wk[11][1])));
    WkIkWk[11][0] = ((IkWk[11][2]*wk[11][1])-(IkWk[11][1]*wk[11][2]));
    WkIkWk[11][1] = ((IkWk[11][0]*wk[11][2])-(IkWk[11][2]*wk[11][0]));
    WkIkWk[11][2] = ((IkWk[11][1]*wk[11][0])-(IkWk[11][0]*wk[11][1]));
    IkWk[12][0] = ((ik[7][0][2]*wk[12][2])+((ik[7][0][0]*wk[12][0])+(ik[7][0][1]
      *wk[12][1])));
    IkWk[12][1] = ((ik[7][1][2]*wk[12][2])+((ik[7][1][0]*wk[12][0])+(ik[7][1][1]
      *wk[12][1])));
    IkWk[12][2] = ((ik[7][2][2]*wk[12][2])+((ik[7][2][0]*wk[12][0])+(ik[7][2][1]
      *wk[12][1])));
    WkIkWk[12][0] = ((IkWk[12][2]*wk[12][1])-(IkWk[12][1]*wk[12][2]));
    WkIkWk[12][1] = ((IkWk[12][0]*wk[12][2])-(IkWk[12][2]*wk[12][0]));
    WkIkWk[12][2] = ((IkWk[12][1]*wk[12][0])-(IkWk[12][0]*wk[12][1]));
    IkWk[13][0] = ((ik[8][0][2]*wk[13][2])+((ik[8][0][0]*wk[13][0])+(ik[8][0][1]
      *wk[13][1])));
    IkWk[13][1] = ((ik[8][1][2]*wk[13][2])+((ik[8][1][0]*wk[13][0])+(ik[8][1][1]
      *wk[13][1])));
    IkWk[13][2] = ((ik[8][2][2]*wk[13][2])+((ik[8][2][0]*wk[13][0])+(ik[8][2][1]
      *wk[13][1])));
    WkIkWk[13][0] = ((IkWk[13][2]*wk[13][1])-(IkWk[13][1]*wk[13][2]));
    WkIkWk[13][1] = ((IkWk[13][0]*wk[13][2])-(IkWk[13][2]*wk[13][0]));
    WkIkWk[13][2] = ((IkWk[13][1]*wk[13][0])-(IkWk[13][0]*wk[13][1]));
    IkWk[14][0] = ((ik[9][0][2]*wk[14][2])+((ik[9][0][0]*wk[14][0])+(ik[9][0][1]
      *wk[14][1])));
    IkWk[14][1] = ((ik[9][1][2]*wk[14][2])+((ik[9][1][0]*wk[14][0])+(ik[9][1][1]
      *wk[14][1])));
    IkWk[14][2] = ((ik[9][2][2]*wk[14][2])+((ik[9][2][0]*wk[14][0])+(ik[9][2][1]
      *wk[14][1])));
    WkIkWk[14][0] = ((IkWk[14][2]*wk[14][1])-(IkWk[14][1]*wk[14][2]));
    WkIkWk[14][1] = ((IkWk[14][0]*wk[14][2])-(IkWk[14][2]*wk[14][0]));
    WkIkWk[14][2] = ((IkWk[14][1]*wk[14][0])-(IkWk[14][0]*wk[14][1]));
    IkWk[15][0] = ((ik[10][0][2]*wk[15][2])+((ik[10][0][0]*wk[15][0])+(
      ik[10][0][1]*wk[15][1])));
    IkWk[15][1] = ((ik[10][1][2]*wk[15][2])+((ik[10][1][0]*wk[15][0])+(
      ik[10][1][1]*wk[15][1])));
    IkWk[15][2] = ((ik[10][2][2]*wk[15][2])+((ik[10][2][0]*wk[15][0])+(
      ik[10][2][1]*wk[15][1])));
    WkIkWk[15][0] = ((IkWk[15][2]*wk[15][1])-(IkWk[15][1]*wk[15][2]));
    WkIkWk[15][1] = ((IkWk[15][0]*wk[15][2])-(IkWk[15][2]*wk[15][0]));
    WkIkWk[15][2] = ((IkWk[15][1]*wk[15][0])-(IkWk[15][0]*wk[15][1]));
    IkWk[16][0] = ((ik[11][0][2]*wk[16][2])+((ik[11][0][0]*wk[16][0])+(
      ik[11][0][1]*wk[16][1])));
    IkWk[16][1] = ((ik[11][1][2]*wk[16][2])+((ik[11][1][0]*wk[16][0])+(
      ik[11][1][1]*wk[16][1])));
    IkWk[16][2] = ((ik[11][2][2]*wk[16][2])+((ik[11][2][0]*wk[16][0])+(
      ik[11][2][1]*wk[16][1])));
    WkIkWk[16][0] = ((IkWk[16][2]*wk[16][1])-(IkWk[16][1]*wk[16][2]));
    WkIkWk[16][1] = ((IkWk[16][0]*wk[16][2])-(IkWk[16][2]*wk[16][0]));
    WkIkWk[16][2] = ((IkWk[16][1]*wk[16][0])-(IkWk[16][0]*wk[16][1]));
    IkWk[17][0] = ((ik[12][0][2]*wk[17][2])+((ik[12][0][0]*wk[17][0])+(
      ik[12][0][1]*wk[17][1])));
    IkWk[17][1] = ((ik[12][1][2]*wk[17][2])+((ik[12][1][0]*wk[17][0])+(
      ik[12][1][1]*wk[17][1])));
    IkWk[17][2] = ((ik[12][2][2]*wk[17][2])+((ik[12][2][0]*wk[17][0])+(
      ik[12][2][1]*wk[17][1])));
    WkIkWk[17][0] = ((IkWk[17][2]*wk[17][1])-(IkWk[17][1]*wk[17][2]));
    WkIkWk[17][1] = ((IkWk[17][0]*wk[17][2])-(IkWk[17][2]*wk[17][0]));
    WkIkWk[17][2] = ((IkWk[17][1]*wk[17][0])-(IkWk[17][0]*wk[17][1]));
    IkWk[18][0] = ((ik[13][0][2]*wk[18][2])+((ik[13][0][0]*wk[18][0])+(
      ik[13][0][1]*wk[18][1])));
    IkWk[18][1] = ((ik[13][1][2]*wk[18][2])+((ik[13][1][0]*wk[18][0])+(
      ik[13][1][1]*wk[18][1])));
    IkWk[18][2] = ((ik[13][2][2]*wk[18][2])+((ik[13][2][0]*wk[18][0])+(
      ik[13][2][1]*wk[18][1])));
    WkIkWk[18][0] = ((IkWk[18][2]*wk[18][1])-(IkWk[18][1]*wk[18][2]));
    WkIkWk[18][1] = ((IkWk[18][0]*wk[18][2])-(IkWk[18][2]*wk[18][0]));
    WkIkWk[18][2] = ((IkWk[18][1]*wk[18][0])-(IkWk[18][0]*wk[18][1]));
    IkWk[19][0] = ((ik[14][0][2]*wk[19][2])+((ik[14][0][0]*wk[19][0])+(
      ik[14][0][1]*wk[19][1])));
    IkWk[19][1] = ((ik[14][1][2]*wk[19][2])+((ik[14][1][0]*wk[19][0])+(
      ik[14][1][1]*wk[19][1])));
    IkWk[19][2] = ((ik[14][2][2]*wk[19][2])+((ik[14][2][0]*wk[19][0])+(
      ik[14][2][1]*wk[19][1])));
    WkIkWk[19][0] = ((IkWk[19][2]*wk[19][1])-(IkWk[19][1]*wk[19][2]));
    WkIkWk[19][1] = ((IkWk[19][0]*wk[19][2])-(IkWk[19][2]*wk[19][0]));
    WkIkWk[19][2] = ((IkWk[19][1]*wk[19][0])-(IkWk[19][0]*wk[19][1]));
    IkWk[20][0] = ((ik[15][0][2]*wk[20][2])+((ik[15][0][0]*wk[20][0])+(
      ik[15][0][1]*wk[20][1])));
    IkWk[20][1] = ((ik[15][1][2]*wk[20][2])+((ik[15][1][0]*wk[20][0])+(
      ik[15][1][1]*wk[20][1])));
    IkWk[20][2] = ((ik[15][2][2]*wk[20][2])+((ik[15][2][0]*wk[20][0])+(
      ik[15][2][1]*wk[20][1])));
    WkIkWk[20][0] = ((IkWk[20][2]*wk[20][1])-(IkWk[20][1]*wk[20][2]));
    WkIkWk[20][1] = ((IkWk[20][0]*wk[20][2])-(IkWk[20][2]*wk[20][0]));
    WkIkWk[20][2] = ((IkWk[20][1]*wk[20][0])-(IkWk[20][0]*wk[20][1]));
    IkWk[21][0] = ((ik[16][0][2]*wk[21][2])+((ik[16][0][0]*wk[21][0])+(
      ik[16][0][1]*wk[21][1])));
    IkWk[21][1] = ((ik[16][1][2]*wk[21][2])+((ik[16][1][0]*wk[21][0])+(
      ik[16][1][1]*wk[21][1])));
    IkWk[21][2] = ((ik[16][2][2]*wk[21][2])+((ik[16][2][0]*wk[21][0])+(
      ik[16][2][1]*wk[21][1])));
    WkIkWk[21][0] = ((IkWk[21][2]*wk[21][1])-(IkWk[21][1]*wk[21][2]));
    WkIkWk[21][1] = ((IkWk[21][0]*wk[21][2])-(IkWk[21][2]*wk[21][0]));
    WkIkWk[21][2] = ((IkWk[21][1]*wk[21][0])-(IkWk[21][0]*wk[21][1]));
    IkWk[22][0] = ((ik[17][0][2]*wk[22][2])+((ik[17][0][0]*wk[22][0])+(
      ik[17][0][1]*wk[22][1])));
    IkWk[22][1] = ((ik[17][1][2]*wk[22][2])+((ik[17][1][0]*wk[22][0])+(
      ik[17][1][1]*wk[22][1])));
    IkWk[22][2] = ((ik[17][2][2]*wk[22][2])+((ik[17][2][0]*wk[22][0])+(
      ik[17][2][1]*wk[22][1])));
    WkIkWk[22][0] = ((IkWk[22][2]*wk[22][1])-(IkWk[22][1]*wk[22][2]));
    WkIkWk[22][1] = ((IkWk[22][0]*wk[22][2])-(IkWk[22][2]*wk[22][0]));
    WkIkWk[22][2] = ((IkWk[22][1]*wk[22][0])-(IkWk[22][0]*wk[22][1]));
    IkWk[23][0] = ((ik[18][0][2]*wk[23][2])+((ik[18][0][0]*wk[23][0])+(
      ik[18][0][1]*wk[23][1])));
    IkWk[23][1] = ((ik[18][1][2]*wk[23][2])+((ik[18][1][0]*wk[23][0])+(
      ik[18][1][1]*wk[23][1])));
    IkWk[23][2] = ((ik[18][2][2]*wk[23][2])+((ik[18][2][0]*wk[23][0])+(
      ik[18][2][1]*wk[23][1])));
    WkIkWk[23][0] = ((IkWk[23][2]*wk[23][1])-(IkWk[23][1]*wk[23][2]));
    WkIkWk[23][1] = ((IkWk[23][0]*wk[23][2])-(IkWk[23][2]*wk[23][0]));
    WkIkWk[23][2] = ((IkWk[23][1]*wk[23][0])-(IkWk[23][0]*wk[23][1]));
    IkWk[24][0] = ((ik[19][0][2]*wk[24][2])+((ik[19][0][0]*wk[24][0])+(
      ik[19][0][1]*wk[24][1])));
    IkWk[24][1] = ((ik[19][1][2]*wk[24][2])+((ik[19][1][0]*wk[24][0])+(
      ik[19][1][1]*wk[24][1])));
    IkWk[24][2] = ((ik[19][2][2]*wk[24][2])+((ik[19][2][0]*wk[24][0])+(
      ik[19][2][1]*wk[24][1])));
    WkIkWk[24][0] = ((IkWk[24][2]*wk[24][1])-(IkWk[24][1]*wk[24][2]));
    WkIkWk[24][1] = ((IkWk[24][0]*wk[24][2])-(IkWk[24][2]*wk[24][0]));
    WkIkWk[24][2] = ((IkWk[24][1]*wk[24][0])-(IkWk[24][0]*wk[24][1]));
    IkWk[25][0] = ((ik[20][0][2]*wk[25][2])+((ik[20][0][0]*wk[25][0])+(
      ik[20][0][1]*wk[25][1])));
    IkWk[25][1] = ((ik[20][1][2]*wk[25][2])+((ik[20][1][0]*wk[25][0])+(
      ik[20][1][1]*wk[25][1])));
    IkWk[25][2] = ((ik[20][2][2]*wk[25][2])+((ik[20][2][0]*wk[25][0])+(
      ik[20][2][1]*wk[25][1])));
    WkIkWk[25][0] = ((IkWk[25][2]*wk[25][1])-(IkWk[25][1]*wk[25][2]));
    WkIkWk[25][1] = ((IkWk[25][0]*wk[25][2])-(IkWk[25][2]*wk[25][0]));
    WkIkWk[25][2] = ((IkWk[25][1]*wk[25][0])-(IkWk[25][0]*wk[25][1]));
/*
Compute temporaries for use in SDRHS
*/
    w0w0[0] = (u[3]*u[3]);
    w0w0[1] = (wk[6][0]*wk[6][0]);
    w0w0[2] = (wk[7][0]*wk[7][0]);
    w0w0[3] = (wk[8][0]*wk[8][0]);
    w0w0[4] = (wk[9][0]*wk[9][0]);
    w0w0[5] = (wk[10][0]*wk[10][0]);
    w0w0[6] = (wk[11][0]*wk[11][0]);
    w0w0[7] = (wk[12][0]*wk[12][0]);
    w0w0[8] = (wk[13][0]*wk[13][0]);
    w0w0[9] = (wk[14][0]*wk[14][0]);
    w0w0[10] = (wk[15][0]*wk[15][0]);
    w0w0[11] = (wk[16][0]*wk[16][0]);
    w0w0[12] = (wk[17][0]*wk[17][0]);
    w0w0[13] = (wk[18][0]*wk[18][0]);
    w0w0[14] = (wk[19][0]*wk[19][0]);
    w0w0[15] = (wk[20][0]*wk[20][0]);
    w0w0[16] = (wk[21][0]*wk[21][0]);
    w0w0[17] = (wk[22][0]*wk[22][0]);
    w0w0[18] = (wk[23][0]*wk[23][0]);
    w0w0[19] = (wk[24][0]*wk[24][0]);
    w0w0[20] = (wk[25][0]*wk[25][0]);
    w1w1[0] = (u[4]*u[4]);
    w1w1[1] = (wk[6][1]*wk[6][1]);
    w1w1[2] = (wk[7][1]*wk[7][1]);
    w1w1[3] = (wk[8][1]*wk[8][1]);
    w1w1[4] = (wk[9][1]*wk[9][1]);
    w1w1[5] = (wk[10][1]*wk[10][1]);
    w1w1[6] = (wk[11][1]*wk[11][1]);
    w1w1[7] = (wk[12][1]*wk[12][1]);
    w1w1[8] = (wk[13][1]*wk[13][1]);
    w1w1[9] = (wk[14][1]*wk[14][1]);
    w1w1[10] = (wk[15][1]*wk[15][1]);
    w1w1[11] = (wk[16][1]*wk[16][1]);
    w1w1[12] = (wk[17][1]*wk[17][1]);
    w1w1[13] = (wk[18][1]*wk[18][1]);
    w1w1[14] = (wk[19][1]*wk[19][1]);
    w1w1[15] = (wk[20][1]*wk[20][1]);
    w1w1[16] = (wk[21][1]*wk[21][1]);
    w1w1[17] = (wk[22][1]*wk[22][1]);
    w1w1[18] = (wk[23][1]*wk[23][1]);
    w1w1[19] = (wk[24][1]*wk[24][1]);
    w1w1[20] = (wk[25][1]*wk[25][1]);
    w2w2[0] = (u[5]*u[5]);
    w2w2[1] = (wk[6][2]*wk[6][2]);
    w2w2[2] = (wk[7][2]*wk[7][2]);
    w2w2[3] = (wk[8][2]*wk[8][2]);
    w2w2[4] = (wk[9][2]*wk[9][2]);
    w2w2[5] = (wk[10][2]*wk[10][2]);
    w2w2[6] = (wk[11][2]*wk[11][2]);
    w2w2[7] = (wk[12][2]*wk[12][2]);
    w2w2[8] = (wk[13][2]*wk[13][2]);
    w2w2[9] = (wk[14][2]*wk[14][2]);
    w2w2[10] = (wk[15][2]*wk[15][2]);
    w2w2[11] = (wk[16][2]*wk[16][2]);
    w2w2[12] = (wk[17][2]*wk[17][2]);
    w2w2[13] = (wk[18][2]*wk[18][2]);
    w2w2[14] = (wk[19][2]*wk[19][2]);
    w2w2[15] = (wk[20][2]*wk[20][2]);
    w2w2[16] = (wk[21][2]*wk[21][2]);
    w2w2[17] = (wk[22][2]*wk[22][2]);
    w2w2[18] = (wk[23][2]*wk[23][2]);
    w2w2[19] = (wk[24][2]*wk[24][2]);
    w2w2[20] = (wk[25][2]*wk[25][2]);
    w0w1[0] = (u[3]*u[4]);
    w0w1[1] = (wk[6][0]*wk[6][1]);
    w0w1[2] = (wk[7][0]*wk[7][1]);
    w0w1[3] = (wk[8][0]*wk[8][1]);
    w0w1[4] = (wk[9][0]*wk[9][1]);
    w0w1[5] = (wk[10][0]*wk[10][1]);
    w0w1[6] = (wk[11][0]*wk[11][1]);
    w0w1[7] = (wk[12][0]*wk[12][1]);
    w0w1[8] = (wk[13][0]*wk[13][1]);
    w0w1[9] = (wk[14][0]*wk[14][1]);
    w0w1[10] = (wk[15][0]*wk[15][1]);
    w0w1[11] = (wk[16][0]*wk[16][1]);
    w0w1[12] = (wk[17][0]*wk[17][1]);
    w0w1[13] = (wk[18][0]*wk[18][1]);
    w0w1[14] = (wk[19][0]*wk[19][1]);
    w0w1[15] = (wk[20][0]*wk[20][1]);
    w0w1[16] = (wk[21][0]*wk[21][1]);
    w0w1[17] = (wk[22][0]*wk[22][1]);
    w0w1[18] = (wk[23][0]*wk[23][1]);
    w0w1[19] = (wk[24][0]*wk[24][1]);
    w0w1[20] = (wk[25][0]*wk[25][1]);
    w0w2[0] = (u[3]*u[5]);
    w0w2[1] = (wk[6][0]*wk[6][2]);
    w0w2[2] = (wk[7][0]*wk[7][2]);
    w0w2[3] = (wk[8][0]*wk[8][2]);
    w0w2[4] = (wk[9][0]*wk[9][2]);
    w0w2[5] = (wk[10][0]*wk[10][2]);
    w0w2[6] = (wk[11][0]*wk[11][2]);
    w0w2[7] = (wk[12][0]*wk[12][2]);
    w0w2[8] = (wk[13][0]*wk[13][2]);
    w0w2[9] = (wk[14][0]*wk[14][2]);
    w0w2[10] = (wk[15][0]*wk[15][2]);
    w0w2[11] = (wk[16][0]*wk[16][2]);
    w0w2[12] = (wk[17][0]*wk[17][2]);
    w0w2[13] = (wk[18][0]*wk[18][2]);
    w0w2[14] = (wk[19][0]*wk[19][2]);
    w0w2[15] = (wk[20][0]*wk[20][2]);
    w0w2[16] = (wk[21][0]*wk[21][2]);
    w0w2[17] = (wk[22][0]*wk[22][2]);
    w0w2[18] = (wk[23][0]*wk[23][2]);
    w0w2[19] = (wk[24][0]*wk[24][2]);
    w0w2[20] = (wk[25][0]*wk[25][2]);
    w1w2[0] = (u[4]*u[5]);
    w1w2[1] = (wk[6][1]*wk[6][2]);
    w1w2[2] = (wk[7][1]*wk[7][2]);
    w1w2[3] = (wk[8][1]*wk[8][2]);
    w1w2[4] = (wk[9][1]*wk[9][2]);
    w1w2[5] = (wk[10][1]*wk[10][2]);
    w1w2[6] = (wk[11][1]*wk[11][2]);
    w1w2[7] = (wk[12][1]*wk[12][2]);
    w1w2[8] = (wk[13][1]*wk[13][2]);
    w1w2[9] = (wk[14][1]*wk[14][2]);
    w1w2[10] = (wk[15][1]*wk[15][2]);
    w1w2[11] = (wk[16][1]*wk[16][2]);
    w1w2[12] = (wk[17][1]*wk[17][2]);
    w1w2[13] = (wk[18][1]*wk[18][2]);
    w1w2[14] = (wk[19][1]*wk[19][2]);
    w1w2[15] = (wk[20][1]*wk[20][2]);
    w1w2[16] = (wk[21][1]*wk[21][2]);
    w1w2[17] = (wk[22][1]*wk[22][2]);
    w1w2[18] = (wk[23][1]*wk[23][2]);
    w1w2[19] = (wk[24][1]*wk[24][2]);
    w1w2[20] = (wk[25][1]*wk[25][2]);
    w00w11[0] = -(w0w0[0]+w1w1[0]);
    w00w11[1] = -(w0w0[1]+w1w1[1]);
    w00w11[2] = -(w0w0[2]+w1w1[2]);
    w00w11[3] = -(w0w0[3]+w1w1[3]);
    w00w11[4] = -(w0w0[4]+w1w1[4]);
    w00w11[5] = -(w0w0[5]+w1w1[5]);
    w00w11[6] = -(w0w0[6]+w1w1[6]);
    w00w11[7] = -(w0w0[7]+w1w1[7]);
    w00w11[8] = -(w0w0[8]+w1w1[8]);
    w00w11[9] = -(w0w0[9]+w1w1[9]);
    w00w11[10] = -(w0w0[10]+w1w1[10]);
    w00w11[11] = -(w0w0[11]+w1w1[11]);
    w00w11[12] = -(w0w0[12]+w1w1[12]);
    w00w11[13] = -(w0w0[13]+w1w1[13]);
    w00w11[14] = -(w0w0[14]+w1w1[14]);
    w00w11[15] = -(w0w0[15]+w1w1[15]);
    w00w11[16] = -(w0w0[16]+w1w1[16]);
    w00w11[17] = -(w0w0[17]+w1w1[17]);
    w00w11[18] = -(w0w0[18]+w1w1[18]);
    w00w11[19] = -(w0w0[19]+w1w1[19]);
    w00w11[20] = -(w0w0[20]+w1w1[20]);
    w00w22[0] = -(w0w0[0]+w2w2[0]);
    w00w22[1] = -(w0w0[1]+w2w2[1]);
    w00w22[2] = -(w0w0[2]+w2w2[2]);
    w00w22[3] = -(w0w0[3]+w2w2[3]);
    w00w22[4] = -(w0w0[4]+w2w2[4]);
    w00w22[5] = -(w0w0[5]+w2w2[5]);
    w00w22[6] = -(w0w0[6]+w2w2[6]);
    w00w22[7] = -(w0w0[7]+w2w2[7]);
    w00w22[8] = -(w0w0[8]+w2w2[8]);
    w00w22[9] = -(w0w0[9]+w2w2[9]);
    w00w22[10] = -(w0w0[10]+w2w2[10]);
    w00w22[11] = -(w0w0[11]+w2w2[11]);
    w00w22[12] = -(w0w0[12]+w2w2[12]);
    w00w22[13] = -(w0w0[13]+w2w2[13]);
    w00w22[14] = -(w0w0[14]+w2w2[14]);
    w00w22[15] = -(w0w0[15]+w2w2[15]);
    w00w22[16] = -(w0w0[16]+w2w2[16]);
    w00w22[17] = -(w0w0[17]+w2w2[17]);
    w00w22[18] = -(w0w0[18]+w2w2[18]);
    w00w22[19] = -(w0w0[19]+w2w2[19]);
    w00w22[20] = -(w0w0[20]+w2w2[20]);
    w11w22[0] = -(w1w1[0]+w2w2[0]);
    w11w22[1] = -(w1w1[1]+w2w2[1]);
    w11w22[2] = -(w1w1[2]+w2w2[2]);
    w11w22[3] = -(w1w1[3]+w2w2[3]);
    w11w22[4] = -(w1w1[4]+w2w2[4]);
    w11w22[5] = -(w1w1[5]+w2w2[5]);
    w11w22[6] = -(w1w1[6]+w2w2[6]);
    w11w22[7] = -(w1w1[7]+w2w2[7]);
    w11w22[8] = -(w1w1[8]+w2w2[8]);
    w11w22[9] = -(w1w1[9]+w2w2[9]);
    w11w22[10] = -(w1w1[10]+w2w2[10]);
    w11w22[11] = -(w1w1[11]+w2w2[11]);
    w11w22[12] = -(w1w1[12]+w2w2[12]);
    w11w22[13] = -(w1w1[13]+w2w2[13]);
    w11w22[14] = -(w1w1[14]+w2w2[14]);
    w11w22[15] = -(w1w1[15]+w2w2[15]);
    w11w22[16] = -(w1w1[16]+w2w2[16]);
    w11w22[17] = -(w1w1[17]+w2w2[17]);
    w11w22[18] = -(w1w1[18]+w2w2[18]);
    w11w22[19] = -(w1w1[19]+w2w2[19]);
    w11w22[20] = -(w1w1[20]+w2w2[20]);
/*
Compute vnk & vnb (mass center linear velocities in N)
*/
    vnk[5][0] = (u[0]+((Cik[3][0][2]*Wkrpk[5][2])+((Cik[3][0][0]*Wkrpk[5][0])+(
      Cik[3][0][1]*Wkrpk[5][1]))));
    vnk[5][1] = (u[1]+((Cik[3][1][2]*Wkrpk[5][2])+((Cik[3][1][0]*Wkrpk[5][0])+(
      Cik[3][1][1]*Wkrpk[5][1]))));
    vnk[5][2] = (u[2]+((Cik[3][2][2]*Wkrpk[5][2])+((Cik[3][2][0]*Wkrpk[5][0])+(
      Cik[3][2][1]*Wkrpk[5][1]))));
    vnk[6][0] = ((vnk[5][0]+((Cik[3][0][2]*Wirk[6][2])+((Cik[3][0][0]*Wirk[6][0]
      )+(Cik[3][0][1]*Wirk[6][1]))))+((cnk[6][0][2]*Wkrpk[6][2])+((Cik[3][0][1]*
      Wkrpk[6][1])+(cnk[6][0][0]*Wkrpk[6][0]))));
    vnk[6][1] = ((vnk[5][1]+((Cik[3][1][2]*Wirk[6][2])+((Cik[3][1][0]*Wirk[6][0]
      )+(Cik[3][1][1]*Wirk[6][1]))))+((cnk[6][1][2]*Wkrpk[6][2])+((Cik[3][1][1]*
      Wkrpk[6][1])+(cnk[6][1][0]*Wkrpk[6][0]))));
    vnk[6][2] = ((vnk[5][2]+((Cik[3][2][2]*Wirk[6][2])+((Cik[3][2][0]*Wirk[6][0]
      )+(Cik[3][2][1]*Wirk[6][1]))))+((cnk[6][2][2]*Wkrpk[6][2])+((Cik[3][2][1]*
      Wkrpk[6][1])+(cnk[6][2][0]*Wkrpk[6][0]))));
    vnk[7][0] = ((vnk[5][0]+((Cik[3][0][2]*Wirk[7][2])+((Cik[3][0][0]*Wirk[7][0]
      )+(Cik[3][0][1]*Wirk[7][1]))))+((cnk[7][0][2]*Wkrpk[7][2])+((Cik[3][0][1]*
      Wkrpk[7][1])+(cnk[7][0][0]*Wkrpk[7][0]))));
    vnk[7][1] = ((vnk[5][1]+((Cik[3][1][2]*Wirk[7][2])+((Cik[3][1][0]*Wirk[7][0]
      )+(Cik[3][1][1]*Wirk[7][1]))))+((cnk[7][1][2]*Wkrpk[7][2])+((Cik[3][1][1]*
      Wkrpk[7][1])+(cnk[7][1][0]*Wkrpk[7][0]))));
    vnk[7][2] = ((vnk[5][2]+((Cik[3][2][2]*Wirk[7][2])+((Cik[3][2][0]*Wirk[7][0]
      )+(Cik[3][2][1]*Wirk[7][1]))))+((cnk[7][2][2]*Wkrpk[7][2])+((Cik[3][2][1]*
      Wkrpk[7][1])+(cnk[7][2][0]*Wkrpk[7][0]))));
    vnk[8][0] = ((vnk[6][0]+((cnk[6][0][2]*Wirk[8][2])+((Cik[3][0][1]*Wirk[8][1]
      )+(cnk[6][0][0]*Wirk[8][0]))))+((cnk[8][0][2]*Wkrpk[8][2])+((cnk[6][0][0]*
      Wkrpk[8][0])+(cnk[8][0][1]*Wkrpk[8][1]))));
    vnk[8][1] = ((vnk[6][1]+((cnk[6][1][2]*Wirk[8][2])+((Cik[3][1][1]*Wirk[8][1]
      )+(cnk[6][1][0]*Wirk[8][0]))))+((cnk[8][1][2]*Wkrpk[8][2])+((cnk[6][1][0]*
      Wkrpk[8][0])+(cnk[8][1][1]*Wkrpk[8][1]))));
    vnk[8][2] = ((vnk[6][2]+((cnk[6][2][2]*Wirk[8][2])+((Cik[3][2][1]*Wirk[8][1]
      )+(cnk[6][2][0]*Wirk[8][0]))))+((cnk[8][2][2]*Wkrpk[8][2])+((cnk[6][2][0]*
      Wkrpk[8][0])+(cnk[8][2][1]*Wkrpk[8][1]))));
    vnk[9][0] = ((vnk[7][0]+((cnk[7][0][2]*Wirk[9][2])+((Cik[3][0][1]*Wirk[9][1]
      )+(cnk[7][0][0]*Wirk[9][0]))))+((cnk[9][0][2]*Wkrpk[9][2])+((cnk[7][0][0]*
      Wkrpk[9][0])+(cnk[9][0][1]*Wkrpk[9][1]))));
    vnk[9][1] = ((vnk[7][1]+((cnk[7][1][2]*Wirk[9][2])+((Cik[3][1][1]*Wirk[9][1]
      )+(cnk[7][1][0]*Wirk[9][0]))))+((cnk[9][1][2]*Wkrpk[9][2])+((cnk[7][1][0]*
      Wkrpk[9][0])+(cnk[9][1][1]*Wkrpk[9][1]))));
    vnk[9][2] = ((vnk[7][2]+((cnk[7][2][2]*Wirk[9][2])+((Cik[3][2][1]*Wirk[9][1]
      )+(cnk[7][2][0]*Wirk[9][0]))))+((cnk[9][2][2]*Wkrpk[9][2])+((cnk[7][2][0]*
      Wkrpk[9][0])+(cnk[9][2][1]*Wkrpk[9][1]))));
    vnk[10][0] = ((vnk[8][0]+((cnk[8][0][2]*Wirk[10][2])+((cnk[6][0][0]*
      Wirk[10][0])+(cnk[8][0][1]*Wirk[10][1]))))+((cnk[8][0][2]*Wkrpk[10][2])+((
      cnk[10][0][0]*Wkrpk[10][0])+(cnk[10][0][1]*Wkrpk[10][1]))));
    vnk[10][1] = ((vnk[8][1]+((cnk[8][1][2]*Wirk[10][2])+((cnk[6][1][0]*
      Wirk[10][0])+(cnk[8][1][1]*Wirk[10][1]))))+((cnk[8][1][2]*Wkrpk[10][2])+((
      cnk[10][1][0]*Wkrpk[10][0])+(cnk[10][1][1]*Wkrpk[10][1]))));
    vnk[10][2] = ((vnk[8][2]+((cnk[8][2][2]*Wirk[10][2])+((cnk[6][2][0]*
      Wirk[10][0])+(cnk[8][2][1]*Wirk[10][1]))))+((cnk[8][2][2]*Wkrpk[10][2])+((
      cnk[10][2][0]*Wkrpk[10][0])+(cnk[10][2][1]*Wkrpk[10][1]))));
    vnk[11][0] = ((vnk[9][0]+((cnk[9][0][2]*Wirk[11][2])+((cnk[7][0][0]*
      Wirk[11][0])+(cnk[9][0][1]*Wirk[11][1]))))+((cnk[9][0][2]*Wkrpk[11][2])+((
      cnk[11][0][0]*Wkrpk[11][0])+(cnk[11][0][1]*Wkrpk[11][1]))));
    vnk[11][1] = ((vnk[9][1]+((cnk[9][1][2]*Wirk[11][2])+((cnk[7][1][0]*
      Wirk[11][0])+(cnk[9][1][1]*Wirk[11][1]))))+((cnk[9][1][2]*Wkrpk[11][2])+((
      cnk[11][1][0]*Wkrpk[11][0])+(cnk[11][1][1]*Wkrpk[11][1]))));
    vnk[11][2] = ((vnk[9][2]+((cnk[9][2][2]*Wirk[11][2])+((cnk[7][2][0]*
      Wirk[11][0])+(cnk[9][2][1]*Wirk[11][1]))))+((cnk[9][2][2]*Wkrpk[11][2])+((
      cnk[11][2][0]*Wkrpk[11][0])+(cnk[11][2][1]*Wkrpk[11][1]))));
    vnk[12][0] = ((vnk[5][0]+((Cik[3][0][2]*Wirk[12][2])+((Cik[3][0][0]*
      Wirk[12][0])+(Cik[3][0][1]*Wirk[12][1]))))+((Cik[3][0][2]*Wkrpk[12][2])+((
      cnk[12][0][0]*Wkrpk[12][0])+(cnk[12][0][1]*Wkrpk[12][1]))));
    vnk[12][1] = ((vnk[5][1]+((Cik[3][1][2]*Wirk[12][2])+((Cik[3][1][0]*
      Wirk[12][0])+(Cik[3][1][1]*Wirk[12][1]))))+((Cik[3][1][2]*Wkrpk[12][2])+((
      cnk[12][1][0]*Wkrpk[12][0])+(cnk[12][1][1]*Wkrpk[12][1]))));
    vnk[12][2] = ((vnk[5][2]+((Cik[3][2][2]*Wirk[12][2])+((Cik[3][2][0]*
      Wirk[12][0])+(Cik[3][2][1]*Wirk[12][1]))))+((Cik[3][2][2]*Wkrpk[12][2])+((
      cnk[12][2][0]*Wkrpk[12][0])+(cnk[12][2][1]*Wkrpk[12][1]))));
    vnk[13][0] = ((vnk[5][0]+((Cik[3][0][2]*Wirk[13][2])+((Cik[3][0][0]*
      Wirk[13][0])+(Cik[3][0][1]*Wirk[13][1]))))+((Cik[3][0][2]*Wkrpk[13][2])+((
      cnk[13][0][0]*Wkrpk[13][0])+(cnk[13][0][1]*Wkrpk[13][1]))));
    vnk[13][1] = ((vnk[5][1]+((Cik[3][1][2]*Wirk[13][2])+((Cik[3][1][0]*
      Wirk[13][0])+(Cik[3][1][1]*Wirk[13][1]))))+((Cik[3][1][2]*Wkrpk[13][2])+((
      cnk[13][1][0]*Wkrpk[13][0])+(cnk[13][1][1]*Wkrpk[13][1]))));
    vnk[13][2] = ((vnk[5][2]+((Cik[3][2][2]*Wirk[13][2])+((Cik[3][2][0]*
      Wirk[13][0])+(Cik[3][2][1]*Wirk[13][1]))))+((Cik[3][2][2]*Wkrpk[13][2])+((
      cnk[13][2][0]*Wkrpk[13][0])+(cnk[13][2][1]*Wkrpk[13][1]))));
    vnk[14][0] = ((vnk[12][0]+((Cik[3][0][2]*Wirk[14][2])+((cnk[12][0][0]*
      Wirk[14][0])+(cnk[12][0][1]*Wirk[14][1]))))+((cnk[14][0][2]*Wkrpk[14][2])+
      ((cnk[12][0][0]*Wkrpk[14][0])+(cnk[14][0][1]*Wkrpk[14][1]))));
    vnk[14][1] = ((vnk[12][1]+((Cik[3][1][2]*Wirk[14][2])+((cnk[12][1][0]*
      Wirk[14][0])+(cnk[12][1][1]*Wirk[14][1]))))+((cnk[14][1][2]*Wkrpk[14][2])+
      ((cnk[12][1][0]*Wkrpk[14][0])+(cnk[14][1][1]*Wkrpk[14][1]))));
    vnk[14][2] = ((vnk[12][2]+((Cik[3][2][2]*Wirk[14][2])+((cnk[12][2][0]*
      Wirk[14][0])+(cnk[12][2][1]*Wirk[14][1]))))+((cnk[14][2][2]*Wkrpk[14][2])+
      ((cnk[12][2][0]*Wkrpk[14][0])+(cnk[14][2][1]*Wkrpk[14][1]))));
    vnk[15][0] = ((vnk[13][0]+((Cik[3][0][2]*Wirk[15][2])+((cnk[13][0][0]*
      Wirk[15][0])+(cnk[13][0][1]*Wirk[15][1]))))+((cnk[15][0][2]*Wkrpk[15][2])+
      ((cnk[13][0][0]*Wkrpk[15][0])+(cnk[15][0][1]*Wkrpk[15][1]))));
    vnk[15][1] = ((vnk[13][1]+((Cik[3][1][2]*Wirk[15][2])+((cnk[13][1][0]*
      Wirk[15][0])+(cnk[13][1][1]*Wirk[15][1]))))+((cnk[15][1][2]*Wkrpk[15][2])+
      ((cnk[13][1][0]*Wkrpk[15][0])+(cnk[15][1][1]*Wkrpk[15][1]))));
    vnk[15][2] = ((vnk[13][2]+((Cik[3][2][2]*Wirk[15][2])+((cnk[13][2][0]*
      Wirk[15][0])+(cnk[13][2][1]*Wirk[15][1]))))+((cnk[15][2][2]*Wkrpk[15][2])+
      ((cnk[13][2][0]*Wkrpk[15][0])+(cnk[15][2][1]*Wkrpk[15][1]))));
    vnk[16][0] = ((vnk[14][0]+((cnk[14][0][2]*Wirk[16][2])+((cnk[12][0][0]*
      Wirk[16][0])+(cnk[14][0][1]*Wirk[16][1]))))+((cnk[16][0][2]*Wkrpk[16][2])+
      ((cnk[14][0][1]*Wkrpk[16][1])+(cnk[16][0][0]*Wkrpk[16][0]))));
    vnk[16][1] = ((vnk[14][1]+((cnk[14][1][2]*Wirk[16][2])+((cnk[12][1][0]*
      Wirk[16][0])+(cnk[14][1][1]*Wirk[16][1]))))+((cnk[16][1][2]*Wkrpk[16][2])+
      ((cnk[14][1][1]*Wkrpk[16][1])+(cnk[16][1][0]*Wkrpk[16][0]))));
    vnk[16][2] = ((vnk[14][2]+((cnk[14][2][2]*Wirk[16][2])+((cnk[12][2][0]*
      Wirk[16][0])+(cnk[14][2][1]*Wirk[16][1]))))+((cnk[16][2][2]*Wkrpk[16][2])+
      ((cnk[14][2][1]*Wkrpk[16][1])+(cnk[16][2][0]*Wkrpk[16][0]))));
    vnk[17][0] = ((vnk[15][0]+((cnk[15][0][2]*Wirk[17][2])+((cnk[13][0][0]*
      Wirk[17][0])+(cnk[15][0][1]*Wirk[17][1]))))+((cnk[17][0][2]*Wkrpk[17][2])+
      ((cnk[15][0][1]*Wkrpk[17][1])+(cnk[17][0][0]*Wkrpk[17][0]))));
    vnk[17][1] = ((vnk[15][1]+((cnk[15][1][2]*Wirk[17][2])+((cnk[13][1][0]*
      Wirk[17][0])+(cnk[15][1][1]*Wirk[17][1]))))+((cnk[17][1][2]*Wkrpk[17][2])+
      ((cnk[15][1][1]*Wkrpk[17][1])+(cnk[17][1][0]*Wkrpk[17][0]))));
    vnk[17][2] = ((vnk[15][2]+((cnk[15][2][2]*Wirk[17][2])+((cnk[13][2][0]*
      Wirk[17][0])+(cnk[15][2][1]*Wirk[17][1]))))+((cnk[17][2][2]*Wkrpk[17][2])+
      ((cnk[15][2][1]*Wkrpk[17][1])+(cnk[17][2][0]*Wkrpk[17][0]))));
    vnk[18][0] = ((vnk[16][0]+((cnk[16][0][2]*Wirk[18][2])+((cnk[14][0][1]*
      Wirk[18][1])+(cnk[16][0][0]*Wirk[18][0]))))+((cnk[18][0][2]*Wkrpk[18][2])+
      ((cnk[14][0][1]*Wkrpk[18][1])+(cnk[18][0][0]*Wkrpk[18][0]))));
    vnk[18][1] = ((vnk[16][1]+((cnk[16][1][2]*Wirk[18][2])+((cnk[14][1][1]*
      Wirk[18][1])+(cnk[16][1][0]*Wirk[18][0]))))+((cnk[18][1][2]*Wkrpk[18][2])+
      ((cnk[14][1][1]*Wkrpk[18][1])+(cnk[18][1][0]*Wkrpk[18][0]))));
    vnk[18][2] = ((vnk[16][2]+((cnk[16][2][2]*Wirk[18][2])+((cnk[14][2][1]*
      Wirk[18][1])+(cnk[16][2][0]*Wirk[18][0]))))+((cnk[18][2][2]*Wkrpk[18][2])+
      ((cnk[14][2][1]*Wkrpk[18][1])+(cnk[18][2][0]*Wkrpk[18][0]))));
    vnk[19][0] = ((vnk[17][0]+((cnk[17][0][2]*Wirk[19][2])+((cnk[15][0][1]*
      Wirk[19][1])+(cnk[17][0][0]*Wirk[19][0]))))+((cnk[19][0][2]*Wkrpk[19][2])+
      ((cnk[15][0][1]*Wkrpk[19][1])+(cnk[19][0][0]*Wkrpk[19][0]))));
    vnk[19][1] = ((vnk[17][1]+((cnk[17][1][2]*Wirk[19][2])+((cnk[15][1][1]*
      Wirk[19][1])+(cnk[17][1][0]*Wirk[19][0]))))+((cnk[19][1][2]*Wkrpk[19][2])+
      ((cnk[15][1][1]*Wkrpk[19][1])+(cnk[19][1][0]*Wkrpk[19][0]))));
    vnk[19][2] = ((vnk[17][2]+((cnk[17][2][2]*Wirk[19][2])+((cnk[15][2][1]*
      Wirk[19][1])+(cnk[17][2][0]*Wirk[19][0]))))+((cnk[19][2][2]*Wkrpk[19][2])+
      ((cnk[15][2][1]*Wkrpk[19][1])+(cnk[19][2][0]*Wkrpk[19][0]))));
    vnk[20][0] = ((vnk[18][0]+((cnk[18][0][2]*Wirk[20][2])+((cnk[14][0][1]*
      Wirk[20][1])+(cnk[18][0][0]*Wirk[20][0]))))+((cnk[20][0][2]*Wkrpk[20][2])+
      ((cnk[14][0][1]*Wkrpk[20][1])+(cnk[20][0][0]*Wkrpk[20][0]))));
    vnk[20][1] = ((vnk[18][1]+((cnk[18][1][2]*Wirk[20][2])+((cnk[14][1][1]*
      Wirk[20][1])+(cnk[18][1][0]*Wirk[20][0]))))+((cnk[20][1][2]*Wkrpk[20][2])+
      ((cnk[14][1][1]*Wkrpk[20][1])+(cnk[20][1][0]*Wkrpk[20][0]))));
    vnk[20][2] = ((vnk[18][2]+((cnk[18][2][2]*Wirk[20][2])+((cnk[14][2][1]*
      Wirk[20][1])+(cnk[18][2][0]*Wirk[20][0]))))+((cnk[20][2][2]*Wkrpk[20][2])+
      ((cnk[14][2][1]*Wkrpk[20][1])+(cnk[20][2][0]*Wkrpk[20][0]))));
    vnk[21][0] = ((vnk[19][0]+((cnk[19][0][2]*Wirk[21][2])+((cnk[15][0][1]*
      Wirk[21][1])+(cnk[19][0][0]*Wirk[21][0]))))+((cnk[21][0][2]*Wkrpk[21][2])+
      ((cnk[15][0][1]*Wkrpk[21][1])+(cnk[21][0][0]*Wkrpk[21][0]))));
    vnk[21][1] = ((vnk[19][1]+((cnk[19][1][2]*Wirk[21][2])+((cnk[15][1][1]*
      Wirk[21][1])+(cnk[19][1][0]*Wirk[21][0]))))+((cnk[21][1][2]*Wkrpk[21][2])+
      ((cnk[15][1][1]*Wkrpk[21][1])+(cnk[21][1][0]*Wkrpk[21][0]))));
    vnk[21][2] = ((vnk[19][2]+((cnk[19][2][2]*Wirk[21][2])+((cnk[15][2][1]*
      Wirk[21][1])+(cnk[19][2][0]*Wirk[21][0]))))+((cnk[21][2][2]*Wkrpk[21][2])+
      ((cnk[15][2][1]*Wkrpk[21][1])+(cnk[21][2][0]*Wkrpk[21][0]))));
    vnk[22][0] = ((vnk[20][0]+((cnk[20][0][2]*Wirk[22][2])+((cnk[14][0][1]*
      Wirk[22][1])+(cnk[20][0][0]*Wirk[22][0]))))+((cnk[22][0][2]*Wkrpk[22][2])+
      ((cnk[20][0][0]*Wkrpk[22][0])+(cnk[22][0][1]*Wkrpk[22][1]))));
    vnk[22][1] = ((vnk[20][1]+((cnk[20][1][2]*Wirk[22][2])+((cnk[14][1][1]*
      Wirk[22][1])+(cnk[20][1][0]*Wirk[22][0]))))+((cnk[22][1][2]*Wkrpk[22][2])+
      ((cnk[20][1][0]*Wkrpk[22][0])+(cnk[22][1][1]*Wkrpk[22][1]))));
    vnk[22][2] = ((vnk[20][2]+((cnk[20][2][2]*Wirk[22][2])+((cnk[14][2][1]*
      Wirk[22][1])+(cnk[20][2][0]*Wirk[22][0]))))+((cnk[22][2][2]*Wkrpk[22][2])+
      ((cnk[20][2][0]*Wkrpk[22][0])+(cnk[22][2][1]*Wkrpk[22][1]))));
    vnk[23][0] = ((vnk[21][0]+((cnk[21][0][2]*Wirk[23][2])+((cnk[15][0][1]*
      Wirk[23][1])+(cnk[21][0][0]*Wirk[23][0]))))+((cnk[23][0][2]*Wkrpk[23][2])+
      ((cnk[21][0][0]*Wkrpk[23][0])+(cnk[23][0][1]*Wkrpk[23][1]))));
    vnk[23][1] = ((vnk[21][1]+((cnk[21][1][2]*Wirk[23][2])+((cnk[15][1][1]*
      Wirk[23][1])+(cnk[21][1][0]*Wirk[23][0]))))+((cnk[23][1][2]*Wkrpk[23][2])+
      ((cnk[21][1][0]*Wkrpk[23][0])+(cnk[23][1][1]*Wkrpk[23][1]))));
    vnk[23][2] = ((vnk[21][2]+((cnk[21][2][2]*Wirk[23][2])+((cnk[15][2][1]*
      Wirk[23][1])+(cnk[21][2][0]*Wirk[23][0]))))+((cnk[23][2][2]*Wkrpk[23][2])+
      ((cnk[21][2][0]*Wkrpk[23][0])+(cnk[23][2][1]*Wkrpk[23][1]))));
    vnk[24][0] = ((vnk[5][0]+((Cik[3][0][2]*Wirk[24][2])+((Cik[3][0][0]*
      Wirk[24][0])+(Cik[3][0][1]*Wirk[24][1]))))+((Cik[3][0][2]*Wkrpk[24][2])+((
      cnk[24][0][0]*Wkrpk[24][0])+(cnk[24][0][1]*Wkrpk[24][1]))));
    vnk[24][1] = ((vnk[5][1]+((Cik[3][1][2]*Wirk[24][2])+((Cik[3][1][0]*
      Wirk[24][0])+(Cik[3][1][1]*Wirk[24][1]))))+((Cik[3][1][2]*Wkrpk[24][2])+((
      cnk[24][1][0]*Wkrpk[24][0])+(cnk[24][1][1]*Wkrpk[24][1]))));
    vnk[24][2] = ((vnk[5][2]+((Cik[3][2][2]*Wirk[24][2])+((Cik[3][2][0]*
      Wirk[24][0])+(Cik[3][2][1]*Wirk[24][1]))))+((Cik[3][2][2]*Wkrpk[24][2])+((
      cnk[24][2][0]*Wkrpk[24][0])+(cnk[24][2][1]*Wkrpk[24][1]))));
    vnk[25][0] = ((vnk[24][0]+((Cik[3][0][2]*Wirk[25][2])+((cnk[24][0][0]*
      Wirk[25][0])+(cnk[24][0][1]*Wirk[25][1]))))+((cnk[25][0][2]*Wkrpk[25][2])+
      ((cnk[24][0][1]*Wkrpk[25][1])+(cnk[25][0][0]*Wkrpk[25][0]))));
    vnk[25][1] = ((vnk[24][1]+((Cik[3][1][2]*Wirk[25][2])+((cnk[24][1][0]*
      Wirk[25][0])+(cnk[24][1][1]*Wirk[25][1]))))+((cnk[25][1][2]*Wkrpk[25][2])+
      ((cnk[24][1][1]*Wkrpk[25][1])+(cnk[25][1][0]*Wkrpk[25][0]))));
    vnk[25][2] = ((vnk[24][2]+((Cik[3][2][2]*Wirk[25][2])+((cnk[24][2][0]*
      Wirk[25][0])+(cnk[24][2][1]*Wirk[25][1]))))+((cnk[25][2][2]*Wkrpk[25][2])+
      ((cnk[24][2][1]*Wkrpk[25][1])+(cnk[25][2][0]*Wkrpk[25][0]))));
    vnb[0][0] = vnk[5][0];
    vnb[0][1] = vnk[5][1];
    vnb[0][2] = vnk[5][2];
    vnb[1][0] = vnk[6][0];
    vnb[1][1] = vnk[6][1];
    vnb[1][2] = vnk[6][2];
    vnb[2][0] = vnk[7][0];
    vnb[2][1] = vnk[7][1];
    vnb[2][2] = vnk[7][2];
    vnb[3][0] = vnk[8][0];
    vnb[3][1] = vnk[8][1];
    vnb[3][2] = vnk[8][2];
    vnb[4][0] = vnk[9][0];
    vnb[4][1] = vnk[9][1];
    vnb[4][2] = vnk[9][2];
    vnb[5][0] = vnk[10][0];
    vnb[5][1] = vnk[10][1];
    vnb[5][2] = vnk[10][2];
    vnb[6][0] = vnk[11][0];
    vnb[6][1] = vnk[11][1];
    vnb[6][2] = vnk[11][2];
    vnb[7][0] = vnk[12][0];
    vnb[7][1] = vnk[12][1];
    vnb[7][2] = vnk[12][2];
    vnb[8][0] = vnk[13][0];
    vnb[8][1] = vnk[13][1];
    vnb[8][2] = vnk[13][2];
    vnb[9][0] = vnk[14][0];
    vnb[9][1] = vnk[14][1];
    vnb[9][2] = vnk[14][2];
    vnb[10][0] = vnk[15][0];
    vnb[10][1] = vnk[15][1];
    vnb[10][2] = vnk[15][2];
    vnb[11][0] = vnk[16][0];
    vnb[11][1] = vnk[16][1];
    vnb[11][2] = vnk[16][2];
    vnb[12][0] = vnk[17][0];
    vnb[12][1] = vnk[17][1];
    vnb[12][2] = vnk[17][2];
    vnb[13][0] = vnk[18][0];
    vnb[13][1] = vnk[18][1];
    vnb[13][2] = vnk[18][2];
    vnb[14][0] = vnk[19][0];
    vnb[14][1] = vnk[19][1];
    vnb[14][2] = vnk[19][2];
    vnb[15][0] = vnk[20][0];
    vnb[15][1] = vnk[20][1];
    vnb[15][2] = vnk[20][2];
    vnb[16][0] = vnk[21][0];
    vnb[16][1] = vnk[21][1];
    vnb[16][2] = vnk[21][2];
    vnb[17][0] = vnk[22][0];
    vnb[17][1] = vnk[22][1];
    vnb[17][2] = vnk[22][2];
    vnb[18][0] = vnk[23][0];
    vnb[18][1] = vnk[23][1];
    vnb[18][2] = vnk[23][2];
    vnb[19][0] = vnk[24][0];
    vnb[19][1] = vnk[24][1];
    vnb[19][2] = vnk[24][2];
    vnb[20][0] = vnk[25][0];
    vnb[20][1] = vnk[25][1];
    vnb[20][2] = vnk[25][2];
/*
Compute qdot (kinematical equations)
*/
    qdot[0] = u[0];
    qdot[1] = u[1];
    qdot[2] = u[2];
    qdot[3] = (.5*((q[26]*u[3])+((q[4]*u[5])-(q[5]*u[4]))));
    qdot[4] = (.5*((q[5]*u[3])+((q[26]*u[4])-(q[3]*u[5]))));
    qdot[5] = (.5*(((q[3]*u[4])+(q[26]*u[5]))-(q[4]*u[3])));
    qdot[26] = -(.5*((q[3]*u[3])+((q[4]*u[4])+(q[5]*u[5]))));
    if (stabvel  !=  0.) {
        ee = ((q[26]*q[26])+((q[5]*q[5])+((q[3]*q[3])+(q[4]*q[4]))));
        stab = ((stabvel*(1.-ee))/ee);
        qdot[3] = (qdot[3]+(q[3]*stab));
        qdot[4] = (qdot[4]+(q[4]*stab));
        qdot[5] = (qdot[5]+(q[5]*stab));
        qdot[26] = (qdot[26]+(q[26]*stab));
    }
    qdot[6] = u[6];
    qdot[7] = u[7];
    qdot[8] = u[8];
    qdot[9] = u[9];
    qdot[10] = u[10];
    qdot[11] = u[11];
    qdot[12] = u[12];
    qdot[13] = u[13];
    qdot[14] = u[14];
    qdot[15] = u[15];
    qdot[16] = u[16];
    qdot[17] = u[17];
    qdot[18] = u[18];
    qdot[19] = u[19];
    qdot[20] = u[20];
    qdot[21] = u[21];
    qdot[22] = u[22];
    qdot[23] = u[23];
    qdot[24] = u[24];
    qdot[25] = u[25];
    skipus: ;
/*
Initialize applied forces and torques to zero
*/
    for (i = 0; i < 21; i++) {
        for (j = 0; j < 3; j++) {
            ufk[i][j] = 0.;
            utk[i][j] = 0.;
        }
    }
    for (i = 0; i < 26; i++) {
        utau[i] = 0.;
    }
    ltauflg = 0;
    fs0flg = 0;
/*
 Used 0.02 seconds CPU time,
 0 additional bytes of memory.
 Equations contain 1596 adds/subtracts/negates
                   2032 multiplies
                      4 divides
                   1483 assignments
*/
}

void sdqdot(double oqdot[27])
{
/*
Return position coordinate derivatives for tree joints.
*/
    int i;

    if ((roustate != 2) && (roustate != 3)) {
        sdseterr(63,23);
        return;
    }
    for (i = 0; i <= 26; i++) {
        oqdot[i] = qdot[i];
    }
}

void sdu2qdot(double uin[26],
    double oqdot[27])
{
/*
Convert velocities to qdots.
*/
    int i;

    if ((roustate != 2) && (roustate != 3)) {
        sdseterr(64,23);
        return;
    }
    for (i = 0; i <= 25; i++) {
        oqdot[i] = uin[i];
    }
    oqdot[3] = (.5*((q[26]*uin[3])+((q[4]*uin[5])-(q[5]*uin[4]))));
    oqdot[4] = (.5*((q[5]*uin[3])+((q[26]*uin[4])-(q[3]*uin[5]))));
    oqdot[5] = (.5*(((q[3]*uin[4])+(q[26]*uin[5]))-(q[4]*uin[3])));
    oqdot[26] = -(.5*((q[3]*uin[3])+((q[4]*uin[4])+(q[5]*uin[5]))));
/*
 Used 0.00 seconds CPU time,
 0 additional bytes of memory.
 Equations contain    9 adds/subtracts/negates
                     16 multiplies
                      0 divides
                     30 assignments
*/
}

void sdpsstate(double lqin[1])
{

    if (roustate != 2) {
        sdseterr(9,23);
        return;
    }
}

void sddovpk(void)
{

    if (vpkflg == 0) {
/*
Compute Wpk (partial angular velocities)
*/
        Wpk[3][3][0] = 1.;
        Wpk[3][4][0] = 1.;
        Wpk[3][5][0] = 1.;
        Wpk[3][6][0] = c6;
        Wpk[3][6][2] = -s6;
        Wpk[3][7][0] = c7;
        Wpk[3][7][2] = -s7;
        Wpk[3][8][0] = c6;
        Wpk[3][8][1] = (s6*s8);
        Wpk[3][8][2] = -(s6*c8);
        Wpk[3][9][0] = c7;
        Wpk[3][9][1] = -(s7*s9);
        Wpk[3][9][2] = -(s7*c9);
        Wpk[3][10][0] = ((c6*c10)-(Wpk[3][8][1]*s10));
        Wpk[3][10][1] = ((Wpk[3][8][1]*c10)+(s10*c6));
        Wpk[3][10][2] = Wpk[3][8][2];
        Wpk[3][11][0] = ((Wpk[3][9][1]*s11)+(c7*c11));
        Wpk[3][11][1] = ((Wpk[3][9][1]*c11)-(s11*c7));
        Wpk[3][11][2] = Wpk[3][9][2];
        Wpk[3][12][0] = c12;
        Wpk[3][12][1] = s12;
        Wpk[3][13][0] = c13;
        Wpk[3][13][1] = -s13;
        Wpk[3][14][0] = c12;
        Wpk[3][14][1] = (s12*c14);
        Wpk[3][14][2] = (s12*s14);
        Wpk[3][15][0] = c13;
        Wpk[3][15][1] = -(s13*c15);
        Wpk[3][15][2] = (s13*s15);
        Wpk[3][16][0] = ((Wpk[3][14][2]*s16)+(c12*c16));
        Wpk[3][16][1] = Wpk[3][14][1];
        Wpk[3][16][2] = ((Wpk[3][14][2]*c16)-(s16*c12));
        Wpk[3][17][0] = ((Wpk[3][15][2]*s17)+(c13*c17));
        Wpk[3][17][1] = Wpk[3][15][1];
        Wpk[3][17][2] = ((Wpk[3][15][2]*c17)-(s17*c13));
        Wpk[3][18][0] = ((Wpk[3][16][0]*c18)+(Wpk[3][16][2]*s18));
        Wpk[3][18][1] = Wpk[3][14][1];
        Wpk[3][18][2] = ((Wpk[3][16][2]*c18)-(Wpk[3][16][0]*s18));
        Wpk[3][19][0] = ((Wpk[3][17][0]*c19)+(Wpk[3][17][2]*s19));
        Wpk[3][19][1] = Wpk[3][15][1];
        Wpk[3][19][2] = ((Wpk[3][17][2]*c19)-(Wpk[3][17][0]*s19));
        Wpk[3][20][0] = ((Wpk[3][18][0]*c20)+(Wpk[3][18][2]*s20));
        Wpk[3][20][1] = Wpk[3][14][1];
        Wpk[3][20][2] = ((Wpk[3][18][2]*c20)-(Wpk[3][18][0]*s20));
        Wpk[3][21][0] = ((Wpk[3][19][0]*c21)+(Wpk[3][19][2]*s21));
        Wpk[3][21][1] = Wpk[3][15][1];
        Wpk[3][21][2] = ((Wpk[3][19][2]*c21)-(Wpk[3][19][0]*s21));
        Wpk[3][22][0] = Wpk[3][20][0];
        Wpk[3][22][1] = ((Wpk[3][14][1]*c22)-(Wpk[3][20][2]*s22));
        Wpk[3][22][2] = ((Wpk[3][14][1]*s22)+(Wpk[3][20][2]*c22));
        Wpk[3][23][0] = Wpk[3][21][0];
        Wpk[3][23][1] = ((Wpk[3][15][1]*c23)+(Wpk[3][21][2]*s23));
        Wpk[3][23][2] = ((Wpk[3][21][2]*c23)-(Wpk[3][15][1]*s23));
        Wpk[3][24][0] = c24;
        Wpk[3][24][1] = -s24;
        Wpk[3][25][0] = (c24*c25);
        Wpk[3][25][1] = -s24;
        Wpk[3][25][2] = -(s25*c24);
        Wpk[4][4][1] = 1.;
        Wpk[4][5][1] = 1.;
        Wpk[4][6][1] = 1.;
        Wpk[4][7][1] = 1.;
        Wpk[4][8][1] = c8;
        Wpk[4][8][2] = s8;
        Wpk[4][9][1] = c9;
        Wpk[4][9][2] = -s9;
        Wpk[4][10][0] = -(s10*c8);
        Wpk[4][10][1] = (c8*c10);
        Wpk[4][10][2] = s8;
        Wpk[4][11][0] = (s11*c9);
        Wpk[4][11][1] = (c9*c11);
        Wpk[4][11][2] = -s9;
        Wpk[4][12][0] = -s12;
        Wpk[4][12][1] = c12;
        Wpk[4][13][0] = s13;
        Wpk[4][13][1] = c13;
        Wpk[4][14][0] = -s12;
        Wpk[4][14][1] = (c12*c14);
        Wpk[4][14][2] = (s14*c12);
        Wpk[4][15][0] = s13;
        Wpk[4][15][1] = (c13*c15);
        Wpk[4][15][2] = -(s15*c13);
        Wpk[4][16][0] = ((Wpk[4][14][2]*s16)-(s12*c16));
        Wpk[4][16][1] = Wpk[4][14][1];
        Wpk[4][16][2] = ((Wpk[4][14][2]*c16)+(s12*s16));
        Wpk[4][17][0] = ((Wpk[4][15][2]*s17)+(s13*c17));
        Wpk[4][17][1] = Wpk[4][15][1];
        Wpk[4][17][2] = ((Wpk[4][15][2]*c17)-(s13*s17));
        Wpk[4][18][0] = ((Wpk[4][16][0]*c18)+(Wpk[4][16][2]*s18));
        Wpk[4][18][1] = Wpk[4][14][1];
        Wpk[4][18][2] = ((Wpk[4][16][2]*c18)-(Wpk[4][16][0]*s18));
        Wpk[4][19][0] = ((Wpk[4][17][0]*c19)+(Wpk[4][17][2]*s19));
        Wpk[4][19][1] = Wpk[4][15][1];
        Wpk[4][19][2] = ((Wpk[4][17][2]*c19)-(Wpk[4][17][0]*s19));
        Wpk[4][20][0] = ((Wpk[4][18][0]*c20)+(Wpk[4][18][2]*s20));
        Wpk[4][20][1] = Wpk[4][14][1];
        Wpk[4][20][2] = ((Wpk[4][18][2]*c20)-(Wpk[4][18][0]*s20));
        Wpk[4][21][0] = ((Wpk[4][19][0]*c21)+(Wpk[4][19][2]*s21));
        Wpk[4][21][1] = Wpk[4][15][1];
        Wpk[4][21][2] = ((Wpk[4][19][2]*c21)-(Wpk[4][19][0]*s21));
        Wpk[4][22][0] = Wpk[4][20][0];
        Wpk[4][22][1] = ((Wpk[4][14][1]*c22)-(Wpk[4][20][2]*s22));
        Wpk[4][22][2] = ((Wpk[4][14][1]*s22)+(Wpk[4][20][2]*c22));
        Wpk[4][23][0] = Wpk[4][21][0];
        Wpk[4][23][1] = ((Wpk[4][15][1]*c23)+(Wpk[4][21][2]*s23));
        Wpk[4][23][2] = ((Wpk[4][21][2]*c23)-(Wpk[4][15][1]*s23));
        Wpk[4][24][0] = s24;
        Wpk[4][24][1] = c24;
        Wpk[4][25][0] = (s24*c25);
        Wpk[4][25][1] = c24;
        Wpk[4][25][2] = -(s24*s25);
        Wpk[5][5][2] = 1.;
        Wpk[5][6][0] = s6;
        Wpk[5][6][2] = c6;
        Wpk[5][7][0] = s7;
        Wpk[5][7][2] = c7;
        Wpk[5][8][0] = s6;
        Wpk[5][8][1] = -(s8*c6);
        Wpk[5][8][2] = (c6*c8);
        Wpk[5][9][0] = s7;
        Wpk[5][9][1] = (s9*c7);
        Wpk[5][9][2] = (c7*c9);
        Wpk[5][10][0] = ((s6*c10)-(Wpk[5][8][1]*s10));
        Wpk[5][10][1] = ((Wpk[5][8][1]*c10)+(s6*s10));
        Wpk[5][10][2] = Wpk[5][8][2];
        Wpk[5][11][0] = ((Wpk[5][9][1]*s11)+(s7*c11));
        Wpk[5][11][1] = ((Wpk[5][9][1]*c11)-(s7*s11));
        Wpk[5][11][2] = Wpk[5][9][2];
        Wpk[5][12][2] = 1.;
        Wpk[5][13][2] = 1.;
        Wpk[5][14][1] = -s14;
        Wpk[5][14][2] = c14;
        Wpk[5][15][1] = s15;
        Wpk[5][15][2] = c15;
        Wpk[5][16][0] = (s16*c14);
        Wpk[5][16][1] = -s14;
        Wpk[5][16][2] = (c14*c16);
        Wpk[5][17][0] = (s17*c15);
        Wpk[5][17][1] = s15;
        Wpk[5][17][2] = (c15*c17);
        Wpk[5][18][0] = ((Wpk[5][16][0]*c18)+(Wpk[5][16][2]*s18));
        Wpk[5][18][1] = -s14;
        Wpk[5][18][2] = ((Wpk[5][16][2]*c18)-(Wpk[5][16][0]*s18));
        Wpk[5][19][0] = ((Wpk[5][17][0]*c19)+(Wpk[5][17][2]*s19));
        Wpk[5][19][1] = s15;
        Wpk[5][19][2] = ((Wpk[5][17][2]*c19)-(Wpk[5][17][0]*s19));
        Wpk[5][20][0] = ((Wpk[5][18][0]*c20)+(Wpk[5][18][2]*s20));
        Wpk[5][20][1] = -s14;
        Wpk[5][20][2] = ((Wpk[5][18][2]*c20)-(Wpk[5][18][0]*s20));
        Wpk[5][21][0] = ((Wpk[5][19][0]*c21)+(Wpk[5][19][2]*s21));
        Wpk[5][21][1] = s15;
        Wpk[5][21][2] = ((Wpk[5][19][2]*c21)-(Wpk[5][19][0]*s21));
        Wpk[5][22][0] = Wpk[5][20][0];
        Wpk[5][22][1] = -((Wpk[5][20][2]*s22)+(s14*c22));
        Wpk[5][22][2] = ((Wpk[5][20][2]*c22)-(s14*s22));
        Wpk[5][23][0] = Wpk[5][21][0];
        Wpk[5][23][1] = ((Wpk[5][21][2]*s23)+(s15*c23));
        Wpk[5][23][2] = ((Wpk[5][21][2]*c23)-(s15*s23));
        Wpk[5][24][2] = 1.;
        Wpk[5][25][0] = s25;
        Wpk[5][25][2] = c25;
        Wpk[6][6][1] = -1.;
        Wpk[6][8][1] = -c8;
        Wpk[6][8][2] = -s8;
        Wpk[6][10][0] = (s10*c8);
        Wpk[6][10][1] = -(c8*c10);
        Wpk[6][10][2] = -s8;
        Wpk[7][7][1] = -1.;
        Wpk[7][9][1] = -c9;
        Wpk[7][9][2] = s9;
        Wpk[7][11][0] = -(s11*c9);
        Wpk[7][11][1] = -(c9*c11);
        Wpk[7][11][2] = s9;
        Wpk[8][8][0] = -1.;
        Wpk[8][10][0] = -c10;
        Wpk[8][10][1] = -s10;
        Wpk[9][9][0] = 1.;
        Wpk[9][11][0] = c11;
        Wpk[9][11][1] = -s11;
        Wpk[10][10][2] = -1.;
        Wpk[11][11][2] = 1.;
        Wpk[12][12][2] = -1.;
        Wpk[12][14][1] = s14;
        Wpk[12][14][2] = -c14;
        Wpk[12][16][0] = -(s16*c14);
        Wpk[12][16][1] = s14;
        Wpk[12][16][2] = -(c14*c16);
        Wpk[12][18][0] = ((Wpk[12][16][0]*c18)+(Wpk[12][16][2]*s18));
        Wpk[12][18][1] = s14;
        Wpk[12][18][2] = ((Wpk[12][16][2]*c18)-(Wpk[12][16][0]*s18));
        Wpk[12][20][0] = ((Wpk[12][18][0]*c20)+(Wpk[12][18][2]*s20));
        Wpk[12][20][1] = s14;
        Wpk[12][20][2] = ((Wpk[12][18][2]*c20)-(Wpk[12][18][0]*s20));
        Wpk[12][22][0] = Wpk[12][20][0];
        Wpk[12][22][1] = ((s14*c22)-(Wpk[12][20][2]*s22));
        Wpk[12][22][2] = ((Wpk[12][20][2]*c22)+(s14*s22));
        Wpk[13][13][2] = 1.;
        Wpk[13][15][1] = s15;
        Wpk[13][15][2] = c15;
        Wpk[13][17][0] = (s17*c15);
        Wpk[13][17][1] = s15;
        Wpk[13][17][2] = (c15*c17);
        Wpk[13][19][0] = ((Wpk[13][17][0]*c19)+(Wpk[13][17][2]*s19));
        Wpk[13][19][1] = s15;
        Wpk[13][19][2] = ((Wpk[13][17][2]*c19)-(Wpk[13][17][0]*s19));
        Wpk[13][21][0] = ((Wpk[13][19][0]*c21)+(Wpk[13][19][2]*s21));
        Wpk[13][21][1] = s15;
        Wpk[13][21][2] = ((Wpk[13][19][2]*c21)-(Wpk[13][19][0]*s21));
        Wpk[13][23][0] = Wpk[13][21][0];
        Wpk[13][23][1] = ((Wpk[13][21][2]*s23)+(s15*c23));
        Wpk[13][23][2] = ((Wpk[13][21][2]*c23)-(s15*s23));
        Wpk[14][14][0] = -1.;
        Wpk[14][16][0] = -c16;
        Wpk[14][16][2] = s16;
        Wpk[14][18][0] = ((s16*s18)-(c16*c18));
        Wpk[14][18][2] = ((s16*c18)+(s18*c16));
        Wpk[14][20][0] = ((Wpk[14][18][0]*c20)+(Wpk[14][18][2]*s20));
        Wpk[14][20][2] = ((Wpk[14][18][2]*c20)-(Wpk[14][18][0]*s20));
        Wpk[14][22][0] = Wpk[14][20][0];
        Wpk[14][22][1] = -(Wpk[14][20][2]*s22);
        Wpk[14][22][2] = (Wpk[14][20][2]*c22);
        Wpk[15][15][0] = 1.;
        Wpk[15][17][0] = c17;
        Wpk[15][17][2] = -s17;
        Wpk[15][19][0] = ((c17*c19)-(s17*s19));
        Wpk[15][19][2] = -((s17*c19)+(s19*c17));
        Wpk[15][21][0] = ((Wpk[15][19][0]*c21)+(Wpk[15][19][2]*s21));
        Wpk[15][21][2] = ((Wpk[15][19][2]*c21)-(Wpk[15][19][0]*s21));
        Wpk[15][23][0] = Wpk[15][21][0];
        Wpk[15][23][1] = (Wpk[15][21][2]*s23);
        Wpk[15][23][2] = (Wpk[15][21][2]*c23);
        Wpk[16][16][1] = -1.;
        Wpk[16][18][1] = -1.;
        Wpk[16][20][1] = -1.;
        Wpk[16][22][1] = -c22;
        Wpk[16][22][2] = -s22;
        Wpk[17][17][1] = -1.;
        Wpk[17][19][1] = -1.;
        Wpk[17][21][1] = -1.;
        Wpk[17][23][1] = -c23;
        Wpk[17][23][2] = s23;
        Wpk[18][18][1] = -1.;
        Wpk[18][20][1] = -1.;
        Wpk[18][22][1] = -c22;
        Wpk[18][22][2] = -s22;
        Wpk[19][19][1] = -1.;
        Wpk[19][21][1] = -1.;
        Wpk[19][23][1] = -c23;
        Wpk[19][23][2] = s23;
        Wpk[20][20][1] = -1.;
        Wpk[20][22][1] = -c22;
        Wpk[20][22][2] = -s22;
        Wpk[21][21][1] = -1.;
        Wpk[21][23][1] = -c23;
        Wpk[21][23][2] = s23;
        Wpk[22][22][0] = -1.;
        Wpk[23][23][0] = 1.;
        Wpk[24][24][2] = 1.;
        Wpk[24][25][0] = s25;
        Wpk[24][25][2] = c25;
        Wpk[25][25][1] = -1.;
/*
Compute Vpk (partial velocities)
*/
        Vpk[0][0][0] = 1.;
        Vpk[0][1][0] = 1.;
        Vpk[0][2][0] = 1.;
        Vpk[0][3][0] = Cik[3][0][0];
        Vpk[0][3][1] = Cik[3][0][1];
        Vpk[0][3][2] = Cik[3][0][2];
        Vpk[0][4][0] = Cik[3][0][0];
        Vpk[0][4][1] = Cik[3][0][1];
        Vpk[0][4][2] = Cik[3][0][2];
        Vpk[0][5][0] = Cik[3][0][0];
        Vpk[0][5][1] = Cik[3][0][1];
        Vpk[0][5][2] = Cik[3][0][2];
        Vpk[0][6][0] = ((Cik[3][0][0]*c6)+(Cik[3][0][2]*s6));
        Vpk[0][6][1] = Cik[3][0][1];
        Vpk[0][6][2] = ((Cik[3][0][2]*c6)-(Cik[3][0][0]*s6));
        Vpk[0][7][0] = ((Cik[3][0][0]*c7)+(Cik[3][0][2]*s7));
        Vpk[0][7][1] = Cik[3][0][1];
        Vpk[0][7][2] = ((Cik[3][0][2]*c7)-(Cik[3][0][0]*s7));
        Vpk[0][8][0] = Vpk[0][6][0];
        Vpk[0][8][1] = ((Cik[3][0][1]*c8)-(Vpk[0][6][2]*s8));
        Vpk[0][8][2] = ((Cik[3][0][1]*s8)+(Vpk[0][6][2]*c8));
        Vpk[0][9][0] = Vpk[0][7][0];
        Vpk[0][9][1] = ((Cik[3][0][1]*c9)+(Vpk[0][7][2]*s9));
        Vpk[0][9][2] = ((Vpk[0][7][2]*c9)-(Cik[3][0][1]*s9));
        Vpk[0][10][0] = ((Vpk[0][6][0]*c10)-(Vpk[0][8][1]*s10));
        Vpk[0][10][1] = ((Vpk[0][6][0]*s10)+(Vpk[0][8][1]*c10));
        Vpk[0][10][2] = Vpk[0][8][2];
        Vpk[0][11][0] = ((Vpk[0][7][0]*c11)+(Vpk[0][9][1]*s11));
        Vpk[0][11][1] = ((Vpk[0][9][1]*c11)-(Vpk[0][7][0]*s11));
        Vpk[0][11][2] = Vpk[0][9][2];
        Vpk[0][12][0] = ((Cik[3][0][0]*c12)-(Cik[3][0][1]*s12));
        Vpk[0][12][1] = ((Cik[3][0][0]*s12)+(Cik[3][0][1]*c12));
        Vpk[0][12][2] = Cik[3][0][2];
        Vpk[0][13][0] = ((Cik[3][0][0]*c13)+(Cik[3][0][1]*s13));
        Vpk[0][13][1] = ((Cik[3][0][1]*c13)-(Cik[3][0][0]*s13));
        Vpk[0][13][2] = Cik[3][0][2];
        Vpk[0][14][0] = Vpk[0][12][0];
        Vpk[0][14][1] = ((Vpk[0][12][1]*c14)-(Cik[3][0][2]*s14));
        Vpk[0][14][2] = ((Cik[3][0][2]*c14)+(Vpk[0][12][1]*s14));
        Vpk[0][15][0] = Vpk[0][13][0];
        Vpk[0][15][1] = ((Cik[3][0][2]*s15)+(Vpk[0][13][1]*c15));
        Vpk[0][15][2] = ((Cik[3][0][2]*c15)-(Vpk[0][13][1]*s15));
        Vpk[0][16][0] = ((Vpk[0][12][0]*c16)+(Vpk[0][14][2]*s16));
        Vpk[0][16][1] = Vpk[0][14][1];
        Vpk[0][16][2] = ((Vpk[0][14][2]*c16)-(Vpk[0][12][0]*s16));
        Vpk[0][17][0] = ((Vpk[0][13][0]*c17)+(Vpk[0][15][2]*s17));
        Vpk[0][17][1] = Vpk[0][15][1];
        Vpk[0][17][2] = ((Vpk[0][15][2]*c17)-(Vpk[0][13][0]*s17));
        Vpk[0][18][0] = ((Vpk[0][16][0]*c18)+(Vpk[0][16][2]*s18));
        Vpk[0][18][1] = Vpk[0][14][1];
        Vpk[0][18][2] = ((Vpk[0][16][2]*c18)-(Vpk[0][16][0]*s18));
        Vpk[0][19][0] = ((Vpk[0][17][0]*c19)+(Vpk[0][17][2]*s19));
        Vpk[0][19][1] = Vpk[0][15][1];
        Vpk[0][19][2] = ((Vpk[0][17][2]*c19)-(Vpk[0][17][0]*s19));
        Vpk[0][20][0] = ((Vpk[0][18][0]*c20)+(Vpk[0][18][2]*s20));
        Vpk[0][20][1] = Vpk[0][14][1];
        Vpk[0][20][2] = ((Vpk[0][18][2]*c20)-(Vpk[0][18][0]*s20));
        Vpk[0][21][0] = ((Vpk[0][19][0]*c21)+(Vpk[0][19][2]*s21));
        Vpk[0][21][1] = Vpk[0][15][1];
        Vpk[0][21][2] = ((Vpk[0][19][2]*c21)-(Vpk[0][19][0]*s21));
        Vpk[0][22][0] = Vpk[0][20][0];
        Vpk[0][22][1] = ((Vpk[0][14][1]*c22)-(Vpk[0][20][2]*s22));
        Vpk[0][22][2] = ((Vpk[0][14][1]*s22)+(Vpk[0][20][2]*c22));
        Vpk[0][23][0] = Vpk[0][21][0];
        Vpk[0][23][1] = ((Vpk[0][15][1]*c23)+(Vpk[0][21][2]*s23));
        Vpk[0][23][2] = ((Vpk[0][21][2]*c23)-(Vpk[0][15][1]*s23));
        Vpk[0][24][0] = ((Cik[3][0][0]*c24)+(Cik[3][0][1]*s24));
        Vpk[0][24][1] = ((Cik[3][0][1]*c24)-(Cik[3][0][0]*s24));
        Vpk[0][24][2] = Cik[3][0][2];
        Vpk[0][25][0] = ((Cik[3][0][2]*s25)+(Vpk[0][24][0]*c25));
        Vpk[0][25][1] = Vpk[0][24][1];
        Vpk[0][25][2] = ((Cik[3][0][2]*c25)-(Vpk[0][24][0]*s25));
        Vpk[1][1][1] = 1.;
        Vpk[1][2][1] = 1.;
        Vpk[1][3][0] = Cik[3][1][0];
        Vpk[1][3][1] = Cik[3][1][1];
        Vpk[1][3][2] = Cik[3][1][2];
        Vpk[1][4][0] = Cik[3][1][0];
        Vpk[1][4][1] = Cik[3][1][1];
        Vpk[1][4][2] = Cik[3][1][2];
        Vpk[1][5][0] = Cik[3][1][0];
        Vpk[1][5][1] = Cik[3][1][1];
        Vpk[1][5][2] = Cik[3][1][2];
        Vpk[1][6][0] = ((Cik[3][1][0]*c6)+(Cik[3][1][2]*s6));
        Vpk[1][6][1] = Cik[3][1][1];
        Vpk[1][6][2] = ((Cik[3][1][2]*c6)-(Cik[3][1][0]*s6));
        Vpk[1][7][0] = ((Cik[3][1][0]*c7)+(Cik[3][1][2]*s7));
        Vpk[1][7][1] = Cik[3][1][1];
        Vpk[1][7][2] = ((Cik[3][1][2]*c7)-(Cik[3][1][0]*s7));
        Vpk[1][8][0] = Vpk[1][6][0];
        Vpk[1][8][1] = ((Cik[3][1][1]*c8)-(Vpk[1][6][2]*s8));
        Vpk[1][8][2] = ((Cik[3][1][1]*s8)+(Vpk[1][6][2]*c8));
        Vpk[1][9][0] = Vpk[1][7][0];
        Vpk[1][9][1] = ((Cik[3][1][1]*c9)+(Vpk[1][7][2]*s9));
        Vpk[1][9][2] = ((Vpk[1][7][2]*c9)-(Cik[3][1][1]*s9));
        Vpk[1][10][0] = ((Vpk[1][6][0]*c10)-(Vpk[1][8][1]*s10));
        Vpk[1][10][1] = ((Vpk[1][6][0]*s10)+(Vpk[1][8][1]*c10));
        Vpk[1][10][2] = Vpk[1][8][2];
        Vpk[1][11][0] = ((Vpk[1][7][0]*c11)+(Vpk[1][9][1]*s11));
        Vpk[1][11][1] = ((Vpk[1][9][1]*c11)-(Vpk[1][7][0]*s11));
        Vpk[1][11][2] = Vpk[1][9][2];
        Vpk[1][12][0] = ((Cik[3][1][0]*c12)-(Cik[3][1][1]*s12));
        Vpk[1][12][1] = ((Cik[3][1][0]*s12)+(Cik[3][1][1]*c12));
        Vpk[1][12][2] = Cik[3][1][2];
        Vpk[1][13][0] = ((Cik[3][1][0]*c13)+(Cik[3][1][1]*s13));
        Vpk[1][13][1] = ((Cik[3][1][1]*c13)-(Cik[3][1][0]*s13));
        Vpk[1][13][2] = Cik[3][1][2];
        Vpk[1][14][0] = Vpk[1][12][0];
        Vpk[1][14][1] = ((Vpk[1][12][1]*c14)-(Cik[3][1][2]*s14));
        Vpk[1][14][2] = ((Cik[3][1][2]*c14)+(Vpk[1][12][1]*s14));
        Vpk[1][15][0] = Vpk[1][13][0];
        Vpk[1][15][1] = ((Cik[3][1][2]*s15)+(Vpk[1][13][1]*c15));
        Vpk[1][15][2] = ((Cik[3][1][2]*c15)-(Vpk[1][13][1]*s15));
        Vpk[1][16][0] = ((Vpk[1][12][0]*c16)+(Vpk[1][14][2]*s16));
        Vpk[1][16][1] = Vpk[1][14][1];
        Vpk[1][16][2] = ((Vpk[1][14][2]*c16)-(Vpk[1][12][0]*s16));
        Vpk[1][17][0] = ((Vpk[1][13][0]*c17)+(Vpk[1][15][2]*s17));
        Vpk[1][17][1] = Vpk[1][15][1];
        Vpk[1][17][2] = ((Vpk[1][15][2]*c17)-(Vpk[1][13][0]*s17));
        Vpk[1][18][0] = ((Vpk[1][16][0]*c18)+(Vpk[1][16][2]*s18));
        Vpk[1][18][1] = Vpk[1][14][1];
        Vpk[1][18][2] = ((Vpk[1][16][2]*c18)-(Vpk[1][16][0]*s18));
        Vpk[1][19][0] = ((Vpk[1][17][0]*c19)+(Vpk[1][17][2]*s19));
        Vpk[1][19][1] = Vpk[1][15][1];
        Vpk[1][19][2] = ((Vpk[1][17][2]*c19)-(Vpk[1][17][0]*s19));
        Vpk[1][20][0] = ((Vpk[1][18][0]*c20)+(Vpk[1][18][2]*s20));
        Vpk[1][20][1] = Vpk[1][14][1];
        Vpk[1][20][2] = ((Vpk[1][18][2]*c20)-(Vpk[1][18][0]*s20));
        Vpk[1][21][0] = ((Vpk[1][19][0]*c21)+(Vpk[1][19][2]*s21));
        Vpk[1][21][1] = Vpk[1][15][1];
        Vpk[1][21][2] = ((Vpk[1][19][2]*c21)-(Vpk[1][19][0]*s21));
        Vpk[1][22][0] = Vpk[1][20][0];
        Vpk[1][22][1] = ((Vpk[1][14][1]*c22)-(Vpk[1][20][2]*s22));
        Vpk[1][22][2] = ((Vpk[1][14][1]*s22)+(Vpk[1][20][2]*c22));
        Vpk[1][23][0] = Vpk[1][21][0];
        Vpk[1][23][1] = ((Vpk[1][15][1]*c23)+(Vpk[1][21][2]*s23));
        Vpk[1][23][2] = ((Vpk[1][21][2]*c23)-(Vpk[1][15][1]*s23));
        Vpk[1][24][0] = ((Cik[3][1][0]*c24)+(Cik[3][1][1]*s24));
        Vpk[1][24][1] = ((Cik[3][1][1]*c24)-(Cik[3][1][0]*s24));
        Vpk[1][24][2] = Cik[3][1][2];
        Vpk[1][25][0] = ((Cik[3][1][2]*s25)+(Vpk[1][24][0]*c25));
        Vpk[1][25][1] = Vpk[1][24][1];
        Vpk[1][25][2] = ((Cik[3][1][2]*c25)-(Vpk[1][24][0]*s25));
        Vpk[2][2][2] = 1.;
        Vpk[2][3][0] = Cik[3][2][0];
        Vpk[2][3][1] = Cik[3][2][1];
        Vpk[2][3][2] = Cik[3][2][2];
        Vpk[2][4][0] = Cik[3][2][0];
        Vpk[2][4][1] = Cik[3][2][1];
        Vpk[2][4][2] = Cik[3][2][2];
        Vpk[2][5][0] = Cik[3][2][0];
        Vpk[2][5][1] = Cik[3][2][1];
        Vpk[2][5][2] = Cik[3][2][2];
        Vpk[2][6][0] = ((Cik[3][2][0]*c6)+(Cik[3][2][2]*s6));
        Vpk[2][6][1] = Cik[3][2][1];
        Vpk[2][6][2] = ((Cik[3][2][2]*c6)-(Cik[3][2][0]*s6));
        Vpk[2][7][0] = ((Cik[3][2][0]*c7)+(Cik[3][2][2]*s7));
        Vpk[2][7][1] = Cik[3][2][1];
        Vpk[2][7][2] = ((Cik[3][2][2]*c7)-(Cik[3][2][0]*s7));
        Vpk[2][8][0] = Vpk[2][6][0];
        Vpk[2][8][1] = ((Cik[3][2][1]*c8)-(Vpk[2][6][2]*s8));
        Vpk[2][8][2] = ((Cik[3][2][1]*s8)+(Vpk[2][6][2]*c8));
        Vpk[2][9][0] = Vpk[2][7][0];
        Vpk[2][9][1] = ((Cik[3][2][1]*c9)+(Vpk[2][7][2]*s9));
        Vpk[2][9][2] = ((Vpk[2][7][2]*c9)-(Cik[3][2][1]*s9));
        Vpk[2][10][0] = ((Vpk[2][6][0]*c10)-(Vpk[2][8][1]*s10));
        Vpk[2][10][1] = ((Vpk[2][6][0]*s10)+(Vpk[2][8][1]*c10));
        Vpk[2][10][2] = Vpk[2][8][2];
        Vpk[2][11][0] = ((Vpk[2][7][0]*c11)+(Vpk[2][9][1]*s11));
        Vpk[2][11][1] = ((Vpk[2][9][1]*c11)-(Vpk[2][7][0]*s11));
        Vpk[2][11][2] = Vpk[2][9][2];
        Vpk[2][12][0] = ((Cik[3][2][0]*c12)-(Cik[3][2][1]*s12));
        Vpk[2][12][1] = ((Cik[3][2][0]*s12)+(Cik[3][2][1]*c12));
        Vpk[2][12][2] = Cik[3][2][2];
        Vpk[2][13][0] = ((Cik[3][2][0]*c13)+(Cik[3][2][1]*s13));
        Vpk[2][13][1] = ((Cik[3][2][1]*c13)-(Cik[3][2][0]*s13));
        Vpk[2][13][2] = Cik[3][2][2];
        Vpk[2][14][0] = Vpk[2][12][0];
        Vpk[2][14][1] = ((Vpk[2][12][1]*c14)-(Cik[3][2][2]*s14));
        Vpk[2][14][2] = ((Cik[3][2][2]*c14)+(Vpk[2][12][1]*s14));
        Vpk[2][15][0] = Vpk[2][13][0];
        Vpk[2][15][1] = ((Cik[3][2][2]*s15)+(Vpk[2][13][1]*c15));
        Vpk[2][15][2] = ((Cik[3][2][2]*c15)-(Vpk[2][13][1]*s15));
        Vpk[2][16][0] = ((Vpk[2][12][0]*c16)+(Vpk[2][14][2]*s16));
        Vpk[2][16][1] = Vpk[2][14][1];
        Vpk[2][16][2] = ((Vpk[2][14][2]*c16)-(Vpk[2][12][0]*s16));
        Vpk[2][17][0] = ((Vpk[2][13][0]*c17)+(Vpk[2][15][2]*s17));
        Vpk[2][17][1] = Vpk[2][15][1];
        Vpk[2][17][2] = ((Vpk[2][15][2]*c17)-(Vpk[2][13][0]*s17));
        Vpk[2][18][0] = ((Vpk[2][16][0]*c18)+(Vpk[2][16][2]*s18));
        Vpk[2][18][1] = Vpk[2][14][1];
        Vpk[2][18][2] = ((Vpk[2][16][2]*c18)-(Vpk[2][16][0]*s18));
        Vpk[2][19][0] = ((Vpk[2][17][0]*c19)+(Vpk[2][17][2]*s19));
        Vpk[2][19][1] = Vpk[2][15][1];
        Vpk[2][19][2] = ((Vpk[2][17][2]*c19)-(Vpk[2][17][0]*s19));
        Vpk[2][20][0] = ((Vpk[2][18][0]*c20)+(Vpk[2][18][2]*s20));
        Vpk[2][20][1] = Vpk[2][14][1];
        Vpk[2][20][2] = ((Vpk[2][18][2]*c20)-(Vpk[2][18][0]*s20));
        Vpk[2][21][0] = ((Vpk[2][19][0]*c21)+(Vpk[2][19][2]*s21));
        Vpk[2][21][1] = Vpk[2][15][1];
        Vpk[2][21][2] = ((Vpk[2][19][2]*c21)-(Vpk[2][19][0]*s21));
        Vpk[2][22][0] = Vpk[2][20][0];
        Vpk[2][22][1] = ((Vpk[2][14][1]*c22)-(Vpk[2][20][2]*s22));
        Vpk[2][22][2] = ((Vpk[2][14][1]*s22)+(Vpk[2][20][2]*c22));
        Vpk[2][23][0] = Vpk[2][21][0];
        Vpk[2][23][1] = ((Vpk[2][15][1]*c23)+(Vpk[2][21][2]*s23));
        Vpk[2][23][2] = ((Vpk[2][21][2]*c23)-(Vpk[2][15][1]*s23));
        Vpk[2][24][0] = ((Cik[3][2][0]*c24)+(Cik[3][2][1]*s24));
        Vpk[2][24][1] = ((Cik[3][2][1]*c24)-(Cik[3][2][0]*s24));
        Vpk[2][24][2] = Cik[3][2][2];
        Vpk[2][25][0] = ((Cik[3][2][2]*s25)+(Vpk[2][24][0]*c25));
        Vpk[2][25][1] = Vpk[2][24][1];
        Vpk[2][25][2] = ((Cik[3][2][2]*c25)-(Vpk[2][24][0]*s25));
        Vpk[3][5][1] = rk[0][2];
        Vpk[3][5][2] = -rk[0][1];
        VWri[3][6][1] = (rk[0][2]-ri[1][2]);
        VWri[3][6][2] = (ri[1][1]-rk[0][1]);
        Vpk[3][6][0] = ((VWri[3][6][2]*s6)-(rk[1][1]*s6));
        Vpk[3][6][1] = (VWri[3][6][1]+((rk[1][0]*s6)+(rk[1][2]*c6)));
        Vpk[3][6][2] = ((VWri[3][6][2]*c6)-(rk[1][1]*c6));
        VWri[3][7][1] = (rk[0][2]-ri[2][2]);
        VWri[3][7][2] = (ri[2][1]-rk[0][1]);
        Vpk[3][7][0] = ((VWri[3][7][2]*s7)-(rk[2][1]*s7));
        Vpk[3][7][1] = (VWri[3][7][1]+((rk[2][0]*s7)+(rk[2][2]*c7)));
        Vpk[3][7][2] = ((VWri[3][7][2]*c7)-(rk[2][1]*c7));
        VWri[3][8][0] = (Vpk[3][6][0]+(ri[3][1]*s6));
        VWri[3][8][1] = (Vpk[3][6][1]-((ri[3][0]*s6)+(ri[3][2]*c6)));
        VWri[3][8][2] = (Vpk[3][6][2]+(ri[3][1]*c6));
        Vpk[3][8][0] = (VWri[3][8][0]+((rk[3][1]*Wpk[3][8][2])-(rk[3][2]*
          Wpk[3][8][1])));
        Vpk[3][8][1] = (((rk[3][2]*c6)-(rk[3][0]*Wpk[3][8][2]))+((VWri[3][8][1]*
          c8)-(VWri[3][8][2]*s8)));
        Vpk[3][8][2] = (((rk[3][0]*Wpk[3][8][1])-(rk[3][1]*c6))+((VWri[3][8][1]*
          s8)+(VWri[3][8][2]*c8)));
        VWri[3][9][0] = (Vpk[3][7][0]+(ri[4][1]*s7));
        VWri[3][9][1] = (Vpk[3][7][1]-((ri[4][0]*s7)+(ri[4][2]*c7)));
        VWri[3][9][2] = (Vpk[3][7][2]+(ri[4][1]*c7));
        Vpk[3][9][0] = (VWri[3][9][0]+((rk[4][1]*Wpk[3][9][2])-(rk[4][2]*
          Wpk[3][9][1])));
        Vpk[3][9][1] = (((rk[4][2]*c7)-(rk[4][0]*Wpk[3][9][2]))+((VWri[3][9][1]*
          c9)+(VWri[3][9][2]*s9)));
        Vpk[3][9][2] = (((rk[4][0]*Wpk[3][9][1])-(rk[4][1]*c7))+((VWri[3][9][2]*
          c9)-(VWri[3][9][1]*s9)));
        VWri[3][10][0] = (Vpk[3][8][0]+((ri[5][2]*Wpk[3][8][1])-(ri[5][1]*
          Wpk[3][8][2])));
        VWri[3][10][1] = (Vpk[3][8][1]+((ri[5][0]*Wpk[3][8][2])-(ri[5][2]*c6)));
        VWri[3][10][2] = (Vpk[3][8][2]+((ri[5][1]*c6)-(ri[5][0]*Wpk[3][8][1])));
        Vpk[3][10][0] = (((rk[5][1]*Wpk[3][8][2])-(rk[5][2]*Wpk[3][10][1]))+((
          VWri[3][10][0]*c10)-(VWri[3][10][1]*s10)));
        Vpk[3][10][1] = (((rk[5][2]*Wpk[3][10][0])-(rk[5][0]*Wpk[3][8][2]))+((
          VWri[3][10][0]*s10)+(VWri[3][10][1]*c10)));
        Vpk[3][10][2] = (VWri[3][10][2]+((rk[5][0]*Wpk[3][10][1])-(rk[5][1]*
          Wpk[3][10][0])));
        VWri[3][11][0] = (Vpk[3][9][0]+((ri[6][2]*Wpk[3][9][1])-(ri[6][1]*
          Wpk[3][9][2])));
        VWri[3][11][1] = (Vpk[3][9][1]+((ri[6][0]*Wpk[3][9][2])-(ri[6][2]*c7)));
        VWri[3][11][2] = (Vpk[3][9][2]+((ri[6][1]*c7)-(ri[6][0]*Wpk[3][9][1])));
        Vpk[3][11][0] = (((rk[6][1]*Wpk[3][9][2])-(rk[6][2]*Wpk[3][11][1]))+((
          VWri[3][11][0]*c11)+(VWri[3][11][1]*s11)));
        Vpk[3][11][1] = (((rk[6][2]*Wpk[3][11][0])-(rk[6][0]*Wpk[3][9][2]))+((
          VWri[3][11][1]*c11)-(VWri[3][11][0]*s11)));
        Vpk[3][11][2] = (VWri[3][11][2]+((rk[6][0]*Wpk[3][11][1])-(rk[6][1]*
          Wpk[3][11][0])));
        VWri[3][12][1] = (rk[0][2]-ri[7][2]);
        VWri[3][12][2] = (ri[7][1]-rk[0][1]);
        Vpk[3][12][0] = -((rk[7][2]*s12)+(VWri[3][12][1]*s12));
        Vpk[3][12][1] = ((rk[7][2]*c12)+(VWri[3][12][1]*c12));
        Vpk[3][12][2] = (VWri[3][12][2]+((rk[7][0]*s12)-(rk[7][1]*c12)));
        VWri[3][13][1] = (rk[0][2]-ri[8][2]);
        VWri[3][13][2] = (ri[8][1]-rk[0][1]);
        Vpk[3][13][0] = ((rk[8][2]*s13)+(VWri[3][13][1]*s13));
        Vpk[3][13][1] = ((rk[8][2]*c13)+(VWri[3][13][1]*c13));
        Vpk[3][13][2] = (VWri[3][13][2]-((rk[8][0]*s13)+(rk[8][1]*c13)));
        VWri[3][14][0] = (Vpk[3][12][0]+(ri[9][2]*s12));
        VWri[3][14][1] = (Vpk[3][12][1]-(ri[9][2]*c12));
        VWri[3][14][2] = (Vpk[3][12][2]+((ri[9][1]*c12)-(ri[9][0]*s12)));
        Vpk[3][14][0] = (VWri[3][14][0]+((rk[9][1]*Wpk[3][14][2])-(rk[9][2]*
          Wpk[3][14][1])));
        Vpk[3][14][1] = (((rk[9][2]*c12)-(rk[9][0]*Wpk[3][14][2]))+((
          VWri[3][14][1]*c14)-(VWri[3][14][2]*s14)));
        Vpk[3][14][2] = (((rk[9][0]*Wpk[3][14][1])-(rk[9][1]*c12))+((
          VWri[3][14][1]*s14)+(VWri[3][14][2]*c14)));
        VWri[3][15][0] = (Vpk[3][13][0]-(ri[10][2]*s13));
        VWri[3][15][1] = (Vpk[3][13][1]-(ri[10][2]*c13));
        VWri[3][15][2] = (Vpk[3][13][2]+((ri[10][0]*s13)+(ri[10][1]*c13)));
        Vpk[3][15][0] = (VWri[3][15][0]+((rk[10][1]*Wpk[3][15][2])-(rk[10][2]*
          Wpk[3][15][1])));
        Vpk[3][15][1] = (((rk[10][2]*c13)-(rk[10][0]*Wpk[3][15][2]))+((
          VWri[3][15][1]*c15)+(VWri[3][15][2]*s15)));
        Vpk[3][15][2] = (((rk[10][0]*Wpk[3][15][1])-(rk[10][1]*c13))+((
          VWri[3][15][2]*c15)-(VWri[3][15][1]*s15)));
        VWri[3][16][0] = (Vpk[3][14][0]+((ri[11][2]*Wpk[3][14][1])-(ri[11][1]*
          Wpk[3][14][2])));
        VWri[3][16][1] = (Vpk[3][14][1]+((ri[11][0]*Wpk[3][14][2])-(ri[11][2]*
          c12)));
        VWri[3][16][2] = (Vpk[3][14][2]+((ri[11][1]*c12)-(ri[11][0]*
          Wpk[3][14][1])));
        Vpk[3][16][0] = (((rk[11][1]*Wpk[3][16][2])-(rk[11][2]*Wpk[3][14][1]))+(
          (VWri[3][16][0]*c16)+(VWri[3][16][2]*s16)));
        Vpk[3][16][1] = (VWri[3][16][1]+((rk[11][2]*Wpk[3][16][0])-(rk[11][0]*
          Wpk[3][16][2])));
        Vpk[3][16][2] = (((rk[11][0]*Wpk[3][14][1])-(rk[11][1]*Wpk[3][16][0]))+(
          (VWri[3][16][2]*c16)-(VWri[3][16][0]*s16)));
        VWri[3][17][0] = (Vpk[3][15][0]+((ri[12][2]*Wpk[3][15][1])-(ri[12][1]*
          Wpk[3][15][2])));
        VWri[3][17][1] = (Vpk[3][15][1]+((ri[12][0]*Wpk[3][15][2])-(ri[12][2]*
          c13)));
        VWri[3][17][2] = (Vpk[3][15][2]+((ri[12][1]*c13)-(ri[12][0]*
          Wpk[3][15][1])));
        Vpk[3][17][0] = (((rk[12][1]*Wpk[3][17][2])-(rk[12][2]*Wpk[3][15][1]))+(
          (VWri[3][17][0]*c17)+(VWri[3][17][2]*s17)));
        Vpk[3][17][1] = (VWri[3][17][1]+((rk[12][2]*Wpk[3][17][0])-(rk[12][0]*
          Wpk[3][17][2])));
        Vpk[3][17][2] = (((rk[12][0]*Wpk[3][15][1])-(rk[12][1]*Wpk[3][17][0]))+(
          (VWri[3][17][2]*c17)-(VWri[3][17][0]*s17)));
        VWri[3][18][0] = (Vpk[3][16][0]+((ri[13][2]*Wpk[3][14][1])-(ri[13][1]*
          Wpk[3][16][2])));
        VWri[3][18][1] = (Vpk[3][16][1]+((ri[13][0]*Wpk[3][16][2])-(ri[13][2]*
          Wpk[3][16][0])));
        VWri[3][18][2] = (Vpk[3][16][2]+((ri[13][1]*Wpk[3][16][0])-(ri[13][0]*
          Wpk[3][14][1])));
        Vpk[3][18][0] = (((rk[13][1]*Wpk[3][18][2])-(rk[13][2]*Wpk[3][14][1]))+(
          (VWri[3][18][0]*c18)+(VWri[3][18][2]*s18)));
        Vpk[3][18][1] = (VWri[3][18][1]+((rk[13][2]*Wpk[3][18][0])-(rk[13][0]*
          Wpk[3][18][2])));
        Vpk[3][18][2] = (((rk[13][0]*Wpk[3][14][1])-(rk[13][1]*Wpk[3][18][0]))+(
          (VWri[3][18][2]*c18)-(VWri[3][18][0]*s18)));
        VWri[3][19][0] = (Vpk[3][17][0]+((ri[14][2]*Wpk[3][15][1])-(ri[14][1]*
          Wpk[3][17][2])));
        VWri[3][19][1] = (Vpk[3][17][1]+((ri[14][0]*Wpk[3][17][2])-(ri[14][2]*
          Wpk[3][17][0])));
        VWri[3][19][2] = (Vpk[3][17][2]+((ri[14][1]*Wpk[3][17][0])-(ri[14][0]*
          Wpk[3][15][1])));
        Vpk[3][19][0] = (((rk[14][1]*Wpk[3][19][2])-(rk[14][2]*Wpk[3][15][1]))+(
          (VWri[3][19][0]*c19)+(VWri[3][19][2]*s19)));
        Vpk[3][19][1] = (VWri[3][19][1]+((rk[14][2]*Wpk[3][19][0])-(rk[14][0]*
          Wpk[3][19][2])));
        Vpk[3][19][2] = (((rk[14][0]*Wpk[3][15][1])-(rk[14][1]*Wpk[3][19][0]))+(
          (VWri[3][19][2]*c19)-(VWri[3][19][0]*s19)));
        VWri[3][20][0] = (Vpk[3][18][0]+((ri[15][2]*Wpk[3][14][1])-(ri[15][1]*
          Wpk[3][18][2])));
        VWri[3][20][1] = (Vpk[3][18][1]+((ri[15][0]*Wpk[3][18][2])-(ri[15][2]*
          Wpk[3][18][0])));
        VWri[3][20][2] = (Vpk[3][18][2]+((ri[15][1]*Wpk[3][18][0])-(ri[15][0]*
          Wpk[3][14][1])));
        Vpk[3][20][0] = (((rk[15][1]*Wpk[3][20][2])-(rk[15][2]*Wpk[3][14][1]))+(
          (VWri[3][20][0]*c20)+(VWri[3][20][2]*s20)));
        Vpk[3][20][1] = (VWri[3][20][1]+((rk[15][2]*Wpk[3][20][0])-(rk[15][0]*
          Wpk[3][20][2])));
        Vpk[3][20][2] = (((rk[15][0]*Wpk[3][14][1])-(rk[15][1]*Wpk[3][20][0]))+(
          (VWri[3][20][2]*c20)-(VWri[3][20][0]*s20)));
        VWri[3][21][0] = (Vpk[3][19][0]+((ri[16][2]*Wpk[3][15][1])-(ri[16][1]*
          Wpk[3][19][2])));
        VWri[3][21][1] = (Vpk[3][19][1]+((ri[16][0]*Wpk[3][19][2])-(ri[16][2]*
          Wpk[3][19][0])));
        VWri[3][21][2] = (Vpk[3][19][2]+((ri[16][1]*Wpk[3][19][0])-(ri[16][0]*
          Wpk[3][15][1])));
        Vpk[3][21][0] = (((rk[16][1]*Wpk[3][21][2])-(rk[16][2]*Wpk[3][15][1]))+(
          (VWri[3][21][0]*c21)+(VWri[3][21][2]*s21)));
        Vpk[3][21][1] = (VWri[3][21][1]+((rk[16][2]*Wpk[3][21][0])-(rk[16][0]*
          Wpk[3][21][2])));
        Vpk[3][21][2] = (((rk[16][0]*Wpk[3][15][1])-(rk[16][1]*Wpk[3][21][0]))+(
          (VWri[3][21][2]*c21)-(VWri[3][21][0]*s21)));
        VWri[3][22][0] = (Vpk[3][20][0]+((ri[17][2]*Wpk[3][14][1])-(ri[17][1]*
          Wpk[3][20][2])));
        VWri[3][22][1] = (Vpk[3][20][1]+((ri[17][0]*Wpk[3][20][2])-(ri[17][2]*
          Wpk[3][20][0])));
        VWri[3][22][2] = (Vpk[3][20][2]+((ri[17][1]*Wpk[3][20][0])-(ri[17][0]*
          Wpk[3][14][1])));
        Vpk[3][22][0] = (VWri[3][22][0]+((rk[17][1]*Wpk[3][22][2])-(rk[17][2]*
          Wpk[3][22][1])));
        Vpk[3][22][1] = (((rk[17][2]*Wpk[3][20][0])-(rk[17][0]*Wpk[3][22][2]))+(
          (VWri[3][22][1]*c22)-(VWri[3][22][2]*s22)));
        Vpk[3][22][2] = (((rk[17][0]*Wpk[3][22][1])-(rk[17][1]*Wpk[3][20][0]))+(
          (VWri[3][22][1]*s22)+(VWri[3][22][2]*c22)));
        VWri[3][23][0] = (Vpk[3][21][0]+((ri[18][2]*Wpk[3][15][1])-(ri[18][1]*
          Wpk[3][21][2])));
        VWri[3][23][1] = (Vpk[3][21][1]+((ri[18][0]*Wpk[3][21][2])-(ri[18][2]*
          Wpk[3][21][0])));
        VWri[3][23][2] = (Vpk[3][21][2]+((ri[18][1]*Wpk[3][21][0])-(ri[18][0]*
          Wpk[3][15][1])));
        Vpk[3][23][0] = (VWri[3][23][0]+((rk[18][1]*Wpk[3][23][2])-(rk[18][2]*
          Wpk[3][23][1])));
        Vpk[3][23][1] = (((rk[18][2]*Wpk[3][21][0])-(rk[18][0]*Wpk[3][23][2]))+(
          (VWri[3][23][1]*c23)+(VWri[3][23][2]*s23)));
        Vpk[3][23][2] = (((rk[18][0]*Wpk[3][23][1])-(rk[18][1]*Wpk[3][21][0]))+(
          (VWri[3][23][2]*c23)-(VWri[3][23][1]*s23)));
        VWri[3][24][1] = (rk[0][2]-ri[19][2]);
        VWri[3][24][2] = (ri[19][1]-rk[0][1]);
        Vpk[3][24][0] = ((rk[19][2]*s24)+(VWri[3][24][1]*s24));
        Vpk[3][24][1] = ((rk[19][2]*c24)+(VWri[3][24][1]*c24));
        Vpk[3][24][2] = (VWri[3][24][2]-((rk[19][0]*s24)+(rk[19][1]*c24)));
        VWri[3][25][0] = (Vpk[3][24][0]-(ri[20][2]*s24));
        VWri[3][25][1] = (Vpk[3][24][1]-(ri[20][2]*c24));
        VWri[3][25][2] = (Vpk[3][24][2]+((ri[20][0]*s24)+(ri[20][1]*c24)));
        Vpk[3][25][0] = (((rk[20][1]*Wpk[3][25][2])+(rk[20][2]*s24))+((
          VWri[3][25][0]*c25)+(VWri[3][25][2]*s25)));
        Vpk[3][25][1] = (VWri[3][25][1]+((rk[20][2]*Wpk[3][25][0])-(rk[20][0]*
          Wpk[3][25][2])));
        Vpk[3][25][2] = (((VWri[3][25][2]*c25)-(VWri[3][25][0]*s25))-((rk[20][0]
          *s24)+(rk[20][1]*Wpk[3][25][0])));
        Vpk[4][5][0] = -rk[0][2];
        Vpk[4][5][2] = rk[0][0];
        VWri[4][6][0] = (ri[1][2]-rk[0][2]);
        VWri[4][6][2] = (rk[0][0]-ri[1][0]);
        Vpk[4][6][0] = (((VWri[4][6][0]*c6)+(VWri[4][6][2]*s6))-rk[1][2]);
        Vpk[4][6][2] = (rk[1][0]+((VWri[4][6][2]*c6)-(VWri[4][6][0]*s6)));
        VWri[4][7][0] = (ri[2][2]-rk[0][2]);
        VWri[4][7][2] = (rk[0][0]-ri[2][0]);
        Vpk[4][7][0] = (((VWri[4][7][0]*c7)+(VWri[4][7][2]*s7))-rk[2][2]);
        Vpk[4][7][2] = (rk[2][0]+((VWri[4][7][2]*c7)-(VWri[4][7][0]*s7)));
        VWri[4][8][0] = (ri[3][2]+Vpk[4][6][0]);
        VWri[4][8][2] = (Vpk[4][6][2]-ri[3][0]);
        Vpk[4][8][0] = (VWri[4][8][0]+((rk[3][1]*s8)-(rk[3][2]*c8)));
        Vpk[4][8][1] = -((rk[3][0]*s8)+(VWri[4][8][2]*s8));
        Vpk[4][8][2] = ((rk[3][0]*c8)+(VWri[4][8][2]*c8));
        VWri[4][9][0] = (ri[4][2]+Vpk[4][7][0]);
        VWri[4][9][2] = (Vpk[4][7][2]-ri[4][0]);
        Vpk[4][9][0] = (VWri[4][9][0]-((rk[4][1]*s9)+(rk[4][2]*c9)));
        Vpk[4][9][1] = ((rk[4][0]*s9)+(VWri[4][9][2]*s9));
        Vpk[4][9][2] = ((rk[4][0]*c9)+(VWri[4][9][2]*c9));
        VWri[4][10][0] = (Vpk[4][8][0]+((ri[5][2]*c8)-(ri[5][1]*s8)));
        VWri[4][10][1] = (Vpk[4][8][1]+(ri[5][0]*s8));
        VWri[4][10][2] = (Vpk[4][8][2]-(ri[5][0]*c8));
        Vpk[4][10][0] = (((rk[5][1]*s8)-(rk[5][2]*Wpk[4][10][1]))+((
          VWri[4][10][0]*c10)-(VWri[4][10][1]*s10)));
        Vpk[4][10][1] = (((rk[5][2]*Wpk[4][10][0])-(rk[5][0]*s8))+((
          VWri[4][10][0]*s10)+(VWri[4][10][1]*c10)));
        Vpk[4][10][2] = (VWri[4][10][2]+((rk[5][0]*Wpk[4][10][1])-(rk[5][1]*
          Wpk[4][10][0])));
        VWri[4][11][0] = (Vpk[4][9][0]+((ri[6][1]*s9)+(ri[6][2]*c9)));
        VWri[4][11][1] = (Vpk[4][9][1]-(ri[6][0]*s9));
        VWri[4][11][2] = (Vpk[4][9][2]-(ri[6][0]*c9));
        Vpk[4][11][0] = (((VWri[4][11][0]*c11)+(VWri[4][11][1]*s11))-((rk[6][1]*
          s9)+(rk[6][2]*Wpk[4][11][1])));
        Vpk[4][11][1] = (((rk[6][0]*s9)+(rk[6][2]*Wpk[4][11][0]))+((
          VWri[4][11][1]*c11)-(VWri[4][11][0]*s11)));
        Vpk[4][11][2] = (VWri[4][11][2]+((rk[6][0]*Wpk[4][11][1])-(rk[6][1]*
          Wpk[4][11][0])));
        VWri[4][12][0] = (ri[7][2]-rk[0][2]);
        VWri[4][12][2] = (rk[0][0]-ri[7][0]);
        Vpk[4][12][0] = ((VWri[4][12][0]*c12)-(rk[7][2]*c12));
        Vpk[4][12][1] = ((VWri[4][12][0]*s12)-(rk[7][2]*s12));
        Vpk[4][12][2] = (VWri[4][12][2]+((rk[7][0]*c12)+(rk[7][1]*s12)));
        VWri[4][13][0] = (ri[8][2]-rk[0][2]);
        VWri[4][13][2] = (rk[0][0]-ri[8][0]);
        Vpk[4][13][0] = ((VWri[4][13][0]*c13)-(rk[8][2]*c13));
        Vpk[4][13][1] = ((rk[8][2]*s13)-(VWri[4][13][0]*s13));
        Vpk[4][13][2] = (VWri[4][13][2]+((rk[8][0]*c13)-(rk[8][1]*s13)));
        VWri[4][14][0] = (Vpk[4][12][0]+(ri[9][2]*c12));
        VWri[4][14][1] = (Vpk[4][12][1]+(ri[9][2]*s12));
        VWri[4][14][2] = (Vpk[4][12][2]-((ri[9][0]*c12)+(ri[9][1]*s12)));
        Vpk[4][14][0] = (VWri[4][14][0]+((rk[9][1]*Wpk[4][14][2])-(rk[9][2]*
          Wpk[4][14][1])));
        Vpk[4][14][1] = (((VWri[4][14][1]*c14)-(VWri[4][14][2]*s14))-((rk[9][0]*
          Wpk[4][14][2])+(rk[9][2]*s12)));
        Vpk[4][14][2] = (((rk[9][0]*Wpk[4][14][1])+(rk[9][1]*s12))+((
          VWri[4][14][1]*s14)+(VWri[4][14][2]*c14)));
        VWri[4][15][0] = (Vpk[4][13][0]+(ri[10][2]*c13));
        VWri[4][15][1] = (Vpk[4][13][1]-(ri[10][2]*s13));
        VWri[4][15][2] = (Vpk[4][13][2]+((ri[10][1]*s13)-(ri[10][0]*c13)));
        Vpk[4][15][0] = (VWri[4][15][0]+((rk[10][1]*Wpk[4][15][2])-(rk[10][2]*
          Wpk[4][15][1])));
        Vpk[4][15][1] = (((rk[10][2]*s13)-(rk[10][0]*Wpk[4][15][2]))+((
          VWri[4][15][1]*c15)+(VWri[4][15][2]*s15)));
        Vpk[4][15][2] = (((rk[10][0]*Wpk[4][15][1])-(rk[10][1]*s13))+((
          VWri[4][15][2]*c15)-(VWri[4][15][1]*s15)));
        VWri[4][16][0] = (Vpk[4][14][0]+((ri[11][2]*Wpk[4][14][1])-(ri[11][1]*
          Wpk[4][14][2])));
        VWri[4][16][1] = (Vpk[4][14][1]+((ri[11][0]*Wpk[4][14][2])+(ri[11][2]*
          s12)));
        VWri[4][16][2] = (Vpk[4][14][2]-((ri[11][0]*Wpk[4][14][1])+(ri[11][1]*
          s12)));
        Vpk[4][16][0] = (((rk[11][1]*Wpk[4][16][2])-(rk[11][2]*Wpk[4][14][1]))+(
          (VWri[4][16][0]*c16)+(VWri[4][16][2]*s16)));
        Vpk[4][16][1] = (VWri[4][16][1]+((rk[11][2]*Wpk[4][16][0])-(rk[11][0]*
          Wpk[4][16][2])));
        Vpk[4][16][2] = (((rk[11][0]*Wpk[4][14][1])-(rk[11][1]*Wpk[4][16][0]))+(
          (VWri[4][16][2]*c16)-(VWri[4][16][0]*s16)));
        VWri[4][17][0] = (Vpk[4][15][0]+((ri[12][2]*Wpk[4][15][1])-(ri[12][1]*
          Wpk[4][15][2])));
        VWri[4][17][1] = (Vpk[4][15][1]+((ri[12][0]*Wpk[4][15][2])-(ri[12][2]*
          s13)));
        VWri[4][17][2] = (Vpk[4][15][2]+((ri[12][1]*s13)-(ri[12][0]*
          Wpk[4][15][1])));
        Vpk[4][17][0] = (((rk[12][1]*Wpk[4][17][2])-(rk[12][2]*Wpk[4][15][1]))+(
          (VWri[4][17][0]*c17)+(VWri[4][17][2]*s17)));
        Vpk[4][17][1] = (VWri[4][17][1]+((rk[12][2]*Wpk[4][17][0])-(rk[12][0]*
          Wpk[4][17][2])));
        Vpk[4][17][2] = (((rk[12][0]*Wpk[4][15][1])-(rk[12][1]*Wpk[4][17][0]))+(
          (VWri[4][17][2]*c17)-(VWri[4][17][0]*s17)));
        VWri[4][18][0] = (Vpk[4][16][0]+((ri[13][2]*Wpk[4][14][1])-(ri[13][1]*
          Wpk[4][16][2])));
        VWri[4][18][1] = (Vpk[4][16][1]+((ri[13][0]*Wpk[4][16][2])-(ri[13][2]*
          Wpk[4][16][0])));
        VWri[4][18][2] = (Vpk[4][16][2]+((ri[13][1]*Wpk[4][16][0])-(ri[13][0]*
          Wpk[4][14][1])));
        Vpk[4][18][0] = (((rk[13][1]*Wpk[4][18][2])-(rk[13][2]*Wpk[4][14][1]))+(
          (VWri[4][18][0]*c18)+(VWri[4][18][2]*s18)));
        Vpk[4][18][1] = (VWri[4][18][1]+((rk[13][2]*Wpk[4][18][0])-(rk[13][0]*
          Wpk[4][18][2])));
        Vpk[4][18][2] = (((rk[13][0]*Wpk[4][14][1])-(rk[13][1]*Wpk[4][18][0]))+(
          (VWri[4][18][2]*c18)-(VWri[4][18][0]*s18)));
        VWri[4][19][0] = (Vpk[4][17][0]+((ri[14][2]*Wpk[4][15][1])-(ri[14][1]*
          Wpk[4][17][2])));
        VWri[4][19][1] = (Vpk[4][17][1]+((ri[14][0]*Wpk[4][17][2])-(ri[14][2]*
          Wpk[4][17][0])));
        VWri[4][19][2] = (Vpk[4][17][2]+((ri[14][1]*Wpk[4][17][0])-(ri[14][0]*
          Wpk[4][15][1])));
        Vpk[4][19][0] = (((rk[14][1]*Wpk[4][19][2])-(rk[14][2]*Wpk[4][15][1]))+(
          (VWri[4][19][0]*c19)+(VWri[4][19][2]*s19)));
        Vpk[4][19][1] = (VWri[4][19][1]+((rk[14][2]*Wpk[4][19][0])-(rk[14][0]*
          Wpk[4][19][2])));
        Vpk[4][19][2] = (((rk[14][0]*Wpk[4][15][1])-(rk[14][1]*Wpk[4][19][0]))+(
          (VWri[4][19][2]*c19)-(VWri[4][19][0]*s19)));
        VWri[4][20][0] = (Vpk[4][18][0]+((ri[15][2]*Wpk[4][14][1])-(ri[15][1]*
          Wpk[4][18][2])));
        VWri[4][20][1] = (Vpk[4][18][1]+((ri[15][0]*Wpk[4][18][2])-(ri[15][2]*
          Wpk[4][18][0])));
        VWri[4][20][2] = (Vpk[4][18][2]+((ri[15][1]*Wpk[4][18][0])-(ri[15][0]*
          Wpk[4][14][1])));
        Vpk[4][20][0] = (((rk[15][1]*Wpk[4][20][2])-(rk[15][2]*Wpk[4][14][1]))+(
          (VWri[4][20][0]*c20)+(VWri[4][20][2]*s20)));
        Vpk[4][20][1] = (VWri[4][20][1]+((rk[15][2]*Wpk[4][20][0])-(rk[15][0]*
          Wpk[4][20][2])));
        Vpk[4][20][2] = (((rk[15][0]*Wpk[4][14][1])-(rk[15][1]*Wpk[4][20][0]))+(
          (VWri[4][20][2]*c20)-(VWri[4][20][0]*s20)));
        VWri[4][21][0] = (Vpk[4][19][0]+((ri[16][2]*Wpk[4][15][1])-(ri[16][1]*
          Wpk[4][19][2])));
        VWri[4][21][1] = (Vpk[4][19][1]+((ri[16][0]*Wpk[4][19][2])-(ri[16][2]*
          Wpk[4][19][0])));
        VWri[4][21][2] = (Vpk[4][19][2]+((ri[16][1]*Wpk[4][19][0])-(ri[16][0]*
          Wpk[4][15][1])));
        Vpk[4][21][0] = (((rk[16][1]*Wpk[4][21][2])-(rk[16][2]*Wpk[4][15][1]))+(
          (VWri[4][21][0]*c21)+(VWri[4][21][2]*s21)));
        Vpk[4][21][1] = (VWri[4][21][1]+((rk[16][2]*Wpk[4][21][0])-(rk[16][0]*
          Wpk[4][21][2])));
        Vpk[4][21][2] = (((rk[16][0]*Wpk[4][15][1])-(rk[16][1]*Wpk[4][21][0]))+(
          (VWri[4][21][2]*c21)-(VWri[4][21][0]*s21)));
        VWri[4][22][0] = (Vpk[4][20][0]+((ri[17][2]*Wpk[4][14][1])-(ri[17][1]*
          Wpk[4][20][2])));
        VWri[4][22][1] = (Vpk[4][20][1]+((ri[17][0]*Wpk[4][20][2])-(ri[17][2]*
          Wpk[4][20][0])));
        VWri[4][22][2] = (Vpk[4][20][2]+((ri[17][1]*Wpk[4][20][0])-(ri[17][0]*
          Wpk[4][14][1])));
        Vpk[4][22][0] = (VWri[4][22][0]+((rk[17][1]*Wpk[4][22][2])-(rk[17][2]*
          Wpk[4][22][1])));
        Vpk[4][22][1] = (((rk[17][2]*Wpk[4][20][0])-(rk[17][0]*Wpk[4][22][2]))+(
          (VWri[4][22][1]*c22)-(VWri[4][22][2]*s22)));
        Vpk[4][22][2] = (((rk[17][0]*Wpk[4][22][1])-(rk[17][1]*Wpk[4][20][0]))+(
          (VWri[4][22][1]*s22)+(VWri[4][22][2]*c22)));
        VWri[4][23][0] = (Vpk[4][21][0]+((ri[18][2]*Wpk[4][15][1])-(ri[18][1]*
          Wpk[4][21][2])));
        VWri[4][23][1] = (Vpk[4][21][1]+((ri[18][0]*Wpk[4][21][2])-(ri[18][2]*
          Wpk[4][21][0])));
        VWri[4][23][2] = (Vpk[4][21][2]+((ri[18][1]*Wpk[4][21][0])-(ri[18][0]*
          Wpk[4][15][1])));
        Vpk[4][23][0] = (VWri[4][23][0]+((rk[18][1]*Wpk[4][23][2])-(rk[18][2]*
          Wpk[4][23][1])));
        Vpk[4][23][1] = (((rk[18][2]*Wpk[4][21][0])-(rk[18][0]*Wpk[4][23][2]))+(
          (VWri[4][23][1]*c23)+(VWri[4][23][2]*s23)));
        Vpk[4][23][2] = (((rk[18][0]*Wpk[4][23][1])-(rk[18][1]*Wpk[4][21][0]))+(
          (VWri[4][23][2]*c23)-(VWri[4][23][1]*s23)));
        VWri[4][24][0] = (ri[19][2]-rk[0][2]);
        VWri[4][24][2] = (rk[0][0]-ri[19][0]);
        Vpk[4][24][0] = ((VWri[4][24][0]*c24)-(rk[19][2]*c24));
        Vpk[4][24][1] = ((rk[19][2]*s24)-(VWri[4][24][0]*s24));
        Vpk[4][24][2] = (VWri[4][24][2]+((rk[19][0]*c24)-(rk[19][1]*s24)));
        VWri[4][25][0] = (Vpk[4][24][0]+(ri[20][2]*c24));
        VWri[4][25][1] = (Vpk[4][24][1]-(ri[20][2]*s24));
        VWri[4][25][2] = (Vpk[4][24][2]+((ri[20][1]*s24)-(ri[20][0]*c24)));
        Vpk[4][25][0] = (((rk[20][1]*Wpk[4][25][2])-(rk[20][2]*c24))+((
          VWri[4][25][0]*c25)+(VWri[4][25][2]*s25)));
        Vpk[4][25][1] = (VWri[4][25][1]+((rk[20][2]*Wpk[4][25][0])-(rk[20][0]*
          Wpk[4][25][2])));
        Vpk[4][25][2] = (((rk[20][0]*c24)-(rk[20][1]*Wpk[4][25][0]))+((
          VWri[4][25][2]*c25)-(VWri[4][25][0]*s25)));
        Vpk[5][5][0] = rk[0][1];
        Vpk[5][5][1] = -rk[0][0];
        VWri[5][6][0] = (rk[0][1]-ri[1][1]);
        VWri[5][6][1] = (ri[1][0]-rk[0][0]);
        Vpk[5][6][0] = ((rk[1][1]*c6)+(VWri[5][6][0]*c6));
        Vpk[5][6][1] = (VWri[5][6][1]+((rk[1][2]*s6)-(rk[1][0]*c6)));
        Vpk[5][6][2] = -((rk[1][1]*s6)+(VWri[5][6][0]*s6));
        VWri[5][7][0] = (rk[0][1]-ri[2][1]);
        VWri[5][7][1] = (ri[2][0]-rk[0][0]);
        Vpk[5][7][0] = ((rk[2][1]*c7)+(VWri[5][7][0]*c7));
        Vpk[5][7][1] = (VWri[5][7][1]+((rk[2][2]*s7)-(rk[2][0]*c7)));
        Vpk[5][7][2] = -((rk[2][1]*s7)+(VWri[5][7][0]*s7));
        VWri[5][8][0] = (Vpk[5][6][0]-(ri[3][1]*c6));
        VWri[5][8][1] = (Vpk[5][6][1]+((ri[3][0]*c6)-(ri[3][2]*s6)));
        VWri[5][8][2] = (Vpk[5][6][2]+(ri[3][1]*s6));
        Vpk[5][8][0] = (VWri[5][8][0]+((rk[3][1]*Wpk[5][8][2])-(rk[3][2]*
          Wpk[5][8][1])));
        Vpk[5][8][1] = (((rk[3][2]*s6)-(rk[3][0]*Wpk[5][8][2]))+((VWri[5][8][1]*
          c8)-(VWri[5][8][2]*s8)));
        Vpk[5][8][2] = (((rk[3][0]*Wpk[5][8][1])-(rk[3][1]*s6))+((VWri[5][8][1]*
          s8)+(VWri[5][8][2]*c8)));
        VWri[5][9][0] = (Vpk[5][7][0]-(ri[4][1]*c7));
        VWri[5][9][1] = (Vpk[5][7][1]+((ri[4][0]*c7)-(ri[4][2]*s7)));
        VWri[5][9][2] = (Vpk[5][7][2]+(ri[4][1]*s7));
        Vpk[5][9][0] = (VWri[5][9][0]+((rk[4][1]*Wpk[5][9][2])-(rk[4][2]*
          Wpk[5][9][1])));
        Vpk[5][9][1] = (((rk[4][2]*s7)-(rk[4][0]*Wpk[5][9][2]))+((VWri[5][9][1]*
          c9)+(VWri[5][9][2]*s9)));
        Vpk[5][9][2] = (((rk[4][0]*Wpk[5][9][1])-(rk[4][1]*s7))+((VWri[5][9][2]*
          c9)-(VWri[5][9][1]*s9)));
        VWri[5][10][0] = (Vpk[5][8][0]+((ri[5][2]*Wpk[5][8][1])-(ri[5][1]*
          Wpk[5][8][2])));
        VWri[5][10][1] = (Vpk[5][8][1]+((ri[5][0]*Wpk[5][8][2])-(ri[5][2]*s6)));
        VWri[5][10][2] = (Vpk[5][8][2]+((ri[5][1]*s6)-(ri[5][0]*Wpk[5][8][1])));
        Vpk[5][10][0] = (((rk[5][1]*Wpk[5][8][2])-(rk[5][2]*Wpk[5][10][1]))+((
          VWri[5][10][0]*c10)-(VWri[5][10][1]*s10)));
        Vpk[5][10][1] = (((rk[5][2]*Wpk[5][10][0])-(rk[5][0]*Wpk[5][8][2]))+((
          VWri[5][10][0]*s10)+(VWri[5][10][1]*c10)));
        Vpk[5][10][2] = (VWri[5][10][2]+((rk[5][0]*Wpk[5][10][1])-(rk[5][1]*
          Wpk[5][10][0])));
        VWri[5][11][0] = (Vpk[5][9][0]+((ri[6][2]*Wpk[5][9][1])-(ri[6][1]*
          Wpk[5][9][2])));
        VWri[5][11][1] = (Vpk[5][9][1]+((ri[6][0]*Wpk[5][9][2])-(ri[6][2]*s7)));
        VWri[5][11][2] = (Vpk[5][9][2]+((ri[6][1]*s7)-(ri[6][0]*Wpk[5][9][1])));
        Vpk[5][11][0] = (((rk[6][1]*Wpk[5][9][2])-(rk[6][2]*Wpk[5][11][1]))+((
          VWri[5][11][0]*c11)+(VWri[5][11][1]*s11)));
        Vpk[5][11][1] = (((rk[6][2]*Wpk[5][11][0])-(rk[6][0]*Wpk[5][9][2]))+((
          VWri[5][11][1]*c11)-(VWri[5][11][0]*s11)));
        Vpk[5][11][2] = (VWri[5][11][2]+((rk[6][0]*Wpk[5][11][1])-(rk[6][1]*
          Wpk[5][11][0])));
        VWri[5][12][0] = (rk[0][1]-ri[7][1]);
        VWri[5][12][1] = (ri[7][0]-rk[0][0]);
        Vpk[5][12][0] = (rk[7][1]+((VWri[5][12][0]*c12)-(VWri[5][12][1]*s12)));
        Vpk[5][12][1] = (((VWri[5][12][0]*s12)+(VWri[5][12][1]*c12))-rk[7][0]);
        VWri[5][13][0] = (rk[0][1]-ri[8][1]);
        VWri[5][13][1] = (ri[8][0]-rk[0][0]);
        Vpk[5][13][0] = (rk[8][1]+((VWri[5][13][0]*c13)+(VWri[5][13][1]*s13)));
        Vpk[5][13][1] = (((VWri[5][13][1]*c13)-(VWri[5][13][0]*s13))-rk[8][0]);
        VWri[5][14][0] = (Vpk[5][12][0]-ri[9][1]);
        VWri[5][14][1] = (ri[9][0]+Vpk[5][12][1]);
        Vpk[5][14][0] = (VWri[5][14][0]+((rk[9][1]*c14)+(rk[9][2]*s14)));
        Vpk[5][14][1] = ((VWri[5][14][1]*c14)-(rk[9][0]*c14));
        Vpk[5][14][2] = ((VWri[5][14][1]*s14)-(rk[9][0]*s14));
        VWri[5][15][0] = (Vpk[5][13][0]-ri[10][1]);
        VWri[5][15][1] = (ri[10][0]+Vpk[5][13][1]);
        Vpk[5][15][0] = (VWri[5][15][0]+((rk[10][1]*c15)-(rk[10][2]*s15)));
        Vpk[5][15][1] = ((VWri[5][15][1]*c15)-(rk[10][0]*c15));
        Vpk[5][15][2] = ((rk[10][0]*s15)-(VWri[5][15][1]*s15));
        VWri[5][16][0] = (Vpk[5][14][0]-((ri[11][1]*c14)+(ri[11][2]*s14)));
        VWri[5][16][1] = (Vpk[5][14][1]+(ri[11][0]*c14));
        VWri[5][16][2] = (Vpk[5][14][2]+(ri[11][0]*s14));
        Vpk[5][16][0] = (((rk[11][1]*Wpk[5][16][2])+(rk[11][2]*s14))+((
          VWri[5][16][0]*c16)+(VWri[5][16][2]*s16)));
        Vpk[5][16][1] = (VWri[5][16][1]+((rk[11][2]*Wpk[5][16][0])-(rk[11][0]*
          Wpk[5][16][2])));
        Vpk[5][16][2] = (((VWri[5][16][2]*c16)-(VWri[5][16][0]*s16))-((rk[11][0]
          *s14)+(rk[11][1]*Wpk[5][16][0])));
        VWri[5][17][0] = (Vpk[5][15][0]+((ri[12][2]*s15)-(ri[12][1]*c15)));
        VWri[5][17][1] = (Vpk[5][15][1]+(ri[12][0]*c15));
        VWri[5][17][2] = (Vpk[5][15][2]-(ri[12][0]*s15));
        Vpk[5][17][0] = (((rk[12][1]*Wpk[5][17][2])-(rk[12][2]*s15))+((
          VWri[5][17][0]*c17)+(VWri[5][17][2]*s17)));
        Vpk[5][17][1] = (VWri[5][17][1]+((rk[12][2]*Wpk[5][17][0])-(rk[12][0]*
          Wpk[5][17][2])));
        Vpk[5][17][2] = (((rk[12][0]*s15)-(rk[12][1]*Wpk[5][17][0]))+((
          VWri[5][17][2]*c17)-(VWri[5][17][0]*s17)));
        VWri[5][18][0] = (Vpk[5][16][0]-((ri[13][1]*Wpk[5][16][2])+(ri[13][2]*
          s14)));
        VWri[5][18][1] = (Vpk[5][16][1]+((ri[13][0]*Wpk[5][16][2])-(ri[13][2]*
          Wpk[5][16][0])));
        VWri[5][18][2] = (Vpk[5][16][2]+((ri[13][0]*s14)+(ri[13][1]*
          Wpk[5][16][0])));
        Vpk[5][18][0] = (((rk[13][1]*Wpk[5][18][2])+(rk[13][2]*s14))+((
          VWri[5][18][0]*c18)+(VWri[5][18][2]*s18)));
        Vpk[5][18][1] = (VWri[5][18][1]+((rk[13][2]*Wpk[5][18][0])-(rk[13][0]*
          Wpk[5][18][2])));
        Vpk[5][18][2] = (((VWri[5][18][2]*c18)-(VWri[5][18][0]*s18))-((rk[13][0]
          *s14)+(rk[13][1]*Wpk[5][18][0])));
        VWri[5][19][0] = (Vpk[5][17][0]+((ri[14][2]*s15)-(ri[14][1]*
          Wpk[5][17][2])));
        VWri[5][19][1] = (Vpk[5][17][1]+((ri[14][0]*Wpk[5][17][2])-(ri[14][2]*
          Wpk[5][17][0])));
        VWri[5][19][2] = (Vpk[5][17][2]+((ri[14][1]*Wpk[5][17][0])-(ri[14][0]*
          s15)));
        Vpk[5][19][0] = (((rk[14][1]*Wpk[5][19][2])-(rk[14][2]*s15))+((
          VWri[5][19][0]*c19)+(VWri[5][19][2]*s19)));
        Vpk[5][19][1] = (VWri[5][19][1]+((rk[14][2]*Wpk[5][19][0])-(rk[14][0]*
          Wpk[5][19][2])));
        Vpk[5][19][2] = (((rk[14][0]*s15)-(rk[14][1]*Wpk[5][19][0]))+((
          VWri[5][19][2]*c19)-(VWri[5][19][0]*s19)));
        VWri[5][20][0] = (Vpk[5][18][0]-((ri[15][1]*Wpk[5][18][2])+(ri[15][2]*
          s14)));
        VWri[5][20][1] = (Vpk[5][18][1]+((ri[15][0]*Wpk[5][18][2])-(ri[15][2]*
          Wpk[5][18][0])));
        VWri[5][20][2] = (Vpk[5][18][2]+((ri[15][0]*s14)+(ri[15][1]*
          Wpk[5][18][0])));
        Vpk[5][20][0] = (((rk[15][1]*Wpk[5][20][2])+(rk[15][2]*s14))+((
          VWri[5][20][0]*c20)+(VWri[5][20][2]*s20)));
        Vpk[5][20][1] = (VWri[5][20][1]+((rk[15][2]*Wpk[5][20][0])-(rk[15][0]*
          Wpk[5][20][2])));
        Vpk[5][20][2] = (((VWri[5][20][2]*c20)-(VWri[5][20][0]*s20))-((rk[15][0]
          *s14)+(rk[15][1]*Wpk[5][20][0])));
        VWri[5][21][0] = (Vpk[5][19][0]+((ri[16][2]*s15)-(ri[16][1]*
          Wpk[5][19][2])));
        VWri[5][21][1] = (Vpk[5][19][1]+((ri[16][0]*Wpk[5][19][2])-(ri[16][2]*
          Wpk[5][19][0])));
        VWri[5][21][2] = (Vpk[5][19][2]+((ri[16][1]*Wpk[5][19][0])-(ri[16][0]*
          s15)));
        Vpk[5][21][0] = (((rk[16][1]*Wpk[5][21][2])-(rk[16][2]*s15))+((
          VWri[5][21][0]*c21)+(VWri[5][21][2]*s21)));
        Vpk[5][21][1] = (VWri[5][21][1]+((rk[16][2]*Wpk[5][21][0])-(rk[16][0]*
          Wpk[5][21][2])));
        Vpk[5][21][2] = (((rk[16][0]*s15)-(rk[16][1]*Wpk[5][21][0]))+((
          VWri[5][21][2]*c21)-(VWri[5][21][0]*s21)));
        VWri[5][22][0] = (Vpk[5][20][0]-((ri[17][1]*Wpk[5][20][2])+(ri[17][2]*
          s14)));
        VWri[5][22][1] = (Vpk[5][20][1]+((ri[17][0]*Wpk[5][20][2])-(ri[17][2]*
          Wpk[5][20][0])));
        VWri[5][22][2] = (Vpk[5][20][2]+((ri[17][0]*s14)+(ri[17][1]*
          Wpk[5][20][0])));
        Vpk[5][22][0] = (VWri[5][22][0]+((rk[17][1]*Wpk[5][22][2])-(rk[17][2]*
          Wpk[5][22][1])));
        Vpk[5][22][1] = (((rk[17][2]*Wpk[5][20][0])-(rk[17][0]*Wpk[5][22][2]))+(
          (VWri[5][22][1]*c22)-(VWri[5][22][2]*s22)));
        Vpk[5][22][2] = (((rk[17][0]*Wpk[5][22][1])-(rk[17][1]*Wpk[5][20][0]))+(
          (VWri[5][22][1]*s22)+(VWri[5][22][2]*c22)));
        VWri[5][23][0] = (Vpk[5][21][0]+((ri[18][2]*s15)-(ri[18][1]*
          Wpk[5][21][2])));
        VWri[5][23][1] = (Vpk[5][21][1]+((ri[18][0]*Wpk[5][21][2])-(ri[18][2]*
          Wpk[5][21][0])));
        VWri[5][23][2] = (Vpk[5][21][2]+((ri[18][1]*Wpk[5][21][0])-(ri[18][0]*
          s15)));
        Vpk[5][23][0] = (VWri[5][23][0]+((rk[18][1]*Wpk[5][23][2])-(rk[18][2]*
          Wpk[5][23][1])));
        Vpk[5][23][1] = (((rk[18][2]*Wpk[5][21][0])-(rk[18][0]*Wpk[5][23][2]))+(
          (VWri[5][23][1]*c23)+(VWri[5][23][2]*s23)));
        Vpk[5][23][2] = (((rk[18][0]*Wpk[5][23][1])-(rk[18][1]*Wpk[5][21][0]))+(
          (VWri[5][23][2]*c23)-(VWri[5][23][1]*s23)));
        VWri[5][24][0] = (rk[0][1]-ri[19][1]);
        VWri[5][24][1] = (ri[19][0]-rk[0][0]);
        Vpk[5][24][0] = (rk[19][1]+((VWri[5][24][0]*c24)+(VWri[5][24][1]*s24)));
        Vpk[5][24][1] = (((VWri[5][24][1]*c24)-(VWri[5][24][0]*s24))-rk[19][0]);
        VWri[5][25][0] = (Vpk[5][24][0]-ri[20][1]);
        VWri[5][25][1] = (ri[20][0]+Vpk[5][24][1]);
        Vpk[5][25][0] = ((rk[20][1]*c25)+(VWri[5][25][0]*c25));
        Vpk[5][25][1] = (VWri[5][25][1]+((rk[20][2]*s25)-(rk[20][0]*c25)));
        Vpk[5][25][2] = -((rk[20][1]*s25)+(VWri[5][25][0]*s25));
        Vpk[6][6][0] = rk[1][2];
        Vpk[6][6][2] = -rk[1][0];
        VWri[6][8][0] = (rk[1][2]-ri[3][2]);
        VWri[6][8][2] = (ri[3][0]-rk[1][0]);
        Vpk[6][8][0] = (VWri[6][8][0]+((rk[3][2]*c8)-(rk[3][1]*s8)));
        Vpk[6][8][1] = ((rk[3][0]*s8)-(VWri[6][8][2]*s8));
        Vpk[6][8][2] = ((VWri[6][8][2]*c8)-(rk[3][0]*c8));
        VWri[6][10][0] = (Vpk[6][8][0]+((ri[5][1]*s8)-(ri[5][2]*c8)));
        VWri[6][10][1] = (Vpk[6][8][1]-(ri[5][0]*s8));
        VWri[6][10][2] = (Vpk[6][8][2]+(ri[5][0]*c8));
        Vpk[6][10][0] = (((VWri[6][10][0]*c10)-(VWri[6][10][1]*s10))-((rk[5][1]*
          s8)+(rk[5][2]*Wpk[6][10][1])));
        Vpk[6][10][1] = (((rk[5][0]*s8)+(rk[5][2]*Wpk[6][10][0]))+((
          VWri[6][10][0]*s10)+(VWri[6][10][1]*c10)));
        Vpk[6][10][2] = (VWri[6][10][2]+((rk[5][0]*Wpk[6][10][1])-(rk[5][1]*
          Wpk[6][10][0])));
        Vpk[7][7][0] = rk[2][2];
        Vpk[7][7][2] = -rk[2][0];
        VWri[7][9][0] = (rk[2][2]-ri[4][2]);
        VWri[7][9][2] = (ri[4][0]-rk[2][0]);
        Vpk[7][9][0] = (VWri[7][9][0]+((rk[4][1]*s9)+(rk[4][2]*c9)));
        Vpk[7][9][1] = ((VWri[7][9][2]*s9)-(rk[4][0]*s9));
        Vpk[7][9][2] = ((VWri[7][9][2]*c9)-(rk[4][0]*c9));
        VWri[7][11][0] = (Vpk[7][9][0]-((ri[6][1]*s9)+(ri[6][2]*c9)));
        VWri[7][11][1] = (Vpk[7][9][1]+(ri[6][0]*s9));
        VWri[7][11][2] = (Vpk[7][9][2]+(ri[6][0]*c9));
        Vpk[7][11][0] = (((rk[6][1]*s9)-(rk[6][2]*Wpk[7][11][1]))+((
          VWri[7][11][0]*c11)+(VWri[7][11][1]*s11)));
        Vpk[7][11][1] = (((rk[6][2]*Wpk[7][11][0])-(rk[6][0]*s9))+((
          VWri[7][11][1]*c11)-(VWri[7][11][0]*s11)));
        Vpk[7][11][2] = (VWri[7][11][2]+((rk[6][0]*Wpk[7][11][1])-(rk[6][1]*
          Wpk[7][11][0])));
        Vpk[8][8][1] = -rk[3][2];
        Vpk[8][8][2] = rk[3][1];
        VWri[8][10][1] = (ri[5][2]-rk[3][2]);
        VWri[8][10][2] = (rk[3][1]-ri[5][1]);
        Vpk[8][10][0] = ((rk[5][2]*s10)-(VWri[8][10][1]*s10));
        Vpk[8][10][1] = ((VWri[8][10][1]*c10)-(rk[5][2]*c10));
        Vpk[8][10][2] = (VWri[8][10][2]+((rk[5][1]*c10)-(rk[5][0]*s10)));
        Vpk[9][9][1] = rk[4][2];
        Vpk[9][9][2] = -rk[4][1];
        VWri[9][11][1] = (rk[4][2]-ri[6][2]);
        VWri[9][11][2] = (ri[6][1]-rk[4][1]);
        Vpk[9][11][0] = ((rk[6][2]*s11)+(VWri[9][11][1]*s11));
        Vpk[9][11][1] = ((rk[6][2]*c11)+(VWri[9][11][1]*c11));
        Vpk[9][11][2] = (VWri[9][11][2]-((rk[6][0]*s11)+(rk[6][1]*c11)));
        Vpk[10][10][0] = -rk[5][1];
        Vpk[10][10][1] = rk[5][0];
        Vpk[11][11][0] = rk[6][1];
        Vpk[11][11][1] = -rk[6][0];
        Vpk[12][12][0] = -rk[7][1];
        Vpk[12][12][1] = rk[7][0];
        VWri[12][14][0] = (ri[9][1]-rk[7][1]);
        VWri[12][14][1] = (rk[7][0]-ri[9][0]);
        Vpk[12][14][0] = (VWri[12][14][0]-((rk[9][1]*c14)+(rk[9][2]*s14)));
        Vpk[12][14][1] = ((rk[9][0]*c14)+(VWri[12][14][1]*c14));
        Vpk[12][14][2] = ((rk[9][0]*s14)+(VWri[12][14][1]*s14));
        VWri[12][16][0] = (Vpk[12][14][0]+((ri[11][1]*c14)+(ri[11][2]*s14)));
        VWri[12][16][1] = (Vpk[12][14][1]-(ri[11][0]*c14));
        VWri[12][16][2] = (Vpk[12][14][2]-(ri[11][0]*s14));
        Vpk[12][16][0] = (((rk[11][1]*Wpk[12][16][2])-(rk[11][2]*s14))+((
          VWri[12][16][0]*c16)+(VWri[12][16][2]*s16)));
        Vpk[12][16][1] = (VWri[12][16][1]+((rk[11][2]*Wpk[12][16][0])-(rk[11][0]
          *Wpk[12][16][2])));
        Vpk[12][16][2] = (((rk[11][0]*s14)-(rk[11][1]*Wpk[12][16][0]))+((
          VWri[12][16][2]*c16)-(VWri[12][16][0]*s16)));
        VWri[12][18][0] = (Vpk[12][16][0]+((ri[13][2]*s14)-(ri[13][1]*
          Wpk[12][16][2])));
        VWri[12][18][1] = (Vpk[12][16][1]+((ri[13][0]*Wpk[12][16][2])-(ri[13][2]
          *Wpk[12][16][0])));
        VWri[12][18][2] = (Vpk[12][16][2]+((ri[13][1]*Wpk[12][16][0])-(ri[13][0]
          *s14)));
        Vpk[12][18][0] = (((rk[13][1]*Wpk[12][18][2])-(rk[13][2]*s14))+((
          VWri[12][18][0]*c18)+(VWri[12][18][2]*s18)));
        Vpk[12][18][1] = (VWri[12][18][1]+((rk[13][2]*Wpk[12][18][0])-(rk[13][0]
          *Wpk[12][18][2])));
        Vpk[12][18][2] = (((rk[13][0]*s14)-(rk[13][1]*Wpk[12][18][0]))+((
          VWri[12][18][2]*c18)-(VWri[12][18][0]*s18)));
        VWri[12][20][0] = (Vpk[12][18][0]+((ri[15][2]*s14)-(ri[15][1]*
          Wpk[12][18][2])));
        VWri[12][20][1] = (Vpk[12][18][1]+((ri[15][0]*Wpk[12][18][2])-(ri[15][2]
          *Wpk[12][18][0])));
        VWri[12][20][2] = (Vpk[12][18][2]+((ri[15][1]*Wpk[12][18][0])-(ri[15][0]
          *s14)));
        Vpk[12][20][0] = (((rk[15][1]*Wpk[12][20][2])-(rk[15][2]*s14))+((
          VWri[12][20][0]*c20)+(VWri[12][20][2]*s20)));
        Vpk[12][20][1] = (VWri[12][20][1]+((rk[15][2]*Wpk[12][20][0])-(rk[15][0]
          *Wpk[12][20][2])));
        Vpk[12][20][2] = (((rk[15][0]*s14)-(rk[15][1]*Wpk[12][20][0]))+((
          VWri[12][20][2]*c20)-(VWri[12][20][0]*s20)));
        VWri[12][22][0] = (Vpk[12][20][0]+((ri[17][2]*s14)-(ri[17][1]*
          Wpk[12][20][2])));
        VWri[12][22][1] = (Vpk[12][20][1]+((ri[17][0]*Wpk[12][20][2])-(ri[17][2]
          *Wpk[12][20][0])));
        VWri[12][22][2] = (Vpk[12][20][2]+((ri[17][1]*Wpk[12][20][0])-(ri[17][0]
          *s14)));
        Vpk[12][22][0] = (VWri[12][22][0]+((rk[17][1]*Wpk[12][22][2])-(rk[17][2]
          *Wpk[12][22][1])));
        Vpk[12][22][1] = (((rk[17][2]*Wpk[12][20][0])-(rk[17][0]*Wpk[12][22][2])
          )+((VWri[12][22][1]*c22)-(VWri[12][22][2]*s22)));
        Vpk[12][22][2] = (((rk[17][0]*Wpk[12][22][1])-(rk[17][1]*Wpk[12][20][0])
          )+((VWri[12][22][1]*s22)+(VWri[12][22][2]*c22)));
        Vpk[13][13][0] = rk[8][1];
        Vpk[13][13][1] = -rk[8][0];
        VWri[13][15][0] = (rk[8][1]-ri[10][1]);
        VWri[13][15][1] = (ri[10][0]-rk[8][0]);
        Vpk[13][15][0] = (VWri[13][15][0]+((rk[10][1]*c15)-(rk[10][2]*s15)));
        Vpk[13][15][1] = ((VWri[13][15][1]*c15)-(rk[10][0]*c15));
        Vpk[13][15][2] = ((rk[10][0]*s15)-(VWri[13][15][1]*s15));
        VWri[13][17][0] = (Vpk[13][15][0]+((ri[12][2]*s15)-(ri[12][1]*c15)));
        VWri[13][17][1] = (Vpk[13][15][1]+(ri[12][0]*c15));
        VWri[13][17][2] = (Vpk[13][15][2]-(ri[12][0]*s15));
        Vpk[13][17][0] = (((rk[12][1]*Wpk[13][17][2])-(rk[12][2]*s15))+((
          VWri[13][17][0]*c17)+(VWri[13][17][2]*s17)));
        Vpk[13][17][1] = (VWri[13][17][1]+((rk[12][2]*Wpk[13][17][0])-(rk[12][0]
          *Wpk[13][17][2])));
        Vpk[13][17][2] = (((rk[12][0]*s15)-(rk[12][1]*Wpk[13][17][0]))+((
          VWri[13][17][2]*c17)-(VWri[13][17][0]*s17)));
        VWri[13][19][0] = (Vpk[13][17][0]+((ri[14][2]*s15)-(ri[14][1]*
          Wpk[13][17][2])));
        VWri[13][19][1] = (Vpk[13][17][1]+((ri[14][0]*Wpk[13][17][2])-(ri[14][2]
          *Wpk[13][17][0])));
        VWri[13][19][2] = (Vpk[13][17][2]+((ri[14][1]*Wpk[13][17][0])-(ri[14][0]
          *s15)));
        Vpk[13][19][0] = (((rk[14][1]*Wpk[13][19][2])-(rk[14][2]*s15))+((
          VWri[13][19][0]*c19)+(VWri[13][19][2]*s19)));
        Vpk[13][19][1] = (VWri[13][19][1]+((rk[14][2]*Wpk[13][19][0])-(rk[14][0]
          *Wpk[13][19][2])));
        Vpk[13][19][2] = (((rk[14][0]*s15)-(rk[14][1]*Wpk[13][19][0]))+((
          VWri[13][19][2]*c19)-(VWri[13][19][0]*s19)));
        VWri[13][21][0] = (Vpk[13][19][0]+((ri[16][2]*s15)-(ri[16][1]*
          Wpk[13][19][2])));
        VWri[13][21][1] = (Vpk[13][19][1]+((ri[16][0]*Wpk[13][19][2])-(ri[16][2]
          *Wpk[13][19][0])));
        VWri[13][21][2] = (Vpk[13][19][2]+((ri[16][1]*Wpk[13][19][0])-(ri[16][0]
          *s15)));
        Vpk[13][21][0] = (((rk[16][1]*Wpk[13][21][2])-(rk[16][2]*s15))+((
          VWri[13][21][0]*c21)+(VWri[13][21][2]*s21)));
        Vpk[13][21][1] = (VWri[13][21][1]+((rk[16][2]*Wpk[13][21][0])-(rk[16][0]
          *Wpk[13][21][2])));
        Vpk[13][21][2] = (((rk[16][0]*s15)-(rk[16][1]*Wpk[13][21][0]))+((
          VWri[13][21][2]*c21)-(VWri[13][21][0]*s21)));
        VWri[13][23][0] = (Vpk[13][21][0]+((ri[18][2]*s15)-(ri[18][1]*
          Wpk[13][21][2])));
        VWri[13][23][1] = (Vpk[13][21][1]+((ri[18][0]*Wpk[13][21][2])-(ri[18][2]
          *Wpk[13][21][0])));
        VWri[13][23][2] = (Vpk[13][21][2]+((ri[18][1]*Wpk[13][21][0])-(ri[18][0]
          *s15)));
        Vpk[13][23][0] = (VWri[13][23][0]+((rk[18][1]*Wpk[13][23][2])-(rk[18][2]
          *Wpk[13][23][1])));
        Vpk[13][23][1] = (((rk[18][2]*Wpk[13][21][0])-(rk[18][0]*Wpk[13][23][2])
          )+((VWri[13][23][1]*c23)+(VWri[13][23][2]*s23)));
        Vpk[13][23][2] = (((rk[18][0]*Wpk[13][23][1])-(rk[18][1]*Wpk[13][21][0])
          )+((VWri[13][23][2]*c23)-(VWri[13][23][1]*s23)));
        Vpk[14][14][1] = -rk[9][2];
        Vpk[14][14][2] = rk[9][1];
        VWri[14][16][1] = (ri[11][2]-rk[9][2]);
        VWri[14][16][2] = (rk[9][1]-ri[11][1]);
        Vpk[14][16][0] = ((rk[11][1]*s16)+(VWri[14][16][2]*s16));
        Vpk[14][16][1] = (VWri[14][16][1]-((rk[11][0]*s16)+(rk[11][2]*c16)));
        Vpk[14][16][2] = ((rk[11][1]*c16)+(VWri[14][16][2]*c16));
        VWri[14][18][0] = (Vpk[14][16][0]-(ri[13][1]*s16));
        VWri[14][18][1] = (Vpk[14][16][1]+((ri[13][0]*s16)+(ri[13][2]*c16)));
        VWri[14][18][2] = (Vpk[14][16][2]-(ri[13][1]*c16));
        Vpk[14][18][0] = ((rk[13][1]*Wpk[14][18][2])+((VWri[14][18][0]*c18)+(
          VWri[14][18][2]*s18)));
        Vpk[14][18][1] = (VWri[14][18][1]+((rk[13][2]*Wpk[14][18][0])-(rk[13][0]
          *Wpk[14][18][2])));
        Vpk[14][18][2] = (((VWri[14][18][2]*c18)-(VWri[14][18][0]*s18))-(
          rk[13][1]*Wpk[14][18][0]));
        VWri[14][20][0] = (Vpk[14][18][0]-(ri[15][1]*Wpk[14][18][2]));
        VWri[14][20][1] = (Vpk[14][18][1]+((ri[15][0]*Wpk[14][18][2])-(ri[15][2]
          *Wpk[14][18][0])));
        VWri[14][20][2] = (Vpk[14][18][2]+(ri[15][1]*Wpk[14][18][0]));
        Vpk[14][20][0] = ((rk[15][1]*Wpk[14][20][2])+((VWri[14][20][0]*c20)+(
          VWri[14][20][2]*s20)));
        Vpk[14][20][1] = (VWri[14][20][1]+((rk[15][2]*Wpk[14][20][0])-(rk[15][0]
          *Wpk[14][20][2])));
        Vpk[14][20][2] = (((VWri[14][20][2]*c20)-(VWri[14][20][0]*s20))-(
          rk[15][1]*Wpk[14][20][0]));
        VWri[14][22][0] = (Vpk[14][20][0]-(ri[17][1]*Wpk[14][20][2]));
        VWri[14][22][1] = (Vpk[14][20][1]+((ri[17][0]*Wpk[14][20][2])-(ri[17][2]
          *Wpk[14][20][0])));
        VWri[14][22][2] = (Vpk[14][20][2]+(ri[17][1]*Wpk[14][20][0]));
        Vpk[14][22][0] = (VWri[14][22][0]+((rk[17][1]*Wpk[14][22][2])-(rk[17][2]
          *Wpk[14][22][1])));
        Vpk[14][22][1] = (((rk[17][2]*Wpk[14][20][0])-(rk[17][0]*Wpk[14][22][2])
          )+((VWri[14][22][1]*c22)-(VWri[14][22][2]*s22)));
        Vpk[14][22][2] = (((rk[17][0]*Wpk[14][22][1])-(rk[17][1]*Wpk[14][20][0])
          )+((VWri[14][22][1]*s22)+(VWri[14][22][2]*c22)));
        Vpk[15][15][1] = rk[10][2];
        Vpk[15][15][2] = -rk[10][1];
        VWri[15][17][1] = (rk[10][2]-ri[12][2]);
        VWri[15][17][2] = (ri[12][1]-rk[10][1]);
        Vpk[15][17][0] = ((VWri[15][17][2]*s17)-(rk[12][1]*s17));
        Vpk[15][17][1] = (VWri[15][17][1]+((rk[12][0]*s17)+(rk[12][2]*c17)));
        Vpk[15][17][2] = ((VWri[15][17][2]*c17)-(rk[12][1]*c17));
        VWri[15][19][0] = (Vpk[15][17][0]+(ri[14][1]*s17));
        VWri[15][19][1] = (Vpk[15][17][1]-((ri[14][0]*s17)+(ri[14][2]*c17)));
        VWri[15][19][2] = (Vpk[15][17][2]+(ri[14][1]*c17));
        Vpk[15][19][0] = ((rk[14][1]*Wpk[15][19][2])+((VWri[15][19][0]*c19)+(
          VWri[15][19][2]*s19)));
        Vpk[15][19][1] = (VWri[15][19][1]+((rk[14][2]*Wpk[15][19][0])-(rk[14][0]
          *Wpk[15][19][2])));
        Vpk[15][19][2] = (((VWri[15][19][2]*c19)-(VWri[15][19][0]*s19))-(
          rk[14][1]*Wpk[15][19][0]));
        VWri[15][21][0] = (Vpk[15][19][0]-(ri[16][1]*Wpk[15][19][2]));
        VWri[15][21][1] = (Vpk[15][19][1]+((ri[16][0]*Wpk[15][19][2])-(ri[16][2]
          *Wpk[15][19][0])));
        VWri[15][21][2] = (Vpk[15][19][2]+(ri[16][1]*Wpk[15][19][0]));
        Vpk[15][21][0] = ((rk[16][1]*Wpk[15][21][2])+((VWri[15][21][0]*c21)+(
          VWri[15][21][2]*s21)));
        Vpk[15][21][1] = (VWri[15][21][1]+((rk[16][2]*Wpk[15][21][0])-(rk[16][0]
          *Wpk[15][21][2])));
        Vpk[15][21][2] = (((VWri[15][21][2]*c21)-(VWri[15][21][0]*s21))-(
          rk[16][1]*Wpk[15][21][0]));
        VWri[15][23][0] = (Vpk[15][21][0]-(ri[18][1]*Wpk[15][21][2]));
        VWri[15][23][1] = (Vpk[15][21][1]+((ri[18][0]*Wpk[15][21][2])-(ri[18][2]
          *Wpk[15][21][0])));
        VWri[15][23][2] = (Vpk[15][21][2]+(ri[18][1]*Wpk[15][21][0]));
        Vpk[15][23][0] = (VWri[15][23][0]+((rk[18][1]*Wpk[15][23][2])-(rk[18][2]
          *Wpk[15][23][1])));
        Vpk[15][23][1] = (((rk[18][2]*Wpk[15][21][0])-(rk[18][0]*Wpk[15][23][2])
          )+((VWri[15][23][1]*c23)+(VWri[15][23][2]*s23)));
        Vpk[15][23][2] = (((rk[18][0]*Wpk[15][23][1])-(rk[18][1]*Wpk[15][21][0])
          )+((VWri[15][23][2]*c23)-(VWri[15][23][1]*s23)));
        Vpk[16][16][0] = rk[11][2];
        Vpk[16][16][2] = -rk[11][0];
        VWri[16][18][0] = (rk[11][2]-ri[13][2]);
        VWri[16][18][2] = (ri[13][0]-rk[11][0]);
        Vpk[16][18][0] = (rk[13][2]+((VWri[16][18][0]*c18)+(VWri[16][18][2]*s18)
          ));
        Vpk[16][18][2] = (((VWri[16][18][2]*c18)-(VWri[16][18][0]*s18))-
          rk[13][0]);
        VWri[16][20][0] = (Vpk[16][18][0]-ri[15][2]);
        VWri[16][20][2] = (ri[15][0]+Vpk[16][18][2]);
        Vpk[16][20][0] = (rk[15][2]+((VWri[16][20][0]*c20)+(VWri[16][20][2]*s20)
          ));
        Vpk[16][20][2] = (((VWri[16][20][2]*c20)-(VWri[16][20][0]*s20))-
          rk[15][0]);
        VWri[16][22][0] = (Vpk[16][20][0]-ri[17][2]);
        VWri[16][22][2] = (ri[17][0]+Vpk[16][20][2]);
        Vpk[16][22][0] = (VWri[16][22][0]+((rk[17][2]*c22)-(rk[17][1]*s22)));
        Vpk[16][22][1] = ((rk[17][0]*s22)-(VWri[16][22][2]*s22));
        Vpk[16][22][2] = ((VWri[16][22][2]*c22)-(rk[17][0]*c22));
        Vpk[17][17][0] = rk[12][2];
        Vpk[17][17][2] = -rk[12][0];
        VWri[17][19][0] = (rk[12][2]-ri[14][2]);
        VWri[17][19][2] = (ri[14][0]-rk[12][0]);
        Vpk[17][19][0] = (rk[14][2]+((VWri[17][19][0]*c19)+(VWri[17][19][2]*s19)
          ));
        Vpk[17][19][2] = (((VWri[17][19][2]*c19)-(VWri[17][19][0]*s19))-
          rk[14][0]);
        VWri[17][21][0] = (Vpk[17][19][0]-ri[16][2]);
        VWri[17][21][2] = (ri[16][0]+Vpk[17][19][2]);
        Vpk[17][21][0] = (rk[16][2]+((VWri[17][21][0]*c21)+(VWri[17][21][2]*s21)
          ));
        Vpk[17][21][2] = (((VWri[17][21][2]*c21)-(VWri[17][21][0]*s21))-
          rk[16][0]);
        VWri[17][23][0] = (Vpk[17][21][0]-ri[18][2]);
        VWri[17][23][2] = (ri[18][0]+Vpk[17][21][2]);
        Vpk[17][23][0] = (VWri[17][23][0]+((rk[18][1]*s23)+(rk[18][2]*c23)));
        Vpk[17][23][1] = ((VWri[17][23][2]*s23)-(rk[18][0]*s23));
        Vpk[17][23][2] = ((VWri[17][23][2]*c23)-(rk[18][0]*c23));
        Vpk[18][18][0] = rk[13][2];
        Vpk[18][18][2] = -rk[13][0];
        VWri[18][20][0] = (rk[13][2]-ri[15][2]);
        VWri[18][20][2] = (ri[15][0]-rk[13][0]);
        Vpk[18][20][0] = (rk[15][2]+((VWri[18][20][0]*c20)+(VWri[18][20][2]*s20)
          ));
        Vpk[18][20][2] = (((VWri[18][20][2]*c20)-(VWri[18][20][0]*s20))-
          rk[15][0]);
        VWri[18][22][0] = (Vpk[18][20][0]-ri[17][2]);
        VWri[18][22][2] = (ri[17][0]+Vpk[18][20][2]);
        Vpk[18][22][0] = (VWri[18][22][0]+((rk[17][2]*c22)-(rk[17][1]*s22)));
        Vpk[18][22][1] = ((rk[17][0]*s22)-(VWri[18][22][2]*s22));
        Vpk[18][22][2] = ((VWri[18][22][2]*c22)-(rk[17][0]*c22));
        Vpk[19][19][0] = rk[14][2];
        Vpk[19][19][2] = -rk[14][0];
        VWri[19][21][0] = (rk[14][2]-ri[16][2]);
        VWri[19][21][2] = (ri[16][0]-rk[14][0]);
        Vpk[19][21][0] = (rk[16][2]+((VWri[19][21][0]*c21)+(VWri[19][21][2]*s21)
          ));
        Vpk[19][21][2] = (((VWri[19][21][2]*c21)-(VWri[19][21][0]*s21))-
          rk[16][0]);
        VWri[19][23][0] = (Vpk[19][21][0]-ri[18][2]);
        VWri[19][23][2] = (ri[18][0]+Vpk[19][21][2]);
        Vpk[19][23][0] = (VWri[19][23][0]+((rk[18][1]*s23)+(rk[18][2]*c23)));
        Vpk[19][23][1] = ((VWri[19][23][2]*s23)-(rk[18][0]*s23));
        Vpk[19][23][2] = ((VWri[19][23][2]*c23)-(rk[18][0]*c23));
        Vpk[20][20][0] = rk[15][2];
        Vpk[20][20][2] = -rk[15][0];
        VWri[20][22][0] = (rk[15][2]-ri[17][2]);
        VWri[20][22][2] = (ri[17][0]-rk[15][0]);
        Vpk[20][22][0] = (VWri[20][22][0]+((rk[17][2]*c22)-(rk[17][1]*s22)));
        Vpk[20][22][1] = ((rk[17][0]*s22)-(VWri[20][22][2]*s22));
        Vpk[20][22][2] = ((VWri[20][22][2]*c22)-(rk[17][0]*c22));
        Vpk[21][21][0] = rk[16][2];
        Vpk[21][21][2] = -rk[16][0];
        VWri[21][23][0] = (rk[16][2]-ri[18][2]);
        VWri[21][23][2] = (ri[18][0]-rk[16][0]);
        Vpk[21][23][0] = (VWri[21][23][0]+((rk[18][1]*s23)+(rk[18][2]*c23)));
        Vpk[21][23][1] = ((VWri[21][23][2]*s23)-(rk[18][0]*s23));
        Vpk[21][23][2] = ((VWri[21][23][2]*c23)-(rk[18][0]*c23));
        Vpk[22][22][1] = -rk[17][2];
        Vpk[22][22][2] = rk[17][1];
        Vpk[23][23][1] = rk[18][2];
        Vpk[23][23][2] = -rk[18][1];
        Vpk[24][24][0] = rk[19][1];
        Vpk[24][24][1] = -rk[19][0];
        VWri[24][25][0] = (rk[19][1]-ri[20][1]);
        VWri[24][25][1] = (ri[20][0]-rk[19][0]);
        Vpk[24][25][0] = ((rk[20][1]*c25)+(VWri[24][25][0]*c25));
        Vpk[24][25][1] = (VWri[24][25][1]+((rk[20][2]*s25)-(rk[20][0]*c25)));
        Vpk[24][25][2] = -((rk[20][1]*s25)+(VWri[24][25][0]*s25));
        Vpk[25][25][0] = rk[20][2];
        Vpk[25][25][2] = -rk[20][0];
        vpkflg = 1;
    }
/*
 Used 0.02 seconds CPU time,
 0 additional bytes of memory.
 Equations contain 1244 adds/subtracts/negates
                   1488 multiplies
                      0 divides
                   1050 assignments
*/
}

void sddoltau(void)
{

/*
Compute effect of loop hinge torques
*/
/*
 Used 0.00 seconds CPU time,
 0 additional bytes of memory.
 Equations contain    0 adds/subtracts/negates
                      0 multiplies
                      0 divides
                      0 assignments
*/
}

void sddoiner(void)
{

/*
Compute inertial accelerations and related temps
*/
    if (inerflg == 0) {
/*
Compute Otk (inertial angular acceleration)
*/
        Otk[6][0] = (u[6]*wk[6][2]);
        Otk[6][2] = -(u[6]*wk[6][0]);
        Otk[7][0] = (u[7]*wk[7][2]);
        Otk[7][2] = -(u[7]*wk[7][0]);
        Otk[8][1] = -((Otk[6][2]*s8)+(u[8]*wk[8][2]));
        Otk[8][2] = ((Otk[6][2]*c8)+(u[8]*wk[8][1]));
        Otk[9][1] = ((Otk[7][2]*s9)+(u[9]*wk[9][2]));
        Otk[9][2] = ((Otk[7][2]*c9)-(u[9]*wk[9][1]));
        Otk[10][0] = (((Otk[6][0]*c10)-(Otk[8][1]*s10))-(u[10]*wk[10][1]));
        Otk[10][1] = ((u[10]*wk[10][0])+((Otk[6][0]*s10)+(Otk[8][1]*c10)));
        Otk[11][0] = ((u[11]*wk[11][1])+((Otk[7][0]*c11)+(Otk[9][1]*s11)));
        Otk[11][1] = (((Otk[9][1]*c11)-(Otk[7][0]*s11))-(u[11]*wk[11][0]));
        Otk[12][0] = -(u[12]*wk[12][1]);
        Otk[12][1] = (u[12]*wk[12][0]);
        Otk[13][0] = (u[13]*wk[13][1]);
        Otk[13][1] = -(u[13]*wk[13][0]);
        Otk[14][1] = ((Otk[12][1]*c14)-(u[14]*wk[14][2]));
        Otk[14][2] = ((Otk[12][1]*s14)+(u[14]*wk[14][1]));
        Otk[15][1] = ((Otk[13][1]*c15)+(u[15]*wk[15][2]));
        Otk[15][2] = -((Otk[13][1]*s15)+(u[15]*wk[15][1]));
        Otk[16][0] = ((u[16]*wk[16][2])+((Otk[12][0]*c16)+(Otk[14][2]*s16)));
        Otk[16][2] = (((Otk[14][2]*c16)-(Otk[12][0]*s16))-(u[16]*wk[16][0]));
        Otk[17][0] = ((u[17]*wk[17][2])+((Otk[13][0]*c17)+(Otk[15][2]*s17)));
        Otk[17][2] = (((Otk[15][2]*c17)-(Otk[13][0]*s17))-(u[17]*wk[17][0]));
        Otk[18][0] = ((u[18]*wk[18][2])+((Otk[16][0]*c18)+(Otk[16][2]*s18)));
        Otk[18][2] = (((Otk[16][2]*c18)-(Otk[16][0]*s18))-(u[18]*wk[18][0]));
        Otk[19][0] = ((u[19]*wk[19][2])+((Otk[17][0]*c19)+(Otk[17][2]*s19)));
        Otk[19][2] = (((Otk[17][2]*c19)-(Otk[17][0]*s19))-(u[19]*wk[19][0]));
        Otk[20][0] = ((u[20]*wk[20][2])+((Otk[18][0]*c20)+(Otk[18][2]*s20)));
        Otk[20][2] = (((Otk[18][2]*c20)-(Otk[18][0]*s20))-(u[20]*wk[20][0]));
        Otk[21][0] = ((u[21]*wk[21][2])+((Otk[19][0]*c21)+(Otk[19][2]*s21)));
        Otk[21][2] = (((Otk[19][2]*c21)-(Otk[19][0]*s21))-(u[21]*wk[21][0]));
        Otk[22][1] = (((Otk[14][1]*c22)-(Otk[20][2]*s22))-(u[22]*wk[22][2]));
        Otk[22][2] = ((u[22]*wk[22][1])+((Otk[14][1]*s22)+(Otk[20][2]*c22)));
        Otk[23][1] = ((u[23]*wk[23][2])+((Otk[15][1]*c23)+(Otk[21][2]*s23)));
        Otk[23][2] = (((Otk[21][2]*c23)-(Otk[15][1]*s23))-(u[23]*wk[23][1]));
        Otk[24][0] = (u[24]*wk[24][1]);
        Otk[24][1] = -(u[24]*wk[24][0]);
        Otk[25][0] = ((Otk[24][0]*c25)+(u[25]*wk[25][2]));
        Otk[25][2] = -((Otk[24][0]*s25)+(u[25]*wk[25][0]));
/*
Compute Atk (inertial linear acceleration)
*/
        Atk[5][0] = ((u[4]*Wkrpk[5][2])-(u[5]*Wkrpk[5][1]));
        Atk[5][1] = ((u[5]*Wkrpk[5][0])-(u[3]*Wkrpk[5][2]));
        Atk[5][2] = ((u[3]*Wkrpk[5][1])-(u[4]*Wkrpk[5][0]));
        AiOiWi[6][0] = (Atk[5][0]+((u[4]*Wirk[6][2])-(u[5]*Wirk[6][1])));
        AiOiWi[6][1] = (Atk[5][1]+((u[5]*Wirk[6][0])-(u[3]*Wirk[6][2])));
        AiOiWi[6][2] = (Atk[5][2]+((u[3]*Wirk[6][1])-(u[4]*Wirk[6][0])));
        Atk[6][0] = (((AiOiWi[6][0]*c6)+(AiOiWi[6][2]*s6))+((Otk[6][2]*rk[1][1])
          +((wk[6][1]*Wkrpk[6][2])-(wk[6][2]*Wkrpk[6][1]))));
        Atk[6][1] = (AiOiWi[6][1]+(((Otk[6][0]*rk[1][2])-(Otk[6][2]*rk[1][0]))+(
          (wk[6][2]*Wkrpk[6][0])-(wk[6][0]*Wkrpk[6][2]))));
        Atk[6][2] = (((AiOiWi[6][2]*c6)-(AiOiWi[6][0]*s6))+(((wk[6][0]*
          Wkrpk[6][1])-(wk[6][1]*Wkrpk[6][0]))-(Otk[6][0]*rk[1][1])));
        AiOiWi[7][0] = (Atk[5][0]+((u[4]*Wirk[7][2])-(u[5]*Wirk[7][1])));
        AiOiWi[7][1] = (Atk[5][1]+((u[5]*Wirk[7][0])-(u[3]*Wirk[7][2])));
        AiOiWi[7][2] = (Atk[5][2]+((u[3]*Wirk[7][1])-(u[4]*Wirk[7][0])));
        Atk[7][0] = (((AiOiWi[7][0]*c7)+(AiOiWi[7][2]*s7))+((Otk[7][2]*rk[2][1])
          +((wk[7][1]*Wkrpk[7][2])-(wk[7][2]*Wkrpk[7][1]))));
        Atk[7][1] = (AiOiWi[7][1]+(((Otk[7][0]*rk[2][2])-(Otk[7][2]*rk[2][0]))+(
          (wk[7][2]*Wkrpk[7][0])-(wk[7][0]*Wkrpk[7][2]))));
        Atk[7][2] = (((AiOiWi[7][2]*c7)-(AiOiWi[7][0]*s7))+(((wk[7][0]*
          Wkrpk[7][1])-(wk[7][1]*Wkrpk[7][0]))-(Otk[7][0]*rk[2][1])));
        AiOiWi[8][0] = (Atk[6][0]+(((Wirk[8][2]*wk[6][1])-(Wirk[8][1]*wk[6][2]))
          -(Otk[6][2]*ri[3][1])));
        AiOiWi[8][1] = (Atk[6][1]+(((Otk[6][2]*ri[3][0])-(Otk[6][0]*ri[3][2]))+(
          (Wirk[8][0]*wk[6][2])-(Wirk[8][2]*wk[6][0]))));
        AiOiWi[8][2] = (Atk[6][2]+((Otk[6][0]*ri[3][1])+((Wirk[8][1]*wk[6][0])-(
          Wirk[8][0]*wk[6][1]))));
        Atk[8][0] = (AiOiWi[8][0]+(((Otk[8][2]*rk[3][1])-(Otk[8][1]*rk[3][2]))+(
          (wk[8][1]*Wkrpk[8][2])-(wk[8][2]*Wkrpk[8][1]))));
        Atk[8][1] = (((AiOiWi[8][1]*c8)-(AiOiWi[8][2]*s8))+(((Otk[6][0]*rk[3][2]
          )-(Otk[8][2]*rk[3][0]))+((wk[8][2]*Wkrpk[8][0])-(wk[8][0]*Wkrpk[8][2])
          )));
        Atk[8][2] = (((AiOiWi[8][1]*s8)+(AiOiWi[8][2]*c8))+(((Otk[8][1]*rk[3][0]
          )-(Otk[6][0]*rk[3][1]))+((wk[8][0]*Wkrpk[8][1])-(wk[8][1]*Wkrpk[8][0])
          )));
        AiOiWi[9][0] = (Atk[7][0]+(((Wirk[9][2]*wk[7][1])-(Wirk[9][1]*wk[7][2]))
          -(Otk[7][2]*ri[4][1])));
        AiOiWi[9][1] = (Atk[7][1]+(((Otk[7][2]*ri[4][0])-(Otk[7][0]*ri[4][2]))+(
          (Wirk[9][0]*wk[7][2])-(Wirk[9][2]*wk[7][0]))));
        AiOiWi[9][2] = (Atk[7][2]+((Otk[7][0]*ri[4][1])+((Wirk[9][1]*wk[7][0])-(
          Wirk[9][0]*wk[7][1]))));
        Atk[9][0] = (AiOiWi[9][0]+(((Otk[9][2]*rk[4][1])-(Otk[9][1]*rk[4][2]))+(
          (wk[9][1]*Wkrpk[9][2])-(wk[9][2]*Wkrpk[9][1]))));
        Atk[9][1] = (((AiOiWi[9][1]*c9)+(AiOiWi[9][2]*s9))+(((Otk[7][0]*rk[4][2]
          )-(Otk[9][2]*rk[4][0]))+((wk[9][2]*Wkrpk[9][0])-(wk[9][0]*Wkrpk[9][2])
          )));
        Atk[9][2] = (((AiOiWi[9][2]*c9)-(AiOiWi[9][1]*s9))+(((Otk[9][1]*rk[4][0]
          )-(Otk[7][0]*rk[4][1]))+((wk[9][0]*Wkrpk[9][1])-(wk[9][1]*Wkrpk[9][0])
          )));
        AiOiWi[10][0] = (Atk[8][0]+(((Otk[8][1]*ri[5][2])-(Otk[8][2]*ri[5][1]))+
          ((Wirk[10][2]*wk[8][1])-(Wirk[10][1]*wk[8][2]))));
        AiOiWi[10][1] = (Atk[8][1]+(((Otk[8][2]*ri[5][0])-(Otk[6][0]*ri[5][2]))+
          ((Wirk[10][0]*wk[8][2])-(Wirk[10][2]*wk[8][0]))));
        AiOiWi[10][2] = (Atk[8][2]+(((Otk[6][0]*ri[5][1])-(Otk[8][1]*ri[5][0]))+
          ((Wirk[10][1]*wk[8][0])-(Wirk[10][0]*wk[8][1]))));
        Atk[10][0] = (((AiOiWi[10][0]*c10)-(AiOiWi[10][1]*s10))+(((Otk[8][2]*
          rk[5][1])-(Otk[10][1]*rk[5][2]))+((wk[10][1]*Wkrpk[10][2])-(wk[10][2]*
          Wkrpk[10][1]))));
        Atk[10][1] = (((AiOiWi[10][0]*s10)+(AiOiWi[10][1]*c10))+(((Otk[10][0]*
          rk[5][2])-(Otk[8][2]*rk[5][0]))+((wk[10][2]*Wkrpk[10][0])-(wk[10][0]*
          Wkrpk[10][2]))));
        Atk[10][2] = (AiOiWi[10][2]+(((Otk[10][1]*rk[5][0])-(Otk[10][0]*rk[5][1]
          ))+((wk[10][0]*Wkrpk[10][1])-(wk[10][1]*Wkrpk[10][0]))));
        AiOiWi[11][0] = (Atk[9][0]+(((Otk[9][1]*ri[6][2])-(Otk[9][2]*ri[6][1]))+
          ((Wirk[11][2]*wk[9][1])-(Wirk[11][1]*wk[9][2]))));
        AiOiWi[11][1] = (Atk[9][1]+(((Otk[9][2]*ri[6][0])-(Otk[7][0]*ri[6][2]))+
          ((Wirk[11][0]*wk[9][2])-(Wirk[11][2]*wk[9][0]))));
        AiOiWi[11][2] = (Atk[9][2]+(((Otk[7][0]*ri[6][1])-(Otk[9][1]*ri[6][0]))+
          ((Wirk[11][1]*wk[9][0])-(Wirk[11][0]*wk[9][1]))));
        Atk[11][0] = (((AiOiWi[11][0]*c11)+(AiOiWi[11][1]*s11))+(((Otk[9][2]*
          rk[6][1])-(Otk[11][1]*rk[6][2]))+((wk[11][1]*Wkrpk[11][2])-(wk[11][2]*
          Wkrpk[11][1]))));
        Atk[11][1] = (((AiOiWi[11][1]*c11)-(AiOiWi[11][0]*s11))+(((Otk[11][0]*
          rk[6][2])-(Otk[9][2]*rk[6][0]))+((wk[11][2]*Wkrpk[11][0])-(wk[11][0]*
          Wkrpk[11][2]))));
        Atk[11][2] = (AiOiWi[11][2]+(((Otk[11][1]*rk[6][0])-(Otk[11][0]*rk[6][1]
          ))+((wk[11][0]*Wkrpk[11][1])-(wk[11][1]*Wkrpk[11][0]))));
        AiOiWi[12][0] = (Atk[5][0]+((u[4]*Wirk[12][2])-(u[5]*Wirk[12][1])));
        AiOiWi[12][1] = (Atk[5][1]+((u[5]*Wirk[12][0])-(u[3]*Wirk[12][2])));
        AiOiWi[12][2] = (Atk[5][2]+((u[3]*Wirk[12][1])-(u[4]*Wirk[12][0])));
        Atk[12][0] = (((AiOiWi[12][0]*c12)-(AiOiWi[12][1]*s12))+(((wk[12][1]*
          Wkrpk[12][2])-(wk[12][2]*Wkrpk[12][1]))-(Otk[12][1]*rk[7][2])));
        Atk[12][1] = (((AiOiWi[12][0]*s12)+(AiOiWi[12][1]*c12))+((Otk[12][0]*
          rk[7][2])+((wk[12][2]*Wkrpk[12][0])-(wk[12][0]*Wkrpk[12][2]))));
        Atk[12][2] = (AiOiWi[12][2]+(((Otk[12][1]*rk[7][0])-(Otk[12][0]*rk[7][1]
          ))+((wk[12][0]*Wkrpk[12][1])-(wk[12][1]*Wkrpk[12][0]))));
        AiOiWi[13][0] = (Atk[5][0]+((u[4]*Wirk[13][2])-(u[5]*Wirk[13][1])));
        AiOiWi[13][1] = (Atk[5][1]+((u[5]*Wirk[13][0])-(u[3]*Wirk[13][2])));
        AiOiWi[13][2] = (Atk[5][2]+((u[3]*Wirk[13][1])-(u[4]*Wirk[13][0])));
        Atk[13][0] = (((AiOiWi[13][0]*c13)+(AiOiWi[13][1]*s13))+(((wk[13][1]*
          Wkrpk[13][2])-(wk[13][2]*Wkrpk[13][1]))-(Otk[13][1]*rk[8][2])));
        Atk[13][1] = (((AiOiWi[13][1]*c13)-(AiOiWi[13][0]*s13))+((Otk[13][0]*
          rk[8][2])+((wk[13][2]*Wkrpk[13][0])-(wk[13][0]*Wkrpk[13][2]))));
        Atk[13][2] = (AiOiWi[13][2]+(((Otk[13][1]*rk[8][0])-(Otk[13][0]*rk[8][1]
          ))+((wk[13][0]*Wkrpk[13][1])-(wk[13][1]*Wkrpk[13][0]))));
        AiOiWi[14][0] = (Atk[12][0]+((Otk[12][1]*ri[9][2])+((Wirk[14][2]*
          wk[12][1])-(Wirk[14][1]*wk[12][2]))));
        AiOiWi[14][1] = (Atk[12][1]+(((Wirk[14][0]*wk[12][2])-(Wirk[14][2]*
          wk[12][0]))-(Otk[12][0]*ri[9][2])));
        AiOiWi[14][2] = (Atk[12][2]+(((Otk[12][0]*ri[9][1])-(Otk[12][1]*ri[9][0]
          ))+((Wirk[14][1]*wk[12][0])-(Wirk[14][0]*wk[12][1]))));
        Atk[14][0] = (AiOiWi[14][0]+(((Otk[14][2]*rk[9][1])-(Otk[14][1]*rk[9][2]
          ))+((wk[14][1]*Wkrpk[14][2])-(wk[14][2]*Wkrpk[14][1]))));
        Atk[14][1] = (((AiOiWi[14][1]*c14)-(AiOiWi[14][2]*s14))+(((Otk[12][0]*
          rk[9][2])-(Otk[14][2]*rk[9][0]))+((wk[14][2]*Wkrpk[14][0])-(wk[14][0]*
          Wkrpk[14][2]))));
        Atk[14][2] = (((AiOiWi[14][1]*s14)+(AiOiWi[14][2]*c14))+(((Otk[14][1]*
          rk[9][0])-(Otk[12][0]*rk[9][1]))+((wk[14][0]*Wkrpk[14][1])-(wk[14][1]*
          Wkrpk[14][0]))));
        AiOiWi[15][0] = (Atk[13][0]+((Otk[13][1]*ri[10][2])+((Wirk[15][2]*
          wk[13][1])-(Wirk[15][1]*wk[13][2]))));
        AiOiWi[15][1] = (Atk[13][1]+(((Wirk[15][0]*wk[13][2])-(Wirk[15][2]*
          wk[13][0]))-(Otk[13][0]*ri[10][2])));
        AiOiWi[15][2] = (Atk[13][2]+(((Otk[13][0]*ri[10][1])-(Otk[13][1]*
          ri[10][0]))+((Wirk[15][1]*wk[13][0])-(Wirk[15][0]*wk[13][1]))));
        Atk[15][0] = (AiOiWi[15][0]+(((Otk[15][2]*rk[10][1])-(Otk[15][1]*
          rk[10][2]))+((wk[15][1]*Wkrpk[15][2])-(wk[15][2]*Wkrpk[15][1]))));
        Atk[15][1] = (((AiOiWi[15][1]*c15)+(AiOiWi[15][2]*s15))+(((Otk[13][0]*
          rk[10][2])-(Otk[15][2]*rk[10][0]))+((wk[15][2]*Wkrpk[15][0])-(
          wk[15][0]*Wkrpk[15][2]))));
        Atk[15][2] = (((AiOiWi[15][2]*c15)-(AiOiWi[15][1]*s15))+(((Otk[15][1]*
          rk[10][0])-(Otk[13][0]*rk[10][1]))+((wk[15][0]*Wkrpk[15][1])-(
          wk[15][1]*Wkrpk[15][0]))));
        AiOiWi[16][0] = (Atk[14][0]+(((Otk[14][1]*ri[11][2])-(Otk[14][2]*
          ri[11][1]))+((Wirk[16][2]*wk[14][1])-(Wirk[16][1]*wk[14][2]))));
        AiOiWi[16][1] = (Atk[14][1]+(((Otk[14][2]*ri[11][0])-(Otk[12][0]*
          ri[11][2]))+((Wirk[16][0]*wk[14][2])-(Wirk[16][2]*wk[14][0]))));
        AiOiWi[16][2] = (Atk[14][2]+(((Otk[12][0]*ri[11][1])-(Otk[14][1]*
          ri[11][0]))+((Wirk[16][1]*wk[14][0])-(Wirk[16][0]*wk[14][1]))));
        Atk[16][0] = (((AiOiWi[16][0]*c16)+(AiOiWi[16][2]*s16))+(((Otk[16][2]*
          rk[11][1])-(Otk[14][1]*rk[11][2]))+((wk[16][1]*Wkrpk[16][2])-(
          wk[16][2]*Wkrpk[16][1]))));
        Atk[16][1] = (AiOiWi[16][1]+(((Otk[16][0]*rk[11][2])-(Otk[16][2]*
          rk[11][0]))+((wk[16][2]*Wkrpk[16][0])-(wk[16][0]*Wkrpk[16][2]))));
        Atk[16][2] = (((AiOiWi[16][2]*c16)-(AiOiWi[16][0]*s16))+(((Otk[14][1]*
          rk[11][0])-(Otk[16][0]*rk[11][1]))+((wk[16][0]*Wkrpk[16][1])-(
          wk[16][1]*Wkrpk[16][0]))));
        AiOiWi[17][0] = (Atk[15][0]+(((Otk[15][1]*ri[12][2])-(Otk[15][2]*
          ri[12][1]))+((Wirk[17][2]*wk[15][1])-(Wirk[17][1]*wk[15][2]))));
        AiOiWi[17][1] = (Atk[15][1]+(((Otk[15][2]*ri[12][0])-(Otk[13][0]*
          ri[12][2]))+((Wirk[17][0]*wk[15][2])-(Wirk[17][2]*wk[15][0]))));
        AiOiWi[17][2] = (Atk[15][2]+(((Otk[13][0]*ri[12][1])-(Otk[15][1]*
          ri[12][0]))+((Wirk[17][1]*wk[15][0])-(Wirk[17][0]*wk[15][1]))));
        Atk[17][0] = (((AiOiWi[17][0]*c17)+(AiOiWi[17][2]*s17))+(((Otk[17][2]*
          rk[12][1])-(Otk[15][1]*rk[12][2]))+((wk[17][1]*Wkrpk[17][2])-(
          wk[17][2]*Wkrpk[17][1]))));
        Atk[17][1] = (AiOiWi[17][1]+(((Otk[17][0]*rk[12][2])-(Otk[17][2]*
          rk[12][0]))+((wk[17][2]*Wkrpk[17][0])-(wk[17][0]*Wkrpk[17][2]))));
        Atk[17][2] = (((AiOiWi[17][2]*c17)-(AiOiWi[17][0]*s17))+(((Otk[15][1]*
          rk[12][0])-(Otk[17][0]*rk[12][1]))+((wk[17][0]*Wkrpk[17][1])-(
          wk[17][1]*Wkrpk[17][0]))));
        AiOiWi[18][0] = (Atk[16][0]+(((Otk[14][1]*ri[13][2])-(Otk[16][2]*
          ri[13][1]))+((Wirk[18][2]*wk[16][1])-(Wirk[18][1]*wk[16][2]))));
        AiOiWi[18][1] = (Atk[16][1]+(((Otk[16][2]*ri[13][0])-(Otk[16][0]*
          ri[13][2]))+((Wirk[18][0]*wk[16][2])-(Wirk[18][2]*wk[16][0]))));
        AiOiWi[18][2] = (Atk[16][2]+(((Otk[16][0]*ri[13][1])-(Otk[14][1]*
          ri[13][0]))+((Wirk[18][1]*wk[16][0])-(Wirk[18][0]*wk[16][1]))));
        Atk[18][0] = (((AiOiWi[18][0]*c18)+(AiOiWi[18][2]*s18))+(((Otk[18][2]*
          rk[13][1])-(Otk[14][1]*rk[13][2]))+((wk[18][1]*Wkrpk[18][2])-(
          wk[18][2]*Wkrpk[18][1]))));
        Atk[18][1] = (AiOiWi[18][1]+(((Otk[18][0]*rk[13][2])-(Otk[18][2]*
          rk[13][0]))+((wk[18][2]*Wkrpk[18][0])-(wk[18][0]*Wkrpk[18][2]))));
        Atk[18][2] = (((AiOiWi[18][2]*c18)-(AiOiWi[18][0]*s18))+(((Otk[14][1]*
          rk[13][0])-(Otk[18][0]*rk[13][1]))+((wk[18][0]*Wkrpk[18][1])-(
          wk[18][1]*Wkrpk[18][0]))));
        AiOiWi[19][0] = (Atk[17][0]+(((Otk[15][1]*ri[14][2])-(Otk[17][2]*
          ri[14][1]))+((Wirk[19][2]*wk[17][1])-(Wirk[19][1]*wk[17][2]))));
        AiOiWi[19][1] = (Atk[17][1]+(((Otk[17][2]*ri[14][0])-(Otk[17][0]*
          ri[14][2]))+((Wirk[19][0]*wk[17][2])-(Wirk[19][2]*wk[17][0]))));
        AiOiWi[19][2] = (Atk[17][2]+(((Otk[17][0]*ri[14][1])-(Otk[15][1]*
          ri[14][0]))+((Wirk[19][1]*wk[17][0])-(Wirk[19][0]*wk[17][1]))));
        Atk[19][0] = (((AiOiWi[19][0]*c19)+(AiOiWi[19][2]*s19))+(((Otk[19][2]*
          rk[14][1])-(Otk[15][1]*rk[14][2]))+((wk[19][1]*Wkrpk[19][2])-(
          wk[19][2]*Wkrpk[19][1]))));
        Atk[19][1] = (AiOiWi[19][1]+(((Otk[19][0]*rk[14][2])-(Otk[19][2]*
          rk[14][0]))+((wk[19][2]*Wkrpk[19][0])-(wk[19][0]*Wkrpk[19][2]))));
        Atk[19][2] = (((AiOiWi[19][2]*c19)-(AiOiWi[19][0]*s19))+(((Otk[15][1]*
          rk[14][0])-(Otk[19][0]*rk[14][1]))+((wk[19][0]*Wkrpk[19][1])-(
          wk[19][1]*Wkrpk[19][0]))));
        AiOiWi[20][0] = (Atk[18][0]+(((Otk[14][1]*ri[15][2])-(Otk[18][2]*
          ri[15][1]))+((Wirk[20][2]*wk[18][1])-(Wirk[20][1]*wk[18][2]))));
        AiOiWi[20][1] = (Atk[18][1]+(((Otk[18][2]*ri[15][0])-(Otk[18][0]*
          ri[15][2]))+((Wirk[20][0]*wk[18][2])-(Wirk[20][2]*wk[18][0]))));
        AiOiWi[20][2] = (Atk[18][2]+(((Otk[18][0]*ri[15][1])-(Otk[14][1]*
          ri[15][0]))+((Wirk[20][1]*wk[18][0])-(Wirk[20][0]*wk[18][1]))));
        Atk[20][0] = (((AiOiWi[20][0]*c20)+(AiOiWi[20][2]*s20))+(((Otk[20][2]*
          rk[15][1])-(Otk[14][1]*rk[15][2]))+((wk[20][1]*Wkrpk[20][2])-(
          wk[20][2]*Wkrpk[20][1]))));
        Atk[20][1] = (AiOiWi[20][1]+(((Otk[20][0]*rk[15][2])-(Otk[20][2]*
          rk[15][0]))+((wk[20][2]*Wkrpk[20][0])-(wk[20][0]*Wkrpk[20][2]))));
        Atk[20][2] = (((AiOiWi[20][2]*c20)-(AiOiWi[20][0]*s20))+(((Otk[14][1]*
          rk[15][0])-(Otk[20][0]*rk[15][1]))+((wk[20][0]*Wkrpk[20][1])-(
          wk[20][1]*Wkrpk[20][0]))));
        AiOiWi[21][0] = (Atk[19][0]+(((Otk[15][1]*ri[16][2])-(Otk[19][2]*
          ri[16][1]))+((Wirk[21][2]*wk[19][1])-(Wirk[21][1]*wk[19][2]))));
        AiOiWi[21][1] = (Atk[19][1]+(((Otk[19][2]*ri[16][0])-(Otk[19][0]*
          ri[16][2]))+((Wirk[21][0]*wk[19][2])-(Wirk[21][2]*wk[19][0]))));
        AiOiWi[21][2] = (Atk[19][2]+(((Otk[19][0]*ri[16][1])-(Otk[15][1]*
          ri[16][0]))+((Wirk[21][1]*wk[19][0])-(Wirk[21][0]*wk[19][1]))));
        Atk[21][0] = (((AiOiWi[21][0]*c21)+(AiOiWi[21][2]*s21))+(((Otk[21][2]*
          rk[16][1])-(Otk[15][1]*rk[16][2]))+((wk[21][1]*Wkrpk[21][2])-(
          wk[21][2]*Wkrpk[21][1]))));
        Atk[21][1] = (AiOiWi[21][1]+(((Otk[21][0]*rk[16][2])-(Otk[21][2]*
          rk[16][0]))+((wk[21][2]*Wkrpk[21][0])-(wk[21][0]*Wkrpk[21][2]))));
        Atk[21][2] = (((AiOiWi[21][2]*c21)-(AiOiWi[21][0]*s21))+(((Otk[15][1]*
          rk[16][0])-(Otk[21][0]*rk[16][1]))+((wk[21][0]*Wkrpk[21][1])-(
          wk[21][1]*Wkrpk[21][0]))));
        AiOiWi[22][0] = (Atk[20][0]+(((Otk[14][1]*ri[17][2])-(Otk[20][2]*
          ri[17][1]))+((Wirk[22][2]*wk[20][1])-(Wirk[22][1]*wk[20][2]))));
        AiOiWi[22][1] = (Atk[20][1]+(((Otk[20][2]*ri[17][0])-(Otk[20][0]*
          ri[17][2]))+((Wirk[22][0]*wk[20][2])-(Wirk[22][2]*wk[20][0]))));
        AiOiWi[22][2] = (Atk[20][2]+(((Otk[20][0]*ri[17][1])-(Otk[14][1]*
          ri[17][0]))+((Wirk[22][1]*wk[20][0])-(Wirk[22][0]*wk[20][1]))));
        Atk[22][0] = (AiOiWi[22][0]+(((Otk[22][2]*rk[17][1])-(Otk[22][1]*
          rk[17][2]))+((wk[22][1]*Wkrpk[22][2])-(wk[22][2]*Wkrpk[22][1]))));
        Atk[22][1] = (((AiOiWi[22][1]*c22)-(AiOiWi[22][2]*s22))+(((Otk[20][0]*
          rk[17][2])-(Otk[22][2]*rk[17][0]))+((wk[22][2]*Wkrpk[22][0])-(
          wk[22][0]*Wkrpk[22][2]))));
        Atk[22][2] = (((AiOiWi[22][1]*s22)+(AiOiWi[22][2]*c22))+(((Otk[22][1]*
          rk[17][0])-(Otk[20][0]*rk[17][1]))+((wk[22][0]*Wkrpk[22][1])-(
          wk[22][1]*Wkrpk[22][0]))));
        AiOiWi[23][0] = (Atk[21][0]+(((Otk[15][1]*ri[18][2])-(Otk[21][2]*
          ri[18][1]))+((Wirk[23][2]*wk[21][1])-(Wirk[23][1]*wk[21][2]))));
        AiOiWi[23][1] = (Atk[21][1]+(((Otk[21][2]*ri[18][0])-(Otk[21][0]*
          ri[18][2]))+((Wirk[23][0]*wk[21][2])-(Wirk[23][2]*wk[21][0]))));
        AiOiWi[23][2] = (Atk[21][2]+(((Otk[21][0]*ri[18][1])-(Otk[15][1]*
          ri[18][0]))+((Wirk[23][1]*wk[21][0])-(Wirk[23][0]*wk[21][1]))));
        Atk[23][0] = (AiOiWi[23][0]+(((Otk[23][2]*rk[18][1])-(Otk[23][1]*
          rk[18][2]))+((wk[23][1]*Wkrpk[23][2])-(wk[23][2]*Wkrpk[23][1]))));
        Atk[23][1] = (((AiOiWi[23][1]*c23)+(AiOiWi[23][2]*s23))+(((Otk[21][0]*
          rk[18][2])-(Otk[23][2]*rk[18][0]))+((wk[23][2]*Wkrpk[23][0])-(
          wk[23][0]*Wkrpk[23][2]))));
        Atk[23][2] = (((AiOiWi[23][2]*c23)-(AiOiWi[23][1]*s23))+(((Otk[23][1]*
          rk[18][0])-(Otk[21][0]*rk[18][1]))+((wk[23][0]*Wkrpk[23][1])-(
          wk[23][1]*Wkrpk[23][0]))));
        AiOiWi[24][0] = (Atk[5][0]+((u[4]*Wirk[24][2])-(u[5]*Wirk[24][1])));
        AiOiWi[24][1] = (Atk[5][1]+((u[5]*Wirk[24][0])-(u[3]*Wirk[24][2])));
        AiOiWi[24][2] = (Atk[5][2]+((u[3]*Wirk[24][1])-(u[4]*Wirk[24][0])));
        Atk[24][0] = (((AiOiWi[24][0]*c24)+(AiOiWi[24][1]*s24))+(((wk[24][1]*
          Wkrpk[24][2])-(wk[24][2]*Wkrpk[24][1]))-(Otk[24][1]*rk[19][2])));
        Atk[24][1] = (((AiOiWi[24][1]*c24)-(AiOiWi[24][0]*s24))+((Otk[24][0]*
          rk[19][2])+((wk[24][2]*Wkrpk[24][0])-(wk[24][0]*Wkrpk[24][2]))));
        Atk[24][2] = (AiOiWi[24][2]+(((Otk[24][1]*rk[19][0])-(Otk[24][0]*
          rk[19][1]))+((wk[24][0]*Wkrpk[24][1])-(wk[24][1]*Wkrpk[24][0]))));
        AiOiWi[25][0] = (Atk[24][0]+((Otk[24][1]*ri[20][2])+((Wirk[25][2]*
          wk[24][1])-(Wirk[25][1]*wk[24][2]))));
        AiOiWi[25][1] = (Atk[24][1]+(((Wirk[25][0]*wk[24][2])-(Wirk[25][2]*
          wk[24][0]))-(Otk[24][0]*ri[20][2])));
        AiOiWi[25][2] = (Atk[24][2]+(((Otk[24][0]*ri[20][1])-(Otk[24][1]*
          ri[20][0]))+((Wirk[25][1]*wk[24][0])-(Wirk[25][0]*wk[24][1]))));
        Atk[25][0] = (((AiOiWi[25][0]*c25)+(AiOiWi[25][2]*s25))+(((Otk[25][2]*
          rk[20][1])-(Otk[24][1]*rk[20][2]))+((wk[25][1]*Wkrpk[25][2])-(
          wk[25][2]*Wkrpk[25][1]))));
        Atk[25][1] = (AiOiWi[25][1]+(((Otk[25][0]*rk[20][2])-(Otk[25][2]*
          rk[20][0]))+((wk[25][2]*Wkrpk[25][0])-(wk[25][0]*Wkrpk[25][2]))));
        Atk[25][2] = (((AiOiWi[25][2]*c25)-(AiOiWi[25][0]*s25))+(((Otk[24][1]*
          rk[20][0])-(Otk[25][0]*rk[20][1]))+((wk[25][0]*Wkrpk[25][1])-(
          wk[25][1]*Wkrpk[25][0]))));
        inerflg = 1;
    }
/*
 Used 0.00 seconds CPU time,
 0 additional bytes of memory.
 Equations contain  531 adds/subtracts/negates
                    606 multiplies
                      0 divides
                    163 assignments
*/
}

void sddofs0(void)
{

/*
Compute effect of all applied loads
*/
    if (fs0flg == 0) {
        sddoltau();
        sddoiner();
/*
Compute Fstar (forces)
*/
        Fstar[5][0] = ((mk[0]*(Atk[5][0]-gk[3][0]))-ufk[0][0]);
        Fstar[5][1] = ((mk[0]*(Atk[5][1]-gk[3][1]))-ufk[0][1]);
        Fstar[5][2] = ((mk[0]*(Atk[5][2]-gk[3][2]))-ufk[0][2]);
        Fstar[6][0] = ((mk[1]*(Atk[6][0]-gk[6][0]))-ufk[1][0]);
        Fstar[6][1] = ((mk[1]*(Atk[6][1]-gk[3][1]))-ufk[1][1]);
        Fstar[6][2] = ((mk[1]*(Atk[6][2]-gk[6][2]))-ufk[1][2]);
        Fstar[7][0] = ((mk[2]*(Atk[7][0]-gk[7][0]))-ufk[2][0]);
        Fstar[7][1] = ((mk[2]*(Atk[7][1]-gk[3][1]))-ufk[2][1]);
        Fstar[7][2] = ((mk[2]*(Atk[7][2]-gk[7][2]))-ufk[2][2]);
        Fstar[8][0] = ((mk[3]*(Atk[8][0]-gk[6][0]))-ufk[3][0]);
        Fstar[8][1] = ((mk[3]*(Atk[8][1]-gk[8][1]))-ufk[3][1]);
        Fstar[8][2] = ((mk[3]*(Atk[8][2]-gk[8][2]))-ufk[3][2]);
        Fstar[9][0] = ((mk[4]*(Atk[9][0]-gk[7][0]))-ufk[4][0]);
        Fstar[9][1] = ((mk[4]*(Atk[9][1]-gk[9][1]))-ufk[4][1]);
        Fstar[9][2] = ((mk[4]*(Atk[9][2]-gk[9][2]))-ufk[4][2]);
        Fstar[10][0] = ((mk[5]*(Atk[10][0]-gk[10][0]))-ufk[5][0]);
        Fstar[10][1] = ((mk[5]*(Atk[10][1]-gk[10][1]))-ufk[5][1]);
        Fstar[10][2] = ((mk[5]*(Atk[10][2]-gk[8][2]))-ufk[5][2]);
        Fstar[11][0] = ((mk[6]*(Atk[11][0]-gk[11][0]))-ufk[6][0]);
        Fstar[11][1] = ((mk[6]*(Atk[11][1]-gk[11][1]))-ufk[6][1]);
        Fstar[11][2] = ((mk[6]*(Atk[11][2]-gk[9][2]))-ufk[6][2]);
        Fstar[12][0] = ((mk[7]*(Atk[12][0]-gk[12][0]))-ufk[7][0]);
        Fstar[12][1] = ((mk[7]*(Atk[12][1]-gk[12][1]))-ufk[7][1]);
        Fstar[12][2] = ((mk[7]*(Atk[12][2]-gk[3][2]))-ufk[7][2]);
        Fstar[13][0] = ((mk[8]*(Atk[13][0]-gk[13][0]))-ufk[8][0]);
        Fstar[13][1] = ((mk[8]*(Atk[13][1]-gk[13][1]))-ufk[8][1]);
        Fstar[13][2] = ((mk[8]*(Atk[13][2]-gk[3][2]))-ufk[8][2]);
        Fstar[14][0] = ((mk[9]*(Atk[14][0]-gk[12][0]))-ufk[9][0]);
        Fstar[14][1] = ((mk[9]*(Atk[14][1]-gk[14][1]))-ufk[9][1]);
        Fstar[14][2] = ((mk[9]*(Atk[14][2]-gk[14][2]))-ufk[9][2]);
        Fstar[15][0] = ((mk[10]*(Atk[15][0]-gk[13][0]))-ufk[10][0]);
        Fstar[15][1] = ((mk[10]*(Atk[15][1]-gk[15][1]))-ufk[10][1]);
        Fstar[15][2] = ((mk[10]*(Atk[15][2]-gk[15][2]))-ufk[10][2]);
        Fstar[16][0] = ((mk[11]*(Atk[16][0]-gk[16][0]))-ufk[11][0]);
        Fstar[16][1] = ((mk[11]*(Atk[16][1]-gk[14][1]))-ufk[11][1]);
        Fstar[16][2] = ((mk[11]*(Atk[16][2]-gk[16][2]))-ufk[11][2]);
        Fstar[17][0] = ((mk[12]*(Atk[17][0]-gk[17][0]))-ufk[12][0]);
        Fstar[17][1] = ((mk[12]*(Atk[17][1]-gk[15][1]))-ufk[12][1]);
        Fstar[17][2] = ((mk[12]*(Atk[17][2]-gk[17][2]))-ufk[12][2]);
        Fstar[18][0] = ((mk[13]*(Atk[18][0]-gk[18][0]))-ufk[13][0]);
        Fstar[18][1] = ((mk[13]*(Atk[18][1]-gk[14][1]))-ufk[13][1]);
        Fstar[18][2] = ((mk[13]*(Atk[18][2]-gk[18][2]))-ufk[13][2]);
        Fstar[19][0] = ((mk[14]*(Atk[19][0]-gk[19][0]))-ufk[14][0]);
        Fstar[19][1] = ((mk[14]*(Atk[19][1]-gk[15][1]))-ufk[14][1]);
        Fstar[19][2] = ((mk[14]*(Atk[19][2]-gk[19][2]))-ufk[14][2]);
        Fstar[20][0] = ((mk[15]*(Atk[20][0]-gk[20][0]))-ufk[15][0]);
        Fstar[20][1] = ((mk[15]*(Atk[20][1]-gk[14][1]))-ufk[15][1]);
        Fstar[20][2] = ((mk[15]*(Atk[20][2]-gk[20][2]))-ufk[15][2]);
        Fstar[21][0] = ((mk[16]*(Atk[21][0]-gk[21][0]))-ufk[16][0]);
        Fstar[21][1] = ((mk[16]*(Atk[21][1]-gk[15][1]))-ufk[16][1]);
        Fstar[21][2] = ((mk[16]*(Atk[21][2]-gk[21][2]))-ufk[16][2]);
        Fstar[22][0] = ((mk[17]*(Atk[22][0]-gk[20][0]))-ufk[17][0]);
        Fstar[22][1] = ((mk[17]*(Atk[22][1]-gk[22][1]))-ufk[17][1]);
        Fstar[22][2] = ((mk[17]*(Atk[22][2]-gk[22][2]))-ufk[17][2]);
        Fstar[23][0] = ((mk[18]*(Atk[23][0]-gk[21][0]))-ufk[18][0]);
        Fstar[23][1] = ((mk[18]*(Atk[23][1]-gk[23][1]))-ufk[18][1]);
        Fstar[23][2] = ((mk[18]*(Atk[23][2]-gk[23][2]))-ufk[18][2]);
        Fstar[24][0] = ((mk[19]*(Atk[24][0]-gk[24][0]))-ufk[19][0]);
        Fstar[24][1] = ((mk[19]*(Atk[24][1]-gk[24][1]))-ufk[19][1]);
        Fstar[24][2] = ((mk[19]*(Atk[24][2]-gk[3][2]))-ufk[19][2]);
        Fstar[25][0] = ((mk[20]*(Atk[25][0]-gk[25][0]))-ufk[20][0]);
        Fstar[25][1] = ((mk[20]*(Atk[25][1]-gk[24][1]))-ufk[20][1]);
        Fstar[25][2] = ((mk[20]*(Atk[25][2]-gk[25][2]))-ufk[20][2]);
/*
Compute Tstar (torques)
*/
        Tstar[5][0] = (WkIkWk[5][0]-utk[0][0]);
        Tstar[5][1] = (WkIkWk[5][1]-utk[0][1]);
        Tstar[5][2] = (WkIkWk[5][2]-utk[0][2]);
        Tstar[6][0] = ((WkIkWk[6][0]+((ik[1][0][0]*Otk[6][0])+(ik[1][0][2]*
          Otk[6][2])))-utk[1][0]);
        Tstar[6][1] = ((WkIkWk[6][1]+((ik[1][1][0]*Otk[6][0])+(ik[1][1][2]*
          Otk[6][2])))-utk[1][1]);
        Tstar[6][2] = ((WkIkWk[6][2]+((ik[1][2][0]*Otk[6][0])+(ik[1][2][2]*
          Otk[6][2])))-utk[1][2]);
        Tstar[7][0] = ((WkIkWk[7][0]+((ik[2][0][0]*Otk[7][0])+(ik[2][0][2]*
          Otk[7][2])))-utk[2][0]);
        Tstar[7][1] = ((WkIkWk[7][1]+((ik[2][1][0]*Otk[7][0])+(ik[2][1][2]*
          Otk[7][2])))-utk[2][1]);
        Tstar[7][2] = ((WkIkWk[7][2]+((ik[2][2][0]*Otk[7][0])+(ik[2][2][2]*
          Otk[7][2])))-utk[2][2]);
        Tstar[8][0] = ((WkIkWk[8][0]+((ik[3][0][2]*Otk[8][2])+((ik[3][0][0]*
          Otk[6][0])+(ik[3][0][1]*Otk[8][1]))))-utk[3][0]);
        Tstar[8][1] = ((WkIkWk[8][1]+((ik[3][1][2]*Otk[8][2])+((ik[3][1][0]*
          Otk[6][0])+(ik[3][1][1]*Otk[8][1]))))-utk[3][1]);
        Tstar[8][2] = ((WkIkWk[8][2]+((ik[3][2][2]*Otk[8][2])+((ik[3][2][0]*
          Otk[6][0])+(ik[3][2][1]*Otk[8][1]))))-utk[3][2]);
        Tstar[9][0] = ((WkIkWk[9][0]+((ik[4][0][2]*Otk[9][2])+((ik[4][0][0]*
          Otk[7][0])+(ik[4][0][1]*Otk[9][1]))))-utk[4][0]);
        Tstar[9][1] = ((WkIkWk[9][1]+((ik[4][1][2]*Otk[9][2])+((ik[4][1][0]*
          Otk[7][0])+(ik[4][1][1]*Otk[9][1]))))-utk[4][1]);
        Tstar[9][2] = ((WkIkWk[9][2]+((ik[4][2][2]*Otk[9][2])+((ik[4][2][0]*
          Otk[7][0])+(ik[4][2][1]*Otk[9][1]))))-utk[4][2]);
        Tstar[10][0] = ((WkIkWk[10][0]+((ik[5][0][2]*Otk[8][2])+((ik[5][0][0]*
          Otk[10][0])+(ik[5][0][1]*Otk[10][1]))))-utk[5][0]);
        Tstar[10][1] = ((WkIkWk[10][1]+((ik[5][1][2]*Otk[8][2])+((ik[5][1][0]*
          Otk[10][0])+(ik[5][1][1]*Otk[10][1]))))-utk[5][1]);
        Tstar[10][2] = ((WkIkWk[10][2]+((ik[5][2][2]*Otk[8][2])+((ik[5][2][0]*
          Otk[10][0])+(ik[5][2][1]*Otk[10][1]))))-utk[5][2]);
        Tstar[11][0] = ((WkIkWk[11][0]+((ik[6][0][2]*Otk[9][2])+((ik[6][0][0]*
          Otk[11][0])+(ik[6][0][1]*Otk[11][1]))))-utk[6][0]);
        Tstar[11][1] = ((WkIkWk[11][1]+((ik[6][1][2]*Otk[9][2])+((ik[6][1][0]*
          Otk[11][0])+(ik[6][1][1]*Otk[11][1]))))-utk[6][1]);
        Tstar[11][2] = ((WkIkWk[11][2]+((ik[6][2][2]*Otk[9][2])+((ik[6][2][0]*
          Otk[11][0])+(ik[6][2][1]*Otk[11][1]))))-utk[6][2]);
        Tstar[12][0] = ((WkIkWk[12][0]+((ik[7][0][0]*Otk[12][0])+(ik[7][0][1]*
          Otk[12][1])))-utk[7][0]);
        Tstar[12][1] = ((WkIkWk[12][1]+((ik[7][1][0]*Otk[12][0])+(ik[7][1][1]*
          Otk[12][1])))-utk[7][1]);
        Tstar[12][2] = ((WkIkWk[12][2]+((ik[7][2][0]*Otk[12][0])+(ik[7][2][1]*
          Otk[12][1])))-utk[7][2]);
        Tstar[13][0] = ((WkIkWk[13][0]+((ik[8][0][0]*Otk[13][0])+(ik[8][0][1]*
          Otk[13][1])))-utk[8][0]);
        Tstar[13][1] = ((WkIkWk[13][1]+((ik[8][1][0]*Otk[13][0])+(ik[8][1][1]*
          Otk[13][1])))-utk[8][1]);
        Tstar[13][2] = ((WkIkWk[13][2]+((ik[8][2][0]*Otk[13][0])+(ik[8][2][1]*
          Otk[13][1])))-utk[8][2]);
        Tstar[14][0] = ((WkIkWk[14][0]+((ik[9][0][2]*Otk[14][2])+((ik[9][0][0]*
          Otk[12][0])+(ik[9][0][1]*Otk[14][1]))))-utk[9][0]);
        Tstar[14][1] = ((WkIkWk[14][1]+((ik[9][1][2]*Otk[14][2])+((ik[9][1][0]*
          Otk[12][0])+(ik[9][1][1]*Otk[14][1]))))-utk[9][1]);
        Tstar[14][2] = ((WkIkWk[14][2]+((ik[9][2][2]*Otk[14][2])+((ik[9][2][0]*
          Otk[12][0])+(ik[9][2][1]*Otk[14][1]))))-utk[9][2]);
        Tstar[15][0] = ((WkIkWk[15][0]+((ik[10][0][2]*Otk[15][2])+((ik[10][0][0]
          *Otk[13][0])+(ik[10][0][1]*Otk[15][1]))))-utk[10][0]);
        Tstar[15][1] = ((WkIkWk[15][1]+((ik[10][1][2]*Otk[15][2])+((ik[10][1][0]
          *Otk[13][0])+(ik[10][1][1]*Otk[15][1]))))-utk[10][1]);
        Tstar[15][2] = ((WkIkWk[15][2]+((ik[10][2][2]*Otk[15][2])+((ik[10][2][0]
          *Otk[13][0])+(ik[10][2][1]*Otk[15][1]))))-utk[10][2]);
        Tstar[16][0] = ((WkIkWk[16][0]+((ik[11][0][2]*Otk[16][2])+((ik[11][0][0]
          *Otk[16][0])+(ik[11][0][1]*Otk[14][1]))))-utk[11][0]);
        Tstar[16][1] = ((WkIkWk[16][1]+((ik[11][1][2]*Otk[16][2])+((ik[11][1][0]
          *Otk[16][0])+(ik[11][1][1]*Otk[14][1]))))-utk[11][1]);
        Tstar[16][2] = ((WkIkWk[16][2]+((ik[11][2][2]*Otk[16][2])+((ik[11][2][0]
          *Otk[16][0])+(ik[11][2][1]*Otk[14][1]))))-utk[11][2]);
        Tstar[17][0] = ((WkIkWk[17][0]+((ik[12][0][2]*Otk[17][2])+((ik[12][0][0]
          *Otk[17][0])+(ik[12][0][1]*Otk[15][1]))))-utk[12][0]);
        Tstar[17][1] = ((WkIkWk[17][1]+((ik[12][1][2]*Otk[17][2])+((ik[12][1][0]
          *Otk[17][0])+(ik[12][1][1]*Otk[15][1]))))-utk[12][1]);
        Tstar[17][2] = ((WkIkWk[17][2]+((ik[12][2][2]*Otk[17][2])+((ik[12][2][0]
          *Otk[17][0])+(ik[12][2][1]*Otk[15][1]))))-utk[12][2]);
        Tstar[18][0] = ((WkIkWk[18][0]+((ik[13][0][2]*Otk[18][2])+((ik[13][0][0]
          *Otk[18][0])+(ik[13][0][1]*Otk[14][1]))))-utk[13][0]);
        Tstar[18][1] = ((WkIkWk[18][1]+((ik[13][1][2]*Otk[18][2])+((ik[13][1][0]
          *Otk[18][0])+(ik[13][1][1]*Otk[14][1]))))-utk[13][1]);
        Tstar[18][2] = ((WkIkWk[18][2]+((ik[13][2][2]*Otk[18][2])+((ik[13][2][0]
          *Otk[18][0])+(ik[13][2][1]*Otk[14][1]))))-utk[13][2]);
        Tstar[19][0] = ((WkIkWk[19][0]+((ik[14][0][2]*Otk[19][2])+((ik[14][0][0]
          *Otk[19][0])+(ik[14][0][1]*Otk[15][1]))))-utk[14][0]);
        Tstar[19][1] = ((WkIkWk[19][1]+((ik[14][1][2]*Otk[19][2])+((ik[14][1][0]
          *Otk[19][0])+(ik[14][1][1]*Otk[15][1]))))-utk[14][1]);
        Tstar[19][2] = ((WkIkWk[19][2]+((ik[14][2][2]*Otk[19][2])+((ik[14][2][0]
          *Otk[19][0])+(ik[14][2][1]*Otk[15][1]))))-utk[14][2]);
        Tstar[20][0] = ((WkIkWk[20][0]+((ik[15][0][2]*Otk[20][2])+((ik[15][0][0]
          *Otk[20][0])+(ik[15][0][1]*Otk[14][1]))))-utk[15][0]);
        Tstar[20][1] = ((WkIkWk[20][1]+((ik[15][1][2]*Otk[20][2])+((ik[15][1][0]
          *Otk[20][0])+(ik[15][1][1]*Otk[14][1]))))-utk[15][1]);
        Tstar[20][2] = ((WkIkWk[20][2]+((ik[15][2][2]*Otk[20][2])+((ik[15][2][0]
          *Otk[20][0])+(ik[15][2][1]*Otk[14][1]))))-utk[15][2]);
        Tstar[21][0] = ((WkIkWk[21][0]+((ik[16][0][2]*Otk[21][2])+((ik[16][0][0]
          *Otk[21][0])+(ik[16][0][1]*Otk[15][1]))))-utk[16][0]);
        Tstar[21][1] = ((WkIkWk[21][1]+((ik[16][1][2]*Otk[21][2])+((ik[16][1][0]
          *Otk[21][0])+(ik[16][1][1]*Otk[15][1]))))-utk[16][1]);
        Tstar[21][2] = ((WkIkWk[21][2]+((ik[16][2][2]*Otk[21][2])+((ik[16][2][0]
          *Otk[21][0])+(ik[16][2][1]*Otk[15][1]))))-utk[16][2]);
        Tstar[22][0] = ((WkIkWk[22][0]+((ik[17][0][2]*Otk[22][2])+((ik[17][0][0]
          *Otk[20][0])+(ik[17][0][1]*Otk[22][1]))))-utk[17][0]);
        Tstar[22][1] = ((WkIkWk[22][1]+((ik[17][1][2]*Otk[22][2])+((ik[17][1][0]
          *Otk[20][0])+(ik[17][1][1]*Otk[22][1]))))-utk[17][1]);
        Tstar[22][2] = ((WkIkWk[22][2]+((ik[17][2][2]*Otk[22][2])+((ik[17][2][0]
          *Otk[20][0])+(ik[17][2][1]*Otk[22][1]))))-utk[17][2]);
        Tstar[23][0] = ((WkIkWk[23][0]+((ik[18][0][2]*Otk[23][2])+((ik[18][0][0]
          *Otk[21][0])+(ik[18][0][1]*Otk[23][1]))))-utk[18][0]);
        Tstar[23][1] = ((WkIkWk[23][1]+((ik[18][1][2]*Otk[23][2])+((ik[18][1][0]
          *Otk[21][0])+(ik[18][1][1]*Otk[23][1]))))-utk[18][1]);
        Tstar[23][2] = ((WkIkWk[23][2]+((ik[18][2][2]*Otk[23][2])+((ik[18][2][0]
          *Otk[21][0])+(ik[18][2][1]*Otk[23][1]))))-utk[18][2]);
        Tstar[24][0] = ((WkIkWk[24][0]+((ik[19][0][0]*Otk[24][0])+(ik[19][0][1]*
          Otk[24][1])))-utk[19][0]);
        Tstar[24][1] = ((WkIkWk[24][1]+((ik[19][1][0]*Otk[24][0])+(ik[19][1][1]*
          Otk[24][1])))-utk[19][1]);
        Tstar[24][2] = ((WkIkWk[24][2]+((ik[19][2][0]*Otk[24][0])+(ik[19][2][1]*
          Otk[24][1])))-utk[19][2]);
        Tstar[25][0] = ((WkIkWk[25][0]+((ik[20][0][2]*Otk[25][2])+((ik[20][0][0]
          *Otk[25][0])+(ik[20][0][1]*Otk[24][1]))))-utk[20][0]);
        Tstar[25][1] = ((WkIkWk[25][1]+((ik[20][1][2]*Otk[25][2])+((ik[20][1][0]
          *Otk[25][0])+(ik[20][1][1]*Otk[24][1]))))-utk[20][1]);
        Tstar[25][2] = ((WkIkWk[25][2]+((ik[20][2][2]*Otk[25][2])+((ik[20][2][0]
          *Otk[25][0])+(ik[20][2][1]*Otk[24][1]))))-utk[20][2]);
/*
Compute fs0 (RHS ignoring constraints)
*/
        sddovpk();
        temp[0] = (((Fstar[8][2]*Vpk[0][8][2])+((Fstar[8][0]*Vpk[0][6][0])+(
          Fstar[8][1]*Vpk[0][8][1])))+(((Fstar[7][2]*Vpk[0][7][2])+((
          Cik[3][0][1]*Fstar[7][1])+(Fstar[7][0]*Vpk[0][7][0])))+(((Cik[3][0][2]
          *Fstar[5][2])+((Cik[3][0][0]*Fstar[5][0])+(Cik[3][0][1]*Fstar[5][1])))
          +((Fstar[6][2]*Vpk[0][6][2])+((Cik[3][0][1]*Fstar[6][1])+(Fstar[6][0]*
          Vpk[0][6][0]))))));
        temp[1] = (((Cik[3][0][2]*Fstar[12][2])+((Fstar[12][0]*Vpk[0][12][0])+(
          Fstar[12][1]*Vpk[0][12][1])))+(((Fstar[11][2]*Vpk[0][9][2])+((
          Fstar[11][0]*Vpk[0][11][0])+(Fstar[11][1]*Vpk[0][11][1])))+(((
          Fstar[10][2]*Vpk[0][8][2])+((Fstar[10][0]*Vpk[0][10][0])+(Fstar[10][1]
          *Vpk[0][10][1])))+(((Fstar[9][2]*Vpk[0][9][2])+((Fstar[9][0]*
          Vpk[0][7][0])+(Fstar[9][1]*Vpk[0][9][1])))+temp[0]))));
        temp[2] = (((Fstar[16][2]*Vpk[0][16][2])+((Fstar[16][0]*Vpk[0][16][0])+(
          Fstar[16][1]*Vpk[0][14][1])))+(((Fstar[15][2]*Vpk[0][15][2])+((
          Fstar[15][0]*Vpk[0][13][0])+(Fstar[15][1]*Vpk[0][15][1])))+(((
          Fstar[14][2]*Vpk[0][14][2])+((Fstar[14][0]*Vpk[0][12][0])+(
          Fstar[14][1]*Vpk[0][14][1])))+(((Cik[3][0][2]*Fstar[13][2])+((
          Fstar[13][0]*Vpk[0][13][0])+(Fstar[13][1]*Vpk[0][13][1])))+temp[1]))))
          ;
        temp[3] = (((Fstar[20][2]*Vpk[0][20][2])+((Fstar[20][0]*Vpk[0][20][0])+(
          Fstar[20][1]*Vpk[0][14][1])))+(((Fstar[19][2]*Vpk[0][19][2])+((
          Fstar[19][0]*Vpk[0][19][0])+(Fstar[19][1]*Vpk[0][15][1])))+(((
          Fstar[18][2]*Vpk[0][18][2])+((Fstar[18][0]*Vpk[0][18][0])+(
          Fstar[18][1]*Vpk[0][14][1])))+(((Fstar[17][2]*Vpk[0][17][2])+((
          Fstar[17][0]*Vpk[0][17][0])+(Fstar[17][1]*Vpk[0][15][1])))+temp[2]))))
          ;
        temp[4] = (((Cik[3][0][2]*Fstar[24][2])+((Fstar[24][0]*Vpk[0][24][0])+(
          Fstar[24][1]*Vpk[0][24][1])))+(((Fstar[23][2]*Vpk[0][23][2])+((
          Fstar[23][0]*Vpk[0][21][0])+(Fstar[23][1]*Vpk[0][23][1])))+(((
          Fstar[22][2]*Vpk[0][22][2])+((Fstar[22][0]*Vpk[0][20][0])+(
          Fstar[22][1]*Vpk[0][22][1])))+(((Fstar[21][2]*Vpk[0][21][2])+((
          Fstar[21][0]*Vpk[0][21][0])+(Fstar[21][1]*Vpk[0][15][1])))+temp[3]))))
          ;
        fs0[0] = (utau[0]-(((Fstar[25][2]*Vpk[0][25][2])+((Fstar[25][0]*
          Vpk[0][25][0])+(Fstar[25][1]*Vpk[0][24][1])))+temp[4]));
        temp[0] = (((Fstar[8][2]*Vpk[1][8][2])+((Fstar[8][0]*Vpk[1][6][0])+(
          Fstar[8][1]*Vpk[1][8][1])))+(((Fstar[7][2]*Vpk[1][7][2])+((
          Cik[3][1][1]*Fstar[7][1])+(Fstar[7][0]*Vpk[1][7][0])))+(((Cik[3][1][2]
          *Fstar[5][2])+((Cik[3][1][0]*Fstar[5][0])+(Cik[3][1][1]*Fstar[5][1])))
          +((Fstar[6][2]*Vpk[1][6][2])+((Cik[3][1][1]*Fstar[6][1])+(Fstar[6][0]*
          Vpk[1][6][0]))))));
        temp[1] = (((Cik[3][1][2]*Fstar[12][2])+((Fstar[12][0]*Vpk[1][12][0])+(
          Fstar[12][1]*Vpk[1][12][1])))+(((Fstar[11][2]*Vpk[1][9][2])+((
          Fstar[11][0]*Vpk[1][11][0])+(Fstar[11][1]*Vpk[1][11][1])))+(((
          Fstar[10][2]*Vpk[1][8][2])+((Fstar[10][0]*Vpk[1][10][0])+(Fstar[10][1]
          *Vpk[1][10][1])))+(((Fstar[9][2]*Vpk[1][9][2])+((Fstar[9][0]*
          Vpk[1][7][0])+(Fstar[9][1]*Vpk[1][9][1])))+temp[0]))));
        temp[2] = (((Fstar[16][2]*Vpk[1][16][2])+((Fstar[16][0]*Vpk[1][16][0])+(
          Fstar[16][1]*Vpk[1][14][1])))+(((Fstar[15][2]*Vpk[1][15][2])+((
          Fstar[15][0]*Vpk[1][13][0])+(Fstar[15][1]*Vpk[1][15][1])))+(((
          Fstar[14][2]*Vpk[1][14][2])+((Fstar[14][0]*Vpk[1][12][0])+(
          Fstar[14][1]*Vpk[1][14][1])))+(((Cik[3][1][2]*Fstar[13][2])+((
          Fstar[13][0]*Vpk[1][13][0])+(Fstar[13][1]*Vpk[1][13][1])))+temp[1]))))
          ;
        temp[3] = (((Fstar[20][2]*Vpk[1][20][2])+((Fstar[20][0]*Vpk[1][20][0])+(
          Fstar[20][1]*Vpk[1][14][1])))+(((Fstar[19][2]*Vpk[1][19][2])+((
          Fstar[19][0]*Vpk[1][19][0])+(Fstar[19][1]*Vpk[1][15][1])))+(((
          Fstar[18][2]*Vpk[1][18][2])+((Fstar[18][0]*Vpk[1][18][0])+(
          Fstar[18][1]*Vpk[1][14][1])))+(((Fstar[17][2]*Vpk[1][17][2])+((
          Fstar[17][0]*Vpk[1][17][0])+(Fstar[17][1]*Vpk[1][15][1])))+temp[2]))))
          ;
        temp[4] = (((Cik[3][1][2]*Fstar[24][2])+((Fstar[24][0]*Vpk[1][24][0])+(
          Fstar[24][1]*Vpk[1][24][1])))+(((Fstar[23][2]*Vpk[1][23][2])+((
          Fstar[23][0]*Vpk[1][21][0])+(Fstar[23][1]*Vpk[1][23][1])))+(((
          Fstar[22][2]*Vpk[1][22][2])+((Fstar[22][0]*Vpk[1][20][0])+(
          Fstar[22][1]*Vpk[1][22][1])))+(((Fstar[21][2]*Vpk[1][21][2])+((
          Fstar[21][0]*Vpk[1][21][0])+(Fstar[21][1]*Vpk[1][15][1])))+temp[3]))))
          ;
        fs0[1] = (utau[1]-(((Fstar[25][2]*Vpk[1][25][2])+((Fstar[25][0]*
          Vpk[1][25][0])+(Fstar[25][1]*Vpk[1][24][1])))+temp[4]));
        temp[0] = (((Fstar[8][2]*Vpk[2][8][2])+((Fstar[8][0]*Vpk[2][6][0])+(
          Fstar[8][1]*Vpk[2][8][1])))+(((Fstar[7][2]*Vpk[2][7][2])+((
          Cik[3][2][1]*Fstar[7][1])+(Fstar[7][0]*Vpk[2][7][0])))+(((Cik[3][2][2]
          *Fstar[5][2])+((Cik[3][2][0]*Fstar[5][0])+(Cik[3][2][1]*Fstar[5][1])))
          +((Fstar[6][2]*Vpk[2][6][2])+((Cik[3][2][1]*Fstar[6][1])+(Fstar[6][0]*
          Vpk[2][6][0]))))));
        temp[1] = (((Cik[3][2][2]*Fstar[12][2])+((Fstar[12][0]*Vpk[2][12][0])+(
          Fstar[12][1]*Vpk[2][12][1])))+(((Fstar[11][2]*Vpk[2][9][2])+((
          Fstar[11][0]*Vpk[2][11][0])+(Fstar[11][1]*Vpk[2][11][1])))+(((
          Fstar[10][2]*Vpk[2][8][2])+((Fstar[10][0]*Vpk[2][10][0])+(Fstar[10][1]
          *Vpk[2][10][1])))+(((Fstar[9][2]*Vpk[2][9][2])+((Fstar[9][0]*
          Vpk[2][7][0])+(Fstar[9][1]*Vpk[2][9][1])))+temp[0]))));
        temp[2] = (((Fstar[16][2]*Vpk[2][16][2])+((Fstar[16][0]*Vpk[2][16][0])+(
          Fstar[16][1]*Vpk[2][14][1])))+(((Fstar[15][2]*Vpk[2][15][2])+((
          Fstar[15][0]*Vpk[2][13][0])+(Fstar[15][1]*Vpk[2][15][1])))+(((
          Fstar[14][2]*Vpk[2][14][2])+((Fstar[14][0]*Vpk[2][12][0])+(
          Fstar[14][1]*Vpk[2][14][1])))+(((Cik[3][2][2]*Fstar[13][2])+((
          Fstar[13][0]*Vpk[2][13][0])+(Fstar[13][1]*Vpk[2][13][1])))+temp[1]))))
          ;
        temp[3] = (((Fstar[20][2]*Vpk[2][20][2])+((Fstar[20][0]*Vpk[2][20][0])+(
          Fstar[20][1]*Vpk[2][14][1])))+(((Fstar[19][2]*Vpk[2][19][2])+((
          Fstar[19][0]*Vpk[2][19][0])+(Fstar[19][1]*Vpk[2][15][1])))+(((
          Fstar[18][2]*Vpk[2][18][2])+((Fstar[18][0]*Vpk[2][18][0])+(
          Fstar[18][1]*Vpk[2][14][1])))+(((Fstar[17][2]*Vpk[2][17][2])+((
          Fstar[17][0]*Vpk[2][17][0])+(Fstar[17][1]*Vpk[2][15][1])))+temp[2]))))
          ;
        temp[4] = (((Cik[3][2][2]*Fstar[24][2])+((Fstar[24][0]*Vpk[2][24][0])+(
          Fstar[24][1]*Vpk[2][24][1])))+(((Fstar[23][2]*Vpk[2][23][2])+((
          Fstar[23][0]*Vpk[2][21][0])+(Fstar[23][1]*Vpk[2][23][1])))+(((
          Fstar[22][2]*Vpk[2][22][2])+((Fstar[22][0]*Vpk[2][20][0])+(
          Fstar[22][1]*Vpk[2][22][1])))+(((Fstar[21][2]*Vpk[2][21][2])+((
          Fstar[21][0]*Vpk[2][21][0])+(Fstar[21][1]*Vpk[2][15][1])))+temp[3]))))
          ;
        fs0[2] = (utau[2]-(((Fstar[25][2]*Vpk[2][25][2])+((Fstar[25][0]*
          Vpk[2][25][0])+(Fstar[25][1]*Vpk[2][24][1])))+temp[4]));
        temp[0] = (((Tstar[5][0]+((Fstar[5][1]*rk[0][2])-(Fstar[5][2]*rk[0][1]))
          )+(((Fstar[6][2]*Vpk[3][6][2])+((Fstar[6][0]*Vpk[3][6][0])+(
          Fstar[6][1]*Vpk[3][6][1])))+((Tstar[6][0]*c6)-(Tstar[6][2]*s6))))+(((
          Fstar[7][2]*Vpk[3][7][2])+((Fstar[7][0]*Vpk[3][7][0])+(Fstar[7][1]*
          Vpk[3][7][1])))+((Tstar[7][0]*c7)-(Tstar[7][2]*s7))));
        temp[1] = ((((Fstar[9][2]*Vpk[3][9][2])+((Fstar[9][0]*Vpk[3][9][0])+(
          Fstar[9][1]*Vpk[3][9][1])))+((Tstar[9][2]*Wpk[3][9][2])+((Tstar[9][0]*
          c7)+(Tstar[9][1]*Wpk[3][9][1]))))+((((Fstar[8][2]*Vpk[3][8][2])+((
          Fstar[8][0]*Vpk[3][8][0])+(Fstar[8][1]*Vpk[3][8][1])))+((Tstar[8][2]*
          Wpk[3][8][2])+((Tstar[8][0]*c6)+(Tstar[8][1]*Wpk[3][8][1]))))+temp[0])
          );
        temp[2] = ((((Fstar[11][2]*Vpk[3][11][2])+((Fstar[11][0]*Vpk[3][11][0])+
          (Fstar[11][1]*Vpk[3][11][1])))+((Tstar[11][2]*Wpk[3][9][2])+((
          Tstar[11][0]*Wpk[3][11][0])+(Tstar[11][1]*Wpk[3][11][1]))))+((((
          Fstar[10][2]*Vpk[3][10][2])+((Fstar[10][0]*Vpk[3][10][0])+(
          Fstar[10][1]*Vpk[3][10][1])))+((Tstar[10][2]*Wpk[3][8][2])+((
          Tstar[10][0]*Wpk[3][10][0])+(Tstar[10][1]*Wpk[3][10][1]))))+temp[1]));
        temp[3] = ((((Fstar[14][2]*Vpk[3][14][2])+((Fstar[14][0]*Vpk[3][14][0])+
          (Fstar[14][1]*Vpk[3][14][1])))+((Tstar[14][2]*Wpk[3][14][2])+((
          Tstar[14][0]*c12)+(Tstar[14][1]*Wpk[3][14][1]))))+((((Fstar[13][2]*
          Vpk[3][13][2])+((Fstar[13][0]*Vpk[3][13][0])+(Fstar[13][1]*
          Vpk[3][13][1])))+((Tstar[13][0]*c13)-(Tstar[13][1]*s13)))+((((
          Fstar[12][2]*Vpk[3][12][2])+((Fstar[12][0]*Vpk[3][12][0])+(
          Fstar[12][1]*Vpk[3][12][1])))+((Tstar[12][0]*c12)+(Tstar[12][1]*s12)))
          +temp[2])));
        temp[4] = ((((Fstar[16][2]*Vpk[3][16][2])+((Fstar[16][0]*Vpk[3][16][0])+
          (Fstar[16][1]*Vpk[3][16][1])))+((Tstar[16][2]*Wpk[3][16][2])+((
          Tstar[16][0]*Wpk[3][16][0])+(Tstar[16][1]*Wpk[3][14][1]))))+((((
          Fstar[15][2]*Vpk[3][15][2])+((Fstar[15][0]*Vpk[3][15][0])+(
          Fstar[15][1]*Vpk[3][15][1])))+((Tstar[15][2]*Wpk[3][15][2])+((
          Tstar[15][0]*c13)+(Tstar[15][1]*Wpk[3][15][1]))))+temp[3]));
        temp[5] = ((((Fstar[18][2]*Vpk[3][18][2])+((Fstar[18][0]*Vpk[3][18][0])+
          (Fstar[18][1]*Vpk[3][18][1])))+((Tstar[18][2]*Wpk[3][18][2])+((
          Tstar[18][0]*Wpk[3][18][0])+(Tstar[18][1]*Wpk[3][14][1]))))+((((
          Fstar[17][2]*Vpk[3][17][2])+((Fstar[17][0]*Vpk[3][17][0])+(
          Fstar[17][1]*Vpk[3][17][1])))+((Tstar[17][2]*Wpk[3][17][2])+((
          Tstar[17][0]*Wpk[3][17][0])+(Tstar[17][1]*Wpk[3][15][1]))))+temp[4]));
        temp[6] = ((((Fstar[20][2]*Vpk[3][20][2])+((Fstar[20][0]*Vpk[3][20][0])+
          (Fstar[20][1]*Vpk[3][20][1])))+((Tstar[20][2]*Wpk[3][20][2])+((
          Tstar[20][0]*Wpk[3][20][0])+(Tstar[20][1]*Wpk[3][14][1]))))+((((
          Fstar[19][2]*Vpk[3][19][2])+((Fstar[19][0]*Vpk[3][19][0])+(
          Fstar[19][1]*Vpk[3][19][1])))+((Tstar[19][2]*Wpk[3][19][2])+((
          Tstar[19][0]*Wpk[3][19][0])+(Tstar[19][1]*Wpk[3][15][1]))))+temp[5]));
        temp[7] = ((((Fstar[22][2]*Vpk[3][22][2])+((Fstar[22][0]*Vpk[3][22][0])+
          (Fstar[22][1]*Vpk[3][22][1])))+((Tstar[22][2]*Wpk[3][22][2])+((
          Tstar[22][0]*Wpk[3][20][0])+(Tstar[22][1]*Wpk[3][22][1]))))+((((
          Fstar[21][2]*Vpk[3][21][2])+((Fstar[21][0]*Vpk[3][21][0])+(
          Fstar[21][1]*Vpk[3][21][1])))+((Tstar[21][2]*Wpk[3][21][2])+((
          Tstar[21][0]*Wpk[3][21][0])+(Tstar[21][1]*Wpk[3][15][1]))))+temp[6]));
        temp[8] = ((((Fstar[24][2]*Vpk[3][24][2])+((Fstar[24][0]*Vpk[3][24][0])+
          (Fstar[24][1]*Vpk[3][24][1])))+((Tstar[24][0]*c24)-(Tstar[24][1]*s24))
          )+((((Fstar[23][2]*Vpk[3][23][2])+((Fstar[23][0]*Vpk[3][23][0])+(
          Fstar[23][1]*Vpk[3][23][1])))+((Tstar[23][2]*Wpk[3][23][2])+((
          Tstar[23][0]*Wpk[3][21][0])+(Tstar[23][1]*Wpk[3][23][1]))))+temp[7]));
        fs0[3] = (utau[3]-((((Fstar[25][2]*Vpk[3][25][2])+((Fstar[25][0]*
          Vpk[3][25][0])+(Fstar[25][1]*Vpk[3][25][1])))+((Tstar[25][2]*
          Wpk[3][25][2])+((Tstar[25][0]*Wpk[3][25][0])-(Tstar[25][1]*s24))))+
          temp[8]));
        temp[0] = (((Tstar[7][1]+((Fstar[7][0]*Vpk[4][7][0])+(Fstar[7][2]*
          Vpk[4][7][2])))+((Tstar[5][1]+((Fstar[5][2]*rk[0][0])-(Fstar[5][0]*
          rk[0][2])))+(Tstar[6][1]+((Fstar[6][0]*Vpk[4][6][0])+(Fstar[6][2]*
          Vpk[4][6][2])))))+(((Fstar[8][2]*Vpk[4][8][2])+((Fstar[8][0]*
          Vpk[4][8][0])+(Fstar[8][1]*Vpk[4][8][1])))+((Tstar[8][1]*c8)+(
          Tstar[8][2]*s8))));
        temp[1] = ((((Fstar[10][2]*Vpk[4][10][2])+((Fstar[10][0]*Vpk[4][10][0])+
          (Fstar[10][1]*Vpk[4][10][1])))+((Tstar[10][2]*s8)+((Tstar[10][0]*
          Wpk[4][10][0])+(Tstar[10][1]*Wpk[4][10][1]))))+((((Fstar[9][2]*
          Vpk[4][9][2])+((Fstar[9][0]*Vpk[4][9][0])+(Fstar[9][1]*Vpk[4][9][1])))
          +((Tstar[9][1]*c9)-(Tstar[9][2]*s9)))+temp[0]));
        temp[2] = ((((Fstar[13][2]*Vpk[4][13][2])+((Fstar[13][0]*Vpk[4][13][0])+
          (Fstar[13][1]*Vpk[4][13][1])))+((Tstar[13][0]*s13)+(Tstar[13][1]*c13))
          )+((((Fstar[12][2]*Vpk[4][12][2])+((Fstar[12][0]*Vpk[4][12][0])+(
          Fstar[12][1]*Vpk[4][12][1])))+((Tstar[12][1]*c12)-(Tstar[12][0]*s12)))
          +((((Fstar[11][2]*Vpk[4][11][2])+((Fstar[11][0]*Vpk[4][11][0])+(
          Fstar[11][1]*Vpk[4][11][1])))+(((Tstar[11][0]*Wpk[4][11][0])+(
          Tstar[11][1]*Wpk[4][11][1]))-(Tstar[11][2]*s9)))+temp[1])));
        temp[3] = ((((Fstar[15][2]*Vpk[4][15][2])+((Fstar[15][0]*Vpk[4][15][0])+
          (Fstar[15][1]*Vpk[4][15][1])))+((Tstar[15][2]*Wpk[4][15][2])+((
          Tstar[15][0]*s13)+(Tstar[15][1]*Wpk[4][15][1]))))+((((Fstar[14][2]*
          Vpk[4][14][2])+((Fstar[14][0]*Vpk[4][14][0])+(Fstar[14][1]*
          Vpk[4][14][1])))+((Tstar[14][2]*Wpk[4][14][2])+((Tstar[14][1]*
          Wpk[4][14][1])-(Tstar[14][0]*s12))))+temp[2]));
        temp[4] = ((((Fstar[17][2]*Vpk[4][17][2])+((Fstar[17][0]*Vpk[4][17][0])+
          (Fstar[17][1]*Vpk[4][17][1])))+((Tstar[17][2]*Wpk[4][17][2])+((
          Tstar[17][0]*Wpk[4][17][0])+(Tstar[17][1]*Wpk[4][15][1]))))+((((
          Fstar[16][2]*Vpk[4][16][2])+((Fstar[16][0]*Vpk[4][16][0])+(
          Fstar[16][1]*Vpk[4][16][1])))+((Tstar[16][2]*Wpk[4][16][2])+((
          Tstar[16][0]*Wpk[4][16][0])+(Tstar[16][1]*Wpk[4][14][1]))))+temp[3]));
        temp[5] = ((((Fstar[19][2]*Vpk[4][19][2])+((Fstar[19][0]*Vpk[4][19][0])+
          (Fstar[19][1]*Vpk[4][19][1])))+((Tstar[19][2]*Wpk[4][19][2])+((
          Tstar[19][0]*Wpk[4][19][0])+(Tstar[19][1]*Wpk[4][15][1]))))+((((
          Fstar[18][2]*Vpk[4][18][2])+((Fstar[18][0]*Vpk[4][18][0])+(
          Fstar[18][1]*Vpk[4][18][1])))+((Tstar[18][2]*Wpk[4][18][2])+((
          Tstar[18][0]*Wpk[4][18][0])+(Tstar[18][1]*Wpk[4][14][1]))))+temp[4]));
        temp[6] = ((((Fstar[21][2]*Vpk[4][21][2])+((Fstar[21][0]*Vpk[4][21][0])+
          (Fstar[21][1]*Vpk[4][21][1])))+((Tstar[21][2]*Wpk[4][21][2])+((
          Tstar[21][0]*Wpk[4][21][0])+(Tstar[21][1]*Wpk[4][15][1]))))+((((
          Fstar[20][2]*Vpk[4][20][2])+((Fstar[20][0]*Vpk[4][20][0])+(
          Fstar[20][1]*Vpk[4][20][1])))+((Tstar[20][2]*Wpk[4][20][2])+((
          Tstar[20][0]*Wpk[4][20][0])+(Tstar[20][1]*Wpk[4][14][1]))))+temp[5]));
        temp[7] = ((((Fstar[23][2]*Vpk[4][23][2])+((Fstar[23][0]*Vpk[4][23][0])+
          (Fstar[23][1]*Vpk[4][23][1])))+((Tstar[23][2]*Wpk[4][23][2])+((
          Tstar[23][0]*Wpk[4][21][0])+(Tstar[23][1]*Wpk[4][23][1]))))+((((
          Fstar[22][2]*Vpk[4][22][2])+((Fstar[22][0]*Vpk[4][22][0])+(
          Fstar[22][1]*Vpk[4][22][1])))+((Tstar[22][2]*Wpk[4][22][2])+((
          Tstar[22][0]*Wpk[4][20][0])+(Tstar[22][1]*Wpk[4][22][1]))))+temp[6]));
        fs0[4] = (utau[4]-((((Fstar[25][2]*Vpk[4][25][2])+((Fstar[25][0]*
          Vpk[4][25][0])+(Fstar[25][1]*Vpk[4][25][1])))+((Tstar[25][2]*
          Wpk[4][25][2])+((Tstar[25][0]*Wpk[4][25][0])+(Tstar[25][1]*c24))))+(((
          (Fstar[24][2]*Vpk[4][24][2])+((Fstar[24][0]*Vpk[4][24][0])+(
          Fstar[24][1]*Vpk[4][24][1])))+((Tstar[24][0]*s24)+(Tstar[24][1]*c24)))
          +temp[7])));
        temp[0] = (((Tstar[5][2]+((Fstar[5][0]*rk[0][1])-(Fstar[5][1]*rk[0][0]))
          )+(((Fstar[6][2]*Vpk[5][6][2])+((Fstar[6][0]*Vpk[5][6][0])+(
          Fstar[6][1]*Vpk[5][6][1])))+((Tstar[6][0]*s6)+(Tstar[6][2]*c6))))+(((
          Fstar[7][2]*Vpk[5][7][2])+((Fstar[7][0]*Vpk[5][7][0])+(Fstar[7][1]*
          Vpk[5][7][1])))+((Tstar[7][0]*s7)+(Tstar[7][2]*c7))));
        temp[1] = ((((Fstar[9][2]*Vpk[5][9][2])+((Fstar[9][0]*Vpk[5][9][0])+(
          Fstar[9][1]*Vpk[5][9][1])))+((Tstar[9][2]*Wpk[5][9][2])+((Tstar[9][0]*
          s7)+(Tstar[9][1]*Wpk[5][9][1]))))+((((Fstar[8][2]*Vpk[5][8][2])+((
          Fstar[8][0]*Vpk[5][8][0])+(Fstar[8][1]*Vpk[5][8][1])))+((Tstar[8][2]*
          Wpk[5][8][2])+((Tstar[8][0]*s6)+(Tstar[8][1]*Wpk[5][8][1]))))+temp[0])
          );
        temp[2] = ((((Fstar[11][2]*Vpk[5][11][2])+((Fstar[11][0]*Vpk[5][11][0])+
          (Fstar[11][1]*Vpk[5][11][1])))+((Tstar[11][2]*Wpk[5][9][2])+((
          Tstar[11][0]*Wpk[5][11][0])+(Tstar[11][1]*Wpk[5][11][1]))))+((((
          Fstar[10][2]*Vpk[5][10][2])+((Fstar[10][0]*Vpk[5][10][0])+(
          Fstar[10][1]*Vpk[5][10][1])))+((Tstar[10][2]*Wpk[5][8][2])+((
          Tstar[10][0]*Wpk[5][10][0])+(Tstar[10][1]*Wpk[5][10][1]))))+temp[1]));
        temp[3] = ((((Fstar[15][2]*Vpk[5][15][2])+((Fstar[15][0]*Vpk[5][15][0])+
          (Fstar[15][1]*Vpk[5][15][1])))+((Tstar[15][1]*s15)+(Tstar[15][2]*c15))
          )+(((Tstar[13][2]+((Fstar[13][0]*Vpk[5][13][0])+(Fstar[13][1]*
          Vpk[5][13][1])))+((Tstar[12][2]+((Fstar[12][0]*Vpk[5][12][0])+(
          Fstar[12][1]*Vpk[5][12][1])))+temp[2]))+(((Fstar[14][2]*Vpk[5][14][2])
          +((Fstar[14][0]*Vpk[5][14][0])+(Fstar[14][1]*Vpk[5][14][1])))+((
          Tstar[14][2]*c14)-(Tstar[14][1]*s14)))));
        temp[4] = ((((Fstar[17][2]*Vpk[5][17][2])+((Fstar[17][0]*Vpk[5][17][0])+
          (Fstar[17][1]*Vpk[5][17][1])))+((Tstar[17][2]*Wpk[5][17][2])+((
          Tstar[17][0]*Wpk[5][17][0])+(Tstar[17][1]*s15))))+((((Fstar[16][2]*
          Vpk[5][16][2])+((Fstar[16][0]*Vpk[5][16][0])+(Fstar[16][1]*
          Vpk[5][16][1])))+((Tstar[16][2]*Wpk[5][16][2])+((Tstar[16][0]*
          Wpk[5][16][0])-(Tstar[16][1]*s14))))+temp[3]));
        temp[5] = ((((Fstar[19][2]*Vpk[5][19][2])+((Fstar[19][0]*Vpk[5][19][0])+
          (Fstar[19][1]*Vpk[5][19][1])))+((Tstar[19][2]*Wpk[5][19][2])+((
          Tstar[19][0]*Wpk[5][19][0])+(Tstar[19][1]*s15))))+((((Fstar[18][2]*
          Vpk[5][18][2])+((Fstar[18][0]*Vpk[5][18][0])+(Fstar[18][1]*
          Vpk[5][18][1])))+((Tstar[18][2]*Wpk[5][18][2])+((Tstar[18][0]*
          Wpk[5][18][0])-(Tstar[18][1]*s14))))+temp[4]));
        temp[6] = ((((Fstar[21][2]*Vpk[5][21][2])+((Fstar[21][0]*Vpk[5][21][0])+
          (Fstar[21][1]*Vpk[5][21][1])))+((Tstar[21][2]*Wpk[5][21][2])+((
          Tstar[21][0]*Wpk[5][21][0])+(Tstar[21][1]*s15))))+((((Fstar[20][2]*
          Vpk[5][20][2])+((Fstar[20][0]*Vpk[5][20][0])+(Fstar[20][1]*
          Vpk[5][20][1])))+((Tstar[20][2]*Wpk[5][20][2])+((Tstar[20][0]*
          Wpk[5][20][0])-(Tstar[20][1]*s14))))+temp[5]));
        temp[7] = ((((Fstar[23][2]*Vpk[5][23][2])+((Fstar[23][0]*Vpk[5][23][0])+
          (Fstar[23][1]*Vpk[5][23][1])))+((Tstar[23][2]*Wpk[5][23][2])+((
          Tstar[23][0]*Wpk[5][21][0])+(Tstar[23][1]*Wpk[5][23][1]))))+((((
          Fstar[22][2]*Vpk[5][22][2])+((Fstar[22][0]*Vpk[5][22][0])+(
          Fstar[22][1]*Vpk[5][22][1])))+((Tstar[22][2]*Wpk[5][22][2])+((
          Tstar[22][0]*Wpk[5][20][0])+(Tstar[22][1]*Wpk[5][22][1]))))+temp[6]));
        fs0[5] = (utau[5]-(((Tstar[24][2]+((Fstar[24][0]*Vpk[5][24][0])+(
          Fstar[24][1]*Vpk[5][24][1])))+temp[7])+(((Fstar[25][2]*Vpk[5][25][2])+
          ((Fstar[25][0]*Vpk[5][25][0])+(Fstar[25][1]*Vpk[5][25][1])))+((
          Tstar[25][0]*s25)+(Tstar[25][2]*c25)))));
        fs0[6] = (utau[6]-((((Fstar[10][2]*Vpk[6][10][2])+((Fstar[10][0]*
          Vpk[6][10][0])+(Fstar[10][1]*Vpk[6][10][1])))+(((Tstar[10][0]*
          Wpk[6][10][0])+(Tstar[10][1]*Wpk[6][10][1]))-(Tstar[10][2]*s8)))+((((
          Fstar[6][0]*rk[1][2])-(Fstar[6][2]*rk[1][0]))-Tstar[6][1])+(((
          Fstar[8][2]*Vpk[6][8][2])+((Fstar[8][0]*Vpk[6][8][0])+(Fstar[8][1]*
          Vpk[6][8][1])))-((Tstar[8][1]*c8)+(Tstar[8][2]*s8))))));
        fs0[7] = (utau[7]-((((Fstar[11][2]*Vpk[7][11][2])+((Fstar[11][0]*
          Vpk[7][11][0])+(Fstar[11][1]*Vpk[7][11][1])))+((Tstar[11][2]*s9)+((
          Tstar[11][0]*Wpk[7][11][0])+(Tstar[11][1]*Wpk[7][11][1]))))+((((
          Fstar[7][0]*rk[2][2])-(Fstar[7][2]*rk[2][0]))-Tstar[7][1])+(((
          Fstar[9][2]*Vpk[7][9][2])+((Fstar[9][0]*Vpk[7][9][0])+(Fstar[9][1]*
          Vpk[7][9][1])))+((Tstar[9][2]*s9)-(Tstar[9][1]*c9))))));
        fs0[8] = (utau[8]-((((Fstar[8][2]*rk[3][1])-(Fstar[8][1]*rk[3][2]))-
          Tstar[8][0])+(((Fstar[10][2]*Vpk[8][10][2])+((Fstar[10][0]*
          Vpk[8][10][0])+(Fstar[10][1]*Vpk[8][10][1])))-((Tstar[10][0]*c10)+(
          Tstar[10][1]*s10)))));
        fs0[9] = (utau[9]-((Tstar[9][0]+((Fstar[9][1]*rk[4][2])-(Fstar[9][2]*
          rk[4][1])))+(((Fstar[11][2]*Vpk[9][11][2])+((Fstar[11][0]*
          Vpk[9][11][0])+(Fstar[11][1]*Vpk[9][11][1])))+((Tstar[11][0]*c11)-(
          Tstar[11][1]*s11)))));
        fs0[10] = (utau[10]-(((Fstar[10][1]*rk[5][0])-(Fstar[10][0]*rk[5][1]))-
          Tstar[10][2]));
        fs0[11] = (utau[11]-(Tstar[11][2]+((Fstar[11][0]*rk[6][1])-(Fstar[11][1]
          *rk[6][0]))));
        temp[0] = ((((Fstar[16][2]*Vpk[12][16][2])+((Fstar[16][0]*Vpk[12][16][0]
          )+(Fstar[16][1]*Vpk[12][16][1])))+((Tstar[16][2]*Wpk[12][16][2])+((
          Tstar[16][0]*Wpk[12][16][0])+(Tstar[16][1]*s14))))+((((Fstar[12][1]*
          rk[7][0])-(Fstar[12][0]*rk[7][1]))-Tstar[12][2])+(((Fstar[14][2]*
          Vpk[12][14][2])+((Fstar[14][0]*Vpk[12][14][0])+(Fstar[14][1]*
          Vpk[12][14][1])))+((Tstar[14][1]*s14)-(Tstar[14][2]*c14)))));
        temp[1] = ((((Fstar[20][2]*Vpk[12][20][2])+((Fstar[20][0]*Vpk[12][20][0]
          )+(Fstar[20][1]*Vpk[12][20][1])))+((Tstar[20][2]*Wpk[12][20][2])+((
          Tstar[20][0]*Wpk[12][20][0])+(Tstar[20][1]*s14))))+((((Fstar[18][2]*
          Vpk[12][18][2])+((Fstar[18][0]*Vpk[12][18][0])+(Fstar[18][1]*
          Vpk[12][18][1])))+((Tstar[18][2]*Wpk[12][18][2])+((Tstar[18][0]*
          Wpk[12][18][0])+(Tstar[18][1]*s14))))+temp[0]));
        fs0[12] = (utau[12]-((((Fstar[22][2]*Vpk[12][22][2])+((Fstar[22][0]*
          Vpk[12][22][0])+(Fstar[22][1]*Vpk[12][22][1])))+((Tstar[22][2]*
          Wpk[12][22][2])+((Tstar[22][0]*Wpk[12][20][0])+(Tstar[22][1]*
          Wpk[12][22][1]))))+temp[1]));
        temp[0] = (((Tstar[13][2]+((Fstar[13][0]*rk[8][1])-(Fstar[13][1]*
          rk[8][0])))+(((Fstar[15][2]*Vpk[13][15][2])+((Fstar[15][0]*
          Vpk[13][15][0])+(Fstar[15][1]*Vpk[13][15][1])))+((Tstar[15][1]*s15)+(
          Tstar[15][2]*c15))))+(((Fstar[17][2]*Vpk[13][17][2])+((Fstar[17][0]*
          Vpk[13][17][0])+(Fstar[17][1]*Vpk[13][17][1])))+((Tstar[17][2]*
          Wpk[13][17][2])+((Tstar[17][0]*Wpk[13][17][0])+(Tstar[17][1]*s15)))));
        temp[1] = ((((Fstar[21][2]*Vpk[13][21][2])+((Fstar[21][0]*Vpk[13][21][0]
          )+(Fstar[21][1]*Vpk[13][21][1])))+((Tstar[21][2]*Wpk[13][21][2])+((
          Tstar[21][0]*Wpk[13][21][0])+(Tstar[21][1]*s15))))+((((Fstar[19][2]*
          Vpk[13][19][2])+((Fstar[19][0]*Vpk[13][19][0])+(Fstar[19][1]*
          Vpk[13][19][1])))+((Tstar[19][2]*Wpk[13][19][2])+((Tstar[19][0]*
          Wpk[13][19][0])+(Tstar[19][1]*s15))))+temp[0]));
        fs0[13] = (utau[13]-((((Fstar[23][2]*Vpk[13][23][2])+((Fstar[23][0]*
          Vpk[13][23][0])+(Fstar[23][1]*Vpk[13][23][1])))+((Tstar[23][2]*
          Wpk[13][23][2])+((Tstar[23][0]*Wpk[13][21][0])+(Tstar[23][1]*
          Wpk[13][23][1]))))+temp[1]));
        temp[0] = ((((Fstar[18][2]*Vpk[14][18][2])+((Fstar[18][0]*Vpk[14][18][0]
          )+(Fstar[18][1]*Vpk[14][18][1])))+((Tstar[18][0]*Wpk[14][18][0])+(
          Tstar[18][2]*Wpk[14][18][2])))+((((Fstar[14][2]*rk[9][1])-(
          Fstar[14][1]*rk[9][2]))-Tstar[14][0])+(((Fstar[16][2]*Vpk[14][16][2])+
          ((Fstar[16][0]*Vpk[14][16][0])+(Fstar[16][1]*Vpk[14][16][1])))+((
          Tstar[16][2]*s16)-(Tstar[16][0]*c16)))));
        fs0[14] = (utau[14]-((((Fstar[22][2]*Vpk[14][22][2])+((Fstar[22][0]*
          Vpk[14][22][0])+(Fstar[22][1]*Vpk[14][22][1])))+((Tstar[22][2]*
          Wpk[14][22][2])+((Tstar[22][0]*Wpk[14][20][0])+(Tstar[22][1]*
          Wpk[14][22][1]))))+((((Fstar[20][2]*Vpk[14][20][2])+((Fstar[20][0]*
          Vpk[14][20][0])+(Fstar[20][1]*Vpk[14][20][1])))+((Tstar[20][0]*
          Wpk[14][20][0])+(Tstar[20][2]*Wpk[14][20][2])))+temp[0])));
        temp[0] = (((Tstar[15][0]+((Fstar[15][1]*rk[10][2])-(Fstar[15][2]*
          rk[10][1])))+(((Fstar[17][2]*Vpk[15][17][2])+((Fstar[17][0]*
          Vpk[15][17][0])+(Fstar[17][1]*Vpk[15][17][1])))+((Tstar[17][0]*c17)-(
          Tstar[17][2]*s17))))+(((Fstar[19][2]*Vpk[15][19][2])+((Fstar[19][0]*
          Vpk[15][19][0])+(Fstar[19][1]*Vpk[15][19][1])))+((Tstar[19][0]*
          Wpk[15][19][0])+(Tstar[19][2]*Wpk[15][19][2]))));
        fs0[15] = (utau[15]-((((Fstar[23][2]*Vpk[15][23][2])+((Fstar[23][0]*
          Vpk[15][23][0])+(Fstar[23][1]*Vpk[15][23][1])))+((Tstar[23][2]*
          Wpk[15][23][2])+((Tstar[23][0]*Wpk[15][21][0])+(Tstar[23][1]*
          Wpk[15][23][1]))))+((((Fstar[21][2]*Vpk[15][21][2])+((Fstar[21][0]*
          Vpk[15][21][0])+(Fstar[21][1]*Vpk[15][21][1])))+((Tstar[21][0]*
          Wpk[15][21][0])+(Tstar[21][2]*Wpk[15][21][2])))+temp[0])));
        fs0[16] = (utau[16]-((((Fstar[22][2]*Vpk[16][22][2])+((Fstar[22][0]*
          Vpk[16][22][0])+(Fstar[22][1]*Vpk[16][22][1])))-((Tstar[22][1]*c22)+(
          Tstar[22][2]*s22)))+((((Fstar[20][0]*Vpk[16][20][0])+(Fstar[20][2]*
          Vpk[16][20][2]))-Tstar[20][1])+((((Fstar[16][0]*rk[11][2])-(
          Fstar[16][2]*rk[11][0]))-Tstar[16][1])+(((Fstar[18][0]*Vpk[16][18][0])
          +(Fstar[18][2]*Vpk[16][18][2]))-Tstar[18][1])))));
        fs0[17] = (utau[17]-((((Fstar[23][2]*Vpk[17][23][2])+((Fstar[23][0]*
          Vpk[17][23][0])+(Fstar[23][1]*Vpk[17][23][1])))+((Tstar[23][2]*s23)-(
          Tstar[23][1]*c23)))+((((Fstar[21][0]*Vpk[17][21][0])+(Fstar[21][2]*
          Vpk[17][21][2]))-Tstar[21][1])+((((Fstar[17][0]*rk[12][2])-(
          Fstar[17][2]*rk[12][0]))-Tstar[17][1])+(((Fstar[19][0]*Vpk[17][19][0])
          +(Fstar[19][2]*Vpk[17][19][2]))-Tstar[19][1])))));
        fs0[18] = (utau[18]-((((Fstar[22][2]*Vpk[18][22][2])+((Fstar[22][0]*
          Vpk[18][22][0])+(Fstar[22][1]*Vpk[18][22][1])))-((Tstar[22][1]*c22)+(
          Tstar[22][2]*s22)))+((((Fstar[18][0]*rk[13][2])-(Fstar[18][2]*
          rk[13][0]))-Tstar[18][1])+(((Fstar[20][0]*Vpk[18][20][0])+(
          Fstar[20][2]*Vpk[18][20][2]))-Tstar[20][1]))));
        fs0[19] = (utau[19]-((((Fstar[23][2]*Vpk[19][23][2])+((Fstar[23][0]*
          Vpk[19][23][0])+(Fstar[23][1]*Vpk[19][23][1])))+((Tstar[23][2]*s23)-(
          Tstar[23][1]*c23)))+((((Fstar[19][0]*rk[14][2])-(Fstar[19][2]*
          rk[14][0]))-Tstar[19][1])+(((Fstar[21][0]*Vpk[19][21][0])+(
          Fstar[21][2]*Vpk[19][21][2]))-Tstar[21][1]))));
        fs0[20] = (utau[20]-((((Fstar[20][0]*rk[15][2])-(Fstar[20][2]*rk[15][0])
          )-Tstar[20][1])+(((Fstar[22][2]*Vpk[20][22][2])+((Fstar[22][0]*
          Vpk[20][22][0])+(Fstar[22][1]*Vpk[20][22][1])))-((Tstar[22][1]*c22)+(
          Tstar[22][2]*s22)))));
        fs0[21] = (utau[21]-((((Fstar[21][0]*rk[16][2])-(Fstar[21][2]*rk[16][0])
          )-Tstar[21][1])+(((Fstar[23][2]*Vpk[21][23][2])+((Fstar[23][0]*
          Vpk[21][23][0])+(Fstar[23][1]*Vpk[21][23][1])))+((Tstar[23][2]*s23)-(
          Tstar[23][1]*c23)))));
        fs0[22] = (utau[22]-(((Fstar[22][2]*rk[17][1])-(Fstar[22][1]*rk[17][2]))
          -Tstar[22][0]));
        fs0[23] = (utau[23]-(Tstar[23][0]+((Fstar[23][1]*rk[18][2])-(
          Fstar[23][2]*rk[18][1]))));
        fs0[24] = (utau[24]-((Tstar[24][2]+((Fstar[24][0]*rk[19][1])-(
          Fstar[24][1]*rk[19][0])))+(((Fstar[25][2]*Vpk[24][25][2])+((
          Fstar[25][0]*Vpk[24][25][0])+(Fstar[25][1]*Vpk[24][25][1])))+((
          Tstar[25][0]*s25)+(Tstar[25][2]*c25)))));
        fs0[25] = (utau[25]-(((Fstar[25][0]*rk[20][2])-(Fstar[25][2]*rk[20][0]))
          -Tstar[25][1]));
        fs0flg = 1;
    }
/*
 Used 0.01 seconds CPU time,
 0 additional bytes of memory.
 Equations contain 1127 adds/subtracts/negates
                    967 multiplies
                      0 divides
                    198 assignments
*/
}

void sddomm(int routine)
{
    int dumroutine,errnum;
    int i;

    if (mmflg == 0) {
/*
Compute mass matrix (MM)
*/
        sddovpk();
        IkWpk[3][6][0] = ((ik[1][0][0]*c6)-(ik[1][0][2]*s6));
        IkWpk[3][6][1] = ((ik[1][1][0]*c6)-(ik[1][1][2]*s6));
        IkWpk[3][6][2] = ((ik[1][2][0]*c6)-(ik[1][2][2]*s6));
        IkWpk[3][7][0] = ((ik[2][0][0]*c7)-(ik[2][0][2]*s7));
        IkWpk[3][7][1] = ((ik[2][1][0]*c7)-(ik[2][1][2]*s7));
        IkWpk[3][7][2] = ((ik[2][2][0]*c7)-(ik[2][2][2]*s7));
        IkWpk[3][8][0] = ((ik[3][0][2]*Wpk[3][8][2])+((ik[3][0][0]*c6)+(
          ik[3][0][1]*Wpk[3][8][1])));
        IkWpk[3][8][1] = ((ik[3][1][2]*Wpk[3][8][2])+((ik[3][1][0]*c6)+(
          ik[3][1][1]*Wpk[3][8][1])));
        IkWpk[3][8][2] = ((ik[3][2][2]*Wpk[3][8][2])+((ik[3][2][0]*c6)+(
          ik[3][2][1]*Wpk[3][8][1])));
        IkWpk[3][9][0] = ((ik[4][0][2]*Wpk[3][9][2])+((ik[4][0][0]*c7)+(
          ik[4][0][1]*Wpk[3][9][1])));
        IkWpk[3][9][1] = ((ik[4][1][2]*Wpk[3][9][2])+((ik[4][1][0]*c7)+(
          ik[4][1][1]*Wpk[3][9][1])));
        IkWpk[3][9][2] = ((ik[4][2][2]*Wpk[3][9][2])+((ik[4][2][0]*c7)+(
          ik[4][2][1]*Wpk[3][9][1])));
        IkWpk[3][10][0] = ((ik[5][0][2]*Wpk[3][8][2])+((ik[5][0][0]*
          Wpk[3][10][0])+(ik[5][0][1]*Wpk[3][10][1])));
        IkWpk[3][10][1] = ((ik[5][1][2]*Wpk[3][8][2])+((ik[5][1][0]*
          Wpk[3][10][0])+(ik[5][1][1]*Wpk[3][10][1])));
        IkWpk[3][10][2] = ((ik[5][2][2]*Wpk[3][8][2])+((ik[5][2][0]*
          Wpk[3][10][0])+(ik[5][2][1]*Wpk[3][10][1])));
        IkWpk[3][11][0] = ((ik[6][0][2]*Wpk[3][9][2])+((ik[6][0][0]*
          Wpk[3][11][0])+(ik[6][0][1]*Wpk[3][11][1])));
        IkWpk[3][11][1] = ((ik[6][1][2]*Wpk[3][9][2])+((ik[6][1][0]*
          Wpk[3][11][0])+(ik[6][1][1]*Wpk[3][11][1])));
        IkWpk[3][11][2] = ((ik[6][2][2]*Wpk[3][9][2])+((ik[6][2][0]*
          Wpk[3][11][0])+(ik[6][2][1]*Wpk[3][11][1])));
        IkWpk[3][12][0] = ((ik[7][0][0]*c12)+(ik[7][0][1]*s12));
        IkWpk[3][12][1] = ((ik[7][1][0]*c12)+(ik[7][1][1]*s12));
        IkWpk[3][12][2] = ((ik[7][2][0]*c12)+(ik[7][2][1]*s12));
        IkWpk[3][13][0] = ((ik[8][0][0]*c13)-(ik[8][0][1]*s13));
        IkWpk[3][13][1] = ((ik[8][1][0]*c13)-(ik[8][1][1]*s13));
        IkWpk[3][13][2] = ((ik[8][2][0]*c13)-(ik[8][2][1]*s13));
        IkWpk[3][14][0] = ((ik[9][0][2]*Wpk[3][14][2])+((ik[9][0][0]*c12)+(
          ik[9][0][1]*Wpk[3][14][1])));
        IkWpk[3][14][1] = ((ik[9][1][2]*Wpk[3][14][2])+((ik[9][1][0]*c12)+(
          ik[9][1][1]*Wpk[3][14][1])));
        IkWpk[3][14][2] = ((ik[9][2][2]*Wpk[3][14][2])+((ik[9][2][0]*c12)+(
          ik[9][2][1]*Wpk[3][14][1])));
        IkWpk[3][15][0] = ((ik[10][0][2]*Wpk[3][15][2])+((ik[10][0][0]*c13)+(
          ik[10][0][1]*Wpk[3][15][1])));
        IkWpk[3][15][1] = ((ik[10][1][2]*Wpk[3][15][2])+((ik[10][1][0]*c13)+(
          ik[10][1][1]*Wpk[3][15][1])));
        IkWpk[3][15][2] = ((ik[10][2][2]*Wpk[3][15][2])+((ik[10][2][0]*c13)+(
          ik[10][2][1]*Wpk[3][15][1])));
        IkWpk[3][16][0] = ((ik[11][0][2]*Wpk[3][16][2])+((ik[11][0][0]*
          Wpk[3][16][0])+(ik[11][0][1]*Wpk[3][14][1])));
        IkWpk[3][16][1] = ((ik[11][1][2]*Wpk[3][16][2])+((ik[11][1][0]*
          Wpk[3][16][0])+(ik[11][1][1]*Wpk[3][14][1])));
        IkWpk[3][16][2] = ((ik[11][2][2]*Wpk[3][16][2])+((ik[11][2][0]*
          Wpk[3][16][0])+(ik[11][2][1]*Wpk[3][14][1])));
        IkWpk[3][17][0] = ((ik[12][0][2]*Wpk[3][17][2])+((ik[12][0][0]*
          Wpk[3][17][0])+(ik[12][0][1]*Wpk[3][15][1])));
        IkWpk[3][17][1] = ((ik[12][1][2]*Wpk[3][17][2])+((ik[12][1][0]*
          Wpk[3][17][0])+(ik[12][1][1]*Wpk[3][15][1])));
        IkWpk[3][17][2] = ((ik[12][2][2]*Wpk[3][17][2])+((ik[12][2][0]*
          Wpk[3][17][0])+(ik[12][2][1]*Wpk[3][15][1])));
        IkWpk[3][18][0] = ((ik[13][0][2]*Wpk[3][18][2])+((ik[13][0][0]*
          Wpk[3][18][0])+(ik[13][0][1]*Wpk[3][14][1])));
        IkWpk[3][18][1] = ((ik[13][1][2]*Wpk[3][18][2])+((ik[13][1][0]*
          Wpk[3][18][0])+(ik[13][1][1]*Wpk[3][14][1])));
        IkWpk[3][18][2] = ((ik[13][2][2]*Wpk[3][18][2])+((ik[13][2][0]*
          Wpk[3][18][0])+(ik[13][2][1]*Wpk[3][14][1])));
        IkWpk[3][19][0] = ((ik[14][0][2]*Wpk[3][19][2])+((ik[14][0][0]*
          Wpk[3][19][0])+(ik[14][0][1]*Wpk[3][15][1])));
        IkWpk[3][19][1] = ((ik[14][1][2]*Wpk[3][19][2])+((ik[14][1][0]*
          Wpk[3][19][0])+(ik[14][1][1]*Wpk[3][15][1])));
        IkWpk[3][19][2] = ((ik[14][2][2]*Wpk[3][19][2])+((ik[14][2][0]*
          Wpk[3][19][0])+(ik[14][2][1]*Wpk[3][15][1])));
        IkWpk[3][20][0] = ((ik[15][0][2]*Wpk[3][20][2])+((ik[15][0][0]*
          Wpk[3][20][0])+(ik[15][0][1]*Wpk[3][14][1])));
        IkWpk[3][20][1] = ((ik[15][1][2]*Wpk[3][20][2])+((ik[15][1][0]*
          Wpk[3][20][0])+(ik[15][1][1]*Wpk[3][14][1])));
        IkWpk[3][20][2] = ((ik[15][2][2]*Wpk[3][20][2])+((ik[15][2][0]*
          Wpk[3][20][0])+(ik[15][2][1]*Wpk[3][14][1])));
        IkWpk[3][21][0] = ((ik[16][0][2]*Wpk[3][21][2])+((ik[16][0][0]*
          Wpk[3][21][0])+(ik[16][0][1]*Wpk[3][15][1])));
        IkWpk[3][21][1] = ((ik[16][1][2]*Wpk[3][21][2])+((ik[16][1][0]*
          Wpk[3][21][0])+(ik[16][1][1]*Wpk[3][15][1])));
        IkWpk[3][21][2] = ((ik[16][2][2]*Wpk[3][21][2])+((ik[16][2][0]*
          Wpk[3][21][0])+(ik[16][2][1]*Wpk[3][15][1])));
        IkWpk[3][22][0] = ((ik[17][0][2]*Wpk[3][22][2])+((ik[17][0][0]*
          Wpk[3][20][0])+(ik[17][0][1]*Wpk[3][22][1])));
        IkWpk[3][22][1] = ((ik[17][1][2]*Wpk[3][22][2])+((ik[17][1][0]*
          Wpk[3][20][0])+(ik[17][1][1]*Wpk[3][22][1])));
        IkWpk[3][22][2] = ((ik[17][2][2]*Wpk[3][22][2])+((ik[17][2][0]*
          Wpk[3][20][0])+(ik[17][2][1]*Wpk[3][22][1])));
        IkWpk[3][23][0] = ((ik[18][0][2]*Wpk[3][23][2])+((ik[18][0][0]*
          Wpk[3][21][0])+(ik[18][0][1]*Wpk[3][23][1])));
        IkWpk[3][23][1] = ((ik[18][1][2]*Wpk[3][23][2])+((ik[18][1][0]*
          Wpk[3][21][0])+(ik[18][1][1]*Wpk[3][23][1])));
        IkWpk[3][23][2] = ((ik[18][2][2]*Wpk[3][23][2])+((ik[18][2][0]*
          Wpk[3][21][0])+(ik[18][2][1]*Wpk[3][23][1])));
        IkWpk[3][24][0] = ((ik[19][0][0]*c24)-(ik[19][0][1]*s24));
        IkWpk[3][24][1] = ((ik[19][1][0]*c24)-(ik[19][1][1]*s24));
        IkWpk[3][24][2] = ((ik[19][2][0]*c24)-(ik[19][2][1]*s24));
        IkWpk[3][25][0] = ((ik[20][0][2]*Wpk[3][25][2])+((ik[20][0][0]*
          Wpk[3][25][0])-(ik[20][0][1]*s24)));
        IkWpk[3][25][1] = ((ik[20][1][2]*Wpk[3][25][2])+((ik[20][1][0]*
          Wpk[3][25][0])-(ik[20][1][1]*s24)));
        IkWpk[3][25][2] = ((ik[20][2][2]*Wpk[3][25][2])+((ik[20][2][0]*
          Wpk[3][25][0])-(ik[20][2][1]*s24)));
        IkWpk[4][8][0] = ((ik[3][0][1]*c8)+(ik[3][0][2]*s8));
        IkWpk[4][8][1] = ((ik[3][1][1]*c8)+(ik[3][1][2]*s8));
        IkWpk[4][8][2] = ((ik[3][2][1]*c8)+(ik[3][2][2]*s8));
        IkWpk[4][9][0] = ((ik[4][0][1]*c9)-(ik[4][0][2]*s9));
        IkWpk[4][9][1] = ((ik[4][1][1]*c9)-(ik[4][1][2]*s9));
        IkWpk[4][9][2] = ((ik[4][2][1]*c9)-(ik[4][2][2]*s9));
        IkWpk[4][10][0] = ((ik[5][0][2]*s8)+((ik[5][0][0]*Wpk[4][10][0])+(
          ik[5][0][1]*Wpk[4][10][1])));
        IkWpk[4][10][1] = ((ik[5][1][2]*s8)+((ik[5][1][0]*Wpk[4][10][0])+(
          ik[5][1][1]*Wpk[4][10][1])));
        IkWpk[4][10][2] = ((ik[5][2][2]*s8)+((ik[5][2][0]*Wpk[4][10][0])+(
          ik[5][2][1]*Wpk[4][10][1])));
        IkWpk[4][11][0] = (((ik[6][0][0]*Wpk[4][11][0])+(ik[6][0][1]*
          Wpk[4][11][1]))-(ik[6][0][2]*s9));
        IkWpk[4][11][1] = (((ik[6][1][0]*Wpk[4][11][0])+(ik[6][1][1]*
          Wpk[4][11][1]))-(ik[6][1][2]*s9));
        IkWpk[4][11][2] = (((ik[6][2][0]*Wpk[4][11][0])+(ik[6][2][1]*
          Wpk[4][11][1]))-(ik[6][2][2]*s9));
        IkWpk[4][12][0] = ((ik[7][0][1]*c12)-(ik[7][0][0]*s12));
        IkWpk[4][12][1] = ((ik[7][1][1]*c12)-(ik[7][1][0]*s12));
        IkWpk[4][12][2] = ((ik[7][2][1]*c12)-(ik[7][2][0]*s12));
        IkWpk[4][13][0] = ((ik[8][0][0]*s13)+(ik[8][0][1]*c13));
        IkWpk[4][13][1] = ((ik[8][1][0]*s13)+(ik[8][1][1]*c13));
        IkWpk[4][13][2] = ((ik[8][2][0]*s13)+(ik[8][2][1]*c13));
        IkWpk[4][14][0] = ((ik[9][0][2]*Wpk[4][14][2])+((ik[9][0][1]*
          Wpk[4][14][1])-(ik[9][0][0]*s12)));
        IkWpk[4][14][1] = ((ik[9][1][2]*Wpk[4][14][2])+((ik[9][1][1]*
          Wpk[4][14][1])-(ik[9][1][0]*s12)));
        IkWpk[4][14][2] = ((ik[9][2][2]*Wpk[4][14][2])+((ik[9][2][1]*
          Wpk[4][14][1])-(ik[9][2][0]*s12)));
        IkWpk[4][15][0] = ((ik[10][0][2]*Wpk[4][15][2])+((ik[10][0][0]*s13)+(
          ik[10][0][1]*Wpk[4][15][1])));
        IkWpk[4][15][1] = ((ik[10][1][2]*Wpk[4][15][2])+((ik[10][1][0]*s13)+(
          ik[10][1][1]*Wpk[4][15][1])));
        IkWpk[4][15][2] = ((ik[10][2][2]*Wpk[4][15][2])+((ik[10][2][0]*s13)+(
          ik[10][2][1]*Wpk[4][15][1])));
        IkWpk[4][16][0] = ((ik[11][0][2]*Wpk[4][16][2])+((ik[11][0][0]*
          Wpk[4][16][0])+(ik[11][0][1]*Wpk[4][14][1])));
        IkWpk[4][16][1] = ((ik[11][1][2]*Wpk[4][16][2])+((ik[11][1][0]*
          Wpk[4][16][0])+(ik[11][1][1]*Wpk[4][14][1])));
        IkWpk[4][16][2] = ((ik[11][2][2]*Wpk[4][16][2])+((ik[11][2][0]*
          Wpk[4][16][0])+(ik[11][2][1]*Wpk[4][14][1])));
        IkWpk[4][17][0] = ((ik[12][0][2]*Wpk[4][17][2])+((ik[12][0][0]*
          Wpk[4][17][0])+(ik[12][0][1]*Wpk[4][15][1])));
        IkWpk[4][17][1] = ((ik[12][1][2]*Wpk[4][17][2])+((ik[12][1][0]*
          Wpk[4][17][0])+(ik[12][1][1]*Wpk[4][15][1])));
        IkWpk[4][17][2] = ((ik[12][2][2]*Wpk[4][17][2])+((ik[12][2][0]*
          Wpk[4][17][0])+(ik[12][2][1]*Wpk[4][15][1])));
        IkWpk[4][18][0] = ((ik[13][0][2]*Wpk[4][18][2])+((ik[13][0][0]*
          Wpk[4][18][0])+(ik[13][0][1]*Wpk[4][14][1])));
        IkWpk[4][18][1] = ((ik[13][1][2]*Wpk[4][18][2])+((ik[13][1][0]*
          Wpk[4][18][0])+(ik[13][1][1]*Wpk[4][14][1])));
        IkWpk[4][18][2] = ((ik[13][2][2]*Wpk[4][18][2])+((ik[13][2][0]*
          Wpk[4][18][0])+(ik[13][2][1]*Wpk[4][14][1])));
        IkWpk[4][19][0] = ((ik[14][0][2]*Wpk[4][19][2])+((ik[14][0][0]*
          Wpk[4][19][0])+(ik[14][0][1]*Wpk[4][15][1])));
        IkWpk[4][19][1] = ((ik[14][1][2]*Wpk[4][19][2])+((ik[14][1][0]*
          Wpk[4][19][0])+(ik[14][1][1]*Wpk[4][15][1])));
        IkWpk[4][19][2] = ((ik[14][2][2]*Wpk[4][19][2])+((ik[14][2][0]*
          Wpk[4][19][0])+(ik[14][2][1]*Wpk[4][15][1])));
        IkWpk[4][20][0] = ((ik[15][0][2]*Wpk[4][20][2])+((ik[15][0][0]*
          Wpk[4][20][0])+(ik[15][0][1]*Wpk[4][14][1])));
        IkWpk[4][20][1] = ((ik[15][1][2]*Wpk[4][20][2])+((ik[15][1][0]*
          Wpk[4][20][0])+(ik[15][1][1]*Wpk[4][14][1])));
        IkWpk[4][20][2] = ((ik[15][2][2]*Wpk[4][20][2])+((ik[15][2][0]*
          Wpk[4][20][0])+(ik[15][2][1]*Wpk[4][14][1])));
        IkWpk[4][21][0] = ((ik[16][0][2]*Wpk[4][21][2])+((ik[16][0][0]*
          Wpk[4][21][0])+(ik[16][0][1]*Wpk[4][15][1])));
        IkWpk[4][21][1] = ((ik[16][1][2]*Wpk[4][21][2])+((ik[16][1][0]*
          Wpk[4][21][0])+(ik[16][1][1]*Wpk[4][15][1])));
        IkWpk[4][21][2] = ((ik[16][2][2]*Wpk[4][21][2])+((ik[16][2][0]*
          Wpk[4][21][0])+(ik[16][2][1]*Wpk[4][15][1])));
        IkWpk[4][22][0] = ((ik[17][0][2]*Wpk[4][22][2])+((ik[17][0][0]*
          Wpk[4][20][0])+(ik[17][0][1]*Wpk[4][22][1])));
        IkWpk[4][22][1] = ((ik[17][1][2]*Wpk[4][22][2])+((ik[17][1][0]*
          Wpk[4][20][0])+(ik[17][1][1]*Wpk[4][22][1])));
        IkWpk[4][22][2] = ((ik[17][2][2]*Wpk[4][22][2])+((ik[17][2][0]*
          Wpk[4][20][0])+(ik[17][2][1]*Wpk[4][22][1])));
        IkWpk[4][23][0] = ((ik[18][0][2]*Wpk[4][23][2])+((ik[18][0][0]*
          Wpk[4][21][0])+(ik[18][0][1]*Wpk[4][23][1])));
        IkWpk[4][23][1] = ((ik[18][1][2]*Wpk[4][23][2])+((ik[18][1][0]*
          Wpk[4][21][0])+(ik[18][1][1]*Wpk[4][23][1])));
        IkWpk[4][23][2] = ((ik[18][2][2]*Wpk[4][23][2])+((ik[18][2][0]*
          Wpk[4][21][0])+(ik[18][2][1]*Wpk[4][23][1])));
        IkWpk[4][24][0] = ((ik[19][0][0]*s24)+(ik[19][0][1]*c24));
        IkWpk[4][24][1] = ((ik[19][1][0]*s24)+(ik[19][1][1]*c24));
        IkWpk[4][24][2] = ((ik[19][2][0]*s24)+(ik[19][2][1]*c24));
        IkWpk[4][25][0] = ((ik[20][0][2]*Wpk[4][25][2])+((ik[20][0][0]*
          Wpk[4][25][0])+(ik[20][0][1]*c24)));
        IkWpk[4][25][1] = ((ik[20][1][2]*Wpk[4][25][2])+((ik[20][1][0]*
          Wpk[4][25][0])+(ik[20][1][1]*c24)));
        IkWpk[4][25][2] = ((ik[20][2][2]*Wpk[4][25][2])+((ik[20][2][0]*
          Wpk[4][25][0])+(ik[20][2][1]*c24)));
        IkWpk[5][6][0] = ((ik[1][0][0]*s6)+(ik[1][0][2]*c6));
        IkWpk[5][6][1] = ((ik[1][1][0]*s6)+(ik[1][1][2]*c6));
        IkWpk[5][6][2] = ((ik[1][2][0]*s6)+(ik[1][2][2]*c6));
        IkWpk[5][7][0] = ((ik[2][0][0]*s7)+(ik[2][0][2]*c7));
        IkWpk[5][7][1] = ((ik[2][1][0]*s7)+(ik[2][1][2]*c7));
        IkWpk[5][7][2] = ((ik[2][2][0]*s7)+(ik[2][2][2]*c7));
        IkWpk[5][8][0] = ((ik[3][0][2]*Wpk[5][8][2])+((ik[3][0][0]*s6)+(
          ik[3][0][1]*Wpk[5][8][1])));
        IkWpk[5][8][1] = ((ik[3][1][2]*Wpk[5][8][2])+((ik[3][1][0]*s6)+(
          ik[3][1][1]*Wpk[5][8][1])));
        IkWpk[5][8][2] = ((ik[3][2][2]*Wpk[5][8][2])+((ik[3][2][0]*s6)+(
          ik[3][2][1]*Wpk[5][8][1])));
        IkWpk[5][9][0] = ((ik[4][0][2]*Wpk[5][9][2])+((ik[4][0][0]*s7)+(
          ik[4][0][1]*Wpk[5][9][1])));
        IkWpk[5][9][1] = ((ik[4][1][2]*Wpk[5][9][2])+((ik[4][1][0]*s7)+(
          ik[4][1][1]*Wpk[5][9][1])));
        IkWpk[5][9][2] = ((ik[4][2][2]*Wpk[5][9][2])+((ik[4][2][0]*s7)+(
          ik[4][2][1]*Wpk[5][9][1])));
        IkWpk[5][10][0] = ((ik[5][0][2]*Wpk[5][8][2])+((ik[5][0][0]*
          Wpk[5][10][0])+(ik[5][0][1]*Wpk[5][10][1])));
        IkWpk[5][10][1] = ((ik[5][1][2]*Wpk[5][8][2])+((ik[5][1][0]*
          Wpk[5][10][0])+(ik[5][1][1]*Wpk[5][10][1])));
        IkWpk[5][10][2] = ((ik[5][2][2]*Wpk[5][8][2])+((ik[5][2][0]*
          Wpk[5][10][0])+(ik[5][2][1]*Wpk[5][10][1])));
        IkWpk[5][11][0] = ((ik[6][0][2]*Wpk[5][9][2])+((ik[6][0][0]*
          Wpk[5][11][0])+(ik[6][0][1]*Wpk[5][11][1])));
        IkWpk[5][11][1] = ((ik[6][1][2]*Wpk[5][9][2])+((ik[6][1][0]*
          Wpk[5][11][0])+(ik[6][1][1]*Wpk[5][11][1])));
        IkWpk[5][11][2] = ((ik[6][2][2]*Wpk[5][9][2])+((ik[6][2][0]*
          Wpk[5][11][0])+(ik[6][2][1]*Wpk[5][11][1])));
        IkWpk[5][14][0] = ((ik[9][0][2]*c14)-(ik[9][0][1]*s14));
        IkWpk[5][14][1] = ((ik[9][1][2]*c14)-(ik[9][1][1]*s14));
        IkWpk[5][14][2] = ((ik[9][2][2]*c14)-(ik[9][2][1]*s14));
        IkWpk[5][15][0] = ((ik[10][0][1]*s15)+(ik[10][0][2]*c15));
        IkWpk[5][15][1] = ((ik[10][1][1]*s15)+(ik[10][1][2]*c15));
        IkWpk[5][15][2] = ((ik[10][2][1]*s15)+(ik[10][2][2]*c15));
        IkWpk[5][16][0] = ((ik[11][0][2]*Wpk[5][16][2])+((ik[11][0][0]*
          Wpk[5][16][0])-(ik[11][0][1]*s14)));
        IkWpk[5][16][1] = ((ik[11][1][2]*Wpk[5][16][2])+((ik[11][1][0]*
          Wpk[5][16][0])-(ik[11][1][1]*s14)));
        IkWpk[5][16][2] = ((ik[11][2][2]*Wpk[5][16][2])+((ik[11][2][0]*
          Wpk[5][16][0])-(ik[11][2][1]*s14)));
        IkWpk[5][17][0] = ((ik[12][0][2]*Wpk[5][17][2])+((ik[12][0][0]*
          Wpk[5][17][0])+(ik[12][0][1]*s15)));
        IkWpk[5][17][1] = ((ik[12][1][2]*Wpk[5][17][2])+((ik[12][1][0]*
          Wpk[5][17][0])+(ik[12][1][1]*s15)));
        IkWpk[5][17][2] = ((ik[12][2][2]*Wpk[5][17][2])+((ik[12][2][0]*
          Wpk[5][17][0])+(ik[12][2][1]*s15)));
        IkWpk[5][18][0] = ((ik[13][0][2]*Wpk[5][18][2])+((ik[13][0][0]*
          Wpk[5][18][0])-(ik[13][0][1]*s14)));
        IkWpk[5][18][1] = ((ik[13][1][2]*Wpk[5][18][2])+((ik[13][1][0]*
          Wpk[5][18][0])-(ik[13][1][1]*s14)));
        IkWpk[5][18][2] = ((ik[13][2][2]*Wpk[5][18][2])+((ik[13][2][0]*
          Wpk[5][18][0])-(ik[13][2][1]*s14)));
        IkWpk[5][19][0] = ((ik[14][0][2]*Wpk[5][19][2])+((ik[14][0][0]*
          Wpk[5][19][0])+(ik[14][0][1]*s15)));
        IkWpk[5][19][1] = ((ik[14][1][2]*Wpk[5][19][2])+((ik[14][1][0]*
          Wpk[5][19][0])+(ik[14][1][1]*s15)));
        IkWpk[5][19][2] = ((ik[14][2][2]*Wpk[5][19][2])+((ik[14][2][0]*
          Wpk[5][19][0])+(ik[14][2][1]*s15)));
        IkWpk[5][20][0] = ((ik[15][0][2]*Wpk[5][20][2])+((ik[15][0][0]*
          Wpk[5][20][0])-(ik[15][0][1]*s14)));
        IkWpk[5][20][1] = ((ik[15][1][2]*Wpk[5][20][2])+((ik[15][1][0]*
          Wpk[5][20][0])-(ik[15][1][1]*s14)));
        IkWpk[5][20][2] = ((ik[15][2][2]*Wpk[5][20][2])+((ik[15][2][0]*
          Wpk[5][20][0])-(ik[15][2][1]*s14)));
        IkWpk[5][21][0] = ((ik[16][0][2]*Wpk[5][21][2])+((ik[16][0][0]*
          Wpk[5][21][0])+(ik[16][0][1]*s15)));
        IkWpk[5][21][1] = ((ik[16][1][2]*Wpk[5][21][2])+((ik[16][1][0]*
          Wpk[5][21][0])+(ik[16][1][1]*s15)));
        IkWpk[5][21][2] = ((ik[16][2][2]*Wpk[5][21][2])+((ik[16][2][0]*
          Wpk[5][21][0])+(ik[16][2][1]*s15)));
        IkWpk[5][22][0] = ((ik[17][0][2]*Wpk[5][22][2])+((ik[17][0][0]*
          Wpk[5][20][0])+(ik[17][0][1]*Wpk[5][22][1])));
        IkWpk[5][22][1] = ((ik[17][1][2]*Wpk[5][22][2])+((ik[17][1][0]*
          Wpk[5][20][0])+(ik[17][1][1]*Wpk[5][22][1])));
        IkWpk[5][22][2] = ((ik[17][2][2]*Wpk[5][22][2])+((ik[17][2][0]*
          Wpk[5][20][0])+(ik[17][2][1]*Wpk[5][22][1])));
        IkWpk[5][23][0] = ((ik[18][0][2]*Wpk[5][23][2])+((ik[18][0][0]*
          Wpk[5][21][0])+(ik[18][0][1]*Wpk[5][23][1])));
        IkWpk[5][23][1] = ((ik[18][1][2]*Wpk[5][23][2])+((ik[18][1][0]*
          Wpk[5][21][0])+(ik[18][1][1]*Wpk[5][23][1])));
        IkWpk[5][23][2] = ((ik[18][2][2]*Wpk[5][23][2])+((ik[18][2][0]*
          Wpk[5][21][0])+(ik[18][2][1]*Wpk[5][23][1])));
        IkWpk[5][25][0] = ((ik[20][0][0]*s25)+(ik[20][0][2]*c25));
        IkWpk[5][25][1] = ((ik[20][1][0]*s25)+(ik[20][1][2]*c25));
        IkWpk[5][25][2] = ((ik[20][2][0]*s25)+(ik[20][2][2]*c25));
        IkWpk[6][8][0] = -((ik[3][0][1]*c8)+(ik[3][0][2]*s8));
        IkWpk[6][8][1] = -((ik[3][1][1]*c8)+(ik[3][1][2]*s8));
        IkWpk[6][8][2] = -((ik[3][2][1]*c8)+(ik[3][2][2]*s8));
        IkWpk[6][10][0] = (((ik[5][0][0]*Wpk[6][10][0])+(ik[5][0][1]*
          Wpk[6][10][1]))-(ik[5][0][2]*s8));
        IkWpk[6][10][1] = (((ik[5][1][0]*Wpk[6][10][0])+(ik[5][1][1]*
          Wpk[6][10][1]))-(ik[5][1][2]*s8));
        IkWpk[6][10][2] = (((ik[5][2][0]*Wpk[6][10][0])+(ik[5][2][1]*
          Wpk[6][10][1]))-(ik[5][2][2]*s8));
        IkWpk[7][9][0] = ((ik[4][0][2]*s9)-(ik[4][0][1]*c9));
        IkWpk[7][9][1] = ((ik[4][1][2]*s9)-(ik[4][1][1]*c9));
        IkWpk[7][9][2] = ((ik[4][2][2]*s9)-(ik[4][2][1]*c9));
        IkWpk[7][11][0] = ((ik[6][0][2]*s9)+((ik[6][0][0]*Wpk[7][11][0])+(
          ik[6][0][1]*Wpk[7][11][1])));
        IkWpk[7][11][1] = ((ik[6][1][2]*s9)+((ik[6][1][0]*Wpk[7][11][0])+(
          ik[6][1][1]*Wpk[7][11][1])));
        IkWpk[7][11][2] = ((ik[6][2][2]*s9)+((ik[6][2][0]*Wpk[7][11][0])+(
          ik[6][2][1]*Wpk[7][11][1])));
        IkWpk[8][10][0] = -((ik[5][0][0]*c10)+(ik[5][0][1]*s10));
        IkWpk[8][10][1] = -((ik[5][1][0]*c10)+(ik[5][1][1]*s10));
        IkWpk[8][10][2] = -((ik[5][2][0]*c10)+(ik[5][2][1]*s10));
        IkWpk[9][11][0] = ((ik[6][0][0]*c11)-(ik[6][0][1]*s11));
        IkWpk[9][11][1] = ((ik[6][1][0]*c11)-(ik[6][1][1]*s11));
        IkWpk[9][11][2] = ((ik[6][2][0]*c11)-(ik[6][2][1]*s11));
        IkWpk[12][14][0] = ((ik[9][0][1]*s14)-(ik[9][0][2]*c14));
        IkWpk[12][14][1] = ((ik[9][1][1]*s14)-(ik[9][1][2]*c14));
        IkWpk[12][14][2] = ((ik[9][2][1]*s14)-(ik[9][2][2]*c14));
        IkWpk[12][16][0] = ((ik[11][0][2]*Wpk[12][16][2])+((ik[11][0][0]*
          Wpk[12][16][0])+(ik[11][0][1]*s14)));
        IkWpk[12][16][1] = ((ik[11][1][2]*Wpk[12][16][2])+((ik[11][1][0]*
          Wpk[12][16][0])+(ik[11][1][1]*s14)));
        IkWpk[12][16][2] = ((ik[11][2][2]*Wpk[12][16][2])+((ik[11][2][0]*
          Wpk[12][16][0])+(ik[11][2][1]*s14)));
        IkWpk[12][18][0] = ((ik[13][0][2]*Wpk[12][18][2])+((ik[13][0][0]*
          Wpk[12][18][0])+(ik[13][0][1]*s14)));
        IkWpk[12][18][1] = ((ik[13][1][2]*Wpk[12][18][2])+((ik[13][1][0]*
          Wpk[12][18][0])+(ik[13][1][1]*s14)));
        IkWpk[12][18][2] = ((ik[13][2][2]*Wpk[12][18][2])+((ik[13][2][0]*
          Wpk[12][18][0])+(ik[13][2][1]*s14)));
        IkWpk[12][20][0] = ((ik[15][0][2]*Wpk[12][20][2])+((ik[15][0][0]*
          Wpk[12][20][0])+(ik[15][0][1]*s14)));
        IkWpk[12][20][1] = ((ik[15][1][2]*Wpk[12][20][2])+((ik[15][1][0]*
          Wpk[12][20][0])+(ik[15][1][1]*s14)));
        IkWpk[12][20][2] = ((ik[15][2][2]*Wpk[12][20][2])+((ik[15][2][0]*
          Wpk[12][20][0])+(ik[15][2][1]*s14)));
        IkWpk[12][22][0] = ((ik[17][0][2]*Wpk[12][22][2])+((ik[17][0][0]*
          Wpk[12][20][0])+(ik[17][0][1]*Wpk[12][22][1])));
        IkWpk[12][22][1] = ((ik[17][1][2]*Wpk[12][22][2])+((ik[17][1][0]*
          Wpk[12][20][0])+(ik[17][1][1]*Wpk[12][22][1])));
        IkWpk[12][22][2] = ((ik[17][2][2]*Wpk[12][22][2])+((ik[17][2][0]*
          Wpk[12][20][0])+(ik[17][2][1]*Wpk[12][22][1])));
        IkWpk[13][15][0] = ((ik[10][0][1]*s15)+(ik[10][0][2]*c15));
        IkWpk[13][15][1] = ((ik[10][1][1]*s15)+(ik[10][1][2]*c15));
        IkWpk[13][15][2] = ((ik[10][2][1]*s15)+(ik[10][2][2]*c15));
        IkWpk[13][17][0] = ((ik[12][0][2]*Wpk[13][17][2])+((ik[12][0][0]*
          Wpk[13][17][0])+(ik[12][0][1]*s15)));
        IkWpk[13][17][1] = ((ik[12][1][2]*Wpk[13][17][2])+((ik[12][1][0]*
          Wpk[13][17][0])+(ik[12][1][1]*s15)));
        IkWpk[13][17][2] = ((ik[12][2][2]*Wpk[13][17][2])+((ik[12][2][0]*
          Wpk[13][17][0])+(ik[12][2][1]*s15)));
        IkWpk[13][19][0] = ((ik[14][0][2]*Wpk[13][19][2])+((ik[14][0][0]*
          Wpk[13][19][0])+(ik[14][0][1]*s15)));
        IkWpk[13][19][1] = ((ik[14][1][2]*Wpk[13][19][2])+((ik[14][1][0]*
          Wpk[13][19][0])+(ik[14][1][1]*s15)));
        IkWpk[13][19][2] = ((ik[14][2][2]*Wpk[13][19][2])+((ik[14][2][0]*
          Wpk[13][19][0])+(ik[14][2][1]*s15)));
        IkWpk[13][21][0] = ((ik[16][0][2]*Wpk[13][21][2])+((ik[16][0][0]*
          Wpk[13][21][0])+(ik[16][0][1]*s15)));
        IkWpk[13][21][1] = ((ik[16][1][2]*Wpk[13][21][2])+((ik[16][1][0]*
          Wpk[13][21][0])+(ik[16][1][1]*s15)));
        IkWpk[13][21][2] = ((ik[16][2][2]*Wpk[13][21][2])+((ik[16][2][0]*
          Wpk[13][21][0])+(ik[16][2][1]*s15)));
        IkWpk[13][23][0] = ((ik[18][0][2]*Wpk[13][23][2])+((ik[18][0][0]*
          Wpk[13][21][0])+(ik[18][0][1]*Wpk[13][23][1])));
        IkWpk[13][23][1] = ((ik[18][1][2]*Wpk[13][23][2])+((ik[18][1][0]*
          Wpk[13][21][0])+(ik[18][1][1]*Wpk[13][23][1])));
        IkWpk[13][23][2] = ((ik[18][2][2]*Wpk[13][23][2])+((ik[18][2][0]*
          Wpk[13][21][0])+(ik[18][2][1]*Wpk[13][23][1])));
        IkWpk[14][16][0] = ((ik[11][0][2]*s16)-(ik[11][0][0]*c16));
        IkWpk[14][16][1] = ((ik[11][1][2]*s16)-(ik[11][1][0]*c16));
        IkWpk[14][16][2] = ((ik[11][2][2]*s16)-(ik[11][2][0]*c16));
        IkWpk[14][18][0] = ((ik[13][0][0]*Wpk[14][18][0])+(ik[13][0][2]*
          Wpk[14][18][2]));
        IkWpk[14][18][1] = ((ik[13][1][0]*Wpk[14][18][0])+(ik[13][1][2]*
          Wpk[14][18][2]));
        IkWpk[14][18][2] = ((ik[13][2][0]*Wpk[14][18][0])+(ik[13][2][2]*
          Wpk[14][18][2]));
        IkWpk[14][20][0] = ((ik[15][0][0]*Wpk[14][20][0])+(ik[15][0][2]*
          Wpk[14][20][2]));
        IkWpk[14][20][1] = ((ik[15][1][0]*Wpk[14][20][0])+(ik[15][1][2]*
          Wpk[14][20][2]));
        IkWpk[14][20][2] = ((ik[15][2][0]*Wpk[14][20][0])+(ik[15][2][2]*
          Wpk[14][20][2]));
        IkWpk[14][22][0] = ((ik[17][0][2]*Wpk[14][22][2])+((ik[17][0][0]*
          Wpk[14][20][0])+(ik[17][0][1]*Wpk[14][22][1])));
        IkWpk[14][22][1] = ((ik[17][1][2]*Wpk[14][22][2])+((ik[17][1][0]*
          Wpk[14][20][0])+(ik[17][1][1]*Wpk[14][22][1])));
        IkWpk[14][22][2] = ((ik[17][2][2]*Wpk[14][22][2])+((ik[17][2][0]*
          Wpk[14][20][0])+(ik[17][2][1]*Wpk[14][22][1])));
        IkWpk[15][17][0] = ((ik[12][0][0]*c17)-(ik[12][0][2]*s17));
        IkWpk[15][17][1] = ((ik[12][1][0]*c17)-(ik[12][1][2]*s17));
        IkWpk[15][17][2] = ((ik[12][2][0]*c17)-(ik[12][2][2]*s17));
        IkWpk[15][19][0] = ((ik[14][0][0]*Wpk[15][19][0])+(ik[14][0][2]*
          Wpk[15][19][2]));
        IkWpk[15][19][1] = ((ik[14][1][0]*Wpk[15][19][0])+(ik[14][1][2]*
          Wpk[15][19][2]));
        IkWpk[15][19][2] = ((ik[14][2][0]*Wpk[15][19][0])+(ik[14][2][2]*
          Wpk[15][19][2]));
        IkWpk[15][21][0] = ((ik[16][0][0]*Wpk[15][21][0])+(ik[16][0][2]*
          Wpk[15][21][2]));
        IkWpk[15][21][1] = ((ik[16][1][0]*Wpk[15][21][0])+(ik[16][1][2]*
          Wpk[15][21][2]));
        IkWpk[15][21][2] = ((ik[16][2][0]*Wpk[15][21][0])+(ik[16][2][2]*
          Wpk[15][21][2]));
        IkWpk[15][23][0] = ((ik[18][0][2]*Wpk[15][23][2])+((ik[18][0][0]*
          Wpk[15][21][0])+(ik[18][0][1]*Wpk[15][23][1])));
        IkWpk[15][23][1] = ((ik[18][1][2]*Wpk[15][23][2])+((ik[18][1][0]*
          Wpk[15][21][0])+(ik[18][1][1]*Wpk[15][23][1])));
        IkWpk[15][23][2] = ((ik[18][2][2]*Wpk[15][23][2])+((ik[18][2][0]*
          Wpk[15][21][0])+(ik[18][2][1]*Wpk[15][23][1])));
        IkWpk[16][22][0] = -((ik[17][0][1]*c22)+(ik[17][0][2]*s22));
        IkWpk[16][22][1] = -((ik[17][1][1]*c22)+(ik[17][1][2]*s22));
        IkWpk[16][22][2] = -((ik[17][2][1]*c22)+(ik[17][2][2]*s22));
        IkWpk[17][23][0] = ((ik[18][0][2]*s23)-(ik[18][0][1]*c23));
        IkWpk[17][23][1] = ((ik[18][1][2]*s23)-(ik[18][1][1]*c23));
        IkWpk[17][23][2] = ((ik[18][2][2]*s23)-(ik[18][2][1]*c23));
        IkWpk[18][22][0] = -((ik[17][0][1]*c22)+(ik[17][0][2]*s22));
        IkWpk[18][22][1] = -((ik[17][1][1]*c22)+(ik[17][1][2]*s22));
        IkWpk[18][22][2] = -((ik[17][2][1]*c22)+(ik[17][2][2]*s22));
        IkWpk[19][23][0] = ((ik[18][0][2]*s23)-(ik[18][0][1]*c23));
        IkWpk[19][23][1] = ((ik[18][1][2]*s23)-(ik[18][1][1]*c23));
        IkWpk[19][23][2] = ((ik[18][2][2]*s23)-(ik[18][2][1]*c23));
        IkWpk[20][22][0] = -((ik[17][0][1]*c22)+(ik[17][0][2]*s22));
        IkWpk[20][22][1] = -((ik[17][1][1]*c22)+(ik[17][1][2]*s22));
        IkWpk[20][22][2] = -((ik[17][2][1]*c22)+(ik[17][2][2]*s22));
        IkWpk[21][23][0] = ((ik[18][0][2]*s23)-(ik[18][0][1]*c23));
        IkWpk[21][23][1] = ((ik[18][1][2]*s23)-(ik[18][1][1]*c23));
        IkWpk[21][23][2] = ((ik[18][2][2]*s23)-(ik[18][2][1]*c23));
        IkWpk[24][25][0] = ((ik[20][0][0]*s25)+(ik[20][0][2]*c25));
        IkWpk[24][25][1] = ((ik[20][1][0]*s25)+(ik[20][1][2]*c25));
        IkWpk[24][25][2] = ((ik[20][2][0]*s25)+(ik[20][2][2]*c25));
        temp[0] = ((mk[2]*((Vpk[0][7][2]*Vpk[0][7][2])+((Cik[3][0][1]*
          Cik[3][0][1])+(Vpk[0][7][0]*Vpk[0][7][0]))))+((mk[0]*((Cik[3][0][2]*
          Cik[3][0][2])+((Cik[3][0][0]*Cik[3][0][0])+(Cik[3][0][1]*Cik[3][0][1])
          )))+(mk[1]*((Vpk[0][6][2]*Vpk[0][6][2])+((Cik[3][0][1]*Cik[3][0][1])+(
          Vpk[0][6][0]*Vpk[0][6][0]))))));
        temp[1] = ((mk[5]*((Vpk[0][8][2]*Vpk[0][8][2])+((Vpk[0][10][0]*
          Vpk[0][10][0])+(Vpk[0][10][1]*Vpk[0][10][1]))))+((mk[4]*((Vpk[0][9][2]
          *Vpk[0][9][2])+((Vpk[0][7][0]*Vpk[0][7][0])+(Vpk[0][9][1]*Vpk[0][9][1]
          ))))+((mk[3]*((Vpk[0][8][2]*Vpk[0][8][2])+((Vpk[0][6][0]*Vpk[0][6][0])
          +(Vpk[0][8][1]*Vpk[0][8][1]))))+temp[0])));
        temp[2] = ((mk[8]*((Cik[3][0][2]*Cik[3][0][2])+((Vpk[0][13][0]*
          Vpk[0][13][0])+(Vpk[0][13][1]*Vpk[0][13][1]))))+((mk[7]*((Cik[3][0][2]
          *Cik[3][0][2])+((Vpk[0][12][0]*Vpk[0][12][0])+(Vpk[0][12][1]*
          Vpk[0][12][1]))))+((mk[6]*((Vpk[0][9][2]*Vpk[0][9][2])+((Vpk[0][11][0]
          *Vpk[0][11][0])+(Vpk[0][11][1]*Vpk[0][11][1]))))+temp[1])));
        temp[3] = ((mk[11]*((Vpk[0][16][2]*Vpk[0][16][2])+((Vpk[0][14][1]*
          Vpk[0][14][1])+(Vpk[0][16][0]*Vpk[0][16][0]))))+((mk[10]*((
          Vpk[0][15][2]*Vpk[0][15][2])+((Vpk[0][13][0]*Vpk[0][13][0])+(
          Vpk[0][15][1]*Vpk[0][15][1]))))+((mk[9]*((Vpk[0][14][2]*Vpk[0][14][2])
          +((Vpk[0][12][0]*Vpk[0][12][0])+(Vpk[0][14][1]*Vpk[0][14][1]))))+
          temp[2])));
        temp[4] = ((mk[14]*((Vpk[0][19][2]*Vpk[0][19][2])+((Vpk[0][15][1]*
          Vpk[0][15][1])+(Vpk[0][19][0]*Vpk[0][19][0]))))+((mk[13]*((
          Vpk[0][18][2]*Vpk[0][18][2])+((Vpk[0][14][1]*Vpk[0][14][1])+(
          Vpk[0][18][0]*Vpk[0][18][0]))))+((mk[12]*((Vpk[0][17][2]*Vpk[0][17][2]
          )+((Vpk[0][15][1]*Vpk[0][15][1])+(Vpk[0][17][0]*Vpk[0][17][0]))))+
          temp[3])));
        temp[5] = ((mk[17]*((Vpk[0][22][2]*Vpk[0][22][2])+((Vpk[0][20][0]*
          Vpk[0][20][0])+(Vpk[0][22][1]*Vpk[0][22][1]))))+((mk[16]*((
          Vpk[0][21][2]*Vpk[0][21][2])+((Vpk[0][15][1]*Vpk[0][15][1])+(
          Vpk[0][21][0]*Vpk[0][21][0]))))+((mk[15]*((Vpk[0][20][2]*Vpk[0][20][2]
          )+((Vpk[0][14][1]*Vpk[0][14][1])+(Vpk[0][20][0]*Vpk[0][20][0]))))+
          temp[4])));
        mm[0][0] = ((mk[20]*((Vpk[0][25][2]*Vpk[0][25][2])+((Vpk[0][24][1]*
          Vpk[0][24][1])+(Vpk[0][25][0]*Vpk[0][25][0]))))+((mk[19]*((
          Cik[3][0][2]*Cik[3][0][2])+((Vpk[0][24][0]*Vpk[0][24][0])+(
          Vpk[0][24][1]*Vpk[0][24][1]))))+((mk[18]*((Vpk[0][23][2]*Vpk[0][23][2]
          )+((Vpk[0][21][0]*Vpk[0][21][0])+(Vpk[0][23][1]*Vpk[0][23][1]))))+
          temp[5])));
        temp[0] = ((mk[2]*((Vpk[0][7][2]*Vpk[1][7][2])+((Cik[3][0][1]*
          Cik[3][1][1])+(Vpk[0][7][0]*Vpk[1][7][0]))))+((mk[0]*((Cik[3][0][2]*
          Cik[3][1][2])+((Cik[3][0][0]*Cik[3][1][0])+(Cik[3][0][1]*Cik[3][1][1])
          )))+(mk[1]*((Vpk[0][6][2]*Vpk[1][6][2])+((Cik[3][0][1]*Cik[3][1][1])+(
          Vpk[0][6][0]*Vpk[1][6][0]))))));
        temp[1] = ((mk[5]*((Vpk[0][8][2]*Vpk[1][8][2])+((Vpk[0][10][0]*
          Vpk[1][10][0])+(Vpk[0][10][1]*Vpk[1][10][1]))))+((mk[4]*((Vpk[0][9][2]
          *Vpk[1][9][2])+((Vpk[0][7][0]*Vpk[1][7][0])+(Vpk[0][9][1]*Vpk[1][9][1]
          ))))+((mk[3]*((Vpk[0][8][2]*Vpk[1][8][2])+((Vpk[0][6][0]*Vpk[1][6][0])
          +(Vpk[0][8][1]*Vpk[1][8][1]))))+temp[0])));
        temp[2] = ((mk[8]*((Cik[3][0][2]*Cik[3][1][2])+((Vpk[0][13][0]*
          Vpk[1][13][0])+(Vpk[0][13][1]*Vpk[1][13][1]))))+((mk[7]*((Cik[3][0][2]
          *Cik[3][1][2])+((Vpk[0][12][0]*Vpk[1][12][0])+(Vpk[0][12][1]*
          Vpk[1][12][1]))))+((mk[6]*((Vpk[0][9][2]*Vpk[1][9][2])+((Vpk[0][11][0]
          *Vpk[1][11][0])+(Vpk[0][11][1]*Vpk[1][11][1]))))+temp[1])));
        temp[3] = ((mk[11]*((Vpk[0][16][2]*Vpk[1][16][2])+((Vpk[0][14][1]*
          Vpk[1][14][1])+(Vpk[0][16][0]*Vpk[1][16][0]))))+((mk[10]*((
          Vpk[0][15][2]*Vpk[1][15][2])+((Vpk[0][13][0]*Vpk[1][13][0])+(
          Vpk[0][15][1]*Vpk[1][15][1]))))+((mk[9]*((Vpk[0][14][2]*Vpk[1][14][2])
          +((Vpk[0][12][0]*Vpk[1][12][0])+(Vpk[0][14][1]*Vpk[1][14][1]))))+
          temp[2])));
        temp[4] = ((mk[14]*((Vpk[0][19][2]*Vpk[1][19][2])+((Vpk[0][15][1]*
          Vpk[1][15][1])+(Vpk[0][19][0]*Vpk[1][19][0]))))+((mk[13]*((
          Vpk[0][18][2]*Vpk[1][18][2])+((Vpk[0][14][1]*Vpk[1][14][1])+(
          Vpk[0][18][0]*Vpk[1][18][0]))))+((mk[12]*((Vpk[0][17][2]*Vpk[1][17][2]
          )+((Vpk[0][15][1]*Vpk[1][15][1])+(Vpk[0][17][0]*Vpk[1][17][0]))))+
          temp[3])));
        temp[5] = ((mk[17]*((Vpk[0][22][2]*Vpk[1][22][2])+((Vpk[0][20][0]*
          Vpk[1][20][0])+(Vpk[0][22][1]*Vpk[1][22][1]))))+((mk[16]*((
          Vpk[0][21][2]*Vpk[1][21][2])+((Vpk[0][15][1]*Vpk[1][15][1])+(
          Vpk[0][21][0]*Vpk[1][21][0]))))+((mk[15]*((Vpk[0][20][2]*Vpk[1][20][2]
          )+((Vpk[0][14][1]*Vpk[1][14][1])+(Vpk[0][20][0]*Vpk[1][20][0]))))+
          temp[4])));
        mm[0][1] = ((mk[20]*((Vpk[0][25][2]*Vpk[1][25][2])+((Vpk[0][24][1]*
          Vpk[1][24][1])+(Vpk[0][25][0]*Vpk[1][25][0]))))+((mk[19]*((
          Cik[3][0][2]*Cik[3][1][2])+((Vpk[0][24][0]*Vpk[1][24][0])+(
          Vpk[0][24][1]*Vpk[1][24][1]))))+((mk[18]*((Vpk[0][23][2]*Vpk[1][23][2]
          )+((Vpk[0][21][0]*Vpk[1][21][0])+(Vpk[0][23][1]*Vpk[1][23][1]))))+
          temp[5])));
        temp[0] = ((mk[2]*((Vpk[0][7][2]*Vpk[2][7][2])+((Cik[3][0][1]*
          Cik[3][2][1])+(Vpk[0][7][0]*Vpk[2][7][0]))))+((mk[0]*((Cik[3][0][2]*
          Cik[3][2][2])+((Cik[3][0][0]*Cik[3][2][0])+(Cik[3][0][1]*Cik[3][2][1])
          )))+(mk[1]*((Vpk[0][6][2]*Vpk[2][6][2])+((Cik[3][0][1]*Cik[3][2][1])+(
          Vpk[0][6][0]*Vpk[2][6][0]))))));
        temp[1] = ((mk[5]*((Vpk[0][8][2]*Vpk[2][8][2])+((Vpk[0][10][0]*
          Vpk[2][10][0])+(Vpk[0][10][1]*Vpk[2][10][1]))))+((mk[4]*((Vpk[0][9][2]
          *Vpk[2][9][2])+((Vpk[0][7][0]*Vpk[2][7][0])+(Vpk[0][9][1]*Vpk[2][9][1]
          ))))+((mk[3]*((Vpk[0][8][2]*Vpk[2][8][2])+((Vpk[0][6][0]*Vpk[2][6][0])
          +(Vpk[0][8][1]*Vpk[2][8][1]))))+temp[0])));
        temp[2] = ((mk[8]*((Cik[3][0][2]*Cik[3][2][2])+((Vpk[0][13][0]*
          Vpk[2][13][0])+(Vpk[0][13][1]*Vpk[2][13][1]))))+((mk[7]*((Cik[3][0][2]
          *Cik[3][2][2])+((Vpk[0][12][0]*Vpk[2][12][0])+(Vpk[0][12][1]*
          Vpk[2][12][1]))))+((mk[6]*((Vpk[0][9][2]*Vpk[2][9][2])+((Vpk[0][11][0]
          *Vpk[2][11][0])+(Vpk[0][11][1]*Vpk[2][11][1]))))+temp[1])));
        temp[3] = ((mk[11]*((Vpk[0][16][2]*Vpk[2][16][2])+((Vpk[0][14][1]*
          Vpk[2][14][1])+(Vpk[0][16][0]*Vpk[2][16][0]))))+((mk[10]*((
          Vpk[0][15][2]*Vpk[2][15][2])+((Vpk[0][13][0]*Vpk[2][13][0])+(
          Vpk[0][15][1]*Vpk[2][15][1]))))+((mk[9]*((Vpk[0][14][2]*Vpk[2][14][2])
          +((Vpk[0][12][0]*Vpk[2][12][0])+(Vpk[0][14][1]*Vpk[2][14][1]))))+
          temp[2])));
        temp[4] = ((mk[14]*((Vpk[0][19][2]*Vpk[2][19][2])+((Vpk[0][15][1]*
          Vpk[2][15][1])+(Vpk[0][19][0]*Vpk[2][19][0]))))+((mk[13]*((
          Vpk[0][18][2]*Vpk[2][18][2])+((Vpk[0][14][1]*Vpk[2][14][1])+(
          Vpk[0][18][0]*Vpk[2][18][0]))))+((mk[12]*((Vpk[0][17][2]*Vpk[2][17][2]
          )+((Vpk[0][15][1]*Vpk[2][15][1])+(Vpk[0][17][0]*Vpk[2][17][0]))))+
          temp[3])));
        temp[5] = ((mk[17]*((Vpk[0][22][2]*Vpk[2][22][2])+((Vpk[0][20][0]*
          Vpk[2][20][0])+(Vpk[0][22][1]*Vpk[2][22][1]))))+((mk[16]*((
          Vpk[0][21][2]*Vpk[2][21][2])+((Vpk[0][15][1]*Vpk[2][15][1])+(
          Vpk[0][21][0]*Vpk[2][21][0]))))+((mk[15]*((Vpk[0][20][2]*Vpk[2][20][2]
          )+((Vpk[0][14][1]*Vpk[2][14][1])+(Vpk[0][20][0]*Vpk[2][20][0]))))+
          temp[4])));
        mm[0][2] = ((mk[20]*((Vpk[0][25][2]*Vpk[2][25][2])+((Vpk[0][24][1]*
          Vpk[2][24][1])+(Vpk[0][25][0]*Vpk[2][25][0]))))+((mk[19]*((
          Cik[3][0][2]*Cik[3][2][2])+((Vpk[0][24][0]*Vpk[2][24][0])+(
          Vpk[0][24][1]*Vpk[2][24][1]))))+((mk[18]*((Vpk[0][23][2]*Vpk[2][23][2]
          )+((Vpk[0][21][0]*Vpk[2][21][0])+(Vpk[0][23][1]*Vpk[2][23][1]))))+
          temp[5])));
        temp[0] = ((mk[3]*((Vpk[0][8][2]*Vpk[3][8][2])+((Vpk[0][6][0]*
          Vpk[3][8][0])+(Vpk[0][8][1]*Vpk[3][8][1]))))+((mk[2]*((Vpk[0][7][2]*
          Vpk[3][7][2])+((Cik[3][0][1]*Vpk[3][7][1])+(Vpk[0][7][0]*Vpk[3][7][0])
          )))+((mk[0]*((Cik[3][0][1]*rk[0][2])-(Cik[3][0][2]*rk[0][1])))+(mk[1]*
          ((Vpk[0][6][2]*Vpk[3][6][2])+((Cik[3][0][1]*Vpk[3][6][1])+(
          Vpk[0][6][0]*Vpk[3][6][0])))))));
        temp[1] = ((mk[6]*((Vpk[0][9][2]*Vpk[3][11][2])+((Vpk[0][11][0]*
          Vpk[3][11][0])+(Vpk[0][11][1]*Vpk[3][11][1]))))+((mk[5]*((Vpk[0][8][2]
          *Vpk[3][10][2])+((Vpk[0][10][0]*Vpk[3][10][0])+(Vpk[0][10][1]*
          Vpk[3][10][1]))))+((mk[4]*((Vpk[0][9][2]*Vpk[3][9][2])+((Vpk[0][7][0]*
          Vpk[3][9][0])+(Vpk[0][9][1]*Vpk[3][9][1]))))+temp[0])));
        temp[2] = ((mk[9]*((Vpk[0][14][2]*Vpk[3][14][2])+((Vpk[0][12][0]*
          Vpk[3][14][0])+(Vpk[0][14][1]*Vpk[3][14][1]))))+((mk[8]*((Cik[3][0][2]
          *Vpk[3][13][2])+((Vpk[0][13][0]*Vpk[3][13][0])+(Vpk[0][13][1]*
          Vpk[3][13][1]))))+((mk[7]*((Cik[3][0][2]*Vpk[3][12][2])+((
          Vpk[0][12][0]*Vpk[3][12][0])+(Vpk[0][12][1]*Vpk[3][12][1]))))+temp[1])
          ));
        temp[3] = ((mk[12]*((Vpk[0][17][2]*Vpk[3][17][2])+((Vpk[0][15][1]*
          Vpk[3][17][1])+(Vpk[0][17][0]*Vpk[3][17][0]))))+((mk[11]*((
          Vpk[0][16][2]*Vpk[3][16][2])+((Vpk[0][14][1]*Vpk[3][16][1])+(
          Vpk[0][16][0]*Vpk[3][16][0]))))+((mk[10]*((Vpk[0][15][2]*Vpk[3][15][2]
          )+((Vpk[0][13][0]*Vpk[3][15][0])+(Vpk[0][15][1]*Vpk[3][15][1]))))+
          temp[2])));
        temp[4] = ((mk[15]*((Vpk[0][20][2]*Vpk[3][20][2])+((Vpk[0][14][1]*
          Vpk[3][20][1])+(Vpk[0][20][0]*Vpk[3][20][0]))))+((mk[14]*((
          Vpk[0][19][2]*Vpk[3][19][2])+((Vpk[0][15][1]*Vpk[3][19][1])+(
          Vpk[0][19][0]*Vpk[3][19][0]))))+((mk[13]*((Vpk[0][18][2]*Vpk[3][18][2]
          )+((Vpk[0][14][1]*Vpk[3][18][1])+(Vpk[0][18][0]*Vpk[3][18][0]))))+
          temp[3])));
        temp[5] = ((mk[18]*((Vpk[0][23][2]*Vpk[3][23][2])+((Vpk[0][21][0]*
          Vpk[3][23][0])+(Vpk[0][23][1]*Vpk[3][23][1]))))+((mk[17]*((
          Vpk[0][22][2]*Vpk[3][22][2])+((Vpk[0][20][0]*Vpk[3][22][0])+(
          Vpk[0][22][1]*Vpk[3][22][1]))))+((mk[16]*((Vpk[0][21][2]*Vpk[3][21][2]
          )+((Vpk[0][15][1]*Vpk[3][21][1])+(Vpk[0][21][0]*Vpk[3][21][0]))))+
          temp[4])));
        mm[0][3] = ((mk[20]*((Vpk[0][25][2]*Vpk[3][25][2])+((Vpk[0][24][1]*
          Vpk[3][25][1])+(Vpk[0][25][0]*Vpk[3][25][0]))))+((mk[19]*((
          Cik[3][0][2]*Vpk[3][24][2])+((Vpk[0][24][0]*Vpk[3][24][0])+(
          Vpk[0][24][1]*Vpk[3][24][1]))))+temp[5]));
        temp[0] = ((mk[3]*((Vpk[0][8][2]*Vpk[4][8][2])+((Vpk[0][6][0]*
          Vpk[4][8][0])+(Vpk[0][8][1]*Vpk[4][8][1]))))+((mk[2]*((Vpk[0][7][0]*
          Vpk[4][7][0])+(Vpk[0][7][2]*Vpk[4][7][2])))+((mk[0]*((Cik[3][0][2]*
          rk[0][0])-(Cik[3][0][0]*rk[0][2])))+(mk[1]*((Vpk[0][6][0]*Vpk[4][6][0]
          )+(Vpk[0][6][2]*Vpk[4][6][2]))))));
        temp[1] = ((mk[6]*((Vpk[0][9][2]*Vpk[4][11][2])+((Vpk[0][11][0]*
          Vpk[4][11][0])+(Vpk[0][11][1]*Vpk[4][11][1]))))+((mk[5]*((Vpk[0][8][2]
          *Vpk[4][10][2])+((Vpk[0][10][0]*Vpk[4][10][0])+(Vpk[0][10][1]*
          Vpk[4][10][1]))))+((mk[4]*((Vpk[0][9][2]*Vpk[4][9][2])+((Vpk[0][7][0]*
          Vpk[4][9][0])+(Vpk[0][9][1]*Vpk[4][9][1]))))+temp[0])));
        temp[2] = ((mk[9]*((Vpk[0][14][2]*Vpk[4][14][2])+((Vpk[0][12][0]*
          Vpk[4][14][0])+(Vpk[0][14][1]*Vpk[4][14][1]))))+((mk[8]*((Cik[3][0][2]
          *Vpk[4][13][2])+((Vpk[0][13][0]*Vpk[4][13][0])+(Vpk[0][13][1]*
          Vpk[4][13][1]))))+((mk[7]*((Cik[3][0][2]*Vpk[4][12][2])+((
          Vpk[0][12][0]*Vpk[4][12][0])+(Vpk[0][12][1]*Vpk[4][12][1]))))+temp[1])
          ));
        temp[3] = ((mk[12]*((Vpk[0][17][2]*Vpk[4][17][2])+((Vpk[0][15][1]*
          Vpk[4][17][1])+(Vpk[0][17][0]*Vpk[4][17][0]))))+((mk[11]*((
          Vpk[0][16][2]*Vpk[4][16][2])+((Vpk[0][14][1]*Vpk[4][16][1])+(
          Vpk[0][16][0]*Vpk[4][16][0]))))+((mk[10]*((Vpk[0][15][2]*Vpk[4][15][2]
          )+((Vpk[0][13][0]*Vpk[4][15][0])+(Vpk[0][15][1]*Vpk[4][15][1]))))+
          temp[2])));
        temp[4] = ((mk[15]*((Vpk[0][20][2]*Vpk[4][20][2])+((Vpk[0][14][1]*
          Vpk[4][20][1])+(Vpk[0][20][0]*Vpk[4][20][0]))))+((mk[14]*((
          Vpk[0][19][2]*Vpk[4][19][2])+((Vpk[0][15][1]*Vpk[4][19][1])+(
          Vpk[0][19][0]*Vpk[4][19][0]))))+((mk[13]*((Vpk[0][18][2]*Vpk[4][18][2]
          )+((Vpk[0][14][1]*Vpk[4][18][1])+(Vpk[0][18][0]*Vpk[4][18][0]))))+
          temp[3])));
        temp[5] = ((mk[18]*((Vpk[0][23][2]*Vpk[4][23][2])+((Vpk[0][21][0]*
          Vpk[4][23][0])+(Vpk[0][23][1]*Vpk[4][23][1]))))+((mk[17]*((
          Vpk[0][22][2]*Vpk[4][22][2])+((Vpk[0][20][0]*Vpk[4][22][0])+(
          Vpk[0][22][1]*Vpk[4][22][1]))))+((mk[16]*((Vpk[0][21][2]*Vpk[4][21][2]
          )+((Vpk[0][15][1]*Vpk[4][21][1])+(Vpk[0][21][0]*Vpk[4][21][0]))))+
          temp[4])));
        mm[0][4] = ((mk[20]*((Vpk[0][25][2]*Vpk[4][25][2])+((Vpk[0][24][1]*
          Vpk[4][25][1])+(Vpk[0][25][0]*Vpk[4][25][0]))))+((mk[19]*((
          Cik[3][0][2]*Vpk[4][24][2])+((Vpk[0][24][0]*Vpk[4][24][0])+(
          Vpk[0][24][1]*Vpk[4][24][1]))))+temp[5]));
        temp[0] = ((mk[3]*((Vpk[0][8][2]*Vpk[5][8][2])+((Vpk[0][6][0]*
          Vpk[5][8][0])+(Vpk[0][8][1]*Vpk[5][8][1]))))+((mk[2]*((Vpk[0][7][2]*
          Vpk[5][7][2])+((Cik[3][0][1]*Vpk[5][7][1])+(Vpk[0][7][0]*Vpk[5][7][0])
          )))+((mk[0]*((Cik[3][0][0]*rk[0][1])-(Cik[3][0][1]*rk[0][0])))+(mk[1]*
          ((Vpk[0][6][2]*Vpk[5][6][2])+((Cik[3][0][1]*Vpk[5][6][1])+(
          Vpk[0][6][0]*Vpk[5][6][0])))))));
        temp[1] = ((mk[7]*((Vpk[0][12][0]*Vpk[5][12][0])+(Vpk[0][12][1]*
          Vpk[5][12][1])))+((mk[6]*((Vpk[0][9][2]*Vpk[5][11][2])+((Vpk[0][11][0]
          *Vpk[5][11][0])+(Vpk[0][11][1]*Vpk[5][11][1]))))+((mk[5]*((
          Vpk[0][8][2]*Vpk[5][10][2])+((Vpk[0][10][0]*Vpk[5][10][0])+(
          Vpk[0][10][1]*Vpk[5][10][1]))))+((mk[4]*((Vpk[0][9][2]*Vpk[5][9][2])+(
          (Vpk[0][7][0]*Vpk[5][9][0])+(Vpk[0][9][1]*Vpk[5][9][1]))))+temp[0]))))
          ;
        temp[2] = ((mk[11]*((Vpk[0][16][2]*Vpk[5][16][2])+((Vpk[0][14][1]*
          Vpk[5][16][1])+(Vpk[0][16][0]*Vpk[5][16][0]))))+((mk[10]*((
          Vpk[0][15][2]*Vpk[5][15][2])+((Vpk[0][13][0]*Vpk[5][15][0])+(
          Vpk[0][15][1]*Vpk[5][15][1]))))+((mk[9]*((Vpk[0][14][2]*Vpk[5][14][2])
          +((Vpk[0][12][0]*Vpk[5][14][0])+(Vpk[0][14][1]*Vpk[5][14][1]))))+((
          mk[8]*((Vpk[0][13][0]*Vpk[5][13][0])+(Vpk[0][13][1]*Vpk[5][13][1])))+
          temp[1]))));
        temp[3] = ((mk[14]*((Vpk[0][19][2]*Vpk[5][19][2])+((Vpk[0][15][1]*
          Vpk[5][19][1])+(Vpk[0][19][0]*Vpk[5][19][0]))))+((mk[13]*((
          Vpk[0][18][2]*Vpk[5][18][2])+((Vpk[0][14][1]*Vpk[5][18][1])+(
          Vpk[0][18][0]*Vpk[5][18][0]))))+((mk[12]*((Vpk[0][17][2]*Vpk[5][17][2]
          )+((Vpk[0][15][1]*Vpk[5][17][1])+(Vpk[0][17][0]*Vpk[5][17][0]))))+
          temp[2])));
        temp[4] = ((mk[17]*((Vpk[0][22][2]*Vpk[5][22][2])+((Vpk[0][20][0]*
          Vpk[5][22][0])+(Vpk[0][22][1]*Vpk[5][22][1]))))+((mk[16]*((
          Vpk[0][21][2]*Vpk[5][21][2])+((Vpk[0][15][1]*Vpk[5][21][1])+(
          Vpk[0][21][0]*Vpk[5][21][0]))))+((mk[15]*((Vpk[0][20][2]*Vpk[5][20][2]
          )+((Vpk[0][14][1]*Vpk[5][20][1])+(Vpk[0][20][0]*Vpk[5][20][0]))))+
          temp[3])));
        mm[0][5] = ((mk[20]*((Vpk[0][25][2]*Vpk[5][25][2])+((Vpk[0][24][1]*
          Vpk[5][25][1])+(Vpk[0][25][0]*Vpk[5][25][0]))))+((mk[19]*((
          Vpk[0][24][0]*Vpk[5][24][0])+(Vpk[0][24][1]*Vpk[5][24][1])))+((mk[18]*
          ((Vpk[0][23][2]*Vpk[5][23][2])+((Vpk[0][21][0]*Vpk[5][23][0])+(
          Vpk[0][23][1]*Vpk[5][23][1]))))+temp[4])));
        mm[0][6] = ((mk[5]*((Vpk[0][8][2]*Vpk[6][10][2])+((Vpk[0][10][0]*
          Vpk[6][10][0])+(Vpk[0][10][1]*Vpk[6][10][1]))))+((mk[1]*((rk[1][2]*
          Vpk[0][6][0])-(rk[1][0]*Vpk[0][6][2])))+(mk[3]*((Vpk[0][8][2]*
          Vpk[6][8][2])+((Vpk[0][6][0]*Vpk[6][8][0])+(Vpk[0][8][1]*Vpk[6][8][1])
          )))));
        mm[0][7] = ((mk[6]*((Vpk[0][9][2]*Vpk[7][11][2])+((Vpk[0][11][0]*
          Vpk[7][11][0])+(Vpk[0][11][1]*Vpk[7][11][1]))))+((mk[2]*((rk[2][2]*
          Vpk[0][7][0])-(rk[2][0]*Vpk[0][7][2])))+(mk[4]*((Vpk[0][9][2]*
          Vpk[7][9][2])+((Vpk[0][7][0]*Vpk[7][9][0])+(Vpk[0][9][1]*Vpk[7][9][1])
          )))));
        mm[0][8] = ((mk[3]*((rk[3][1]*Vpk[0][8][2])-(rk[3][2]*Vpk[0][8][1])))+(
          mk[5]*((Vpk[0][8][2]*Vpk[8][10][2])+((Vpk[0][10][0]*Vpk[8][10][0])+(
          Vpk[0][10][1]*Vpk[8][10][1])))));
        mm[0][9] = ((mk[4]*((rk[4][2]*Vpk[0][9][1])-(rk[4][1]*Vpk[0][9][2])))+(
          mk[6]*((Vpk[0][9][2]*Vpk[9][11][2])+((Vpk[0][11][0]*Vpk[9][11][0])+(
          Vpk[0][11][1]*Vpk[9][11][1])))));
        mm[0][10] = (mk[5]*((rk[5][0]*Vpk[0][10][1])-(rk[5][1]*Vpk[0][10][0])));
        mm[0][11] = (mk[6]*((rk[6][1]*Vpk[0][11][0])-(rk[6][0]*Vpk[0][11][1])));
        temp[0] = ((mk[13]*((Vpk[0][18][2]*Vpk[12][18][2])+((Vpk[0][14][1]*
          Vpk[12][18][1])+(Vpk[0][18][0]*Vpk[12][18][0]))))+((mk[11]*((
          Vpk[0][16][2]*Vpk[12][16][2])+((Vpk[0][14][1]*Vpk[12][16][1])+(
          Vpk[0][16][0]*Vpk[12][16][0]))))+((mk[7]*((rk[7][0]*Vpk[0][12][1])-(
          rk[7][1]*Vpk[0][12][0])))+(mk[9]*((Vpk[0][14][2]*Vpk[12][14][2])+((
          Vpk[0][12][0]*Vpk[12][14][0])+(Vpk[0][14][1]*Vpk[12][14][1])))))));
        mm[0][12] = ((mk[17]*((Vpk[0][22][2]*Vpk[12][22][2])+((Vpk[0][20][0]*
          Vpk[12][22][0])+(Vpk[0][22][1]*Vpk[12][22][1]))))+((mk[15]*((
          Vpk[0][20][2]*Vpk[12][20][2])+((Vpk[0][14][1]*Vpk[12][20][1])+(
          Vpk[0][20][0]*Vpk[12][20][0]))))+temp[0]));
        temp[0] = ((mk[14]*((Vpk[0][19][2]*Vpk[13][19][2])+((Vpk[0][15][1]*
          Vpk[13][19][1])+(Vpk[0][19][0]*Vpk[13][19][0]))))+((mk[12]*((
          Vpk[0][17][2]*Vpk[13][17][2])+((Vpk[0][15][1]*Vpk[13][17][1])+(
          Vpk[0][17][0]*Vpk[13][17][0]))))+((mk[8]*((rk[8][1]*Vpk[0][13][0])-(
          rk[8][0]*Vpk[0][13][1])))+(mk[10]*((Vpk[0][15][2]*Vpk[13][15][2])+((
          Vpk[0][13][0]*Vpk[13][15][0])+(Vpk[0][15][1]*Vpk[13][15][1])))))));
        mm[0][13] = ((mk[18]*((Vpk[0][23][2]*Vpk[13][23][2])+((Vpk[0][21][0]*
          Vpk[13][23][0])+(Vpk[0][23][1]*Vpk[13][23][1]))))+((mk[16]*((
          Vpk[0][21][2]*Vpk[13][21][2])+((Vpk[0][15][1]*Vpk[13][21][1])+(
          Vpk[0][21][0]*Vpk[13][21][0]))))+temp[0]));
        temp[0] = ((mk[15]*((Vpk[0][20][2]*Vpk[14][20][2])+((Vpk[0][14][1]*
          Vpk[14][20][1])+(Vpk[0][20][0]*Vpk[14][20][0]))))+((mk[13]*((
          Vpk[0][18][2]*Vpk[14][18][2])+((Vpk[0][14][1]*Vpk[14][18][1])+(
          Vpk[0][18][0]*Vpk[14][18][0]))))+((mk[9]*((rk[9][1]*Vpk[0][14][2])-(
          rk[9][2]*Vpk[0][14][1])))+(mk[11]*((Vpk[0][16][2]*Vpk[14][16][2])+((
          Vpk[0][14][1]*Vpk[14][16][1])+(Vpk[0][16][0]*Vpk[14][16][0])))))));
        mm[0][14] = ((mk[17]*((Vpk[0][22][2]*Vpk[14][22][2])+((Vpk[0][20][0]*
          Vpk[14][22][0])+(Vpk[0][22][1]*Vpk[14][22][1]))))+temp[0]);
        temp[0] = ((mk[16]*((Vpk[0][21][2]*Vpk[15][21][2])+((Vpk[0][15][1]*
          Vpk[15][21][1])+(Vpk[0][21][0]*Vpk[15][21][0]))))+((mk[14]*((
          Vpk[0][19][2]*Vpk[15][19][2])+((Vpk[0][15][1]*Vpk[15][19][1])+(
          Vpk[0][19][0]*Vpk[15][19][0]))))+((mk[10]*((rk[10][2]*Vpk[0][15][1])-(
          rk[10][1]*Vpk[0][15][2])))+(mk[12]*((Vpk[0][17][2]*Vpk[15][17][2])+((
          Vpk[0][15][1]*Vpk[15][17][1])+(Vpk[0][17][0]*Vpk[15][17][0])))))));
        mm[0][15] = ((mk[18]*((Vpk[0][23][2]*Vpk[15][23][2])+((Vpk[0][21][0]*
          Vpk[15][23][0])+(Vpk[0][23][1]*Vpk[15][23][1]))))+temp[0]);
        mm[0][16] = ((mk[17]*((Vpk[0][22][2]*Vpk[16][22][2])+((Vpk[0][20][0]*
          Vpk[16][22][0])+(Vpk[0][22][1]*Vpk[16][22][1]))))+((mk[15]*((
          Vpk[0][20][0]*Vpk[16][20][0])+(Vpk[0][20][2]*Vpk[16][20][2])))+((
          mk[11]*((rk[11][2]*Vpk[0][16][0])-(rk[11][0]*Vpk[0][16][2])))+(mk[13]*
          ((Vpk[0][18][0]*Vpk[16][18][0])+(Vpk[0][18][2]*Vpk[16][18][2]))))));
        mm[0][17] = ((mk[18]*((Vpk[0][23][2]*Vpk[17][23][2])+((Vpk[0][21][0]*
          Vpk[17][23][0])+(Vpk[0][23][1]*Vpk[17][23][1]))))+((mk[16]*((
          Vpk[0][21][0]*Vpk[17][21][0])+(Vpk[0][21][2]*Vpk[17][21][2])))+((
          mk[12]*((rk[12][2]*Vpk[0][17][0])-(rk[12][0]*Vpk[0][17][2])))+(mk[14]*
          ((Vpk[0][19][0]*Vpk[17][19][0])+(Vpk[0][19][2]*Vpk[17][19][2]))))));
        mm[0][18] = ((mk[17]*((Vpk[0][22][2]*Vpk[18][22][2])+((Vpk[0][20][0]*
          Vpk[18][22][0])+(Vpk[0][22][1]*Vpk[18][22][1]))))+((mk[13]*((rk[13][2]
          *Vpk[0][18][0])-(rk[13][0]*Vpk[0][18][2])))+(mk[15]*((Vpk[0][20][0]*
          Vpk[18][20][0])+(Vpk[0][20][2]*Vpk[18][20][2])))));
        mm[0][19] = ((mk[18]*((Vpk[0][23][2]*Vpk[19][23][2])+((Vpk[0][21][0]*
          Vpk[19][23][0])+(Vpk[0][23][1]*Vpk[19][23][1]))))+((mk[14]*((rk[14][2]
          *Vpk[0][19][0])-(rk[14][0]*Vpk[0][19][2])))+(mk[16]*((Vpk[0][21][0]*
          Vpk[19][21][0])+(Vpk[0][21][2]*Vpk[19][21][2])))));
        mm[0][20] = ((mk[15]*((rk[15][2]*Vpk[0][20][0])-(rk[15][0]*Vpk[0][20][2]
          )))+(mk[17]*((Vpk[0][22][2]*Vpk[20][22][2])+((Vpk[0][20][0]*
          Vpk[20][22][0])+(Vpk[0][22][1]*Vpk[20][22][1])))));
        mm[0][21] = ((mk[16]*((rk[16][2]*Vpk[0][21][0])-(rk[16][0]*Vpk[0][21][2]
          )))+(mk[18]*((Vpk[0][23][2]*Vpk[21][23][2])+((Vpk[0][21][0]*
          Vpk[21][23][0])+(Vpk[0][23][1]*Vpk[21][23][1])))));
        mm[0][22] = (mk[17]*((rk[17][1]*Vpk[0][22][2])-(rk[17][2]*Vpk[0][22][1])
          ));
        mm[0][23] = (mk[18]*((rk[18][2]*Vpk[0][23][1])-(rk[18][1]*Vpk[0][23][2])
          ));
        mm[0][24] = ((mk[19]*((rk[19][1]*Vpk[0][24][0])-(rk[19][0]*Vpk[0][24][1]
          )))+(mk[20]*((Vpk[0][25][2]*Vpk[24][25][2])+((Vpk[0][24][1]*
          Vpk[24][25][1])+(Vpk[0][25][0]*Vpk[24][25][0])))));
        mm[0][25] = (mk[20]*((rk[20][2]*Vpk[0][25][0])-(rk[20][0]*Vpk[0][25][2])
          ));
        temp[0] = ((mk[2]*((Vpk[1][7][2]*Vpk[1][7][2])+((Cik[3][1][1]*
          Cik[3][1][1])+(Vpk[1][7][0]*Vpk[1][7][0]))))+((mk[0]*((Cik[3][1][2]*
          Cik[3][1][2])+((Cik[3][1][0]*Cik[3][1][0])+(Cik[3][1][1]*Cik[3][1][1])
          )))+(mk[1]*((Vpk[1][6][2]*Vpk[1][6][2])+((Cik[3][1][1]*Cik[3][1][1])+(
          Vpk[1][6][0]*Vpk[1][6][0]))))));
        temp[1] = ((mk[5]*((Vpk[1][8][2]*Vpk[1][8][2])+((Vpk[1][10][0]*
          Vpk[1][10][0])+(Vpk[1][10][1]*Vpk[1][10][1]))))+((mk[4]*((Vpk[1][9][2]
          *Vpk[1][9][2])+((Vpk[1][7][0]*Vpk[1][7][0])+(Vpk[1][9][1]*Vpk[1][9][1]
          ))))+((mk[3]*((Vpk[1][8][2]*Vpk[1][8][2])+((Vpk[1][6][0]*Vpk[1][6][0])
          +(Vpk[1][8][1]*Vpk[1][8][1]))))+temp[0])));
        temp[2] = ((mk[8]*((Cik[3][1][2]*Cik[3][1][2])+((Vpk[1][13][0]*
          Vpk[1][13][0])+(Vpk[1][13][1]*Vpk[1][13][1]))))+((mk[7]*((Cik[3][1][2]
          *Cik[3][1][2])+((Vpk[1][12][0]*Vpk[1][12][0])+(Vpk[1][12][1]*
          Vpk[1][12][1]))))+((mk[6]*((Vpk[1][9][2]*Vpk[1][9][2])+((Vpk[1][11][0]
          *Vpk[1][11][0])+(Vpk[1][11][1]*Vpk[1][11][1]))))+temp[1])));
        temp[3] = ((mk[11]*((Vpk[1][16][2]*Vpk[1][16][2])+((Vpk[1][14][1]*
          Vpk[1][14][1])+(Vpk[1][16][0]*Vpk[1][16][0]))))+((mk[10]*((
          Vpk[1][15][2]*Vpk[1][15][2])+((Vpk[1][13][0]*Vpk[1][13][0])+(
          Vpk[1][15][1]*Vpk[1][15][1]))))+((mk[9]*((Vpk[1][14][2]*Vpk[1][14][2])
          +((Vpk[1][12][0]*Vpk[1][12][0])+(Vpk[1][14][1]*Vpk[1][14][1]))))+
          temp[2])));
        temp[4] = ((mk[14]*((Vpk[1][19][2]*Vpk[1][19][2])+((Vpk[1][15][1]*
          Vpk[1][15][1])+(Vpk[1][19][0]*Vpk[1][19][0]))))+((mk[13]*((
          Vpk[1][18][2]*Vpk[1][18][2])+((Vpk[1][14][1]*Vpk[1][14][1])+(
          Vpk[1][18][0]*Vpk[1][18][0]))))+((mk[12]*((Vpk[1][17][2]*Vpk[1][17][2]
          )+((Vpk[1][15][1]*Vpk[1][15][1])+(Vpk[1][17][0]*Vpk[1][17][0]))))+
          temp[3])));
        temp[5] = ((mk[17]*((Vpk[1][22][2]*Vpk[1][22][2])+((Vpk[1][20][0]*
          Vpk[1][20][0])+(Vpk[1][22][1]*Vpk[1][22][1]))))+((mk[16]*((
          Vpk[1][21][2]*Vpk[1][21][2])+((Vpk[1][15][1]*Vpk[1][15][1])+(
          Vpk[1][21][0]*Vpk[1][21][0]))))+((mk[15]*((Vpk[1][20][2]*Vpk[1][20][2]
          )+((Vpk[1][14][1]*Vpk[1][14][1])+(Vpk[1][20][0]*Vpk[1][20][0]))))+
          temp[4])));
        mm[1][1] = ((mk[20]*((Vpk[1][25][2]*Vpk[1][25][2])+((Vpk[1][24][1]*
          Vpk[1][24][1])+(Vpk[1][25][0]*Vpk[1][25][0]))))+((mk[19]*((
          Cik[3][1][2]*Cik[3][1][2])+((Vpk[1][24][0]*Vpk[1][24][0])+(
          Vpk[1][24][1]*Vpk[1][24][1]))))+((mk[18]*((Vpk[1][23][2]*Vpk[1][23][2]
          )+((Vpk[1][21][0]*Vpk[1][21][0])+(Vpk[1][23][1]*Vpk[1][23][1]))))+
          temp[5])));
        temp[0] = ((mk[2]*((Vpk[1][7][2]*Vpk[2][7][2])+((Cik[3][1][1]*
          Cik[3][2][1])+(Vpk[1][7][0]*Vpk[2][7][0]))))+((mk[0]*((Cik[3][1][2]*
          Cik[3][2][2])+((Cik[3][1][0]*Cik[3][2][0])+(Cik[3][1][1]*Cik[3][2][1])
          )))+(mk[1]*((Vpk[1][6][2]*Vpk[2][6][2])+((Cik[3][1][1]*Cik[3][2][1])+(
          Vpk[1][6][0]*Vpk[2][6][0]))))));
        temp[1] = ((mk[5]*((Vpk[1][8][2]*Vpk[2][8][2])+((Vpk[1][10][0]*
          Vpk[2][10][0])+(Vpk[1][10][1]*Vpk[2][10][1]))))+((mk[4]*((Vpk[1][9][2]
          *Vpk[2][9][2])+((Vpk[1][7][0]*Vpk[2][7][0])+(Vpk[1][9][1]*Vpk[2][9][1]
          ))))+((mk[3]*((Vpk[1][8][2]*Vpk[2][8][2])+((Vpk[1][6][0]*Vpk[2][6][0])
          +(Vpk[1][8][1]*Vpk[2][8][1]))))+temp[0])));
        temp[2] = ((mk[8]*((Cik[3][1][2]*Cik[3][2][2])+((Vpk[1][13][0]*
          Vpk[2][13][0])+(Vpk[1][13][1]*Vpk[2][13][1]))))+((mk[7]*((Cik[3][1][2]
          *Cik[3][2][2])+((Vpk[1][12][0]*Vpk[2][12][0])+(Vpk[1][12][1]*
          Vpk[2][12][1]))))+((mk[6]*((Vpk[1][9][2]*Vpk[2][9][2])+((Vpk[1][11][0]
          *Vpk[2][11][0])+(Vpk[1][11][1]*Vpk[2][11][1]))))+temp[1])));
        temp[3] = ((mk[11]*((Vpk[1][16][2]*Vpk[2][16][2])+((Vpk[1][14][1]*
          Vpk[2][14][1])+(Vpk[1][16][0]*Vpk[2][16][0]))))+((mk[10]*((
          Vpk[1][15][2]*Vpk[2][15][2])+((Vpk[1][13][0]*Vpk[2][13][0])+(
          Vpk[1][15][1]*Vpk[2][15][1]))))+((mk[9]*((Vpk[1][14][2]*Vpk[2][14][2])
          +((Vpk[1][12][0]*Vpk[2][12][0])+(Vpk[1][14][1]*Vpk[2][14][1]))))+
          temp[2])));
        temp[4] = ((mk[14]*((Vpk[1][19][2]*Vpk[2][19][2])+((Vpk[1][15][1]*
          Vpk[2][15][1])+(Vpk[1][19][0]*Vpk[2][19][0]))))+((mk[13]*((
          Vpk[1][18][2]*Vpk[2][18][2])+((Vpk[1][14][1]*Vpk[2][14][1])+(
          Vpk[1][18][0]*Vpk[2][18][0]))))+((mk[12]*((Vpk[1][17][2]*Vpk[2][17][2]
          )+((Vpk[1][15][1]*Vpk[2][15][1])+(Vpk[1][17][0]*Vpk[2][17][0]))))+
          temp[3])));
        temp[5] = ((mk[17]*((Vpk[1][22][2]*Vpk[2][22][2])+((Vpk[1][20][0]*
          Vpk[2][20][0])+(Vpk[1][22][1]*Vpk[2][22][1]))))+((mk[16]*((
          Vpk[1][21][2]*Vpk[2][21][2])+((Vpk[1][15][1]*Vpk[2][15][1])+(
          Vpk[1][21][0]*Vpk[2][21][0]))))+((mk[15]*((Vpk[1][20][2]*Vpk[2][20][2]
          )+((Vpk[1][14][1]*Vpk[2][14][1])+(Vpk[1][20][0]*Vpk[2][20][0]))))+
          temp[4])));
        mm[1][2] = ((mk[20]*((Vpk[1][25][2]*Vpk[2][25][2])+((Vpk[1][24][1]*
          Vpk[2][24][1])+(Vpk[1][25][0]*Vpk[2][25][0]))))+((mk[19]*((
          Cik[3][1][2]*Cik[3][2][2])+((Vpk[1][24][0]*Vpk[2][24][0])+(
          Vpk[1][24][1]*Vpk[2][24][1]))))+((mk[18]*((Vpk[1][23][2]*Vpk[2][23][2]
          )+((Vpk[1][21][0]*Vpk[2][21][0])+(Vpk[1][23][1]*Vpk[2][23][1]))))+
          temp[5])));
        temp[0] = ((mk[3]*((Vpk[1][8][2]*Vpk[3][8][2])+((Vpk[1][6][0]*
          Vpk[3][8][0])+(Vpk[1][8][1]*Vpk[3][8][1]))))+((mk[2]*((Vpk[1][7][2]*
          Vpk[3][7][2])+((Cik[3][1][1]*Vpk[3][7][1])+(Vpk[1][7][0]*Vpk[3][7][0])
          )))+((mk[0]*((Cik[3][1][1]*rk[0][2])-(Cik[3][1][2]*rk[0][1])))+(mk[1]*
          ((Vpk[1][6][2]*Vpk[3][6][2])+((Cik[3][1][1]*Vpk[3][6][1])+(
          Vpk[1][6][0]*Vpk[3][6][0])))))));
        temp[1] = ((mk[6]*((Vpk[1][9][2]*Vpk[3][11][2])+((Vpk[1][11][0]*
          Vpk[3][11][0])+(Vpk[1][11][1]*Vpk[3][11][1]))))+((mk[5]*((Vpk[1][8][2]
          *Vpk[3][10][2])+((Vpk[1][10][0]*Vpk[3][10][0])+(Vpk[1][10][1]*
          Vpk[3][10][1]))))+((mk[4]*((Vpk[1][9][2]*Vpk[3][9][2])+((Vpk[1][7][0]*
          Vpk[3][9][0])+(Vpk[1][9][1]*Vpk[3][9][1]))))+temp[0])));
        temp[2] = ((mk[9]*((Vpk[1][14][2]*Vpk[3][14][2])+((Vpk[1][12][0]*
          Vpk[3][14][0])+(Vpk[1][14][1]*Vpk[3][14][1]))))+((mk[8]*((Cik[3][1][2]
          *Vpk[3][13][2])+((Vpk[1][13][0]*Vpk[3][13][0])+(Vpk[1][13][1]*
          Vpk[3][13][1]))))+((mk[7]*((Cik[3][1][2]*Vpk[3][12][2])+((
          Vpk[1][12][0]*Vpk[3][12][0])+(Vpk[1][12][1]*Vpk[3][12][1]))))+temp[1])
          ));
        temp[3] = ((mk[12]*((Vpk[1][17][2]*Vpk[3][17][2])+((Vpk[1][15][1]*
          Vpk[3][17][1])+(Vpk[1][17][0]*Vpk[3][17][0]))))+((mk[11]*((
          Vpk[1][16][2]*Vpk[3][16][2])+((Vpk[1][14][1]*Vpk[3][16][1])+(
          Vpk[1][16][0]*Vpk[3][16][0]))))+((mk[10]*((Vpk[1][15][2]*Vpk[3][15][2]
          )+((Vpk[1][13][0]*Vpk[3][15][0])+(Vpk[1][15][1]*Vpk[3][15][1]))))+
          temp[2])));
        temp[4] = ((mk[15]*((Vpk[1][20][2]*Vpk[3][20][2])+((Vpk[1][14][1]*
          Vpk[3][20][1])+(Vpk[1][20][0]*Vpk[3][20][0]))))+((mk[14]*((
          Vpk[1][19][2]*Vpk[3][19][2])+((Vpk[1][15][1]*Vpk[3][19][1])+(
          Vpk[1][19][0]*Vpk[3][19][0]))))+((mk[13]*((Vpk[1][18][2]*Vpk[3][18][2]
          )+((Vpk[1][14][1]*Vpk[3][18][1])+(Vpk[1][18][0]*Vpk[3][18][0]))))+
          temp[3])));
        temp[5] = ((mk[18]*((Vpk[1][23][2]*Vpk[3][23][2])+((Vpk[1][21][0]*
          Vpk[3][23][0])+(Vpk[1][23][1]*Vpk[3][23][1]))))+((mk[17]*((
          Vpk[1][22][2]*Vpk[3][22][2])+((Vpk[1][20][0]*Vpk[3][22][0])+(
          Vpk[1][22][1]*Vpk[3][22][1]))))+((mk[16]*((Vpk[1][21][2]*Vpk[3][21][2]
          )+((Vpk[1][15][1]*Vpk[3][21][1])+(Vpk[1][21][0]*Vpk[3][21][0]))))+
          temp[4])));
        mm[1][3] = ((mk[20]*((Vpk[1][25][2]*Vpk[3][25][2])+((Vpk[1][24][1]*
          Vpk[3][25][1])+(Vpk[1][25][0]*Vpk[3][25][0]))))+((mk[19]*((
          Cik[3][1][2]*Vpk[3][24][2])+((Vpk[1][24][0]*Vpk[3][24][0])+(
          Vpk[1][24][1]*Vpk[3][24][1]))))+temp[5]));
        temp[0] = ((mk[3]*((Vpk[1][8][2]*Vpk[4][8][2])+((Vpk[1][6][0]*
          Vpk[4][8][0])+(Vpk[1][8][1]*Vpk[4][8][1]))))+((mk[2]*((Vpk[1][7][0]*
          Vpk[4][7][0])+(Vpk[1][7][2]*Vpk[4][7][2])))+((mk[0]*((Cik[3][1][2]*
          rk[0][0])-(Cik[3][1][0]*rk[0][2])))+(mk[1]*((Vpk[1][6][0]*Vpk[4][6][0]
          )+(Vpk[1][6][2]*Vpk[4][6][2]))))));
        temp[1] = ((mk[6]*((Vpk[1][9][2]*Vpk[4][11][2])+((Vpk[1][11][0]*
          Vpk[4][11][0])+(Vpk[1][11][1]*Vpk[4][11][1]))))+((mk[5]*((Vpk[1][8][2]
          *Vpk[4][10][2])+((Vpk[1][10][0]*Vpk[4][10][0])+(Vpk[1][10][1]*
          Vpk[4][10][1]))))+((mk[4]*((Vpk[1][9][2]*Vpk[4][9][2])+((Vpk[1][7][0]*
          Vpk[4][9][0])+(Vpk[1][9][1]*Vpk[4][9][1]))))+temp[0])));
        temp[2] = ((mk[9]*((Vpk[1][14][2]*Vpk[4][14][2])+((Vpk[1][12][0]*
          Vpk[4][14][0])+(Vpk[1][14][1]*Vpk[4][14][1]))))+((mk[8]*((Cik[3][1][2]
          *Vpk[4][13][2])+((Vpk[1][13][0]*Vpk[4][13][0])+(Vpk[1][13][1]*
          Vpk[4][13][1]))))+((mk[7]*((Cik[3][1][2]*Vpk[4][12][2])+((
          Vpk[1][12][0]*Vpk[4][12][0])+(Vpk[1][12][1]*Vpk[4][12][1]))))+temp[1])
          ));
        temp[3] = ((mk[12]*((Vpk[1][17][2]*Vpk[4][17][2])+((Vpk[1][15][1]*
          Vpk[4][17][1])+(Vpk[1][17][0]*Vpk[4][17][0]))))+((mk[11]*((
          Vpk[1][16][2]*Vpk[4][16][2])+((Vpk[1][14][1]*Vpk[4][16][1])+(
          Vpk[1][16][0]*Vpk[4][16][0]))))+((mk[10]*((Vpk[1][15][2]*Vpk[4][15][2]
          )+((Vpk[1][13][0]*Vpk[4][15][0])+(Vpk[1][15][1]*Vpk[4][15][1]))))+
          temp[2])));
        temp[4] = ((mk[15]*((Vpk[1][20][2]*Vpk[4][20][2])+((Vpk[1][14][1]*
          Vpk[4][20][1])+(Vpk[1][20][0]*Vpk[4][20][0]))))+((mk[14]*((
          Vpk[1][19][2]*Vpk[4][19][2])+((Vpk[1][15][1]*Vpk[4][19][1])+(
          Vpk[1][19][0]*Vpk[4][19][0]))))+((mk[13]*((Vpk[1][18][2]*Vpk[4][18][2]
          )+((Vpk[1][14][1]*Vpk[4][18][1])+(Vpk[1][18][0]*Vpk[4][18][0]))))+
          temp[3])));
        temp[5] = ((mk[18]*((Vpk[1][23][2]*Vpk[4][23][2])+((Vpk[1][21][0]*
          Vpk[4][23][0])+(Vpk[1][23][1]*Vpk[4][23][1]))))+((mk[17]*((
          Vpk[1][22][2]*Vpk[4][22][2])+((Vpk[1][20][0]*Vpk[4][22][0])+(
          Vpk[1][22][1]*Vpk[4][22][1]))))+((mk[16]*((Vpk[1][21][2]*Vpk[4][21][2]
          )+((Vpk[1][15][1]*Vpk[4][21][1])+(Vpk[1][21][0]*Vpk[4][21][0]))))+
          temp[4])));
        mm[1][4] = ((mk[20]*((Vpk[1][25][2]*Vpk[4][25][2])+((Vpk[1][24][1]*
          Vpk[4][25][1])+(Vpk[1][25][0]*Vpk[4][25][0]))))+((mk[19]*((
          Cik[3][1][2]*Vpk[4][24][2])+((Vpk[1][24][0]*Vpk[4][24][0])+(
          Vpk[1][24][1]*Vpk[4][24][1]))))+temp[5]));
        temp[0] = ((mk[3]*((Vpk[1][8][2]*Vpk[5][8][2])+((Vpk[1][6][0]*
          Vpk[5][8][0])+(Vpk[1][8][1]*Vpk[5][8][1]))))+((mk[2]*((Vpk[1][7][2]*
          Vpk[5][7][2])+((Cik[3][1][1]*Vpk[5][7][1])+(Vpk[1][7][0]*Vpk[5][7][0])
          )))+((mk[0]*((Cik[3][1][0]*rk[0][1])-(Cik[3][1][1]*rk[0][0])))+(mk[1]*
          ((Vpk[1][6][2]*Vpk[5][6][2])+((Cik[3][1][1]*Vpk[5][6][1])+(
          Vpk[1][6][0]*Vpk[5][6][0])))))));
        temp[1] = ((mk[7]*((Vpk[1][12][0]*Vpk[5][12][0])+(Vpk[1][12][1]*
          Vpk[5][12][1])))+((mk[6]*((Vpk[1][9][2]*Vpk[5][11][2])+((Vpk[1][11][0]
          *Vpk[5][11][0])+(Vpk[1][11][1]*Vpk[5][11][1]))))+((mk[5]*((
          Vpk[1][8][2]*Vpk[5][10][2])+((Vpk[1][10][0]*Vpk[5][10][0])+(
          Vpk[1][10][1]*Vpk[5][10][1]))))+((mk[4]*((Vpk[1][9][2]*Vpk[5][9][2])+(
          (Vpk[1][7][0]*Vpk[5][9][0])+(Vpk[1][9][1]*Vpk[5][9][1]))))+temp[0]))))
          ;
        temp[2] = ((mk[11]*((Vpk[1][16][2]*Vpk[5][16][2])+((Vpk[1][14][1]*
          Vpk[5][16][1])+(Vpk[1][16][0]*Vpk[5][16][0]))))+((mk[10]*((
          Vpk[1][15][2]*Vpk[5][15][2])+((Vpk[1][13][0]*Vpk[5][15][0])+(
          Vpk[1][15][1]*Vpk[5][15][1]))))+((mk[9]*((Vpk[1][14][2]*Vpk[5][14][2])
          +((Vpk[1][12][0]*Vpk[5][14][0])+(Vpk[1][14][1]*Vpk[5][14][1]))))+((
          mk[8]*((Vpk[1][13][0]*Vpk[5][13][0])+(Vpk[1][13][1]*Vpk[5][13][1])))+
          temp[1]))));
        temp[3] = ((mk[14]*((Vpk[1][19][2]*Vpk[5][19][2])+((Vpk[1][15][1]*
          Vpk[5][19][1])+(Vpk[1][19][0]*Vpk[5][19][0]))))+((mk[13]*((
          Vpk[1][18][2]*Vpk[5][18][2])+((Vpk[1][14][1]*Vpk[5][18][1])+(
          Vpk[1][18][0]*Vpk[5][18][0]))))+((mk[12]*((Vpk[1][17][2]*Vpk[5][17][2]
          )+((Vpk[1][15][1]*Vpk[5][17][1])+(Vpk[1][17][0]*Vpk[5][17][0]))))+
          temp[2])));
        temp[4] = ((mk[17]*((Vpk[1][22][2]*Vpk[5][22][2])+((Vpk[1][20][0]*
          Vpk[5][22][0])+(Vpk[1][22][1]*Vpk[5][22][1]))))+((mk[16]*((
          Vpk[1][21][2]*Vpk[5][21][2])+((Vpk[1][15][1]*Vpk[5][21][1])+(
          Vpk[1][21][0]*Vpk[5][21][0]))))+((mk[15]*((Vpk[1][20][2]*Vpk[5][20][2]
          )+((Vpk[1][14][1]*Vpk[5][20][1])+(Vpk[1][20][0]*Vpk[5][20][0]))))+
          temp[3])));
        mm[1][5] = ((mk[20]*((Vpk[1][25][2]*Vpk[5][25][2])+((Vpk[1][24][1]*
          Vpk[5][25][1])+(Vpk[1][25][0]*Vpk[5][25][0]))))+((mk[19]*((
          Vpk[1][24][0]*Vpk[5][24][0])+(Vpk[1][24][1]*Vpk[5][24][1])))+((mk[18]*
          ((Vpk[1][23][2]*Vpk[5][23][2])+((Vpk[1][21][0]*Vpk[5][23][0])+(
          Vpk[1][23][1]*Vpk[5][23][1]))))+temp[4])));
        mm[1][6] = ((mk[5]*((Vpk[1][8][2]*Vpk[6][10][2])+((Vpk[1][10][0]*
          Vpk[6][10][0])+(Vpk[1][10][1]*Vpk[6][10][1]))))+((mk[1]*((rk[1][2]*
          Vpk[1][6][0])-(rk[1][0]*Vpk[1][6][2])))+(mk[3]*((Vpk[1][8][2]*
          Vpk[6][8][2])+((Vpk[1][6][0]*Vpk[6][8][0])+(Vpk[1][8][1]*Vpk[6][8][1])
          )))));
        mm[1][7] = ((mk[6]*((Vpk[1][9][2]*Vpk[7][11][2])+((Vpk[1][11][0]*
          Vpk[7][11][0])+(Vpk[1][11][1]*Vpk[7][11][1]))))+((mk[2]*((rk[2][2]*
          Vpk[1][7][0])-(rk[2][0]*Vpk[1][7][2])))+(mk[4]*((Vpk[1][9][2]*
          Vpk[7][9][2])+((Vpk[1][7][0]*Vpk[7][9][0])+(Vpk[1][9][1]*Vpk[7][9][1])
          )))));
        mm[1][8] = ((mk[3]*((rk[3][1]*Vpk[1][8][2])-(rk[3][2]*Vpk[1][8][1])))+(
          mk[5]*((Vpk[1][8][2]*Vpk[8][10][2])+((Vpk[1][10][0]*Vpk[8][10][0])+(
          Vpk[1][10][1]*Vpk[8][10][1])))));
        mm[1][9] = ((mk[4]*((rk[4][2]*Vpk[1][9][1])-(rk[4][1]*Vpk[1][9][2])))+(
          mk[6]*((Vpk[1][9][2]*Vpk[9][11][2])+((Vpk[1][11][0]*Vpk[9][11][0])+(
          Vpk[1][11][1]*Vpk[9][11][1])))));
        mm[1][10] = (mk[5]*((rk[5][0]*Vpk[1][10][1])-(rk[5][1]*Vpk[1][10][0])));
        mm[1][11] = (mk[6]*((rk[6][1]*Vpk[1][11][0])-(rk[6][0]*Vpk[1][11][1])));
        temp[0] = ((mk[13]*((Vpk[1][18][2]*Vpk[12][18][2])+((Vpk[1][14][1]*
          Vpk[12][18][1])+(Vpk[1][18][0]*Vpk[12][18][0]))))+((mk[11]*((
          Vpk[1][16][2]*Vpk[12][16][2])+((Vpk[1][14][1]*Vpk[12][16][1])+(
          Vpk[1][16][0]*Vpk[12][16][0]))))+((mk[7]*((rk[7][0]*Vpk[1][12][1])-(
          rk[7][1]*Vpk[1][12][0])))+(mk[9]*((Vpk[1][14][2]*Vpk[12][14][2])+((
          Vpk[1][12][0]*Vpk[12][14][0])+(Vpk[1][14][1]*Vpk[12][14][1])))))));
        mm[1][12] = ((mk[17]*((Vpk[1][22][2]*Vpk[12][22][2])+((Vpk[1][20][0]*
          Vpk[12][22][0])+(Vpk[1][22][1]*Vpk[12][22][1]))))+((mk[15]*((
          Vpk[1][20][2]*Vpk[12][20][2])+((Vpk[1][14][1]*Vpk[12][20][1])+(
          Vpk[1][20][0]*Vpk[12][20][0]))))+temp[0]));
        temp[0] = ((mk[14]*((Vpk[1][19][2]*Vpk[13][19][2])+((Vpk[1][15][1]*
          Vpk[13][19][1])+(Vpk[1][19][0]*Vpk[13][19][0]))))+((mk[12]*((
          Vpk[1][17][2]*Vpk[13][17][2])+((Vpk[1][15][1]*Vpk[13][17][1])+(
          Vpk[1][17][0]*Vpk[13][17][0]))))+((mk[8]*((rk[8][1]*Vpk[1][13][0])-(
          rk[8][0]*Vpk[1][13][1])))+(mk[10]*((Vpk[1][15][2]*Vpk[13][15][2])+((
          Vpk[1][13][0]*Vpk[13][15][0])+(Vpk[1][15][1]*Vpk[13][15][1])))))));
        mm[1][13] = ((mk[18]*((Vpk[1][23][2]*Vpk[13][23][2])+((Vpk[1][21][0]*
          Vpk[13][23][0])+(Vpk[1][23][1]*Vpk[13][23][1]))))+((mk[16]*((
          Vpk[1][21][2]*Vpk[13][21][2])+((Vpk[1][15][1]*Vpk[13][21][1])+(
          Vpk[1][21][0]*Vpk[13][21][0]))))+temp[0]));
        temp[0] = ((mk[15]*((Vpk[1][20][2]*Vpk[14][20][2])+((Vpk[1][14][1]*
          Vpk[14][20][1])+(Vpk[1][20][0]*Vpk[14][20][0]))))+((mk[13]*((
          Vpk[1][18][2]*Vpk[14][18][2])+((Vpk[1][14][1]*Vpk[14][18][1])+(
          Vpk[1][18][0]*Vpk[14][18][0]))))+((mk[9]*((rk[9][1]*Vpk[1][14][2])-(
          rk[9][2]*Vpk[1][14][1])))+(mk[11]*((Vpk[1][16][2]*Vpk[14][16][2])+((
          Vpk[1][14][1]*Vpk[14][16][1])+(Vpk[1][16][0]*Vpk[14][16][0])))))));
        mm[1][14] = ((mk[17]*((Vpk[1][22][2]*Vpk[14][22][2])+((Vpk[1][20][0]*
          Vpk[14][22][0])+(Vpk[1][22][1]*Vpk[14][22][1]))))+temp[0]);
        temp[0] = ((mk[16]*((Vpk[1][21][2]*Vpk[15][21][2])+((Vpk[1][15][1]*
          Vpk[15][21][1])+(Vpk[1][21][0]*Vpk[15][21][0]))))+((mk[14]*((
          Vpk[1][19][2]*Vpk[15][19][2])+((Vpk[1][15][1]*Vpk[15][19][1])+(
          Vpk[1][19][0]*Vpk[15][19][0]))))+((mk[10]*((rk[10][2]*Vpk[1][15][1])-(
          rk[10][1]*Vpk[1][15][2])))+(mk[12]*((Vpk[1][17][2]*Vpk[15][17][2])+((
          Vpk[1][15][1]*Vpk[15][17][1])+(Vpk[1][17][0]*Vpk[15][17][0])))))));
        mm[1][15] = ((mk[18]*((Vpk[1][23][2]*Vpk[15][23][2])+((Vpk[1][21][0]*
          Vpk[15][23][0])+(Vpk[1][23][1]*Vpk[15][23][1]))))+temp[0]);
        mm[1][16] = ((mk[17]*((Vpk[1][22][2]*Vpk[16][22][2])+((Vpk[1][20][0]*
          Vpk[16][22][0])+(Vpk[1][22][1]*Vpk[16][22][1]))))+((mk[15]*((
          Vpk[1][20][0]*Vpk[16][20][0])+(Vpk[1][20][2]*Vpk[16][20][2])))+((
          mk[11]*((rk[11][2]*Vpk[1][16][0])-(rk[11][0]*Vpk[1][16][2])))+(mk[13]*
          ((Vpk[1][18][0]*Vpk[16][18][0])+(Vpk[1][18][2]*Vpk[16][18][2]))))));
        mm[1][17] = ((mk[18]*((Vpk[1][23][2]*Vpk[17][23][2])+((Vpk[1][21][0]*
          Vpk[17][23][0])+(Vpk[1][23][1]*Vpk[17][23][1]))))+((mk[16]*((
          Vpk[1][21][0]*Vpk[17][21][0])+(Vpk[1][21][2]*Vpk[17][21][2])))+((
          mk[12]*((rk[12][2]*Vpk[1][17][0])-(rk[12][0]*Vpk[1][17][2])))+(mk[14]*
          ((Vpk[1][19][0]*Vpk[17][19][0])+(Vpk[1][19][2]*Vpk[17][19][2]))))));
        mm[1][18] = ((mk[17]*((Vpk[1][22][2]*Vpk[18][22][2])+((Vpk[1][20][0]*
          Vpk[18][22][0])+(Vpk[1][22][1]*Vpk[18][22][1]))))+((mk[13]*((rk[13][2]
          *Vpk[1][18][0])-(rk[13][0]*Vpk[1][18][2])))+(mk[15]*((Vpk[1][20][0]*
          Vpk[18][20][0])+(Vpk[1][20][2]*Vpk[18][20][2])))));
        mm[1][19] = ((mk[18]*((Vpk[1][23][2]*Vpk[19][23][2])+((Vpk[1][21][0]*
          Vpk[19][23][0])+(Vpk[1][23][1]*Vpk[19][23][1]))))+((mk[14]*((rk[14][2]
          *Vpk[1][19][0])-(rk[14][0]*Vpk[1][19][2])))+(mk[16]*((Vpk[1][21][0]*
          Vpk[19][21][0])+(Vpk[1][21][2]*Vpk[19][21][2])))));
        mm[1][20] = ((mk[15]*((rk[15][2]*Vpk[1][20][0])-(rk[15][0]*Vpk[1][20][2]
          )))+(mk[17]*((Vpk[1][22][2]*Vpk[20][22][2])+((Vpk[1][20][0]*
          Vpk[20][22][0])+(Vpk[1][22][1]*Vpk[20][22][1])))));
        mm[1][21] = ((mk[16]*((rk[16][2]*Vpk[1][21][0])-(rk[16][0]*Vpk[1][21][2]
          )))+(mk[18]*((Vpk[1][23][2]*Vpk[21][23][2])+((Vpk[1][21][0]*
          Vpk[21][23][0])+(Vpk[1][23][1]*Vpk[21][23][1])))));
        mm[1][22] = (mk[17]*((rk[17][1]*Vpk[1][22][2])-(rk[17][2]*Vpk[1][22][1])
          ));
        mm[1][23] = (mk[18]*((rk[18][2]*Vpk[1][23][1])-(rk[18][1]*Vpk[1][23][2])
          ));
        mm[1][24] = ((mk[19]*((rk[19][1]*Vpk[1][24][0])-(rk[19][0]*Vpk[1][24][1]
          )))+(mk[20]*((Vpk[1][25][2]*Vpk[24][25][2])+((Vpk[1][24][1]*
          Vpk[24][25][1])+(Vpk[1][25][0]*Vpk[24][25][0])))));
        mm[1][25] = (mk[20]*((rk[20][2]*Vpk[1][25][0])-(rk[20][0]*Vpk[1][25][2])
          ));
        temp[0] = ((mk[2]*((Vpk[2][7][2]*Vpk[2][7][2])+((Cik[3][2][1]*
          Cik[3][2][1])+(Vpk[2][7][0]*Vpk[2][7][0]))))+((mk[0]*((Cik[3][2][2]*
          Cik[3][2][2])+((Cik[3][2][0]*Cik[3][2][0])+(Cik[3][2][1]*Cik[3][2][1])
          )))+(mk[1]*((Vpk[2][6][2]*Vpk[2][6][2])+((Cik[3][2][1]*Cik[3][2][1])+(
          Vpk[2][6][0]*Vpk[2][6][0]))))));
        temp[1] = ((mk[5]*((Vpk[2][8][2]*Vpk[2][8][2])+((Vpk[2][10][0]*
          Vpk[2][10][0])+(Vpk[2][10][1]*Vpk[2][10][1]))))+((mk[4]*((Vpk[2][9][2]
          *Vpk[2][9][2])+((Vpk[2][7][0]*Vpk[2][7][0])+(Vpk[2][9][1]*Vpk[2][9][1]
          ))))+((mk[3]*((Vpk[2][8][2]*Vpk[2][8][2])+((Vpk[2][6][0]*Vpk[2][6][0])
          +(Vpk[2][8][1]*Vpk[2][8][1]))))+temp[0])));
        temp[2] = ((mk[8]*((Cik[3][2][2]*Cik[3][2][2])+((Vpk[2][13][0]*
          Vpk[2][13][0])+(Vpk[2][13][1]*Vpk[2][13][1]))))+((mk[7]*((Cik[3][2][2]
          *Cik[3][2][2])+((Vpk[2][12][0]*Vpk[2][12][0])+(Vpk[2][12][1]*
          Vpk[2][12][1]))))+((mk[6]*((Vpk[2][9][2]*Vpk[2][9][2])+((Vpk[2][11][0]
          *Vpk[2][11][0])+(Vpk[2][11][1]*Vpk[2][11][1]))))+temp[1])));
        temp[3] = ((mk[11]*((Vpk[2][16][2]*Vpk[2][16][2])+((Vpk[2][14][1]*
          Vpk[2][14][1])+(Vpk[2][16][0]*Vpk[2][16][0]))))+((mk[10]*((
          Vpk[2][15][2]*Vpk[2][15][2])+((Vpk[2][13][0]*Vpk[2][13][0])+(
          Vpk[2][15][1]*Vpk[2][15][1]))))+((mk[9]*((Vpk[2][14][2]*Vpk[2][14][2])
          +((Vpk[2][12][0]*Vpk[2][12][0])+(Vpk[2][14][1]*Vpk[2][14][1]))))+
          temp[2])));
        temp[4] = ((mk[14]*((Vpk[2][19][2]*Vpk[2][19][2])+((Vpk[2][15][1]*
          Vpk[2][15][1])+(Vpk[2][19][0]*Vpk[2][19][0]))))+((mk[13]*((
          Vpk[2][18][2]*Vpk[2][18][2])+((Vpk[2][14][1]*Vpk[2][14][1])+(
          Vpk[2][18][0]*Vpk[2][18][0]))))+((mk[12]*((Vpk[2][17][2]*Vpk[2][17][2]
          )+((Vpk[2][15][1]*Vpk[2][15][1])+(Vpk[2][17][0]*Vpk[2][17][0]))))+
          temp[3])));
        temp[5] = ((mk[17]*((Vpk[2][22][2]*Vpk[2][22][2])+((Vpk[2][20][0]*
          Vpk[2][20][0])+(Vpk[2][22][1]*Vpk[2][22][1]))))+((mk[16]*((
          Vpk[2][21][2]*Vpk[2][21][2])+((Vpk[2][15][1]*Vpk[2][15][1])+(
          Vpk[2][21][0]*Vpk[2][21][0]))))+((mk[15]*((Vpk[2][20][2]*Vpk[2][20][2]
          )+((Vpk[2][14][1]*Vpk[2][14][1])+(Vpk[2][20][0]*Vpk[2][20][0]))))+
          temp[4])));
        mm[2][2] = ((mk[20]*((Vpk[2][25][2]*Vpk[2][25][2])+((Vpk[2][24][1]*
          Vpk[2][24][1])+(Vpk[2][25][0]*Vpk[2][25][0]))))+((mk[19]*((
          Cik[3][2][2]*Cik[3][2][2])+((Vpk[2][24][0]*Vpk[2][24][0])+(
          Vpk[2][24][1]*Vpk[2][24][1]))))+((mk[18]*((Vpk[2][23][2]*Vpk[2][23][2]
          )+((Vpk[2][21][0]*Vpk[2][21][0])+(Vpk[2][23][1]*Vpk[2][23][1]))))+
          temp[5])));
        temp[0] = ((mk[3]*((Vpk[2][8][2]*Vpk[3][8][2])+((Vpk[2][6][0]*
          Vpk[3][8][0])+(Vpk[2][8][1]*Vpk[3][8][1]))))+((mk[2]*((Vpk[2][7][2]*
          Vpk[3][7][2])+((Cik[3][2][1]*Vpk[3][7][1])+(Vpk[2][7][0]*Vpk[3][7][0])
          )))+((mk[0]*((Cik[3][2][1]*rk[0][2])-(Cik[3][2][2]*rk[0][1])))+(mk[1]*
          ((Vpk[2][6][2]*Vpk[3][6][2])+((Cik[3][2][1]*Vpk[3][6][1])+(
          Vpk[2][6][0]*Vpk[3][6][0])))))));
        temp[1] = ((mk[6]*((Vpk[2][9][2]*Vpk[3][11][2])+((Vpk[2][11][0]*
          Vpk[3][11][0])+(Vpk[2][11][1]*Vpk[3][11][1]))))+((mk[5]*((Vpk[2][8][2]
          *Vpk[3][10][2])+((Vpk[2][10][0]*Vpk[3][10][0])+(Vpk[2][10][1]*
          Vpk[3][10][1]))))+((mk[4]*((Vpk[2][9][2]*Vpk[3][9][2])+((Vpk[2][7][0]*
          Vpk[3][9][0])+(Vpk[2][9][1]*Vpk[3][9][1]))))+temp[0])));
        temp[2] = ((mk[9]*((Vpk[2][14][2]*Vpk[3][14][2])+((Vpk[2][12][0]*
          Vpk[3][14][0])+(Vpk[2][14][1]*Vpk[3][14][1]))))+((mk[8]*((Cik[3][2][2]
          *Vpk[3][13][2])+((Vpk[2][13][0]*Vpk[3][13][0])+(Vpk[2][13][1]*
          Vpk[3][13][1]))))+((mk[7]*((Cik[3][2][2]*Vpk[3][12][2])+((
          Vpk[2][12][0]*Vpk[3][12][0])+(Vpk[2][12][1]*Vpk[3][12][1]))))+temp[1])
          ));
        temp[3] = ((mk[12]*((Vpk[2][17][2]*Vpk[3][17][2])+((Vpk[2][15][1]*
          Vpk[3][17][1])+(Vpk[2][17][0]*Vpk[3][17][0]))))+((mk[11]*((
          Vpk[2][16][2]*Vpk[3][16][2])+((Vpk[2][14][1]*Vpk[3][16][1])+(
          Vpk[2][16][0]*Vpk[3][16][0]))))+((mk[10]*((Vpk[2][15][2]*Vpk[3][15][2]
          )+((Vpk[2][13][0]*Vpk[3][15][0])+(Vpk[2][15][1]*Vpk[3][15][1]))))+
          temp[2])));
        temp[4] = ((mk[15]*((Vpk[2][20][2]*Vpk[3][20][2])+((Vpk[2][14][1]*
          Vpk[3][20][1])+(Vpk[2][20][0]*Vpk[3][20][0]))))+((mk[14]*((
          Vpk[2][19][2]*Vpk[3][19][2])+((Vpk[2][15][1]*Vpk[3][19][1])+(
          Vpk[2][19][0]*Vpk[3][19][0]))))+((mk[13]*((Vpk[2][18][2]*Vpk[3][18][2]
          )+((Vpk[2][14][1]*Vpk[3][18][1])+(Vpk[2][18][0]*Vpk[3][18][0]))))+
          temp[3])));
        temp[5] = ((mk[18]*((Vpk[2][23][2]*Vpk[3][23][2])+((Vpk[2][21][0]*
          Vpk[3][23][0])+(Vpk[2][23][1]*Vpk[3][23][1]))))+((mk[17]*((
          Vpk[2][22][2]*Vpk[3][22][2])+((Vpk[2][20][0]*Vpk[3][22][0])+(
          Vpk[2][22][1]*Vpk[3][22][1]))))+((mk[16]*((Vpk[2][21][2]*Vpk[3][21][2]
          )+((Vpk[2][15][1]*Vpk[3][21][1])+(Vpk[2][21][0]*Vpk[3][21][0]))))+
          temp[4])));
        mm[2][3] = ((mk[20]*((Vpk[2][25][2]*Vpk[3][25][2])+((Vpk[2][24][1]*
          Vpk[3][25][1])+(Vpk[2][25][0]*Vpk[3][25][0]))))+((mk[19]*((
          Cik[3][2][2]*Vpk[3][24][2])+((Vpk[2][24][0]*Vpk[3][24][0])+(
          Vpk[2][24][1]*Vpk[3][24][1]))))+temp[5]));
        temp[0] = ((mk[3]*((Vpk[2][8][2]*Vpk[4][8][2])+((Vpk[2][6][0]*
          Vpk[4][8][0])+(Vpk[2][8][1]*Vpk[4][8][1]))))+((mk[2]*((Vpk[2][7][0]*
          Vpk[4][7][0])+(Vpk[2][7][2]*Vpk[4][7][2])))+((mk[0]*((Cik[3][2][2]*
          rk[0][0])-(Cik[3][2][0]*rk[0][2])))+(mk[1]*((Vpk[2][6][0]*Vpk[4][6][0]
          )+(Vpk[2][6][2]*Vpk[4][6][2]))))));
        temp[1] = ((mk[6]*((Vpk[2][9][2]*Vpk[4][11][2])+((Vpk[2][11][0]*
          Vpk[4][11][0])+(Vpk[2][11][1]*Vpk[4][11][1]))))+((mk[5]*((Vpk[2][8][2]
          *Vpk[4][10][2])+((Vpk[2][10][0]*Vpk[4][10][0])+(Vpk[2][10][1]*
          Vpk[4][10][1]))))+((mk[4]*((Vpk[2][9][2]*Vpk[4][9][2])+((Vpk[2][7][0]*
          Vpk[4][9][0])+(Vpk[2][9][1]*Vpk[4][9][1]))))+temp[0])));
        temp[2] = ((mk[9]*((Vpk[2][14][2]*Vpk[4][14][2])+((Vpk[2][12][0]*
          Vpk[4][14][0])+(Vpk[2][14][1]*Vpk[4][14][1]))))+((mk[8]*((Cik[3][2][2]
          *Vpk[4][13][2])+((Vpk[2][13][0]*Vpk[4][13][0])+(Vpk[2][13][1]*
          Vpk[4][13][1]))))+((mk[7]*((Cik[3][2][2]*Vpk[4][12][2])+((
          Vpk[2][12][0]*Vpk[4][12][0])+(Vpk[2][12][1]*Vpk[4][12][1]))))+temp[1])
          ));
        temp[3] = ((mk[12]*((Vpk[2][17][2]*Vpk[4][17][2])+((Vpk[2][15][1]*
          Vpk[4][17][1])+(Vpk[2][17][0]*Vpk[4][17][0]))))+((mk[11]*((
          Vpk[2][16][2]*Vpk[4][16][2])+((Vpk[2][14][1]*Vpk[4][16][1])+(
          Vpk[2][16][0]*Vpk[4][16][0]))))+((mk[10]*((Vpk[2][15][2]*Vpk[4][15][2]
          )+((Vpk[2][13][0]*Vpk[4][15][0])+(Vpk[2][15][1]*Vpk[4][15][1]))))+
          temp[2])));
        temp[4] = ((mk[15]*((Vpk[2][20][2]*Vpk[4][20][2])+((Vpk[2][14][1]*
          Vpk[4][20][1])+(Vpk[2][20][0]*Vpk[4][20][0]))))+((mk[14]*((
          Vpk[2][19][2]*Vpk[4][19][2])+((Vpk[2][15][1]*Vpk[4][19][1])+(
          Vpk[2][19][0]*Vpk[4][19][0]))))+((mk[13]*((Vpk[2][18][2]*Vpk[4][18][2]
          )+((Vpk[2][14][1]*Vpk[4][18][1])+(Vpk[2][18][0]*Vpk[4][18][0]))))+
          temp[3])));
        temp[5] = ((mk[18]*((Vpk[2][23][2]*Vpk[4][23][2])+((Vpk[2][21][0]*
          Vpk[4][23][0])+(Vpk[2][23][1]*Vpk[4][23][1]))))+((mk[17]*((
          Vpk[2][22][2]*Vpk[4][22][2])+((Vpk[2][20][0]*Vpk[4][22][0])+(
          Vpk[2][22][1]*Vpk[4][22][1]))))+((mk[16]*((Vpk[2][21][2]*Vpk[4][21][2]
          )+((Vpk[2][15][1]*Vpk[4][21][1])+(Vpk[2][21][0]*Vpk[4][21][0]))))+
          temp[4])));
        mm[2][4] = ((mk[20]*((Vpk[2][25][2]*Vpk[4][25][2])+((Vpk[2][24][1]*
          Vpk[4][25][1])+(Vpk[2][25][0]*Vpk[4][25][0]))))+((mk[19]*((
          Cik[3][2][2]*Vpk[4][24][2])+((Vpk[2][24][0]*Vpk[4][24][0])+(
          Vpk[2][24][1]*Vpk[4][24][1]))))+temp[5]));
        temp[0] = ((mk[3]*((Vpk[2][8][2]*Vpk[5][8][2])+((Vpk[2][6][0]*
          Vpk[5][8][0])+(Vpk[2][8][1]*Vpk[5][8][1]))))+((mk[2]*((Vpk[2][7][2]*
          Vpk[5][7][2])+((Cik[3][2][1]*Vpk[5][7][1])+(Vpk[2][7][0]*Vpk[5][7][0])
          )))+((mk[0]*((Cik[3][2][0]*rk[0][1])-(Cik[3][2][1]*rk[0][0])))+(mk[1]*
          ((Vpk[2][6][2]*Vpk[5][6][2])+((Cik[3][2][1]*Vpk[5][6][1])+(
          Vpk[2][6][0]*Vpk[5][6][0])))))));
        temp[1] = ((mk[7]*((Vpk[2][12][0]*Vpk[5][12][0])+(Vpk[2][12][1]*
          Vpk[5][12][1])))+((mk[6]*((Vpk[2][9][2]*Vpk[5][11][2])+((Vpk[2][11][0]
          *Vpk[5][11][0])+(Vpk[2][11][1]*Vpk[5][11][1]))))+((mk[5]*((
          Vpk[2][8][2]*Vpk[5][10][2])+((Vpk[2][10][0]*Vpk[5][10][0])+(
          Vpk[2][10][1]*Vpk[5][10][1]))))+((mk[4]*((Vpk[2][9][2]*Vpk[5][9][2])+(
          (Vpk[2][7][0]*Vpk[5][9][0])+(Vpk[2][9][1]*Vpk[5][9][1]))))+temp[0]))))
          ;
        temp[2] = ((mk[11]*((Vpk[2][16][2]*Vpk[5][16][2])+((Vpk[2][14][1]*
          Vpk[5][16][1])+(Vpk[2][16][0]*Vpk[5][16][0]))))+((mk[10]*((
          Vpk[2][15][2]*Vpk[5][15][2])+((Vpk[2][13][0]*Vpk[5][15][0])+(
          Vpk[2][15][1]*Vpk[5][15][1]))))+((mk[9]*((Vpk[2][14][2]*Vpk[5][14][2])
          +((Vpk[2][12][0]*Vpk[5][14][0])+(Vpk[2][14][1]*Vpk[5][14][1]))))+((
          mk[8]*((Vpk[2][13][0]*Vpk[5][13][0])+(Vpk[2][13][1]*Vpk[5][13][1])))+
          temp[1]))));
        temp[3] = ((mk[14]*((Vpk[2][19][2]*Vpk[5][19][2])+((Vpk[2][15][1]*
          Vpk[5][19][1])+(Vpk[2][19][0]*Vpk[5][19][0]))))+((mk[13]*((
          Vpk[2][18][2]*Vpk[5][18][2])+((Vpk[2][14][1]*Vpk[5][18][1])+(
          Vpk[2][18][0]*Vpk[5][18][0]))))+((mk[12]*((Vpk[2][17][2]*Vpk[5][17][2]
          )+((Vpk[2][15][1]*Vpk[5][17][1])+(Vpk[2][17][0]*Vpk[5][17][0]))))+
          temp[2])));
        temp[4] = ((mk[17]*((Vpk[2][22][2]*Vpk[5][22][2])+((Vpk[2][20][0]*
          Vpk[5][22][0])+(Vpk[2][22][1]*Vpk[5][22][1]))))+((mk[16]*((
          Vpk[2][21][2]*Vpk[5][21][2])+((Vpk[2][15][1]*Vpk[5][21][1])+(
          Vpk[2][21][0]*Vpk[5][21][0]))))+((mk[15]*((Vpk[2][20][2]*Vpk[5][20][2]
          )+((Vpk[2][14][1]*Vpk[5][20][1])+(Vpk[2][20][0]*Vpk[5][20][0]))))+
          temp[3])));
        mm[2][5] = ((mk[20]*((Vpk[2][25][2]*Vpk[5][25][2])+((Vpk[2][24][1]*
          Vpk[5][25][1])+(Vpk[2][25][0]*Vpk[5][25][0]))))+((mk[19]*((
          Vpk[2][24][0]*Vpk[5][24][0])+(Vpk[2][24][1]*Vpk[5][24][1])))+((mk[18]*
          ((Vpk[2][23][2]*Vpk[5][23][2])+((Vpk[2][21][0]*Vpk[5][23][0])+(
          Vpk[2][23][1]*Vpk[5][23][1]))))+temp[4])));
        mm[2][6] = ((mk[5]*((Vpk[2][8][2]*Vpk[6][10][2])+((Vpk[2][10][0]*
          Vpk[6][10][0])+(Vpk[2][10][1]*Vpk[6][10][1]))))+((mk[1]*((rk[1][2]*
          Vpk[2][6][0])-(rk[1][0]*Vpk[2][6][2])))+(mk[3]*((Vpk[2][8][2]*
          Vpk[6][8][2])+((Vpk[2][6][0]*Vpk[6][8][0])+(Vpk[2][8][1]*Vpk[6][8][1])
          )))));
        mm[2][7] = ((mk[6]*((Vpk[2][9][2]*Vpk[7][11][2])+((Vpk[2][11][0]*
          Vpk[7][11][0])+(Vpk[2][11][1]*Vpk[7][11][1]))))+((mk[2]*((rk[2][2]*
          Vpk[2][7][0])-(rk[2][0]*Vpk[2][7][2])))+(mk[4]*((Vpk[2][9][2]*
          Vpk[7][9][2])+((Vpk[2][7][0]*Vpk[7][9][0])+(Vpk[2][9][1]*Vpk[7][9][1])
          )))));
        mm[2][8] = ((mk[3]*((rk[3][1]*Vpk[2][8][2])-(rk[3][2]*Vpk[2][8][1])))+(
          mk[5]*((Vpk[2][8][2]*Vpk[8][10][2])+((Vpk[2][10][0]*Vpk[8][10][0])+(
          Vpk[2][10][1]*Vpk[8][10][1])))));
        mm[2][9] = ((mk[4]*((rk[4][2]*Vpk[2][9][1])-(rk[4][1]*Vpk[2][9][2])))+(
          mk[6]*((Vpk[2][9][2]*Vpk[9][11][2])+((Vpk[2][11][0]*Vpk[9][11][0])+(
          Vpk[2][11][1]*Vpk[9][11][1])))));
        mm[2][10] = (mk[5]*((rk[5][0]*Vpk[2][10][1])-(rk[5][1]*Vpk[2][10][0])));
        mm[2][11] = (mk[6]*((rk[6][1]*Vpk[2][11][0])-(rk[6][0]*Vpk[2][11][1])));
        temp[0] = ((mk[13]*((Vpk[2][18][2]*Vpk[12][18][2])+((Vpk[2][14][1]*
          Vpk[12][18][1])+(Vpk[2][18][0]*Vpk[12][18][0]))))+((mk[11]*((
          Vpk[2][16][2]*Vpk[12][16][2])+((Vpk[2][14][1]*Vpk[12][16][1])+(
          Vpk[2][16][0]*Vpk[12][16][0]))))+((mk[7]*((rk[7][0]*Vpk[2][12][1])-(
          rk[7][1]*Vpk[2][12][0])))+(mk[9]*((Vpk[2][14][2]*Vpk[12][14][2])+((
          Vpk[2][12][0]*Vpk[12][14][0])+(Vpk[2][14][1]*Vpk[12][14][1])))))));
        mm[2][12] = ((mk[17]*((Vpk[2][22][2]*Vpk[12][22][2])+((Vpk[2][20][0]*
          Vpk[12][22][0])+(Vpk[2][22][1]*Vpk[12][22][1]))))+((mk[15]*((
          Vpk[2][20][2]*Vpk[12][20][2])+((Vpk[2][14][1]*Vpk[12][20][1])+(
          Vpk[2][20][0]*Vpk[12][20][0]))))+temp[0]));
        temp[0] = ((mk[14]*((Vpk[2][19][2]*Vpk[13][19][2])+((Vpk[2][15][1]*
          Vpk[13][19][1])+(Vpk[2][19][0]*Vpk[13][19][0]))))+((mk[12]*((
          Vpk[2][17][2]*Vpk[13][17][2])+((Vpk[2][15][1]*Vpk[13][17][1])+(
          Vpk[2][17][0]*Vpk[13][17][0]))))+((mk[8]*((rk[8][1]*Vpk[2][13][0])-(
          rk[8][0]*Vpk[2][13][1])))+(mk[10]*((Vpk[2][15][2]*Vpk[13][15][2])+((
          Vpk[2][13][0]*Vpk[13][15][0])+(Vpk[2][15][1]*Vpk[13][15][1])))))));
        mm[2][13] = ((mk[18]*((Vpk[2][23][2]*Vpk[13][23][2])+((Vpk[2][21][0]*
          Vpk[13][23][0])+(Vpk[2][23][1]*Vpk[13][23][1]))))+((mk[16]*((
          Vpk[2][21][2]*Vpk[13][21][2])+((Vpk[2][15][1]*Vpk[13][21][1])+(
          Vpk[2][21][0]*Vpk[13][21][0]))))+temp[0]));
        temp[0] = ((mk[15]*((Vpk[2][20][2]*Vpk[14][20][2])+((Vpk[2][14][1]*
          Vpk[14][20][1])+(Vpk[2][20][0]*Vpk[14][20][0]))))+((mk[13]*((
          Vpk[2][18][2]*Vpk[14][18][2])+((Vpk[2][14][1]*Vpk[14][18][1])+(
          Vpk[2][18][0]*Vpk[14][18][0]))))+((mk[9]*((rk[9][1]*Vpk[2][14][2])-(
          rk[9][2]*Vpk[2][14][1])))+(mk[11]*((Vpk[2][16][2]*Vpk[14][16][2])+((
          Vpk[2][14][1]*Vpk[14][16][1])+(Vpk[2][16][0]*Vpk[14][16][0])))))));
        mm[2][14] = ((mk[17]*((Vpk[2][22][2]*Vpk[14][22][2])+((Vpk[2][20][0]*
          Vpk[14][22][0])+(Vpk[2][22][1]*Vpk[14][22][1]))))+temp[0]);
        temp[0] = ((mk[16]*((Vpk[2][21][2]*Vpk[15][21][2])+((Vpk[2][15][1]*
          Vpk[15][21][1])+(Vpk[2][21][0]*Vpk[15][21][0]))))+((mk[14]*((
          Vpk[2][19][2]*Vpk[15][19][2])+((Vpk[2][15][1]*Vpk[15][19][1])+(
          Vpk[2][19][0]*Vpk[15][19][0]))))+((mk[10]*((rk[10][2]*Vpk[2][15][1])-(
          rk[10][1]*Vpk[2][15][2])))+(mk[12]*((Vpk[2][17][2]*Vpk[15][17][2])+((
          Vpk[2][15][1]*Vpk[15][17][1])+(Vpk[2][17][0]*Vpk[15][17][0])))))));
        mm[2][15] = ((mk[18]*((Vpk[2][23][2]*Vpk[15][23][2])+((Vpk[2][21][0]*
          Vpk[15][23][0])+(Vpk[2][23][1]*Vpk[15][23][1]))))+temp[0]);
        mm[2][16] = ((mk[17]*((Vpk[2][22][2]*Vpk[16][22][2])+((Vpk[2][20][0]*
          Vpk[16][22][0])+(Vpk[2][22][1]*Vpk[16][22][1]))))+((mk[15]*((
          Vpk[2][20][0]*Vpk[16][20][0])+(Vpk[2][20][2]*Vpk[16][20][2])))+((
          mk[11]*((rk[11][2]*Vpk[2][16][0])-(rk[11][0]*Vpk[2][16][2])))+(mk[13]*
          ((Vpk[2][18][0]*Vpk[16][18][0])+(Vpk[2][18][2]*Vpk[16][18][2]))))));
        mm[2][17] = ((mk[18]*((Vpk[2][23][2]*Vpk[17][23][2])+((Vpk[2][21][0]*
          Vpk[17][23][0])+(Vpk[2][23][1]*Vpk[17][23][1]))))+((mk[16]*((
          Vpk[2][21][0]*Vpk[17][21][0])+(Vpk[2][21][2]*Vpk[17][21][2])))+((
          mk[12]*((rk[12][2]*Vpk[2][17][0])-(rk[12][0]*Vpk[2][17][2])))+(mk[14]*
          ((Vpk[2][19][0]*Vpk[17][19][0])+(Vpk[2][19][2]*Vpk[17][19][2]))))));
        mm[2][18] = ((mk[17]*((Vpk[2][22][2]*Vpk[18][22][2])+((Vpk[2][20][0]*
          Vpk[18][22][0])+(Vpk[2][22][1]*Vpk[18][22][1]))))+((mk[13]*((rk[13][2]
          *Vpk[2][18][0])-(rk[13][0]*Vpk[2][18][2])))+(mk[15]*((Vpk[2][20][0]*
          Vpk[18][20][0])+(Vpk[2][20][2]*Vpk[18][20][2])))));
        mm[2][19] = ((mk[18]*((Vpk[2][23][2]*Vpk[19][23][2])+((Vpk[2][21][0]*
          Vpk[19][23][0])+(Vpk[2][23][1]*Vpk[19][23][1]))))+((mk[14]*((rk[14][2]
          *Vpk[2][19][0])-(rk[14][0]*Vpk[2][19][2])))+(mk[16]*((Vpk[2][21][0]*
          Vpk[19][21][0])+(Vpk[2][21][2]*Vpk[19][21][2])))));
        mm[2][20] = ((mk[15]*((rk[15][2]*Vpk[2][20][0])-(rk[15][0]*Vpk[2][20][2]
          )))+(mk[17]*((Vpk[2][22][2]*Vpk[20][22][2])+((Vpk[2][20][0]*
          Vpk[20][22][0])+(Vpk[2][22][1]*Vpk[20][22][1])))));
        mm[2][21] = ((mk[16]*((rk[16][2]*Vpk[2][21][0])-(rk[16][0]*Vpk[2][21][2]
          )))+(mk[18]*((Vpk[2][23][2]*Vpk[21][23][2])+((Vpk[2][21][0]*
          Vpk[21][23][0])+(Vpk[2][23][1]*Vpk[21][23][1])))));
        mm[2][22] = (mk[17]*((rk[17][1]*Vpk[2][22][2])-(rk[17][2]*Vpk[2][22][1])
          ));
        mm[2][23] = (mk[18]*((rk[18][2]*Vpk[2][23][1])-(rk[18][1]*Vpk[2][23][2])
          ));
        mm[2][24] = ((mk[19]*((rk[19][1]*Vpk[2][24][0])-(rk[19][0]*Vpk[2][24][1]
          )))+(mk[20]*((Vpk[2][25][2]*Vpk[24][25][2])+((Vpk[2][24][1]*
          Vpk[24][25][1])+(Vpk[2][25][0]*Vpk[24][25][0])))));
        mm[2][25] = (mk[20]*((rk[20][2]*Vpk[2][25][0])-(rk[20][0]*Vpk[2][25][2])
          ));
        temp[0] = (((ik[0][0][0]+(mk[0]*((rk[0][1]*rk[0][1])+(rk[0][2]*rk[0][2])
          )))+((mk[1]*((Vpk[3][6][2]*Vpk[3][6][2])+((Vpk[3][6][0]*Vpk[3][6][0])+
          (Vpk[3][6][1]*Vpk[3][6][1]))))+((IkWpk[3][6][0]*c6)-(IkWpk[3][6][2]*s6
          ))))+((mk[2]*((Vpk[3][7][2]*Vpk[3][7][2])+((Vpk[3][7][0]*Vpk[3][7][0])
          +(Vpk[3][7][1]*Vpk[3][7][1]))))+((IkWpk[3][7][0]*c7)-(IkWpk[3][7][2]*
          s7))));
        temp[1] = (((mk[4]*((Vpk[3][9][2]*Vpk[3][9][2])+((Vpk[3][9][0]*
          Vpk[3][9][0])+(Vpk[3][9][1]*Vpk[3][9][1]))))+((IkWpk[3][9][2]*
          Wpk[3][9][2])+((IkWpk[3][9][0]*c7)+(IkWpk[3][9][1]*Wpk[3][9][1]))))+((
          (mk[3]*((Vpk[3][8][2]*Vpk[3][8][2])+((Vpk[3][8][0]*Vpk[3][8][0])+(
          Vpk[3][8][1]*Vpk[3][8][1]))))+((IkWpk[3][8][2]*Wpk[3][8][2])+((
          IkWpk[3][8][0]*c6)+(IkWpk[3][8][1]*Wpk[3][8][1]))))+temp[0]));
        temp[2] = (((mk[5]*((Vpk[3][10][2]*Vpk[3][10][2])+((Vpk[3][10][0]*
          Vpk[3][10][0])+(Vpk[3][10][1]*Vpk[3][10][1]))))+((IkWpk[3][10][2]*
          Wpk[3][8][2])+((IkWpk[3][10][0]*Wpk[3][10][0])+(IkWpk[3][10][1]*
          Wpk[3][10][1]))))+temp[1]);
        temp[3] = (((mk[7]*((Vpk[3][12][2]*Vpk[3][12][2])+((Vpk[3][12][0]*
          Vpk[3][12][0])+(Vpk[3][12][1]*Vpk[3][12][1]))))+((IkWpk[3][12][0]*c12)
          +(IkWpk[3][12][1]*s12)))+(((mk[6]*((Vpk[3][11][2]*Vpk[3][11][2])+((
          Vpk[3][11][0]*Vpk[3][11][0])+(Vpk[3][11][1]*Vpk[3][11][1]))))+((
          IkWpk[3][11][2]*Wpk[3][9][2])+((IkWpk[3][11][0]*Wpk[3][11][0])+(
          IkWpk[3][11][1]*Wpk[3][11][1]))))+temp[2]));
        temp[4] = (((mk[9]*((Vpk[3][14][2]*Vpk[3][14][2])+((Vpk[3][14][0]*
          Vpk[3][14][0])+(Vpk[3][14][1]*Vpk[3][14][1]))))+((IkWpk[3][14][2]*
          Wpk[3][14][2])+((IkWpk[3][14][0]*c12)+(IkWpk[3][14][1]*Wpk[3][14][1]))
          ))+(((mk[8]*((Vpk[3][13][2]*Vpk[3][13][2])+((Vpk[3][13][0]*
          Vpk[3][13][0])+(Vpk[3][13][1]*Vpk[3][13][1]))))+((IkWpk[3][13][0]*c13)
          -(IkWpk[3][13][1]*s13)))+temp[3]));
        temp[5] = (((mk[11]*((Vpk[3][16][2]*Vpk[3][16][2])+((Vpk[3][16][0]*
          Vpk[3][16][0])+(Vpk[3][16][1]*Vpk[3][16][1]))))+((IkWpk[3][16][2]*
          Wpk[3][16][2])+((IkWpk[3][16][0]*Wpk[3][16][0])+(IkWpk[3][16][1]*
          Wpk[3][14][1]))))+(((mk[10]*((Vpk[3][15][2]*Vpk[3][15][2])+((
          Vpk[3][15][0]*Vpk[3][15][0])+(Vpk[3][15][1]*Vpk[3][15][1]))))+((
          IkWpk[3][15][2]*Wpk[3][15][2])+((IkWpk[3][15][0]*c13)+(IkWpk[3][15][1]
          *Wpk[3][15][1]))))+temp[4]));
        temp[6] = (((mk[12]*((Vpk[3][17][2]*Vpk[3][17][2])+((Vpk[3][17][0]*
          Vpk[3][17][0])+(Vpk[3][17][1]*Vpk[3][17][1]))))+((IkWpk[3][17][2]*
          Wpk[3][17][2])+((IkWpk[3][17][0]*Wpk[3][17][0])+(IkWpk[3][17][1]*
          Wpk[3][15][1]))))+temp[5]);
        temp[7] = (((mk[13]*((Vpk[3][18][2]*Vpk[3][18][2])+((Vpk[3][18][0]*
          Vpk[3][18][0])+(Vpk[3][18][1]*Vpk[3][18][1]))))+((IkWpk[3][18][2]*
          Wpk[3][18][2])+((IkWpk[3][18][0]*Wpk[3][18][0])+(IkWpk[3][18][1]*
          Wpk[3][14][1]))))+temp[6]);
        temp[8] = (((mk[14]*((Vpk[3][19][2]*Vpk[3][19][2])+((Vpk[3][19][0]*
          Vpk[3][19][0])+(Vpk[3][19][1]*Vpk[3][19][1]))))+((IkWpk[3][19][2]*
          Wpk[3][19][2])+((IkWpk[3][19][0]*Wpk[3][19][0])+(IkWpk[3][19][1]*
          Wpk[3][15][1]))))+temp[7]);
        temp[9] = (((mk[15]*((Vpk[3][20][2]*Vpk[3][20][2])+((Vpk[3][20][0]*
          Vpk[3][20][0])+(Vpk[3][20][1]*Vpk[3][20][1]))))+((IkWpk[3][20][2]*
          Wpk[3][20][2])+((IkWpk[3][20][0]*Wpk[3][20][0])+(IkWpk[3][20][1]*
          Wpk[3][14][1]))))+temp[8]);
        temp[10] = (((mk[16]*((Vpk[3][21][2]*Vpk[3][21][2])+((Vpk[3][21][0]*
          Vpk[3][21][0])+(Vpk[3][21][1]*Vpk[3][21][1]))))+((IkWpk[3][21][2]*
          Wpk[3][21][2])+((IkWpk[3][21][0]*Wpk[3][21][0])+(IkWpk[3][21][1]*
          Wpk[3][15][1]))))+temp[9]);
        temp[11] = (((mk[17]*((Vpk[3][22][2]*Vpk[3][22][2])+((Vpk[3][22][0]*
          Vpk[3][22][0])+(Vpk[3][22][1]*Vpk[3][22][1]))))+((IkWpk[3][22][2]*
          Wpk[3][22][2])+((IkWpk[3][22][0]*Wpk[3][20][0])+(IkWpk[3][22][1]*
          Wpk[3][22][1]))))+temp[10]);
        temp[12] = (((mk[19]*((Vpk[3][24][2]*Vpk[3][24][2])+((Vpk[3][24][0]*
          Vpk[3][24][0])+(Vpk[3][24][1]*Vpk[3][24][1]))))+((IkWpk[3][24][0]*c24)
          -(IkWpk[3][24][1]*s24)))+(((mk[18]*((Vpk[3][23][2]*Vpk[3][23][2])+((
          Vpk[3][23][0]*Vpk[3][23][0])+(Vpk[3][23][1]*Vpk[3][23][1]))))+((
          IkWpk[3][23][2]*Wpk[3][23][2])+((IkWpk[3][23][0]*Wpk[3][21][0])+(
          IkWpk[3][23][1]*Wpk[3][23][1]))))+temp[11]));
        mm[3][3] = (((mk[20]*((Vpk[3][25][2]*Vpk[3][25][2])+((Vpk[3][25][0]*
          Vpk[3][25][0])+(Vpk[3][25][1]*Vpk[3][25][1]))))+((IkWpk[3][25][2]*
          Wpk[3][25][2])+((IkWpk[3][25][0]*Wpk[3][25][0])-(IkWpk[3][25][1]*s24))
          ))+temp[12]);
        temp[0] = (((ik[0][0][1]-(mk[0]*(rk[0][0]*rk[0][1])))+((mk[1]*((
          Vpk[3][6][0]*Vpk[4][6][0])+(Vpk[3][6][2]*Vpk[4][6][2])))+((ik[1][0][1]
          *c6)-(ik[1][2][1]*s6))))+((mk[2]*((Vpk[3][7][0]*Vpk[4][7][0])+(
          Vpk[3][7][2]*Vpk[4][7][2])))+((ik[2][0][1]*c7)-(ik[2][2][1]*s7))));
        temp[1] = (((mk[4]*((Vpk[3][9][2]*Vpk[4][9][2])+((Vpk[3][9][0]*
          Vpk[4][9][0])+(Vpk[3][9][1]*Vpk[4][9][1]))))+((IkWpk[4][9][2]*
          Wpk[3][9][2])+((IkWpk[4][9][0]*c7)+(IkWpk[4][9][1]*Wpk[3][9][1]))))+((
          (mk[3]*((Vpk[3][8][2]*Vpk[4][8][2])+((Vpk[3][8][0]*Vpk[4][8][0])+(
          Vpk[3][8][1]*Vpk[4][8][1]))))+((IkWpk[4][8][2]*Wpk[3][8][2])+((
          IkWpk[4][8][0]*c6)+(IkWpk[4][8][1]*Wpk[3][8][1]))))+temp[0]));
        temp[2] = (((mk[5]*((Vpk[3][10][2]*Vpk[4][10][2])+((Vpk[3][10][0]*
          Vpk[4][10][0])+(Vpk[3][10][1]*Vpk[4][10][1]))))+((IkWpk[4][10][2]*
          Wpk[3][8][2])+((IkWpk[4][10][0]*Wpk[3][10][0])+(IkWpk[4][10][1]*
          Wpk[3][10][1]))))+temp[1]);
        temp[3] = (((mk[7]*((Vpk[3][12][2]*Vpk[4][12][2])+((Vpk[3][12][0]*
          Vpk[4][12][0])+(Vpk[3][12][1]*Vpk[4][12][1]))))+((IkWpk[4][12][0]*c12)
          +(IkWpk[4][12][1]*s12)))+(((mk[6]*((Vpk[3][11][2]*Vpk[4][11][2])+((
          Vpk[3][11][0]*Vpk[4][11][0])+(Vpk[3][11][1]*Vpk[4][11][1]))))+((
          IkWpk[4][11][2]*Wpk[3][9][2])+((IkWpk[4][11][0]*Wpk[3][11][0])+(
          IkWpk[4][11][1]*Wpk[3][11][1]))))+temp[2]));
        temp[4] = (((mk[9]*((Vpk[3][14][2]*Vpk[4][14][2])+((Vpk[3][14][0]*
          Vpk[4][14][0])+(Vpk[3][14][1]*Vpk[4][14][1]))))+((IkWpk[4][14][2]*
          Wpk[3][14][2])+((IkWpk[4][14][0]*c12)+(IkWpk[4][14][1]*Wpk[3][14][1]))
          ))+(((mk[8]*((Vpk[3][13][2]*Vpk[4][13][2])+((Vpk[3][13][0]*
          Vpk[4][13][0])+(Vpk[3][13][1]*Vpk[4][13][1]))))+((IkWpk[4][13][0]*c13)
          -(IkWpk[4][13][1]*s13)))+temp[3]));
        temp[5] = (((mk[11]*((Vpk[3][16][2]*Vpk[4][16][2])+((Vpk[3][16][0]*
          Vpk[4][16][0])+(Vpk[3][16][1]*Vpk[4][16][1]))))+((IkWpk[4][16][2]*
          Wpk[3][16][2])+((IkWpk[4][16][0]*Wpk[3][16][0])+(IkWpk[4][16][1]*
          Wpk[3][14][1]))))+(((mk[10]*((Vpk[3][15][2]*Vpk[4][15][2])+((
          Vpk[3][15][0]*Vpk[4][15][0])+(Vpk[3][15][1]*Vpk[4][15][1]))))+((
          IkWpk[4][15][2]*Wpk[3][15][2])+((IkWpk[4][15][0]*c13)+(IkWpk[4][15][1]
          *Wpk[3][15][1]))))+temp[4]));
        temp[6] = (((mk[12]*((Vpk[3][17][2]*Vpk[4][17][2])+((Vpk[3][17][0]*
          Vpk[4][17][0])+(Vpk[3][17][1]*Vpk[4][17][1]))))+((IkWpk[4][17][2]*
          Wpk[3][17][2])+((IkWpk[4][17][0]*Wpk[3][17][0])+(IkWpk[4][17][1]*
          Wpk[3][15][1]))))+temp[5]);
        temp[7] = (((mk[13]*((Vpk[3][18][2]*Vpk[4][18][2])+((Vpk[3][18][0]*
          Vpk[4][18][0])+(Vpk[3][18][1]*Vpk[4][18][1]))))+((IkWpk[4][18][2]*
          Wpk[3][18][2])+((IkWpk[4][18][0]*Wpk[3][18][0])+(IkWpk[4][18][1]*
          Wpk[3][14][1]))))+temp[6]);
        temp[8] = (((mk[14]*((Vpk[3][19][2]*Vpk[4][19][2])+((Vpk[3][19][0]*
          Vpk[4][19][0])+(Vpk[3][19][1]*Vpk[4][19][1]))))+((IkWpk[4][19][2]*
          Wpk[3][19][2])+((IkWpk[4][19][0]*Wpk[3][19][0])+(IkWpk[4][19][1]*
          Wpk[3][15][1]))))+temp[7]);
        temp[9] = (((mk[15]*((Vpk[3][20][2]*Vpk[4][20][2])+((Vpk[3][20][0]*
          Vpk[4][20][0])+(Vpk[3][20][1]*Vpk[4][20][1]))))+((IkWpk[4][20][2]*
          Wpk[3][20][2])+((IkWpk[4][20][0]*Wpk[3][20][0])+(IkWpk[4][20][1]*
          Wpk[3][14][1]))))+temp[8]);
        temp[10] = (((mk[16]*((Vpk[3][21][2]*Vpk[4][21][2])+((Vpk[3][21][0]*
          Vpk[4][21][0])+(Vpk[3][21][1]*Vpk[4][21][1]))))+((IkWpk[4][21][2]*
          Wpk[3][21][2])+((IkWpk[4][21][0]*Wpk[3][21][0])+(IkWpk[4][21][1]*
          Wpk[3][15][1]))))+temp[9]);
        temp[11] = (((mk[17]*((Vpk[3][22][2]*Vpk[4][22][2])+((Vpk[3][22][0]*
          Vpk[4][22][0])+(Vpk[3][22][1]*Vpk[4][22][1]))))+((IkWpk[4][22][2]*
          Wpk[3][22][2])+((IkWpk[4][22][0]*Wpk[3][20][0])+(IkWpk[4][22][1]*
          Wpk[3][22][1]))))+temp[10]);
        temp[12] = (((mk[19]*((Vpk[3][24][2]*Vpk[4][24][2])+((Vpk[3][24][0]*
          Vpk[4][24][0])+(Vpk[3][24][1]*Vpk[4][24][1]))))+((IkWpk[4][24][0]*c24)
          -(IkWpk[4][24][1]*s24)))+(((mk[18]*((Vpk[3][23][2]*Vpk[4][23][2])+((
          Vpk[3][23][0]*Vpk[4][23][0])+(Vpk[3][23][1]*Vpk[4][23][1]))))+((
          IkWpk[4][23][2]*Wpk[3][23][2])+((IkWpk[4][23][0]*Wpk[3][21][0])+(
          IkWpk[4][23][1]*Wpk[3][23][1]))))+temp[11]));
        mm[3][4] = (((mk[20]*((Vpk[3][25][2]*Vpk[4][25][2])+((Vpk[3][25][0]*
          Vpk[4][25][0])+(Vpk[3][25][1]*Vpk[4][25][1]))))+((IkWpk[4][25][2]*
          Wpk[3][25][2])+((IkWpk[4][25][0]*Wpk[3][25][0])-(IkWpk[4][25][1]*s24))
          ))+temp[12]);
        temp[0] = (((ik[0][0][2]-(mk[0]*(rk[0][0]*rk[0][2])))+((mk[1]*((
          Vpk[3][6][2]*Vpk[5][6][2])+((Vpk[3][6][0]*Vpk[5][6][0])+(Vpk[3][6][1]*
          Vpk[5][6][1]))))+((IkWpk[5][6][0]*c6)-(IkWpk[5][6][2]*s6))))+((mk[2]*(
          (Vpk[3][7][2]*Vpk[5][7][2])+((Vpk[3][7][0]*Vpk[5][7][0])+(Vpk[3][7][1]
          *Vpk[5][7][1]))))+((IkWpk[5][7][0]*c7)-(IkWpk[5][7][2]*s7))));
        temp[1] = (((mk[4]*((Vpk[3][9][2]*Vpk[5][9][2])+((Vpk[3][9][0]*
          Vpk[5][9][0])+(Vpk[3][9][1]*Vpk[5][9][1]))))+((IkWpk[5][9][2]*
          Wpk[3][9][2])+((IkWpk[5][9][0]*c7)+(IkWpk[5][9][1]*Wpk[3][9][1]))))+((
          (mk[3]*((Vpk[3][8][2]*Vpk[5][8][2])+((Vpk[3][8][0]*Vpk[5][8][0])+(
          Vpk[3][8][1]*Vpk[5][8][1]))))+((IkWpk[5][8][2]*Wpk[3][8][2])+((
          IkWpk[5][8][0]*c6)+(IkWpk[5][8][1]*Wpk[3][8][1]))))+temp[0]));
        temp[2] = (((mk[5]*((Vpk[3][10][2]*Vpk[5][10][2])+((Vpk[3][10][0]*
          Vpk[5][10][0])+(Vpk[3][10][1]*Vpk[5][10][1]))))+((IkWpk[5][10][2]*
          Wpk[3][8][2])+((IkWpk[5][10][0]*Wpk[3][10][0])+(IkWpk[5][10][1]*
          Wpk[3][10][1]))))+temp[1]);
        temp[3] = (((mk[7]*((Vpk[3][12][0]*Vpk[5][12][0])+(Vpk[3][12][1]*
          Vpk[5][12][1])))+((ik[7][0][2]*c12)+(ik[7][1][2]*s12)))+(((mk[6]*((
          Vpk[3][11][2]*Vpk[5][11][2])+((Vpk[3][11][0]*Vpk[5][11][0])+(
          Vpk[3][11][1]*Vpk[5][11][1]))))+((IkWpk[5][11][2]*Wpk[3][9][2])+((
          IkWpk[5][11][0]*Wpk[3][11][0])+(IkWpk[5][11][1]*Wpk[3][11][1]))))+
          temp[2]));
        temp[4] = (((mk[9]*((Vpk[3][14][2]*Vpk[5][14][2])+((Vpk[3][14][0]*
          Vpk[5][14][0])+(Vpk[3][14][1]*Vpk[5][14][1]))))+((IkWpk[5][14][2]*
          Wpk[3][14][2])+((IkWpk[5][14][0]*c12)+(IkWpk[5][14][1]*Wpk[3][14][1]))
          ))+(((mk[8]*((Vpk[3][13][0]*Vpk[5][13][0])+(Vpk[3][13][1]*
          Vpk[5][13][1])))+((ik[8][0][2]*c13)-(ik[8][1][2]*s13)))+temp[3]));
        temp[5] = (((mk[11]*((Vpk[3][16][2]*Vpk[5][16][2])+((Vpk[3][16][0]*
          Vpk[5][16][0])+(Vpk[3][16][1]*Vpk[5][16][1]))))+((IkWpk[5][16][2]*
          Wpk[3][16][2])+((IkWpk[5][16][0]*Wpk[3][16][0])+(IkWpk[5][16][1]*
          Wpk[3][14][1]))))+(((mk[10]*((Vpk[3][15][2]*Vpk[5][15][2])+((
          Vpk[3][15][0]*Vpk[5][15][0])+(Vpk[3][15][1]*Vpk[5][15][1]))))+((
          IkWpk[5][15][2]*Wpk[3][15][2])+((IkWpk[5][15][0]*c13)+(IkWpk[5][15][1]
          *Wpk[3][15][1]))))+temp[4]));
        temp[6] = (((mk[12]*((Vpk[3][17][2]*Vpk[5][17][2])+((Vpk[3][17][0]*
          Vpk[5][17][0])+(Vpk[3][17][1]*Vpk[5][17][1]))))+((IkWpk[5][17][2]*
          Wpk[3][17][2])+((IkWpk[5][17][0]*Wpk[3][17][0])+(IkWpk[5][17][1]*
          Wpk[3][15][1]))))+temp[5]);
        temp[7] = (((mk[13]*((Vpk[3][18][2]*Vpk[5][18][2])+((Vpk[3][18][0]*
          Vpk[5][18][0])+(Vpk[3][18][1]*Vpk[5][18][1]))))+((IkWpk[5][18][2]*
          Wpk[3][18][2])+((IkWpk[5][18][0]*Wpk[3][18][0])+(IkWpk[5][18][1]*
          Wpk[3][14][1]))))+temp[6]);
        temp[8] = (((mk[14]*((Vpk[3][19][2]*Vpk[5][19][2])+((Vpk[3][19][0]*
          Vpk[5][19][0])+(Vpk[3][19][1]*Vpk[5][19][1]))))+((IkWpk[5][19][2]*
          Wpk[3][19][2])+((IkWpk[5][19][0]*Wpk[3][19][0])+(IkWpk[5][19][1]*
          Wpk[3][15][1]))))+temp[7]);
        temp[9] = (((mk[15]*((Vpk[3][20][2]*Vpk[5][20][2])+((Vpk[3][20][0]*
          Vpk[5][20][0])+(Vpk[3][20][1]*Vpk[5][20][1]))))+((IkWpk[5][20][2]*
          Wpk[3][20][2])+((IkWpk[5][20][0]*Wpk[3][20][0])+(IkWpk[5][20][1]*
          Wpk[3][14][1]))))+temp[8]);
        temp[10] = (((mk[16]*((Vpk[3][21][2]*Vpk[5][21][2])+((Vpk[3][21][0]*
          Vpk[5][21][0])+(Vpk[3][21][1]*Vpk[5][21][1]))))+((IkWpk[5][21][2]*
          Wpk[3][21][2])+((IkWpk[5][21][0]*Wpk[3][21][0])+(IkWpk[5][21][1]*
          Wpk[3][15][1]))))+temp[9]);
        temp[11] = (((mk[17]*((Vpk[3][22][2]*Vpk[5][22][2])+((Vpk[3][22][0]*
          Vpk[5][22][0])+(Vpk[3][22][1]*Vpk[5][22][1]))))+((IkWpk[5][22][2]*
          Wpk[3][22][2])+((IkWpk[5][22][0]*Wpk[3][20][0])+(IkWpk[5][22][1]*
          Wpk[3][22][1]))))+temp[10]);
        temp[12] = (((mk[19]*((Vpk[3][24][0]*Vpk[5][24][0])+(Vpk[3][24][1]*
          Vpk[5][24][1])))+((ik[19][0][2]*c24)-(ik[19][1][2]*s24)))+(((mk[18]*((
          Vpk[3][23][2]*Vpk[5][23][2])+((Vpk[3][23][0]*Vpk[5][23][0])+(
          Vpk[3][23][1]*Vpk[5][23][1]))))+((IkWpk[5][23][2]*Wpk[3][23][2])+((
          IkWpk[5][23][0]*Wpk[3][21][0])+(IkWpk[5][23][1]*Wpk[3][23][1]))))+
          temp[11]));
        mm[3][5] = (((mk[20]*((Vpk[3][25][2]*Vpk[5][25][2])+((Vpk[3][25][0]*
          Vpk[5][25][0])+(Vpk[3][25][1]*Vpk[5][25][1]))))+((IkWpk[5][25][2]*
          Wpk[3][25][2])+((IkWpk[5][25][0]*Wpk[3][25][0])-(IkWpk[5][25][1]*s24))
          ))+temp[12]);
        temp[0] = (((mk[1]*((rk[1][2]*Vpk[3][6][0])-(rk[1][0]*Vpk[3][6][2])))+((
          ik[1][2][1]*s6)-(ik[1][0][1]*c6)))+((mk[3]*((Vpk[3][8][2]*Vpk[6][8][2]
          )+((Vpk[3][8][0]*Vpk[6][8][0])+(Vpk[3][8][1]*Vpk[6][8][1]))))+((
          IkWpk[6][8][2]*Wpk[3][8][2])+((IkWpk[6][8][0]*c6)+(IkWpk[6][8][1]*
          Wpk[3][8][1])))));
        mm[3][6] = (((mk[5]*((Vpk[3][10][2]*Vpk[6][10][2])+((Vpk[3][10][0]*
          Vpk[6][10][0])+(Vpk[3][10][1]*Vpk[6][10][1]))))+((IkWpk[6][10][2]*
          Wpk[3][8][2])+((IkWpk[6][10][0]*Wpk[3][10][0])+(IkWpk[6][10][1]*
          Wpk[3][10][1]))))+temp[0]);
        temp[0] = (((mk[2]*((rk[2][2]*Vpk[3][7][0])-(rk[2][0]*Vpk[3][7][2])))+((
          ik[2][2][1]*s7)-(ik[2][0][1]*c7)))+((mk[4]*((Vpk[3][9][2]*Vpk[7][9][2]
          )+((Vpk[3][9][0]*Vpk[7][9][0])+(Vpk[3][9][1]*Vpk[7][9][1]))))+((
          IkWpk[7][9][2]*Wpk[3][9][2])+((IkWpk[7][9][0]*c7)+(IkWpk[7][9][1]*
          Wpk[3][9][1])))));
        mm[3][7] = (((mk[6]*((Vpk[3][11][2]*Vpk[7][11][2])+((Vpk[3][11][0]*
          Vpk[7][11][0])+(Vpk[3][11][1]*Vpk[7][11][1]))))+((IkWpk[7][11][2]*
          Wpk[3][9][2])+((IkWpk[7][11][0]*Wpk[3][11][0])+(IkWpk[7][11][1]*
          Wpk[3][11][1]))))+temp[0]);
        mm[3][8] = (((mk[3]*((rk[3][1]*Vpk[3][8][2])-(rk[3][2]*Vpk[3][8][1])))-(
          (ik[3][2][0]*Wpk[3][8][2])+((ik[3][0][0]*c6)+(ik[3][1][0]*Wpk[3][8][1]
          ))))+((mk[5]*((Vpk[3][10][2]*Vpk[8][10][2])+((Vpk[3][10][0]*
          Vpk[8][10][0])+(Vpk[3][10][1]*Vpk[8][10][1]))))+((IkWpk[8][10][2]*
          Wpk[3][8][2])+((IkWpk[8][10][0]*Wpk[3][10][0])+(IkWpk[8][10][1]*
          Wpk[3][10][1])))));
        mm[3][9] = (((mk[4]*((rk[4][2]*Vpk[3][9][1])-(rk[4][1]*Vpk[3][9][2])))+(
          (ik[4][2][0]*Wpk[3][9][2])+((ik[4][0][0]*c7)+(ik[4][1][0]*Wpk[3][9][1]
          ))))+((mk[6]*((Vpk[3][11][2]*Vpk[9][11][2])+((Vpk[3][11][0]*
          Vpk[9][11][0])+(Vpk[3][11][1]*Vpk[9][11][1]))))+((IkWpk[9][11][2]*
          Wpk[3][9][2])+((IkWpk[9][11][0]*Wpk[3][11][0])+(IkWpk[9][11][1]*
          Wpk[3][11][1])))));
        mm[3][10] = ((mk[5]*((rk[5][0]*Vpk[3][10][1])-(rk[5][1]*Vpk[3][10][0])))
          -((ik[5][2][2]*Wpk[3][8][2])+((ik[5][0][2]*Wpk[3][10][0])+(ik[5][1][2]
          *Wpk[3][10][1]))));
        mm[3][11] = ((mk[6]*((rk[6][1]*Vpk[3][11][0])-(rk[6][0]*Vpk[3][11][1])))
          +((ik[6][2][2]*Wpk[3][9][2])+((ik[6][0][2]*Wpk[3][11][0])+(ik[6][1][2]
          *Wpk[3][11][1]))));
        temp[0] = (((mk[7]*((rk[7][0]*Vpk[3][12][1])-(rk[7][1]*Vpk[3][12][0])))-
          ((ik[7][0][2]*c12)+(ik[7][1][2]*s12)))+((mk[9]*((Vpk[3][14][2]*
          Vpk[12][14][2])+((Vpk[3][14][0]*Vpk[12][14][0])+(Vpk[3][14][1]*
          Vpk[12][14][1]))))+((IkWpk[12][14][2]*Wpk[3][14][2])+((
          IkWpk[12][14][0]*c12)+(IkWpk[12][14][1]*Wpk[3][14][1])))));
        temp[1] = (((mk[11]*((Vpk[3][16][2]*Vpk[12][16][2])+((Vpk[3][16][0]*
          Vpk[12][16][0])+(Vpk[3][16][1]*Vpk[12][16][1]))))+((IkWpk[12][16][2]*
          Wpk[3][16][2])+((IkWpk[12][16][0]*Wpk[3][16][0])+(IkWpk[12][16][1]*
          Wpk[3][14][1]))))+temp[0]);
        temp[2] = (((mk[13]*((Vpk[3][18][2]*Vpk[12][18][2])+((Vpk[3][18][0]*
          Vpk[12][18][0])+(Vpk[3][18][1]*Vpk[12][18][1]))))+((IkWpk[12][18][2]*
          Wpk[3][18][2])+((IkWpk[12][18][0]*Wpk[3][18][0])+(IkWpk[12][18][1]*
          Wpk[3][14][1]))))+temp[1]);
        temp[3] = (((mk[15]*((Vpk[3][20][2]*Vpk[12][20][2])+((Vpk[3][20][0]*
          Vpk[12][20][0])+(Vpk[3][20][1]*Vpk[12][20][1]))))+((IkWpk[12][20][2]*
          Wpk[3][20][2])+((IkWpk[12][20][0]*Wpk[3][20][0])+(IkWpk[12][20][1]*
          Wpk[3][14][1]))))+temp[2]);
        mm[3][12] = (((mk[17]*((Vpk[3][22][2]*Vpk[12][22][2])+((Vpk[3][22][0]*
          Vpk[12][22][0])+(Vpk[3][22][1]*Vpk[12][22][1]))))+((IkWpk[12][22][2]*
          Wpk[3][22][2])+((IkWpk[12][22][0]*Wpk[3][20][0])+(IkWpk[12][22][1]*
          Wpk[3][22][1]))))+temp[3]);
        temp[0] = (((mk[8]*((rk[8][1]*Vpk[3][13][0])-(rk[8][0]*Vpk[3][13][1])))+
          ((ik[8][0][2]*c13)-(ik[8][1][2]*s13)))+((mk[10]*((Vpk[3][15][2]*
          Vpk[13][15][2])+((Vpk[3][15][0]*Vpk[13][15][0])+(Vpk[3][15][1]*
          Vpk[13][15][1]))))+((IkWpk[13][15][2]*Wpk[3][15][2])+((
          IkWpk[13][15][0]*c13)+(IkWpk[13][15][1]*Wpk[3][15][1])))));
        temp[1] = (((mk[12]*((Vpk[3][17][2]*Vpk[13][17][2])+((Vpk[3][17][0]*
          Vpk[13][17][0])+(Vpk[3][17][1]*Vpk[13][17][1]))))+((IkWpk[13][17][2]*
          Wpk[3][17][2])+((IkWpk[13][17][0]*Wpk[3][17][0])+(IkWpk[13][17][1]*
          Wpk[3][15][1]))))+temp[0]);
        temp[2] = (((mk[14]*((Vpk[3][19][2]*Vpk[13][19][2])+((Vpk[3][19][0]*
          Vpk[13][19][0])+(Vpk[3][19][1]*Vpk[13][19][1]))))+((IkWpk[13][19][2]*
          Wpk[3][19][2])+((IkWpk[13][19][0]*Wpk[3][19][0])+(IkWpk[13][19][1]*
          Wpk[3][15][1]))))+temp[1]);
        temp[3] = (((mk[16]*((Vpk[3][21][2]*Vpk[13][21][2])+((Vpk[3][21][0]*
          Vpk[13][21][0])+(Vpk[3][21][1]*Vpk[13][21][1]))))+((IkWpk[13][21][2]*
          Wpk[3][21][2])+((IkWpk[13][21][0]*Wpk[3][21][0])+(IkWpk[13][21][1]*
          Wpk[3][15][1]))))+temp[2]);
        mm[3][13] = (((mk[18]*((Vpk[3][23][2]*Vpk[13][23][2])+((Vpk[3][23][0]*
          Vpk[13][23][0])+(Vpk[3][23][1]*Vpk[13][23][1]))))+((IkWpk[13][23][2]*
          Wpk[3][23][2])+((IkWpk[13][23][0]*Wpk[3][21][0])+(IkWpk[13][23][1]*
          Wpk[3][23][1]))))+temp[3]);
        temp[0] = (((mk[9]*((rk[9][1]*Vpk[3][14][2])-(rk[9][2]*Vpk[3][14][1])))-
          ((ik[9][2][0]*Wpk[3][14][2])+((ik[9][0][0]*c12)+(ik[9][1][0]*
          Wpk[3][14][1]))))+((mk[11]*((Vpk[3][16][2]*Vpk[14][16][2])+((
          Vpk[3][16][0]*Vpk[14][16][0])+(Vpk[3][16][1]*Vpk[14][16][1]))))+((
          IkWpk[14][16][2]*Wpk[3][16][2])+((IkWpk[14][16][0]*Wpk[3][16][0])+(
          IkWpk[14][16][1]*Wpk[3][14][1])))));
        temp[1] = (((mk[13]*((Vpk[3][18][2]*Vpk[14][18][2])+((Vpk[3][18][0]*
          Vpk[14][18][0])+(Vpk[3][18][1]*Vpk[14][18][1]))))+((IkWpk[14][18][2]*
          Wpk[3][18][2])+((IkWpk[14][18][0]*Wpk[3][18][0])+(IkWpk[14][18][1]*
          Wpk[3][14][1]))))+temp[0]);
        temp[2] = (((mk[15]*((Vpk[3][20][2]*Vpk[14][20][2])+((Vpk[3][20][0]*
          Vpk[14][20][0])+(Vpk[3][20][1]*Vpk[14][20][1]))))+((IkWpk[14][20][2]*
          Wpk[3][20][2])+((IkWpk[14][20][0]*Wpk[3][20][0])+(IkWpk[14][20][1]*
          Wpk[3][14][1]))))+temp[1]);
        mm[3][14] = (((mk[17]*((Vpk[3][22][2]*Vpk[14][22][2])+((Vpk[3][22][0]*
          Vpk[14][22][0])+(Vpk[3][22][1]*Vpk[14][22][1]))))+((IkWpk[14][22][2]*
          Wpk[3][22][2])+((IkWpk[14][22][0]*Wpk[3][20][0])+(IkWpk[14][22][1]*
          Wpk[3][22][1]))))+temp[2]);
        temp[0] = (((mk[10]*((rk[10][2]*Vpk[3][15][1])-(rk[10][1]*Vpk[3][15][2])
          ))+((ik[10][2][0]*Wpk[3][15][2])+((ik[10][0][0]*c13)+(ik[10][1][0]*
          Wpk[3][15][1]))))+((mk[12]*((Vpk[3][17][2]*Vpk[15][17][2])+((
          Vpk[3][17][0]*Vpk[15][17][0])+(Vpk[3][17][1]*Vpk[15][17][1]))))+((
          IkWpk[15][17][2]*Wpk[3][17][2])+((IkWpk[15][17][0]*Wpk[3][17][0])+(
          IkWpk[15][17][1]*Wpk[3][15][1])))));
        temp[1] = (((mk[14]*((Vpk[3][19][2]*Vpk[15][19][2])+((Vpk[3][19][0]*
          Vpk[15][19][0])+(Vpk[3][19][1]*Vpk[15][19][1]))))+((IkWpk[15][19][2]*
          Wpk[3][19][2])+((IkWpk[15][19][0]*Wpk[3][19][0])+(IkWpk[15][19][1]*
          Wpk[3][15][1]))))+temp[0]);
        temp[2] = (((mk[16]*((Vpk[3][21][2]*Vpk[15][21][2])+((Vpk[3][21][0]*
          Vpk[15][21][0])+(Vpk[3][21][1]*Vpk[15][21][1]))))+((IkWpk[15][21][2]*
          Wpk[3][21][2])+((IkWpk[15][21][0]*Wpk[3][21][0])+(IkWpk[15][21][1]*
          Wpk[3][15][1]))))+temp[1]);
        mm[3][15] = (((mk[18]*((Vpk[3][23][2]*Vpk[15][23][2])+((Vpk[3][23][0]*
          Vpk[15][23][0])+(Vpk[3][23][1]*Vpk[15][23][1]))))+((IkWpk[15][23][2]*
          Wpk[3][23][2])+((IkWpk[15][23][0]*Wpk[3][21][0])+(IkWpk[15][23][1]*
          Wpk[3][23][1]))))+temp[2]);
        temp[0] = (((mk[11]*((rk[11][2]*Vpk[3][16][0])-(rk[11][0]*Vpk[3][16][2])
          ))-((ik[11][2][1]*Wpk[3][16][2])+((ik[11][0][1]*Wpk[3][16][0])+(
          ik[11][1][1]*Wpk[3][14][1]))))+((mk[13]*((Vpk[3][18][0]*Vpk[16][18][0]
          )+(Vpk[3][18][2]*Vpk[16][18][2])))-((ik[13][2][1]*Wpk[3][18][2])+((
          ik[13][0][1]*Wpk[3][18][0])+(ik[13][1][1]*Wpk[3][14][1])))));
        mm[3][16] = (((mk[17]*((Vpk[3][22][2]*Vpk[16][22][2])+((Vpk[3][22][0]*
          Vpk[16][22][0])+(Vpk[3][22][1]*Vpk[16][22][1]))))+((IkWpk[16][22][2]*
          Wpk[3][22][2])+((IkWpk[16][22][0]*Wpk[3][20][0])+(IkWpk[16][22][1]*
          Wpk[3][22][1]))))+(((mk[15]*((Vpk[3][20][0]*Vpk[16][20][0])+(
          Vpk[3][20][2]*Vpk[16][20][2])))-((ik[15][2][1]*Wpk[3][20][2])+((
          ik[15][0][1]*Wpk[3][20][0])+(ik[15][1][1]*Wpk[3][14][1]))))+temp[0]));
        temp[0] = (((mk[12]*((rk[12][2]*Vpk[3][17][0])-(rk[12][0]*Vpk[3][17][2])
          ))-((ik[12][2][1]*Wpk[3][17][2])+((ik[12][0][1]*Wpk[3][17][0])+(
          ik[12][1][1]*Wpk[3][15][1]))))+((mk[14]*((Vpk[3][19][0]*Vpk[17][19][0]
          )+(Vpk[3][19][2]*Vpk[17][19][2])))-((ik[14][2][1]*Wpk[3][19][2])+((
          ik[14][0][1]*Wpk[3][19][0])+(ik[14][1][1]*Wpk[3][15][1])))));
        mm[3][17] = (((mk[18]*((Vpk[3][23][2]*Vpk[17][23][2])+((Vpk[3][23][0]*
          Vpk[17][23][0])+(Vpk[3][23][1]*Vpk[17][23][1]))))+((IkWpk[17][23][2]*
          Wpk[3][23][2])+((IkWpk[17][23][0]*Wpk[3][21][0])+(IkWpk[17][23][1]*
          Wpk[3][23][1]))))+(((mk[16]*((Vpk[3][21][0]*Vpk[17][21][0])+(
          Vpk[3][21][2]*Vpk[17][21][2])))-((ik[16][2][1]*Wpk[3][21][2])+((
          ik[16][0][1]*Wpk[3][21][0])+(ik[16][1][1]*Wpk[3][15][1]))))+temp[0]));
        temp[0] = (((mk[13]*((rk[13][2]*Vpk[3][18][0])-(rk[13][0]*Vpk[3][18][2])
          ))-((ik[13][2][1]*Wpk[3][18][2])+((ik[13][0][1]*Wpk[3][18][0])+(
          ik[13][1][1]*Wpk[3][14][1]))))+((mk[15]*((Vpk[3][20][0]*Vpk[18][20][0]
          )+(Vpk[3][20][2]*Vpk[18][20][2])))-((ik[15][2][1]*Wpk[3][20][2])+((
          ik[15][0][1]*Wpk[3][20][0])+(ik[15][1][1]*Wpk[3][14][1])))));
        mm[3][18] = (((mk[17]*((Vpk[3][22][2]*Vpk[18][22][2])+((Vpk[3][22][0]*
          Vpk[18][22][0])+(Vpk[3][22][1]*Vpk[18][22][1]))))+((IkWpk[18][22][2]*
          Wpk[3][22][2])+((IkWpk[18][22][0]*Wpk[3][20][0])+(IkWpk[18][22][1]*
          Wpk[3][22][1]))))+temp[0]);
        temp[0] = (((mk[14]*((rk[14][2]*Vpk[3][19][0])-(rk[14][0]*Vpk[3][19][2])
          ))-((ik[14][2][1]*Wpk[3][19][2])+((ik[14][0][1]*Wpk[3][19][0])+(
          ik[14][1][1]*Wpk[3][15][1]))))+((mk[16]*((Vpk[3][21][0]*Vpk[19][21][0]
          )+(Vpk[3][21][2]*Vpk[19][21][2])))-((ik[16][2][1]*Wpk[3][21][2])+((
          ik[16][0][1]*Wpk[3][21][0])+(ik[16][1][1]*Wpk[3][15][1])))));
        mm[3][19] = (((mk[18]*((Vpk[3][23][2]*Vpk[19][23][2])+((Vpk[3][23][0]*
          Vpk[19][23][0])+(Vpk[3][23][1]*Vpk[19][23][1]))))+((IkWpk[19][23][2]*
          Wpk[3][23][2])+((IkWpk[19][23][0]*Wpk[3][21][0])+(IkWpk[19][23][1]*
          Wpk[3][23][1]))))+temp[0]);
        mm[3][20] = (((mk[15]*((rk[15][2]*Vpk[3][20][0])-(rk[15][0]*
          Vpk[3][20][2])))-((ik[15][2][1]*Wpk[3][20][2])+((ik[15][0][1]*
          Wpk[3][20][0])+(ik[15][1][1]*Wpk[3][14][1]))))+((mk[17]*((
          Vpk[3][22][2]*Vpk[20][22][2])+((Vpk[3][22][0]*Vpk[20][22][0])+(
          Vpk[3][22][1]*Vpk[20][22][1]))))+((IkWpk[20][22][2]*Wpk[3][22][2])+((
          IkWpk[20][22][0]*Wpk[3][20][0])+(IkWpk[20][22][1]*Wpk[3][22][1])))));
        mm[3][21] = (((mk[16]*((rk[16][2]*Vpk[3][21][0])-(rk[16][0]*
          Vpk[3][21][2])))-((ik[16][2][1]*Wpk[3][21][2])+((ik[16][0][1]*
          Wpk[3][21][0])+(ik[16][1][1]*Wpk[3][15][1]))))+((mk[18]*((
          Vpk[3][23][2]*Vpk[21][23][2])+((Vpk[3][23][0]*Vpk[21][23][0])+(
          Vpk[3][23][1]*Vpk[21][23][1]))))+((IkWpk[21][23][2]*Wpk[3][23][2])+((
          IkWpk[21][23][0]*Wpk[3][21][0])+(IkWpk[21][23][1]*Wpk[3][23][1])))));
        mm[3][22] = ((mk[17]*((rk[17][1]*Vpk[3][22][2])-(rk[17][2]*Vpk[3][22][1]
          )))-((ik[17][2][0]*Wpk[3][22][2])+((ik[17][0][0]*Wpk[3][20][0])+(
          ik[17][1][0]*Wpk[3][22][1]))));
        mm[3][23] = ((mk[18]*((rk[18][2]*Vpk[3][23][1])-(rk[18][1]*Vpk[3][23][2]
          )))+((ik[18][2][0]*Wpk[3][23][2])+((ik[18][0][0]*Wpk[3][21][0])+(
          ik[18][1][0]*Wpk[3][23][1]))));
        mm[3][24] = (((mk[19]*((rk[19][1]*Vpk[3][24][0])-(rk[19][0]*
          Vpk[3][24][1])))+((ik[19][0][2]*c24)-(ik[19][1][2]*s24)))+((mk[20]*((
          Vpk[3][25][2]*Vpk[24][25][2])+((Vpk[3][25][0]*Vpk[24][25][0])+(
          Vpk[3][25][1]*Vpk[24][25][1]))))+((IkWpk[24][25][2]*Wpk[3][25][2])+((
          IkWpk[24][25][0]*Wpk[3][25][0])-(IkWpk[24][25][1]*s24)))));
        mm[3][25] = ((mk[20]*((rk[20][2]*Vpk[3][25][0])-(rk[20][0]*Vpk[3][25][2]
          )))+(((ik[20][1][1]*s24)-(ik[20][0][1]*Wpk[3][25][0]))-(ik[20][2][1]*
          Wpk[3][25][2])));
        temp[0] = (((ik[2][1][1]+(mk[2]*((Vpk[4][7][0]*Vpk[4][7][0])+(
          Vpk[4][7][2]*Vpk[4][7][2]))))+((ik[0][1][1]+(mk[0]*((rk[0][0]*rk[0][0]
          )+(rk[0][2]*rk[0][2]))))+(ik[1][1][1]+(mk[1]*((Vpk[4][6][0]*
          Vpk[4][6][0])+(Vpk[4][6][2]*Vpk[4][6][2]))))))+((mk[3]*((Vpk[4][8][2]*
          Vpk[4][8][2])+((Vpk[4][8][0]*Vpk[4][8][0])+(Vpk[4][8][1]*Vpk[4][8][1])
          )))+((IkWpk[4][8][1]*c8)+(IkWpk[4][8][2]*s8))));
        temp[1] = (((mk[5]*((Vpk[4][10][2]*Vpk[4][10][2])+((Vpk[4][10][0]*
          Vpk[4][10][0])+(Vpk[4][10][1]*Vpk[4][10][1]))))+((IkWpk[4][10][2]*s8)+
          ((IkWpk[4][10][0]*Wpk[4][10][0])+(IkWpk[4][10][1]*Wpk[4][10][1]))))+((
          (mk[4]*((Vpk[4][9][2]*Vpk[4][9][2])+((Vpk[4][9][0]*Vpk[4][9][0])+(
          Vpk[4][9][1]*Vpk[4][9][1]))))+((IkWpk[4][9][1]*c9)-(IkWpk[4][9][2]*s9)
          ))+temp[0]));
        temp[2] = (((mk[7]*((Vpk[4][12][2]*Vpk[4][12][2])+((Vpk[4][12][0]*
          Vpk[4][12][0])+(Vpk[4][12][1]*Vpk[4][12][1]))))+((IkWpk[4][12][1]*c12)
          -(IkWpk[4][12][0]*s12)))+(((mk[6]*((Vpk[4][11][2]*Vpk[4][11][2])+((
          Vpk[4][11][0]*Vpk[4][11][0])+(Vpk[4][11][1]*Vpk[4][11][1]))))+(((
          IkWpk[4][11][0]*Wpk[4][11][0])+(IkWpk[4][11][1]*Wpk[4][11][1]))-(
          IkWpk[4][11][2]*s9)))+temp[1]));
        temp[3] = (((mk[9]*((Vpk[4][14][2]*Vpk[4][14][2])+((Vpk[4][14][0]*
          Vpk[4][14][0])+(Vpk[4][14][1]*Vpk[4][14][1]))))+((IkWpk[4][14][2]*
          Wpk[4][14][2])+((IkWpk[4][14][1]*Wpk[4][14][1])-(IkWpk[4][14][0]*s12))
          ))+(((mk[8]*((Vpk[4][13][2]*Vpk[4][13][2])+((Vpk[4][13][0]*
          Vpk[4][13][0])+(Vpk[4][13][1]*Vpk[4][13][1]))))+((IkWpk[4][13][0]*s13)
          +(IkWpk[4][13][1]*c13)))+temp[2]));
        temp[4] = (((mk[11]*((Vpk[4][16][2]*Vpk[4][16][2])+((Vpk[4][16][0]*
          Vpk[4][16][0])+(Vpk[4][16][1]*Vpk[4][16][1]))))+((IkWpk[4][16][2]*
          Wpk[4][16][2])+((IkWpk[4][16][0]*Wpk[4][16][0])+(IkWpk[4][16][1]*
          Wpk[4][14][1]))))+(((mk[10]*((Vpk[4][15][2]*Vpk[4][15][2])+((
          Vpk[4][15][0]*Vpk[4][15][0])+(Vpk[4][15][1]*Vpk[4][15][1]))))+((
          IkWpk[4][15][2]*Wpk[4][15][2])+((IkWpk[4][15][0]*s13)+(IkWpk[4][15][1]
          *Wpk[4][15][1]))))+temp[3]));
        temp[5] = (((mk[12]*((Vpk[4][17][2]*Vpk[4][17][2])+((Vpk[4][17][0]*
          Vpk[4][17][0])+(Vpk[4][17][1]*Vpk[4][17][1]))))+((IkWpk[4][17][2]*
          Wpk[4][17][2])+((IkWpk[4][17][0]*Wpk[4][17][0])+(IkWpk[4][17][1]*
          Wpk[4][15][1]))))+temp[4]);
        temp[6] = (((mk[13]*((Vpk[4][18][2]*Vpk[4][18][2])+((Vpk[4][18][0]*
          Vpk[4][18][0])+(Vpk[4][18][1]*Vpk[4][18][1]))))+((IkWpk[4][18][2]*
          Wpk[4][18][2])+((IkWpk[4][18][0]*Wpk[4][18][0])+(IkWpk[4][18][1]*
          Wpk[4][14][1]))))+temp[5]);
        temp[7] = (((mk[14]*((Vpk[4][19][2]*Vpk[4][19][2])+((Vpk[4][19][0]*
          Vpk[4][19][0])+(Vpk[4][19][1]*Vpk[4][19][1]))))+((IkWpk[4][19][2]*
          Wpk[4][19][2])+((IkWpk[4][19][0]*Wpk[4][19][0])+(IkWpk[4][19][1]*
          Wpk[4][15][1]))))+temp[6]);
        temp[8] = (((mk[15]*((Vpk[4][20][2]*Vpk[4][20][2])+((Vpk[4][20][0]*
          Vpk[4][20][0])+(Vpk[4][20][1]*Vpk[4][20][1]))))+((IkWpk[4][20][2]*
          Wpk[4][20][2])+((IkWpk[4][20][0]*Wpk[4][20][0])+(IkWpk[4][20][1]*
          Wpk[4][14][1]))))+temp[7]);
        temp[9] = (((mk[16]*((Vpk[4][21][2]*Vpk[4][21][2])+((Vpk[4][21][0]*
          Vpk[4][21][0])+(Vpk[4][21][1]*Vpk[4][21][1]))))+((IkWpk[4][21][2]*
          Wpk[4][21][2])+((IkWpk[4][21][0]*Wpk[4][21][0])+(IkWpk[4][21][1]*
          Wpk[4][15][1]))))+temp[8]);
        temp[10] = (((mk[17]*((Vpk[4][22][2]*Vpk[4][22][2])+((Vpk[4][22][0]*
          Vpk[4][22][0])+(Vpk[4][22][1]*Vpk[4][22][1]))))+((IkWpk[4][22][2]*
          Wpk[4][22][2])+((IkWpk[4][22][0]*Wpk[4][20][0])+(IkWpk[4][22][1]*
          Wpk[4][22][1]))))+temp[9]);
        temp[11] = (((mk[19]*((Vpk[4][24][2]*Vpk[4][24][2])+((Vpk[4][24][0]*
          Vpk[4][24][0])+(Vpk[4][24][1]*Vpk[4][24][1]))))+((IkWpk[4][24][0]*s24)
          +(IkWpk[4][24][1]*c24)))+(((mk[18]*((Vpk[4][23][2]*Vpk[4][23][2])+((
          Vpk[4][23][0]*Vpk[4][23][0])+(Vpk[4][23][1]*Vpk[4][23][1]))))+((
          IkWpk[4][23][2]*Wpk[4][23][2])+((IkWpk[4][23][0]*Wpk[4][21][0])+(
          IkWpk[4][23][1]*Wpk[4][23][1]))))+temp[10]));
        mm[4][4] = (((mk[20]*((Vpk[4][25][2]*Vpk[4][25][2])+((Vpk[4][25][0]*
          Vpk[4][25][0])+(Vpk[4][25][1]*Vpk[4][25][1]))))+((IkWpk[4][25][2]*
          Wpk[4][25][2])+((IkWpk[4][25][0]*Wpk[4][25][0])+(IkWpk[4][25][1]*c24))
          ))+temp[11]);
        temp[0] = (((IkWpk[5][7][1]+(mk[2]*((Vpk[4][7][0]*Vpk[5][7][0])+(
          Vpk[4][7][2]*Vpk[5][7][2]))))+((ik[0][1][2]-(mk[0]*(rk[0][1]*rk[0][2])
          ))+(IkWpk[5][6][1]+(mk[1]*((Vpk[4][6][0]*Vpk[5][6][0])+(Vpk[4][6][2]*
          Vpk[5][6][2]))))))+((mk[3]*((Vpk[4][8][2]*Vpk[5][8][2])+((Vpk[4][8][0]
          *Vpk[5][8][0])+(Vpk[4][8][1]*Vpk[5][8][1]))))+((IkWpk[5][8][1]*c8)+(
          IkWpk[5][8][2]*s8))));
        temp[1] = (((mk[5]*((Vpk[4][10][2]*Vpk[5][10][2])+((Vpk[4][10][0]*
          Vpk[5][10][0])+(Vpk[4][10][1]*Vpk[5][10][1]))))+((IkWpk[5][10][2]*s8)+
          ((IkWpk[5][10][0]*Wpk[4][10][0])+(IkWpk[5][10][1]*Wpk[4][10][1]))))+((
          (mk[4]*((Vpk[4][9][2]*Vpk[5][9][2])+((Vpk[4][9][0]*Vpk[5][9][0])+(
          Vpk[4][9][1]*Vpk[5][9][1]))))+((IkWpk[5][9][1]*c9)-(IkWpk[5][9][2]*s9)
          ))+temp[0]));
        temp[2] = (((mk[7]*((Vpk[4][12][0]*Vpk[5][12][0])+(Vpk[4][12][1]*
          Vpk[5][12][1])))+((ik[7][1][2]*c12)-(ik[7][0][2]*s12)))+(((mk[6]*((
          Vpk[4][11][2]*Vpk[5][11][2])+((Vpk[4][11][0]*Vpk[5][11][0])+(
          Vpk[4][11][1]*Vpk[5][11][1]))))+(((IkWpk[5][11][0]*Wpk[4][11][0])+(
          IkWpk[5][11][1]*Wpk[4][11][1]))-(IkWpk[5][11][2]*s9)))+temp[1]));
        temp[3] = (((mk[9]*((Vpk[4][14][2]*Vpk[5][14][2])+((Vpk[4][14][0]*
          Vpk[5][14][0])+(Vpk[4][14][1]*Vpk[5][14][1]))))+((IkWpk[5][14][2]*
          Wpk[4][14][2])+((IkWpk[5][14][1]*Wpk[4][14][1])-(IkWpk[5][14][0]*s12))
          ))+(((mk[8]*((Vpk[4][13][0]*Vpk[5][13][0])+(Vpk[4][13][1]*
          Vpk[5][13][1])))+((ik[8][0][2]*s13)+(ik[8][1][2]*c13)))+temp[2]));
        temp[4] = (((mk[11]*((Vpk[4][16][2]*Vpk[5][16][2])+((Vpk[4][16][0]*
          Vpk[5][16][0])+(Vpk[4][16][1]*Vpk[5][16][1]))))+((IkWpk[5][16][2]*
          Wpk[4][16][2])+((IkWpk[5][16][0]*Wpk[4][16][0])+(IkWpk[5][16][1]*
          Wpk[4][14][1]))))+(((mk[10]*((Vpk[4][15][2]*Vpk[5][15][2])+((
          Vpk[4][15][0]*Vpk[5][15][0])+(Vpk[4][15][1]*Vpk[5][15][1]))))+((
          IkWpk[5][15][2]*Wpk[4][15][2])+((IkWpk[5][15][0]*s13)+(IkWpk[5][15][1]
          *Wpk[4][15][1]))))+temp[3]));
        temp[5] = (((mk[12]*((Vpk[4][17][2]*Vpk[5][17][2])+((Vpk[4][17][0]*
          Vpk[5][17][0])+(Vpk[4][17][1]*Vpk[5][17][1]))))+((IkWpk[5][17][2]*
          Wpk[4][17][2])+((IkWpk[5][17][0]*Wpk[4][17][0])+(IkWpk[5][17][1]*
          Wpk[4][15][1]))))+temp[4]);
        temp[6] = (((mk[13]*((Vpk[4][18][2]*Vpk[5][18][2])+((Vpk[4][18][0]*
          Vpk[5][18][0])+(Vpk[4][18][1]*Vpk[5][18][1]))))+((IkWpk[5][18][2]*
          Wpk[4][18][2])+((IkWpk[5][18][0]*Wpk[4][18][0])+(IkWpk[5][18][1]*
          Wpk[4][14][1]))))+temp[5]);
        temp[7] = (((mk[14]*((Vpk[4][19][2]*Vpk[5][19][2])+((Vpk[4][19][0]*
          Vpk[5][19][0])+(Vpk[4][19][1]*Vpk[5][19][1]))))+((IkWpk[5][19][2]*
          Wpk[4][19][2])+((IkWpk[5][19][0]*Wpk[4][19][0])+(IkWpk[5][19][1]*
          Wpk[4][15][1]))))+temp[6]);
        temp[8] = (((mk[15]*((Vpk[4][20][2]*Vpk[5][20][2])+((Vpk[4][20][0]*
          Vpk[5][20][0])+(Vpk[4][20][1]*Vpk[5][20][1]))))+((IkWpk[5][20][2]*
          Wpk[4][20][2])+((IkWpk[5][20][0]*Wpk[4][20][0])+(IkWpk[5][20][1]*
          Wpk[4][14][1]))))+temp[7]);
        temp[9] = (((mk[16]*((Vpk[4][21][2]*Vpk[5][21][2])+((Vpk[4][21][0]*
          Vpk[5][21][0])+(Vpk[4][21][1]*Vpk[5][21][1]))))+((IkWpk[5][21][2]*
          Wpk[4][21][2])+((IkWpk[5][21][0]*Wpk[4][21][0])+(IkWpk[5][21][1]*
          Wpk[4][15][1]))))+temp[8]);
        temp[10] = (((mk[17]*((Vpk[4][22][2]*Vpk[5][22][2])+((Vpk[4][22][0]*
          Vpk[5][22][0])+(Vpk[4][22][1]*Vpk[5][22][1]))))+((IkWpk[5][22][2]*
          Wpk[4][22][2])+((IkWpk[5][22][0]*Wpk[4][20][0])+(IkWpk[5][22][1]*
          Wpk[4][22][1]))))+temp[9]);
        temp[11] = (((mk[19]*((Vpk[4][24][0]*Vpk[5][24][0])+(Vpk[4][24][1]*
          Vpk[5][24][1])))+((ik[19][0][2]*s24)+(ik[19][1][2]*c24)))+(((mk[18]*((
          Vpk[4][23][2]*Vpk[5][23][2])+((Vpk[4][23][0]*Vpk[5][23][0])+(
          Vpk[4][23][1]*Vpk[5][23][1]))))+((IkWpk[5][23][2]*Wpk[4][23][2])+((
          IkWpk[5][23][0]*Wpk[4][21][0])+(IkWpk[5][23][1]*Wpk[4][23][1]))))+
          temp[10]));
        mm[4][5] = (((mk[20]*((Vpk[4][25][2]*Vpk[5][25][2])+((Vpk[4][25][0]*
          Vpk[5][25][0])+(Vpk[4][25][1]*Vpk[5][25][1]))))+((IkWpk[5][25][2]*
          Wpk[4][25][2])+((IkWpk[5][25][0]*Wpk[4][25][0])+(IkWpk[5][25][1]*c24))
          ))+temp[11]);
        temp[0] = (((mk[1]*((rk[1][2]*Vpk[4][6][0])-(rk[1][0]*Vpk[4][6][2])))-
          ik[1][1][1])+((mk[3]*((Vpk[4][8][2]*Vpk[6][8][2])+((Vpk[4][8][0]*
          Vpk[6][8][0])+(Vpk[4][8][1]*Vpk[6][8][1]))))+((IkWpk[6][8][1]*c8)+(
          IkWpk[6][8][2]*s8))));
        mm[4][6] = (((mk[5]*((Vpk[4][10][2]*Vpk[6][10][2])+((Vpk[4][10][0]*
          Vpk[6][10][0])+(Vpk[4][10][1]*Vpk[6][10][1]))))+((IkWpk[6][10][2]*s8)+
          ((IkWpk[6][10][0]*Wpk[4][10][0])+(IkWpk[6][10][1]*Wpk[4][10][1]))))+
          temp[0]);
        temp[0] = (((mk[2]*((rk[2][2]*Vpk[4][7][0])-(rk[2][0]*Vpk[4][7][2])))-
          ik[2][1][1])+((mk[4]*((Vpk[4][9][2]*Vpk[7][9][2])+((Vpk[4][9][0]*
          Vpk[7][9][0])+(Vpk[4][9][1]*Vpk[7][9][1]))))+((IkWpk[7][9][1]*c9)-(
          IkWpk[7][9][2]*s9))));
        mm[4][7] = (((mk[6]*((Vpk[4][11][2]*Vpk[7][11][2])+((Vpk[4][11][0]*
          Vpk[7][11][0])+(Vpk[4][11][1]*Vpk[7][11][1]))))+(((IkWpk[7][11][0]*
          Wpk[4][11][0])+(IkWpk[7][11][1]*Wpk[4][11][1]))-(IkWpk[7][11][2]*s9)))
          +temp[0]);
        mm[4][8] = (((mk[3]*((rk[3][1]*Vpk[4][8][2])-(rk[3][2]*Vpk[4][8][1])))-(
          (ik[3][1][0]*c8)+(ik[3][2][0]*s8)))+((mk[5]*((Vpk[4][10][2]*
          Vpk[8][10][2])+((Vpk[4][10][0]*Vpk[8][10][0])+(Vpk[4][10][1]*
          Vpk[8][10][1]))))+((IkWpk[8][10][2]*s8)+((IkWpk[8][10][0]*
          Wpk[4][10][0])+(IkWpk[8][10][1]*Wpk[4][10][1])))));
        mm[4][9] = (((mk[4]*((rk[4][2]*Vpk[4][9][1])-(rk[4][1]*Vpk[4][9][2])))+(
          (ik[4][1][0]*c9)-(ik[4][2][0]*s9)))+((mk[6]*((Vpk[4][11][2]*
          Vpk[9][11][2])+((Vpk[4][11][0]*Vpk[9][11][0])+(Vpk[4][11][1]*
          Vpk[9][11][1]))))+(((IkWpk[9][11][0]*Wpk[4][11][0])+(IkWpk[9][11][1]*
          Wpk[4][11][1]))-(IkWpk[9][11][2]*s9))));
        mm[4][10] = ((mk[5]*((rk[5][0]*Vpk[4][10][1])-(rk[5][1]*Vpk[4][10][0])))
          -((ik[5][2][2]*s8)+((ik[5][0][2]*Wpk[4][10][0])+(ik[5][1][2]*
          Wpk[4][10][1]))));
        mm[4][11] = ((mk[6]*((rk[6][1]*Vpk[4][11][0])-(rk[6][0]*Vpk[4][11][1])))
          +(((ik[6][0][2]*Wpk[4][11][0])+(ik[6][1][2]*Wpk[4][11][1]))-(
          ik[6][2][2]*s9)));
        temp[0] = (((mk[7]*((rk[7][0]*Vpk[4][12][1])-(rk[7][1]*Vpk[4][12][0])))+
          ((ik[7][0][2]*s12)-(ik[7][1][2]*c12)))+((mk[9]*((Vpk[4][14][2]*
          Vpk[12][14][2])+((Vpk[4][14][0]*Vpk[12][14][0])+(Vpk[4][14][1]*
          Vpk[12][14][1]))))+((IkWpk[12][14][2]*Wpk[4][14][2])+((
          IkWpk[12][14][1]*Wpk[4][14][1])-(IkWpk[12][14][0]*s12)))));
        temp[1] = (((mk[11]*((Vpk[4][16][2]*Vpk[12][16][2])+((Vpk[4][16][0]*
          Vpk[12][16][0])+(Vpk[4][16][1]*Vpk[12][16][1]))))+((IkWpk[12][16][2]*
          Wpk[4][16][2])+((IkWpk[12][16][0]*Wpk[4][16][0])+(IkWpk[12][16][1]*
          Wpk[4][14][1]))))+temp[0]);
        temp[2] = (((mk[13]*((Vpk[4][18][2]*Vpk[12][18][2])+((Vpk[4][18][0]*
          Vpk[12][18][0])+(Vpk[4][18][1]*Vpk[12][18][1]))))+((IkWpk[12][18][2]*
          Wpk[4][18][2])+((IkWpk[12][18][0]*Wpk[4][18][0])+(IkWpk[12][18][1]*
          Wpk[4][14][1]))))+temp[1]);
        temp[3] = (((mk[15]*((Vpk[4][20][2]*Vpk[12][20][2])+((Vpk[4][20][0]*
          Vpk[12][20][0])+(Vpk[4][20][1]*Vpk[12][20][1]))))+((IkWpk[12][20][2]*
          Wpk[4][20][2])+((IkWpk[12][20][0]*Wpk[4][20][0])+(IkWpk[12][20][1]*
          Wpk[4][14][1]))))+temp[2]);
        mm[4][12] = (((mk[17]*((Vpk[4][22][2]*Vpk[12][22][2])+((Vpk[4][22][0]*
          Vpk[12][22][0])+(Vpk[4][22][1]*Vpk[12][22][1]))))+((IkWpk[12][22][2]*
          Wpk[4][22][2])+((IkWpk[12][22][0]*Wpk[4][20][0])+(IkWpk[12][22][1]*
          Wpk[4][22][1]))))+temp[3]);
        temp[0] = (((mk[8]*((rk[8][1]*Vpk[4][13][0])-(rk[8][0]*Vpk[4][13][1])))+
          ((ik[8][0][2]*s13)+(ik[8][1][2]*c13)))+((mk[10]*((Vpk[4][15][2]*
          Vpk[13][15][2])+((Vpk[4][15][0]*Vpk[13][15][0])+(Vpk[4][15][1]*
          Vpk[13][15][1]))))+((IkWpk[13][15][2]*Wpk[4][15][2])+((
          IkWpk[13][15][0]*s13)+(IkWpk[13][15][1]*Wpk[4][15][1])))));
        temp[1] = (((mk[12]*((Vpk[4][17][2]*Vpk[13][17][2])+((Vpk[4][17][0]*
          Vpk[13][17][0])+(Vpk[4][17][1]*Vpk[13][17][1]))))+((IkWpk[13][17][2]*
          Wpk[4][17][2])+((IkWpk[13][17][0]*Wpk[4][17][0])+(IkWpk[13][17][1]*
          Wpk[4][15][1]))))+temp[0]);
        temp[2] = (((mk[14]*((Vpk[4][19][2]*Vpk[13][19][2])+((Vpk[4][19][0]*
          Vpk[13][19][0])+(Vpk[4][19][1]*Vpk[13][19][1]))))+((IkWpk[13][19][2]*
          Wpk[4][19][2])+((IkWpk[13][19][0]*Wpk[4][19][0])+(IkWpk[13][19][1]*
          Wpk[4][15][1]))))+temp[1]);
        temp[3] = (((mk[16]*((Vpk[4][21][2]*Vpk[13][21][2])+((Vpk[4][21][0]*
          Vpk[13][21][0])+(Vpk[4][21][1]*Vpk[13][21][1]))))+((IkWpk[13][21][2]*
          Wpk[4][21][2])+((IkWpk[13][21][0]*Wpk[4][21][0])+(IkWpk[13][21][1]*
          Wpk[4][15][1]))))+temp[2]);
        mm[4][13] = (((mk[18]*((Vpk[4][23][2]*Vpk[13][23][2])+((Vpk[4][23][0]*
          Vpk[13][23][0])+(Vpk[4][23][1]*Vpk[13][23][1]))))+((IkWpk[13][23][2]*
          Wpk[4][23][2])+((IkWpk[13][23][0]*Wpk[4][21][0])+(IkWpk[13][23][1]*
          Wpk[4][23][1]))))+temp[3]);
        temp[0] = (((mk[9]*((rk[9][1]*Vpk[4][14][2])-(rk[9][2]*Vpk[4][14][1])))+
          (((ik[9][0][0]*s12)-(ik[9][1][0]*Wpk[4][14][1]))-(ik[9][2][0]*
          Wpk[4][14][2])))+((mk[11]*((Vpk[4][16][2]*Vpk[14][16][2])+((
          Vpk[4][16][0]*Vpk[14][16][0])+(Vpk[4][16][1]*Vpk[14][16][1]))))+((
          IkWpk[14][16][2]*Wpk[4][16][2])+((IkWpk[14][16][0]*Wpk[4][16][0])+(
          IkWpk[14][16][1]*Wpk[4][14][1])))));
        temp[1] = (((mk[13]*((Vpk[4][18][2]*Vpk[14][18][2])+((Vpk[4][18][0]*
          Vpk[14][18][0])+(Vpk[4][18][1]*Vpk[14][18][1]))))+((IkWpk[14][18][2]*
          Wpk[4][18][2])+((IkWpk[14][18][0]*Wpk[4][18][0])+(IkWpk[14][18][1]*
          Wpk[4][14][1]))))+temp[0]);
        temp[2] = (((mk[15]*((Vpk[4][20][2]*Vpk[14][20][2])+((Vpk[4][20][0]*
          Vpk[14][20][0])+(Vpk[4][20][1]*Vpk[14][20][1]))))+((IkWpk[14][20][2]*
          Wpk[4][20][2])+((IkWpk[14][20][0]*Wpk[4][20][0])+(IkWpk[14][20][1]*
          Wpk[4][14][1]))))+temp[1]);
        mm[4][14] = (((mk[17]*((Vpk[4][22][2]*Vpk[14][22][2])+((Vpk[4][22][0]*
          Vpk[14][22][0])+(Vpk[4][22][1]*Vpk[14][22][1]))))+((IkWpk[14][22][2]*
          Wpk[4][22][2])+((IkWpk[14][22][0]*Wpk[4][20][0])+(IkWpk[14][22][1]*
          Wpk[4][22][1]))))+temp[2]);
        temp[0] = (((mk[10]*((rk[10][2]*Vpk[4][15][1])-(rk[10][1]*Vpk[4][15][2])
          ))+((ik[10][2][0]*Wpk[4][15][2])+((ik[10][0][0]*s13)+(ik[10][1][0]*
          Wpk[4][15][1]))))+((mk[12]*((Vpk[4][17][2]*Vpk[15][17][2])+((
          Vpk[4][17][0]*Vpk[15][17][0])+(Vpk[4][17][1]*Vpk[15][17][1]))))+((
          IkWpk[15][17][2]*Wpk[4][17][2])+((IkWpk[15][17][0]*Wpk[4][17][0])+(
          IkWpk[15][17][1]*Wpk[4][15][1])))));
        temp[1] = (((mk[14]*((Vpk[4][19][2]*Vpk[15][19][2])+((Vpk[4][19][0]*
          Vpk[15][19][0])+(Vpk[4][19][1]*Vpk[15][19][1]))))+((IkWpk[15][19][2]*
          Wpk[4][19][2])+((IkWpk[15][19][0]*Wpk[4][19][0])+(IkWpk[15][19][1]*
          Wpk[4][15][1]))))+temp[0]);
        temp[2] = (((mk[16]*((Vpk[4][21][2]*Vpk[15][21][2])+((Vpk[4][21][0]*
          Vpk[15][21][0])+(Vpk[4][21][1]*Vpk[15][21][1]))))+((IkWpk[15][21][2]*
          Wpk[4][21][2])+((IkWpk[15][21][0]*Wpk[4][21][0])+(IkWpk[15][21][1]*
          Wpk[4][15][1]))))+temp[1]);
        mm[4][15] = (((mk[18]*((Vpk[4][23][2]*Vpk[15][23][2])+((Vpk[4][23][0]*
          Vpk[15][23][0])+(Vpk[4][23][1]*Vpk[15][23][1]))))+((IkWpk[15][23][2]*
          Wpk[4][23][2])+((IkWpk[15][23][0]*Wpk[4][21][0])+(IkWpk[15][23][1]*
          Wpk[4][23][1]))))+temp[2]);
        temp[0] = (((mk[11]*((rk[11][2]*Vpk[4][16][0])-(rk[11][0]*Vpk[4][16][2])
          ))-((ik[11][2][1]*Wpk[4][16][2])+((ik[11][0][1]*Wpk[4][16][0])+(
          ik[11][1][1]*Wpk[4][14][1]))))+((mk[13]*((Vpk[4][18][0]*Vpk[16][18][0]
          )+(Vpk[4][18][2]*Vpk[16][18][2])))-((ik[13][2][1]*Wpk[4][18][2])+((
          ik[13][0][1]*Wpk[4][18][0])+(ik[13][1][1]*Wpk[4][14][1])))));
        mm[4][16] = (((mk[17]*((Vpk[4][22][2]*Vpk[16][22][2])+((Vpk[4][22][0]*
          Vpk[16][22][0])+(Vpk[4][22][1]*Vpk[16][22][1]))))+((IkWpk[16][22][2]*
          Wpk[4][22][2])+((IkWpk[16][22][0]*Wpk[4][20][0])+(IkWpk[16][22][1]*
          Wpk[4][22][1]))))+(((mk[15]*((Vpk[4][20][0]*Vpk[16][20][0])+(
          Vpk[4][20][2]*Vpk[16][20][2])))-((ik[15][2][1]*Wpk[4][20][2])+((
          ik[15][0][1]*Wpk[4][20][0])+(ik[15][1][1]*Wpk[4][14][1]))))+temp[0]));
        temp[0] = (((mk[12]*((rk[12][2]*Vpk[4][17][0])-(rk[12][0]*Vpk[4][17][2])
          ))-((ik[12][2][1]*Wpk[4][17][2])+((ik[12][0][1]*Wpk[4][17][0])+(
          ik[12][1][1]*Wpk[4][15][1]))))+((mk[14]*((Vpk[4][19][0]*Vpk[17][19][0]
          )+(Vpk[4][19][2]*Vpk[17][19][2])))-((ik[14][2][1]*Wpk[4][19][2])+((
          ik[14][0][1]*Wpk[4][19][0])+(ik[14][1][1]*Wpk[4][15][1])))));
        mm[4][17] = (((mk[18]*((Vpk[4][23][2]*Vpk[17][23][2])+((Vpk[4][23][0]*
          Vpk[17][23][0])+(Vpk[4][23][1]*Vpk[17][23][1]))))+((IkWpk[17][23][2]*
          Wpk[4][23][2])+((IkWpk[17][23][0]*Wpk[4][21][0])+(IkWpk[17][23][1]*
          Wpk[4][23][1]))))+(((mk[16]*((Vpk[4][21][0]*Vpk[17][21][0])+(
          Vpk[4][21][2]*Vpk[17][21][2])))-((ik[16][2][1]*Wpk[4][21][2])+((
          ik[16][0][1]*Wpk[4][21][0])+(ik[16][1][1]*Wpk[4][15][1]))))+temp[0]));
        temp[0] = (((mk[13]*((rk[13][2]*Vpk[4][18][0])-(rk[13][0]*Vpk[4][18][2])
          ))-((ik[13][2][1]*Wpk[4][18][2])+((ik[13][0][1]*Wpk[4][18][0])+(
          ik[13][1][1]*Wpk[4][14][1]))))+((mk[15]*((Vpk[4][20][0]*Vpk[18][20][0]
          )+(Vpk[4][20][2]*Vpk[18][20][2])))-((ik[15][2][1]*Wpk[4][20][2])+((
          ik[15][0][1]*Wpk[4][20][0])+(ik[15][1][1]*Wpk[4][14][1])))));
        mm[4][18] = (((mk[17]*((Vpk[4][22][2]*Vpk[18][22][2])+((Vpk[4][22][0]*
          Vpk[18][22][0])+(Vpk[4][22][1]*Vpk[18][22][1]))))+((IkWpk[18][22][2]*
          Wpk[4][22][2])+((IkWpk[18][22][0]*Wpk[4][20][0])+(IkWpk[18][22][1]*
          Wpk[4][22][1]))))+temp[0]);
        temp[0] = (((mk[14]*((rk[14][2]*Vpk[4][19][0])-(rk[14][0]*Vpk[4][19][2])
          ))-((ik[14][2][1]*Wpk[4][19][2])+((ik[14][0][1]*Wpk[4][19][0])+(
          ik[14][1][1]*Wpk[4][15][1]))))+((mk[16]*((Vpk[4][21][0]*Vpk[19][21][0]
          )+(Vpk[4][21][2]*Vpk[19][21][2])))-((ik[16][2][1]*Wpk[4][21][2])+((
          ik[16][0][1]*Wpk[4][21][0])+(ik[16][1][1]*Wpk[4][15][1])))));
        mm[4][19] = (((mk[18]*((Vpk[4][23][2]*Vpk[19][23][2])+((Vpk[4][23][0]*
          Vpk[19][23][0])+(Vpk[4][23][1]*Vpk[19][23][1]))))+((IkWpk[19][23][2]*
          Wpk[4][23][2])+((IkWpk[19][23][0]*Wpk[4][21][0])+(IkWpk[19][23][1]*
          Wpk[4][23][1]))))+temp[0]);
        mm[4][20] = (((mk[15]*((rk[15][2]*Vpk[4][20][0])-(rk[15][0]*
          Vpk[4][20][2])))-((ik[15][2][1]*Wpk[4][20][2])+((ik[15][0][1]*
          Wpk[4][20][0])+(ik[15][1][1]*Wpk[4][14][1]))))+((mk[17]*((
          Vpk[4][22][2]*Vpk[20][22][2])+((Vpk[4][22][0]*Vpk[20][22][0])+(
          Vpk[4][22][1]*Vpk[20][22][1]))))+((IkWpk[20][22][2]*Wpk[4][22][2])+((
          IkWpk[20][22][0]*Wpk[4][20][0])+(IkWpk[20][22][1]*Wpk[4][22][1])))));
        mm[4][21] = (((mk[16]*((rk[16][2]*Vpk[4][21][0])-(rk[16][0]*
          Vpk[4][21][2])))-((ik[16][2][1]*Wpk[4][21][2])+((ik[16][0][1]*
          Wpk[4][21][0])+(ik[16][1][1]*Wpk[4][15][1]))))+((mk[18]*((
          Vpk[4][23][2]*Vpk[21][23][2])+((Vpk[4][23][0]*Vpk[21][23][0])+(
          Vpk[4][23][1]*Vpk[21][23][1]))))+((IkWpk[21][23][2]*Wpk[4][23][2])+((
          IkWpk[21][23][0]*Wpk[4][21][0])+(IkWpk[21][23][1]*Wpk[4][23][1])))));
        mm[4][22] = ((mk[17]*((rk[17][1]*Vpk[4][22][2])-(rk[17][2]*Vpk[4][22][1]
          )))-((ik[17][2][0]*Wpk[4][22][2])+((ik[17][0][0]*Wpk[4][20][0])+(
          ik[17][1][0]*Wpk[4][22][1]))));
        mm[4][23] = ((mk[18]*((rk[18][2]*Vpk[4][23][1])-(rk[18][1]*Vpk[4][23][2]
          )))+((ik[18][2][0]*Wpk[4][23][2])+((ik[18][0][0]*Wpk[4][21][0])+(
          ik[18][1][0]*Wpk[4][23][1]))));
        mm[4][24] = (((mk[19]*((rk[19][1]*Vpk[4][24][0])-(rk[19][0]*
          Vpk[4][24][1])))+((ik[19][0][2]*s24)+(ik[19][1][2]*c24)))+((mk[20]*((
          Vpk[4][25][2]*Vpk[24][25][2])+((Vpk[4][25][0]*Vpk[24][25][0])+(
          Vpk[4][25][1]*Vpk[24][25][1]))))+((IkWpk[24][25][2]*Wpk[4][25][2])+((
          IkWpk[24][25][0]*Wpk[4][25][0])+(IkWpk[24][25][1]*c24)))));
        mm[4][25] = ((mk[20]*((rk[20][2]*Vpk[4][25][0])-(rk[20][0]*Vpk[4][25][2]
          )))-((ik[20][2][1]*Wpk[4][25][2])+((ik[20][0][1]*Wpk[4][25][0])+(
          ik[20][1][1]*c24))));
        temp[0] = (((ik[0][2][2]+(mk[0]*((rk[0][0]*rk[0][0])+(rk[0][1]*rk[0][1])
          )))+((mk[1]*((Vpk[5][6][2]*Vpk[5][6][2])+((Vpk[5][6][0]*Vpk[5][6][0])+
          (Vpk[5][6][1]*Vpk[5][6][1]))))+((IkWpk[5][6][0]*s6)+(IkWpk[5][6][2]*c6
          ))))+((mk[2]*((Vpk[5][7][2]*Vpk[5][7][2])+((Vpk[5][7][0]*Vpk[5][7][0])
          +(Vpk[5][7][1]*Vpk[5][7][1]))))+((IkWpk[5][7][0]*s7)+(IkWpk[5][7][2]*
          c7))));
        temp[1] = (((mk[4]*((Vpk[5][9][2]*Vpk[5][9][2])+((Vpk[5][9][0]*
          Vpk[5][9][0])+(Vpk[5][9][1]*Vpk[5][9][1]))))+((IkWpk[5][9][2]*
          Wpk[5][9][2])+((IkWpk[5][9][0]*s7)+(IkWpk[5][9][1]*Wpk[5][9][1]))))+((
          (mk[3]*((Vpk[5][8][2]*Vpk[5][8][2])+((Vpk[5][8][0]*Vpk[5][8][0])+(
          Vpk[5][8][1]*Vpk[5][8][1]))))+((IkWpk[5][8][2]*Wpk[5][8][2])+((
          IkWpk[5][8][0]*s6)+(IkWpk[5][8][1]*Wpk[5][8][1]))))+temp[0]));
        temp[2] = (((mk[5]*((Vpk[5][10][2]*Vpk[5][10][2])+((Vpk[5][10][0]*
          Vpk[5][10][0])+(Vpk[5][10][1]*Vpk[5][10][1]))))+((IkWpk[5][10][2]*
          Wpk[5][8][2])+((IkWpk[5][10][0]*Wpk[5][10][0])+(IkWpk[5][10][1]*
          Wpk[5][10][1]))))+temp[1]);
        temp[3] = ((ik[8][2][2]+(mk[8]*((Vpk[5][13][0]*Vpk[5][13][0])+(
          Vpk[5][13][1]*Vpk[5][13][1]))))+((ik[7][2][2]+(mk[7]*((Vpk[5][12][0]*
          Vpk[5][12][0])+(Vpk[5][12][1]*Vpk[5][12][1]))))+(((mk[6]*((
          Vpk[5][11][2]*Vpk[5][11][2])+((Vpk[5][11][0]*Vpk[5][11][0])+(
          Vpk[5][11][1]*Vpk[5][11][1]))))+((IkWpk[5][11][2]*Wpk[5][9][2])+((
          IkWpk[5][11][0]*Wpk[5][11][0])+(IkWpk[5][11][1]*Wpk[5][11][1]))))+
          temp[2])));
        temp[4] = (((mk[10]*((Vpk[5][15][2]*Vpk[5][15][2])+((Vpk[5][15][0]*
          Vpk[5][15][0])+(Vpk[5][15][1]*Vpk[5][15][1]))))+((IkWpk[5][15][1]*s15)
          +(IkWpk[5][15][2]*c15)))+(temp[3]+((mk[9]*((Vpk[5][14][2]*
          Vpk[5][14][2])+((Vpk[5][14][0]*Vpk[5][14][0])+(Vpk[5][14][1]*
          Vpk[5][14][1]))))+((IkWpk[5][14][2]*c14)-(IkWpk[5][14][1]*s14)))));
        temp[5] = (((mk[12]*((Vpk[5][17][2]*Vpk[5][17][2])+((Vpk[5][17][0]*
          Vpk[5][17][0])+(Vpk[5][17][1]*Vpk[5][17][1]))))+((IkWpk[5][17][2]*
          Wpk[5][17][2])+((IkWpk[5][17][0]*Wpk[5][17][0])+(IkWpk[5][17][1]*s15))
          ))+(((mk[11]*((Vpk[5][16][2]*Vpk[5][16][2])+((Vpk[5][16][0]*
          Vpk[5][16][0])+(Vpk[5][16][1]*Vpk[5][16][1]))))+((IkWpk[5][16][2]*
          Wpk[5][16][2])+((IkWpk[5][16][0]*Wpk[5][16][0])-(IkWpk[5][16][1]*s14))
          ))+temp[4]));
        temp[6] = (((mk[14]*((Vpk[5][19][2]*Vpk[5][19][2])+((Vpk[5][19][0]*
          Vpk[5][19][0])+(Vpk[5][19][1]*Vpk[5][19][1]))))+((IkWpk[5][19][2]*
          Wpk[5][19][2])+((IkWpk[5][19][0]*Wpk[5][19][0])+(IkWpk[5][19][1]*s15))
          ))+(((mk[13]*((Vpk[5][18][2]*Vpk[5][18][2])+((Vpk[5][18][0]*
          Vpk[5][18][0])+(Vpk[5][18][1]*Vpk[5][18][1]))))+((IkWpk[5][18][2]*
          Wpk[5][18][2])+((IkWpk[5][18][0]*Wpk[5][18][0])-(IkWpk[5][18][1]*s14))
          ))+temp[5]));
        temp[7] = (((mk[16]*((Vpk[5][21][2]*Vpk[5][21][2])+((Vpk[5][21][0]*
          Vpk[5][21][0])+(Vpk[5][21][1]*Vpk[5][21][1]))))+((IkWpk[5][21][2]*
          Wpk[5][21][2])+((IkWpk[5][21][0]*Wpk[5][21][0])+(IkWpk[5][21][1]*s15))
          ))+(((mk[15]*((Vpk[5][20][2]*Vpk[5][20][2])+((Vpk[5][20][0]*
          Vpk[5][20][0])+(Vpk[5][20][1]*Vpk[5][20][1]))))+((IkWpk[5][20][2]*
          Wpk[5][20][2])+((IkWpk[5][20][0]*Wpk[5][20][0])-(IkWpk[5][20][1]*s14))
          ))+temp[6]));
        temp[8] = (((mk[17]*((Vpk[5][22][2]*Vpk[5][22][2])+((Vpk[5][22][0]*
          Vpk[5][22][0])+(Vpk[5][22][1]*Vpk[5][22][1]))))+((IkWpk[5][22][2]*
          Wpk[5][22][2])+((IkWpk[5][22][0]*Wpk[5][20][0])+(IkWpk[5][22][1]*
          Wpk[5][22][1]))))+temp[7]);
        temp[9] = ((ik[19][2][2]+(mk[19]*((Vpk[5][24][0]*Vpk[5][24][0])+(
          Vpk[5][24][1]*Vpk[5][24][1]))))+(((mk[18]*((Vpk[5][23][2]*
          Vpk[5][23][2])+((Vpk[5][23][0]*Vpk[5][23][0])+(Vpk[5][23][1]*
          Vpk[5][23][1]))))+((IkWpk[5][23][2]*Wpk[5][23][2])+((IkWpk[5][23][0]*
          Wpk[5][21][0])+(IkWpk[5][23][1]*Wpk[5][23][1]))))+temp[8]));
        mm[5][5] = (temp[9]+((mk[20]*((Vpk[5][25][2]*Vpk[5][25][2])+((
          Vpk[5][25][0]*Vpk[5][25][0])+(Vpk[5][25][1]*Vpk[5][25][1]))))+((
          IkWpk[5][25][0]*s25)+(IkWpk[5][25][2]*c25))));
        temp[0] = (((mk[1]*((rk[1][2]*Vpk[5][6][0])-(rk[1][0]*Vpk[5][6][2])))-((
          ik[1][0][1]*s6)+(ik[1][2][1]*c6)))+((mk[3]*((Vpk[5][8][2]*Vpk[6][8][2]
          )+((Vpk[5][8][0]*Vpk[6][8][0])+(Vpk[5][8][1]*Vpk[6][8][1]))))+((
          IkWpk[6][8][2]*Wpk[5][8][2])+((IkWpk[6][8][0]*s6)+(IkWpk[6][8][1]*
          Wpk[5][8][1])))));
        mm[5][6] = (((mk[5]*((Vpk[5][10][2]*Vpk[6][10][2])+((Vpk[5][10][0]*
          Vpk[6][10][0])+(Vpk[5][10][1]*Vpk[6][10][1]))))+((IkWpk[6][10][2]*
          Wpk[5][8][2])+((IkWpk[6][10][0]*Wpk[5][10][0])+(IkWpk[6][10][1]*
          Wpk[5][10][1]))))+temp[0]);
        temp[0] = (((mk[2]*((rk[2][2]*Vpk[5][7][0])-(rk[2][0]*Vpk[5][7][2])))-((
          ik[2][0][1]*s7)+(ik[2][2][1]*c7)))+((mk[4]*((Vpk[5][9][2]*Vpk[7][9][2]
          )+((Vpk[5][9][0]*Vpk[7][9][0])+(Vpk[5][9][1]*Vpk[7][9][1]))))+((
          IkWpk[7][9][2]*Wpk[5][9][2])+((IkWpk[7][9][0]*s7)+(IkWpk[7][9][1]*
          Wpk[5][9][1])))));
        mm[5][7] = (((mk[6]*((Vpk[5][11][2]*Vpk[7][11][2])+((Vpk[5][11][0]*
          Vpk[7][11][0])+(Vpk[5][11][1]*Vpk[7][11][1]))))+((IkWpk[7][11][2]*
          Wpk[5][9][2])+((IkWpk[7][11][0]*Wpk[5][11][0])+(IkWpk[7][11][1]*
          Wpk[5][11][1]))))+temp[0]);
        mm[5][8] = (((mk[3]*((rk[3][1]*Vpk[5][8][2])-(rk[3][2]*Vpk[5][8][1])))-(
          (ik[3][2][0]*Wpk[5][8][2])+((ik[3][0][0]*s6)+(ik[3][1][0]*Wpk[5][8][1]
          ))))+((mk[5]*((Vpk[5][10][2]*Vpk[8][10][2])+((Vpk[5][10][0]*
          Vpk[8][10][0])+(Vpk[5][10][1]*Vpk[8][10][1]))))+((IkWpk[8][10][2]*
          Wpk[5][8][2])+((IkWpk[8][10][0]*Wpk[5][10][0])+(IkWpk[8][10][1]*
          Wpk[5][10][1])))));
        mm[5][9] = (((mk[4]*((rk[4][2]*Vpk[5][9][1])-(rk[4][1]*Vpk[5][9][2])))+(
          (ik[4][2][0]*Wpk[5][9][2])+((ik[4][0][0]*s7)+(ik[4][1][0]*Wpk[5][9][1]
          ))))+((mk[6]*((Vpk[5][11][2]*Vpk[9][11][2])+((Vpk[5][11][0]*
          Vpk[9][11][0])+(Vpk[5][11][1]*Vpk[9][11][1]))))+((IkWpk[9][11][2]*
          Wpk[5][9][2])+((IkWpk[9][11][0]*Wpk[5][11][0])+(IkWpk[9][11][1]*
          Wpk[5][11][1])))));
        mm[5][10] = ((mk[5]*((rk[5][0]*Vpk[5][10][1])-(rk[5][1]*Vpk[5][10][0])))
          -((ik[5][2][2]*Wpk[5][8][2])+((ik[5][0][2]*Wpk[5][10][0])+(ik[5][1][2]
          *Wpk[5][10][1]))));
        mm[5][11] = ((mk[6]*((rk[6][1]*Vpk[5][11][0])-(rk[6][0]*Vpk[5][11][1])))
          +((ik[6][2][2]*Wpk[5][9][2])+((ik[6][0][2]*Wpk[5][11][0])+(ik[6][1][2]
          *Wpk[5][11][1]))));
        temp[0] = (((mk[7]*((rk[7][0]*Vpk[5][12][1])-(rk[7][1]*Vpk[5][12][0])))-
          ik[7][2][2])+((mk[9]*((Vpk[5][14][2]*Vpk[12][14][2])+((Vpk[5][14][0]*
          Vpk[12][14][0])+(Vpk[5][14][1]*Vpk[12][14][1]))))+((IkWpk[12][14][2]*
          c14)-(IkWpk[12][14][1]*s14))));
        temp[1] = (((mk[13]*((Vpk[5][18][2]*Vpk[12][18][2])+((Vpk[5][18][0]*
          Vpk[12][18][0])+(Vpk[5][18][1]*Vpk[12][18][1]))))+((IkWpk[12][18][2]*
          Wpk[5][18][2])+((IkWpk[12][18][0]*Wpk[5][18][0])-(IkWpk[12][18][1]*s14
          ))))+(((mk[11]*((Vpk[5][16][2]*Vpk[12][16][2])+((Vpk[5][16][0]*
          Vpk[12][16][0])+(Vpk[5][16][1]*Vpk[12][16][1]))))+((IkWpk[12][16][2]*
          Wpk[5][16][2])+((IkWpk[12][16][0]*Wpk[5][16][0])-(IkWpk[12][16][1]*s14
          ))))+temp[0]));
        mm[5][12] = (((mk[17]*((Vpk[5][22][2]*Vpk[12][22][2])+((Vpk[5][22][0]*
          Vpk[12][22][0])+(Vpk[5][22][1]*Vpk[12][22][1]))))+((IkWpk[12][22][2]*
          Wpk[5][22][2])+((IkWpk[12][22][0]*Wpk[5][20][0])+(IkWpk[12][22][1]*
          Wpk[5][22][1]))))+(((mk[15]*((Vpk[5][20][2]*Vpk[12][20][2])+((
          Vpk[5][20][0]*Vpk[12][20][0])+(Vpk[5][20][1]*Vpk[12][20][1]))))+((
          IkWpk[12][20][2]*Wpk[5][20][2])+((IkWpk[12][20][0]*Wpk[5][20][0])-(
          IkWpk[12][20][1]*s14))))+temp[1]));
        temp[0] = ((ik[8][2][2]+(mk[8]*((rk[8][1]*Vpk[5][13][0])-(rk[8][0]*
          Vpk[5][13][1]))))+((mk[10]*((Vpk[5][15][2]*Vpk[13][15][2])+((
          Vpk[5][15][0]*Vpk[13][15][0])+(Vpk[5][15][1]*Vpk[13][15][1]))))+((
          IkWpk[13][15][1]*s15)+(IkWpk[13][15][2]*c15))));
        temp[1] = (((mk[14]*((Vpk[5][19][2]*Vpk[13][19][2])+((Vpk[5][19][0]*
          Vpk[13][19][0])+(Vpk[5][19][1]*Vpk[13][19][1]))))+((IkWpk[13][19][2]*
          Wpk[5][19][2])+((IkWpk[13][19][0]*Wpk[5][19][0])+(IkWpk[13][19][1]*s15
          ))))+(temp[0]+((mk[12]*((Vpk[5][17][2]*Vpk[13][17][2])+((Vpk[5][17][0]
          *Vpk[13][17][0])+(Vpk[5][17][1]*Vpk[13][17][1]))))+((IkWpk[13][17][2]*
          Wpk[5][17][2])+((IkWpk[13][17][0]*Wpk[5][17][0])+(IkWpk[13][17][1]*s15
          ))))));
        mm[5][13] = (((mk[18]*((Vpk[5][23][2]*Vpk[13][23][2])+((Vpk[5][23][0]*
          Vpk[13][23][0])+(Vpk[5][23][1]*Vpk[13][23][1]))))+((IkWpk[13][23][2]*
          Wpk[5][23][2])+((IkWpk[13][23][0]*Wpk[5][21][0])+(IkWpk[13][23][1]*
          Wpk[5][23][1]))))+(((mk[16]*((Vpk[5][21][2]*Vpk[13][21][2])+((
          Vpk[5][21][0]*Vpk[13][21][0])+(Vpk[5][21][1]*Vpk[13][21][1]))))+((
          IkWpk[13][21][2]*Wpk[5][21][2])+((IkWpk[13][21][0]*Wpk[5][21][0])+(
          IkWpk[13][21][1]*s15))))+temp[1]));
        temp[0] = (((mk[9]*((rk[9][1]*Vpk[5][14][2])-(rk[9][2]*Vpk[5][14][1])))+
          ((ik[9][1][0]*s14)-(ik[9][2][0]*c14)))+((mk[11]*((Vpk[5][16][2]*
          Vpk[14][16][2])+((Vpk[5][16][0]*Vpk[14][16][0])+(Vpk[5][16][1]*
          Vpk[14][16][1]))))+((IkWpk[14][16][2]*Wpk[5][16][2])+((
          IkWpk[14][16][0]*Wpk[5][16][0])-(IkWpk[14][16][1]*s14)))));
        temp[1] = (((mk[15]*((Vpk[5][20][2]*Vpk[14][20][2])+((Vpk[5][20][0]*
          Vpk[14][20][0])+(Vpk[5][20][1]*Vpk[14][20][1]))))+((IkWpk[14][20][2]*
          Wpk[5][20][2])+((IkWpk[14][20][0]*Wpk[5][20][0])-(IkWpk[14][20][1]*s14
          ))))+(((mk[13]*((Vpk[5][18][2]*Vpk[14][18][2])+((Vpk[5][18][0]*
          Vpk[14][18][0])+(Vpk[5][18][1]*Vpk[14][18][1]))))+((IkWpk[14][18][2]*
          Wpk[5][18][2])+((IkWpk[14][18][0]*Wpk[5][18][0])-(IkWpk[14][18][1]*s14
          ))))+temp[0]));
        mm[5][14] = (((mk[17]*((Vpk[5][22][2]*Vpk[14][22][2])+((Vpk[5][22][0]*
          Vpk[14][22][0])+(Vpk[5][22][1]*Vpk[14][22][1]))))+((IkWpk[14][22][2]*
          Wpk[5][22][2])+((IkWpk[14][22][0]*Wpk[5][20][0])+(IkWpk[14][22][1]*
          Wpk[5][22][1]))))+temp[1]);
        temp[0] = (((mk[10]*((rk[10][2]*Vpk[5][15][1])-(rk[10][1]*Vpk[5][15][2])
          ))+((ik[10][1][0]*s15)+(ik[10][2][0]*c15)))+((mk[12]*((Vpk[5][17][2]*
          Vpk[15][17][2])+((Vpk[5][17][0]*Vpk[15][17][0])+(Vpk[5][17][1]*
          Vpk[15][17][1]))))+((IkWpk[15][17][2]*Wpk[5][17][2])+((
          IkWpk[15][17][0]*Wpk[5][17][0])+(IkWpk[15][17][1]*s15)))));
        temp[1] = (((mk[16]*((Vpk[5][21][2]*Vpk[15][21][2])+((Vpk[5][21][0]*
          Vpk[15][21][0])+(Vpk[5][21][1]*Vpk[15][21][1]))))+((IkWpk[15][21][2]*
          Wpk[5][21][2])+((IkWpk[15][21][0]*Wpk[5][21][0])+(IkWpk[15][21][1]*s15
          ))))+(((mk[14]*((Vpk[5][19][2]*Vpk[15][19][2])+((Vpk[5][19][0]*
          Vpk[15][19][0])+(Vpk[5][19][1]*Vpk[15][19][1]))))+((IkWpk[15][19][2]*
          Wpk[5][19][2])+((IkWpk[15][19][0]*Wpk[5][19][0])+(IkWpk[15][19][1]*s15
          ))))+temp[0]));
        mm[5][15] = (((mk[18]*((Vpk[5][23][2]*Vpk[15][23][2])+((Vpk[5][23][0]*
          Vpk[15][23][0])+(Vpk[5][23][1]*Vpk[15][23][1]))))+((IkWpk[15][23][2]*
          Wpk[5][23][2])+((IkWpk[15][23][0]*Wpk[5][21][0])+(IkWpk[15][23][1]*
          Wpk[5][23][1]))))+temp[1]);
        temp[0] = (((mk[11]*((rk[11][2]*Vpk[5][16][0])-(rk[11][0]*Vpk[5][16][2])
          ))+(((ik[11][1][1]*s14)-(ik[11][0][1]*Wpk[5][16][0]))-(ik[11][2][1]*
          Wpk[5][16][2])))+((mk[13]*((Vpk[5][18][0]*Vpk[16][18][0])+(
          Vpk[5][18][2]*Vpk[16][18][2])))+(((ik[13][1][1]*s14)-(ik[13][0][1]*
          Wpk[5][18][0]))-(ik[13][2][1]*Wpk[5][18][2]))));
        mm[5][16] = (((mk[17]*((Vpk[5][22][2]*Vpk[16][22][2])+((Vpk[5][22][0]*
          Vpk[16][22][0])+(Vpk[5][22][1]*Vpk[16][22][1]))))+((IkWpk[16][22][2]*
          Wpk[5][22][2])+((IkWpk[16][22][0]*Wpk[5][20][0])+(IkWpk[16][22][1]*
          Wpk[5][22][1]))))+(((mk[15]*((Vpk[5][20][0]*Vpk[16][20][0])+(
          Vpk[5][20][2]*Vpk[16][20][2])))+(((ik[15][1][1]*s14)-(ik[15][0][1]*
          Wpk[5][20][0]))-(ik[15][2][1]*Wpk[5][20][2])))+temp[0]));
        temp[0] = (((mk[12]*((rk[12][2]*Vpk[5][17][0])-(rk[12][0]*Vpk[5][17][2])
          ))-((ik[12][2][1]*Wpk[5][17][2])+((ik[12][0][1]*Wpk[5][17][0])+(
          ik[12][1][1]*s15))))+((mk[14]*((Vpk[5][19][0]*Vpk[17][19][0])+(
          Vpk[5][19][2]*Vpk[17][19][2])))-((ik[14][2][1]*Wpk[5][19][2])+((
          ik[14][0][1]*Wpk[5][19][0])+(ik[14][1][1]*s15)))));
        mm[5][17] = (((mk[18]*((Vpk[5][23][2]*Vpk[17][23][2])+((Vpk[5][23][0]*
          Vpk[17][23][0])+(Vpk[5][23][1]*Vpk[17][23][1]))))+((IkWpk[17][23][2]*
          Wpk[5][23][2])+((IkWpk[17][23][0]*Wpk[5][21][0])+(IkWpk[17][23][1]*
          Wpk[5][23][1]))))+(((mk[16]*((Vpk[5][21][0]*Vpk[17][21][0])+(
          Vpk[5][21][2]*Vpk[17][21][2])))-((ik[16][2][1]*Wpk[5][21][2])+((
          ik[16][0][1]*Wpk[5][21][0])+(ik[16][1][1]*s15))))+temp[0]));
        temp[0] = (((mk[13]*((rk[13][2]*Vpk[5][18][0])-(rk[13][0]*Vpk[5][18][2])
          ))+(((ik[13][1][1]*s14)-(ik[13][0][1]*Wpk[5][18][0]))-(ik[13][2][1]*
          Wpk[5][18][2])))+((mk[15]*((Vpk[5][20][0]*Vpk[18][20][0])+(
          Vpk[5][20][2]*Vpk[18][20][2])))+(((ik[15][1][1]*s14)-(ik[15][0][1]*
          Wpk[5][20][0]))-(ik[15][2][1]*Wpk[5][20][2]))));
        mm[5][18] = (((mk[17]*((Vpk[5][22][2]*Vpk[18][22][2])+((Vpk[5][22][0]*
          Vpk[18][22][0])+(Vpk[5][22][1]*Vpk[18][22][1]))))+((IkWpk[18][22][2]*
          Wpk[5][22][2])+((IkWpk[18][22][0]*Wpk[5][20][0])+(IkWpk[18][22][1]*
          Wpk[5][22][1]))))+temp[0]);
        temp[0] = (((mk[14]*((rk[14][2]*Vpk[5][19][0])-(rk[14][0]*Vpk[5][19][2])
          ))-((ik[14][2][1]*Wpk[5][19][2])+((ik[14][0][1]*Wpk[5][19][0])+(
          ik[14][1][1]*s15))))+((mk[16]*((Vpk[5][21][0]*Vpk[19][21][0])+(
          Vpk[5][21][2]*Vpk[19][21][2])))-((ik[16][2][1]*Wpk[5][21][2])+((
          ik[16][0][1]*Wpk[5][21][0])+(ik[16][1][1]*s15)))));
        mm[5][19] = (((mk[18]*((Vpk[5][23][2]*Vpk[19][23][2])+((Vpk[5][23][0]*
          Vpk[19][23][0])+(Vpk[5][23][1]*Vpk[19][23][1]))))+((IkWpk[19][23][2]*
          Wpk[5][23][2])+((IkWpk[19][23][0]*Wpk[5][21][0])+(IkWpk[19][23][1]*
          Wpk[5][23][1]))))+temp[0]);
        mm[5][20] = (((mk[15]*((rk[15][2]*Vpk[5][20][0])-(rk[15][0]*
          Vpk[5][20][2])))+(((ik[15][1][1]*s14)-(ik[15][0][1]*Wpk[5][20][0]))-(
          ik[15][2][1]*Wpk[5][20][2])))+((mk[17]*((Vpk[5][22][2]*Vpk[20][22][2])
          +((Vpk[5][22][0]*Vpk[20][22][0])+(Vpk[5][22][1]*Vpk[20][22][1]))))+((
          IkWpk[20][22][2]*Wpk[5][22][2])+((IkWpk[20][22][0]*Wpk[5][20][0])+(
          IkWpk[20][22][1]*Wpk[5][22][1])))));
        mm[5][21] = (((mk[16]*((rk[16][2]*Vpk[5][21][0])-(rk[16][0]*
          Vpk[5][21][2])))-((ik[16][2][1]*Wpk[5][21][2])+((ik[16][0][1]*
          Wpk[5][21][0])+(ik[16][1][1]*s15))))+((mk[18]*((Vpk[5][23][2]*
          Vpk[21][23][2])+((Vpk[5][23][0]*Vpk[21][23][0])+(Vpk[5][23][1]*
          Vpk[21][23][1]))))+((IkWpk[21][23][2]*Wpk[5][23][2])+((
          IkWpk[21][23][0]*Wpk[5][21][0])+(IkWpk[21][23][1]*Wpk[5][23][1])))));
        mm[5][22] = ((mk[17]*((rk[17][1]*Vpk[5][22][2])-(rk[17][2]*Vpk[5][22][1]
          )))-((ik[17][2][0]*Wpk[5][22][2])+((ik[17][0][0]*Wpk[5][20][0])+(
          ik[17][1][0]*Wpk[5][22][1]))));
        mm[5][23] = ((mk[18]*((rk[18][2]*Vpk[5][23][1])-(rk[18][1]*Vpk[5][23][2]
          )))+((ik[18][2][0]*Wpk[5][23][2])+((ik[18][0][0]*Wpk[5][21][0])+(
          ik[18][1][0]*Wpk[5][23][1]))));
        mm[5][24] = ((ik[19][2][2]+(mk[19]*((rk[19][1]*Vpk[5][24][0])-(rk[19][0]
          *Vpk[5][24][1]))))+((mk[20]*((Vpk[5][25][2]*Vpk[24][25][2])+((
          Vpk[5][25][0]*Vpk[24][25][0])+(Vpk[5][25][1]*Vpk[24][25][1]))))+((
          IkWpk[24][25][0]*s25)+(IkWpk[24][25][2]*c25))));
        mm[5][25] = ((mk[20]*((rk[20][2]*Vpk[5][25][0])-(rk[20][0]*Vpk[5][25][2]
          )))-((ik[20][0][1]*s25)+(ik[20][2][1]*c25)));
        temp[0] = ((ik[1][1][1]+(mk[1]*((rk[1][0]*rk[1][0])+(rk[1][2]*rk[1][2]))
          ))+((mk[3]*((Vpk[6][8][2]*Vpk[6][8][2])+((Vpk[6][8][0]*Vpk[6][8][0])+(
          Vpk[6][8][1]*Vpk[6][8][1]))))-((IkWpk[6][8][1]*c8)+(IkWpk[6][8][2]*s8)
          )));
        mm[6][6] = (temp[0]+((mk[5]*((Vpk[6][10][2]*Vpk[6][10][2])+((
          Vpk[6][10][0]*Vpk[6][10][0])+(Vpk[6][10][1]*Vpk[6][10][1]))))+(((
          IkWpk[6][10][0]*Wpk[6][10][0])+(IkWpk[6][10][1]*Wpk[6][10][1]))-(
          IkWpk[6][10][2]*s8))));
        mm[6][7] = 0.;
        mm[6][8] = (((mk[3]*((rk[3][1]*Vpk[6][8][2])-(rk[3][2]*Vpk[6][8][1])))+(
          (ik[3][1][0]*c8)+(ik[3][2][0]*s8)))+((mk[5]*((Vpk[6][10][2]*
          Vpk[8][10][2])+((Vpk[6][10][0]*Vpk[8][10][0])+(Vpk[6][10][1]*
          Vpk[8][10][1]))))+(((IkWpk[8][10][0]*Wpk[6][10][0])+(IkWpk[8][10][1]*
          Wpk[6][10][1]))-(IkWpk[8][10][2]*s8))));
        mm[6][9] = 0.;
        mm[6][10] = ((mk[5]*((rk[5][0]*Vpk[6][10][1])-(rk[5][1]*Vpk[6][10][0])))
          +((ik[5][2][2]*s8)-((ik[5][0][2]*Wpk[6][10][0])+(ik[5][1][2]*
          Wpk[6][10][1]))));
        mm[6][11] = 0.;
        mm[6][12] = 0.;
        mm[6][13] = 0.;
        mm[6][14] = 0.;
        mm[6][15] = 0.;
        mm[6][16] = 0.;
        mm[6][17] = 0.;
        mm[6][18] = 0.;
        mm[6][19] = 0.;
        mm[6][20] = 0.;
        mm[6][21] = 0.;
        mm[6][22] = 0.;
        mm[6][23] = 0.;
        mm[6][24] = 0.;
        mm[6][25] = 0.;
        temp[0] = ((ik[2][1][1]+(mk[2]*((rk[2][0]*rk[2][0])+(rk[2][2]*rk[2][2]))
          ))+((mk[4]*((Vpk[7][9][2]*Vpk[7][9][2])+((Vpk[7][9][0]*Vpk[7][9][0])+(
          Vpk[7][9][1]*Vpk[7][9][1]))))+((IkWpk[7][9][2]*s9)-(IkWpk[7][9][1]*c9)
          )));
        mm[7][7] = (temp[0]+((mk[6]*((Vpk[7][11][2]*Vpk[7][11][2])+((
          Vpk[7][11][0]*Vpk[7][11][0])+(Vpk[7][11][1]*Vpk[7][11][1]))))+((
          IkWpk[7][11][2]*s9)+((IkWpk[7][11][0]*Wpk[7][11][0])+(IkWpk[7][11][1]*
          Wpk[7][11][1])))));
        mm[7][8] = 0.;
        mm[7][9] = (((mk[4]*((rk[4][2]*Vpk[7][9][1])-(rk[4][1]*Vpk[7][9][2])))+(
          (ik[4][2][0]*s9)-(ik[4][1][0]*c9)))+((mk[6]*((Vpk[7][11][2]*
          Vpk[9][11][2])+((Vpk[7][11][0]*Vpk[9][11][0])+(Vpk[7][11][1]*
          Vpk[9][11][1]))))+((IkWpk[9][11][2]*s9)+((IkWpk[9][11][0]*
          Wpk[7][11][0])+(IkWpk[9][11][1]*Wpk[7][11][1])))));
        mm[7][10] = 0.;
        mm[7][11] = ((mk[6]*((rk[6][1]*Vpk[7][11][0])-(rk[6][0]*Vpk[7][11][1])))
          +((ik[6][2][2]*s9)+((ik[6][0][2]*Wpk[7][11][0])+(ik[6][1][2]*
          Wpk[7][11][1]))));
        mm[7][12] = 0.;
        mm[7][13] = 0.;
        mm[7][14] = 0.;
        mm[7][15] = 0.;
        mm[7][16] = 0.;
        mm[7][17] = 0.;
        mm[7][18] = 0.;
        mm[7][19] = 0.;
        mm[7][20] = 0.;
        mm[7][21] = 0.;
        mm[7][22] = 0.;
        mm[7][23] = 0.;
        mm[7][24] = 0.;
        mm[7][25] = 0.;
        mm[8][8] = ((ik[3][0][0]+(mk[3]*((rk[3][1]*rk[3][1])+(rk[3][2]*rk[3][2])
          )))+((mk[5]*((Vpk[8][10][2]*Vpk[8][10][2])+((Vpk[8][10][0]*
          Vpk[8][10][0])+(Vpk[8][10][1]*Vpk[8][10][1]))))-((IkWpk[8][10][0]*c10)
          +(IkWpk[8][10][1]*s10))));
        mm[8][9] = 0.;
        mm[8][10] = ((mk[5]*((rk[5][0]*Vpk[8][10][1])-(rk[5][1]*Vpk[8][10][0])))
          +((ik[5][0][2]*c10)+(ik[5][1][2]*s10)));
        mm[8][11] = 0.;
        mm[8][12] = 0.;
        mm[8][13] = 0.;
        mm[8][14] = 0.;
        mm[8][15] = 0.;
        mm[8][16] = 0.;
        mm[8][17] = 0.;
        mm[8][18] = 0.;
        mm[8][19] = 0.;
        mm[8][20] = 0.;
        mm[8][21] = 0.;
        mm[8][22] = 0.;
        mm[8][23] = 0.;
        mm[8][24] = 0.;
        mm[8][25] = 0.;
        mm[9][9] = ((ik[4][0][0]+(mk[4]*((rk[4][1]*rk[4][1])+(rk[4][2]*rk[4][2])
          )))+((mk[6]*((Vpk[9][11][2]*Vpk[9][11][2])+((Vpk[9][11][0]*
          Vpk[9][11][0])+(Vpk[9][11][1]*Vpk[9][11][1]))))+((IkWpk[9][11][0]*c11)
          -(IkWpk[9][11][1]*s11))));
        mm[9][10] = 0.;
        mm[9][11] = ((mk[6]*((rk[6][1]*Vpk[9][11][0])-(rk[6][0]*Vpk[9][11][1])))
          +((ik[6][0][2]*c11)-(ik[6][1][2]*s11)));
        mm[9][12] = 0.;
        mm[9][13] = 0.;
        mm[9][14] = 0.;
        mm[9][15] = 0.;
        mm[9][16] = 0.;
        mm[9][17] = 0.;
        mm[9][18] = 0.;
        mm[9][19] = 0.;
        mm[9][20] = 0.;
        mm[9][21] = 0.;
        mm[9][22] = 0.;
        mm[9][23] = 0.;
        mm[9][24] = 0.;
        mm[9][25] = 0.;
        mm[10][10] = (ik[5][2][2]+(mk[5]*((rk[5][0]*rk[5][0])+(rk[5][1]*rk[5][1]
          ))));
        mm[10][11] = 0.;
        mm[10][12] = 0.;
        mm[10][13] = 0.;
        mm[10][14] = 0.;
        mm[10][15] = 0.;
        mm[10][16] = 0.;
        mm[10][17] = 0.;
        mm[10][18] = 0.;
        mm[10][19] = 0.;
        mm[10][20] = 0.;
        mm[10][21] = 0.;
        mm[10][22] = 0.;
        mm[10][23] = 0.;
        mm[10][24] = 0.;
        mm[10][25] = 0.;
        mm[11][11] = (ik[6][2][2]+(mk[6]*((rk[6][0]*rk[6][0])+(rk[6][1]*rk[6][1]
          ))));
        mm[11][12] = 0.;
        mm[11][13] = 0.;
        mm[11][14] = 0.;
        mm[11][15] = 0.;
        mm[11][16] = 0.;
        mm[11][17] = 0.;
        mm[11][18] = 0.;
        mm[11][19] = 0.;
        mm[11][20] = 0.;
        mm[11][21] = 0.;
        mm[11][22] = 0.;
        mm[11][23] = 0.;
        mm[11][24] = 0.;
        mm[11][25] = 0.;
        temp[0] = ((ik[7][2][2]+(mk[7]*((rk[7][0]*rk[7][0])+(rk[7][1]*rk[7][1]))
          ))+((mk[9]*((Vpk[12][14][2]*Vpk[12][14][2])+((Vpk[12][14][0]*
          Vpk[12][14][0])+(Vpk[12][14][1]*Vpk[12][14][1]))))+((IkWpk[12][14][1]*
          s14)-(IkWpk[12][14][2]*c14))));
        temp[1] = (((mk[13]*((Vpk[12][18][2]*Vpk[12][18][2])+((Vpk[12][18][0]*
          Vpk[12][18][0])+(Vpk[12][18][1]*Vpk[12][18][1]))))+((IkWpk[12][18][2]*
          Wpk[12][18][2])+((IkWpk[12][18][0]*Wpk[12][18][0])+(IkWpk[12][18][1]*
          s14))))+(temp[0]+((mk[11]*((Vpk[12][16][2]*Vpk[12][16][2])+((
          Vpk[12][16][0]*Vpk[12][16][0])+(Vpk[12][16][1]*Vpk[12][16][1]))))+((
          IkWpk[12][16][2]*Wpk[12][16][2])+((IkWpk[12][16][0]*Wpk[12][16][0])+(
          IkWpk[12][16][1]*s14))))));
        mm[12][12] = (((mk[17]*((Vpk[12][22][2]*Vpk[12][22][2])+((Vpk[12][22][0]
          *Vpk[12][22][0])+(Vpk[12][22][1]*Vpk[12][22][1]))))+((IkWpk[12][22][2]
          *Wpk[12][22][2])+((IkWpk[12][22][0]*Wpk[12][20][0])+(IkWpk[12][22][1]*
          Wpk[12][22][1]))))+(((mk[15]*((Vpk[12][20][2]*Vpk[12][20][2])+((
          Vpk[12][20][0]*Vpk[12][20][0])+(Vpk[12][20][1]*Vpk[12][20][1]))))+((
          IkWpk[12][20][2]*Wpk[12][20][2])+((IkWpk[12][20][0]*Wpk[12][20][0])+(
          IkWpk[12][20][1]*s14))))+temp[1]));
        mm[12][13] = 0.;
        temp[0] = (((mk[9]*((rk[9][1]*Vpk[12][14][2])-(rk[9][2]*Vpk[12][14][1]))
          )+((ik[9][2][0]*c14)-(ik[9][1][0]*s14)))+((mk[11]*((Vpk[12][16][2]*
          Vpk[14][16][2])+((Vpk[12][16][0]*Vpk[14][16][0])+(Vpk[12][16][1]*
          Vpk[14][16][1]))))+((IkWpk[14][16][2]*Wpk[12][16][2])+((
          IkWpk[14][16][0]*Wpk[12][16][0])+(IkWpk[14][16][1]*s14)))));
        temp[1] = (((mk[15]*((Vpk[12][20][2]*Vpk[14][20][2])+((Vpk[12][20][0]*
          Vpk[14][20][0])+(Vpk[12][20][1]*Vpk[14][20][1]))))+((IkWpk[14][20][2]*
          Wpk[12][20][2])+((IkWpk[14][20][0]*Wpk[12][20][0])+(IkWpk[14][20][1]*
          s14))))+(((mk[13]*((Vpk[12][18][2]*Vpk[14][18][2])+((Vpk[12][18][0]*
          Vpk[14][18][0])+(Vpk[12][18][1]*Vpk[14][18][1]))))+((IkWpk[14][18][2]*
          Wpk[12][18][2])+((IkWpk[14][18][0]*Wpk[12][18][0])+(IkWpk[14][18][1]*
          s14))))+temp[0]));
        mm[12][14] = (((mk[17]*((Vpk[12][22][2]*Vpk[14][22][2])+((Vpk[12][22][0]
          *Vpk[14][22][0])+(Vpk[12][22][1]*Vpk[14][22][1]))))+((IkWpk[14][22][2]
          *Wpk[12][22][2])+((IkWpk[14][22][0]*Wpk[12][20][0])+(IkWpk[14][22][1]*
          Wpk[12][22][1]))))+temp[1]);
        mm[12][15] = 0.;
        temp[0] = (((mk[11]*((rk[11][2]*Vpk[12][16][0])-(rk[11][0]*
          Vpk[12][16][2])))-((ik[11][2][1]*Wpk[12][16][2])+((ik[11][0][1]*
          Wpk[12][16][0])+(ik[11][1][1]*s14))))+((mk[13]*((Vpk[12][18][0]*
          Vpk[16][18][0])+(Vpk[12][18][2]*Vpk[16][18][2])))-((ik[13][2][1]*
          Wpk[12][18][2])+((ik[13][0][1]*Wpk[12][18][0])+(ik[13][1][1]*s14)))));
        mm[12][16] = (((mk[17]*((Vpk[12][22][2]*Vpk[16][22][2])+((Vpk[12][22][0]
          *Vpk[16][22][0])+(Vpk[12][22][1]*Vpk[16][22][1]))))+((IkWpk[16][22][2]
          *Wpk[12][22][2])+((IkWpk[16][22][0]*Wpk[12][20][0])+(IkWpk[16][22][1]*
          Wpk[12][22][1]))))+(((mk[15]*((Vpk[12][20][0]*Vpk[16][20][0])+(
          Vpk[12][20][2]*Vpk[16][20][2])))-((ik[15][2][1]*Wpk[12][20][2])+((
          ik[15][0][1]*Wpk[12][20][0])+(ik[15][1][1]*s14))))+temp[0]));
        mm[12][17] = 0.;
        temp[0] = (((mk[13]*((rk[13][2]*Vpk[12][18][0])-(rk[13][0]*
          Vpk[12][18][2])))-((ik[13][2][1]*Wpk[12][18][2])+((ik[13][0][1]*
          Wpk[12][18][0])+(ik[13][1][1]*s14))))+((mk[15]*((Vpk[12][20][0]*
          Vpk[18][20][0])+(Vpk[12][20][2]*Vpk[18][20][2])))-((ik[15][2][1]*
          Wpk[12][20][2])+((ik[15][0][1]*Wpk[12][20][0])+(ik[15][1][1]*s14)))));
        mm[12][18] = (((mk[17]*((Vpk[12][22][2]*Vpk[18][22][2])+((Vpk[12][22][0]
          *Vpk[18][22][0])+(Vpk[12][22][1]*Vpk[18][22][1]))))+((IkWpk[18][22][2]
          *Wpk[12][22][2])+((IkWpk[18][22][0]*Wpk[12][20][0])+(IkWpk[18][22][1]*
          Wpk[12][22][1]))))+temp[0]);
        mm[12][19] = 0.;
        mm[12][20] = (((mk[15]*((rk[15][2]*Vpk[12][20][0])-(rk[15][0]*
          Vpk[12][20][2])))-((ik[15][2][1]*Wpk[12][20][2])+((ik[15][0][1]*
          Wpk[12][20][0])+(ik[15][1][1]*s14))))+((mk[17]*((Vpk[12][22][2]*
          Vpk[20][22][2])+((Vpk[12][22][0]*Vpk[20][22][0])+(Vpk[12][22][1]*
          Vpk[20][22][1]))))+((IkWpk[20][22][2]*Wpk[12][22][2])+((
          IkWpk[20][22][0]*Wpk[12][20][0])+(IkWpk[20][22][1]*Wpk[12][22][1])))))
          ;
        mm[12][21] = 0.;
        mm[12][22] = ((mk[17]*((rk[17][1]*Vpk[12][22][2])-(rk[17][2]*
          Vpk[12][22][1])))-((ik[17][2][0]*Wpk[12][22][2])+((ik[17][0][0]*
          Wpk[12][20][0])+(ik[17][1][0]*Wpk[12][22][1]))));
        mm[12][23] = 0.;
        mm[12][24] = 0.;
        mm[12][25] = 0.;
        temp[0] = ((ik[8][2][2]+(mk[8]*((rk[8][0]*rk[8][0])+(rk[8][1]*rk[8][1]))
          ))+((mk[10]*((Vpk[13][15][2]*Vpk[13][15][2])+((Vpk[13][15][0]*
          Vpk[13][15][0])+(Vpk[13][15][1]*Vpk[13][15][1]))))+((IkWpk[13][15][1]*
          s15)+(IkWpk[13][15][2]*c15))));
        temp[1] = (((mk[14]*((Vpk[13][19][2]*Vpk[13][19][2])+((Vpk[13][19][0]*
          Vpk[13][19][0])+(Vpk[13][19][1]*Vpk[13][19][1]))))+((IkWpk[13][19][2]*
          Wpk[13][19][2])+((IkWpk[13][19][0]*Wpk[13][19][0])+(IkWpk[13][19][1]*
          s15))))+(temp[0]+((mk[12]*((Vpk[13][17][2]*Vpk[13][17][2])+((
          Vpk[13][17][0]*Vpk[13][17][0])+(Vpk[13][17][1]*Vpk[13][17][1]))))+((
          IkWpk[13][17][2]*Wpk[13][17][2])+((IkWpk[13][17][0]*Wpk[13][17][0])+(
          IkWpk[13][17][1]*s15))))));
        mm[13][13] = (((mk[18]*((Vpk[13][23][2]*Vpk[13][23][2])+((Vpk[13][23][0]
          *Vpk[13][23][0])+(Vpk[13][23][1]*Vpk[13][23][1]))))+((IkWpk[13][23][2]
          *Wpk[13][23][2])+((IkWpk[13][23][0]*Wpk[13][21][0])+(IkWpk[13][23][1]*
          Wpk[13][23][1]))))+(((mk[16]*((Vpk[13][21][2]*Vpk[13][21][2])+((
          Vpk[13][21][0]*Vpk[13][21][0])+(Vpk[13][21][1]*Vpk[13][21][1]))))+((
          IkWpk[13][21][2]*Wpk[13][21][2])+((IkWpk[13][21][0]*Wpk[13][21][0])+(
          IkWpk[13][21][1]*s15))))+temp[1]));
        mm[13][14] = 0.;
        temp[0] = (((mk[10]*((rk[10][2]*Vpk[13][15][1])-(rk[10][1]*
          Vpk[13][15][2])))+((ik[10][1][0]*s15)+(ik[10][2][0]*c15)))+((mk[12]*((
          Vpk[13][17][2]*Vpk[15][17][2])+((Vpk[13][17][0]*Vpk[15][17][0])+(
          Vpk[13][17][1]*Vpk[15][17][1]))))+((IkWpk[15][17][2]*Wpk[13][17][2])+(
          (IkWpk[15][17][0]*Wpk[13][17][0])+(IkWpk[15][17][1]*s15)))));
        temp[1] = (((mk[16]*((Vpk[13][21][2]*Vpk[15][21][2])+((Vpk[13][21][0]*
          Vpk[15][21][0])+(Vpk[13][21][1]*Vpk[15][21][1]))))+((IkWpk[15][21][2]*
          Wpk[13][21][2])+((IkWpk[15][21][0]*Wpk[13][21][0])+(IkWpk[15][21][1]*
          s15))))+(((mk[14]*((Vpk[13][19][2]*Vpk[15][19][2])+((Vpk[13][19][0]*
          Vpk[15][19][0])+(Vpk[13][19][1]*Vpk[15][19][1]))))+((IkWpk[15][19][2]*
          Wpk[13][19][2])+((IkWpk[15][19][0]*Wpk[13][19][0])+(IkWpk[15][19][1]*
          s15))))+temp[0]));
        mm[13][15] = (((mk[18]*((Vpk[13][23][2]*Vpk[15][23][2])+((Vpk[13][23][0]
          *Vpk[15][23][0])+(Vpk[13][23][1]*Vpk[15][23][1]))))+((IkWpk[15][23][2]
          *Wpk[13][23][2])+((IkWpk[15][23][0]*Wpk[13][21][0])+(IkWpk[15][23][1]*
          Wpk[13][23][1]))))+temp[1]);
        mm[13][16] = 0.;
        temp[0] = (((mk[12]*((rk[12][2]*Vpk[13][17][0])-(rk[12][0]*
          Vpk[13][17][2])))-((ik[12][2][1]*Wpk[13][17][2])+((ik[12][0][1]*
          Wpk[13][17][0])+(ik[12][1][1]*s15))))+((mk[14]*((Vpk[13][19][0]*
          Vpk[17][19][0])+(Vpk[13][19][2]*Vpk[17][19][2])))-((ik[14][2][1]*
          Wpk[13][19][2])+((ik[14][0][1]*Wpk[13][19][0])+(ik[14][1][1]*s15)))));
        mm[13][17] = (((mk[18]*((Vpk[13][23][2]*Vpk[17][23][2])+((Vpk[13][23][0]
          *Vpk[17][23][0])+(Vpk[13][23][1]*Vpk[17][23][1]))))+((IkWpk[17][23][2]
          *Wpk[13][23][2])+((IkWpk[17][23][0]*Wpk[13][21][0])+(IkWpk[17][23][1]*
          Wpk[13][23][1]))))+(((mk[16]*((Vpk[13][21][0]*Vpk[17][21][0])+(
          Vpk[13][21][2]*Vpk[17][21][2])))-((ik[16][2][1]*Wpk[13][21][2])+((
          ik[16][0][1]*Wpk[13][21][0])+(ik[16][1][1]*s15))))+temp[0]));
        mm[13][18] = 0.;
        temp[0] = (((mk[14]*((rk[14][2]*Vpk[13][19][0])-(rk[14][0]*
          Vpk[13][19][2])))-((ik[14][2][1]*Wpk[13][19][2])+((ik[14][0][1]*
          Wpk[13][19][0])+(ik[14][1][1]*s15))))+((mk[16]*((Vpk[13][21][0]*
          Vpk[19][21][0])+(Vpk[13][21][2]*Vpk[19][21][2])))-((ik[16][2][1]*
          Wpk[13][21][2])+((ik[16][0][1]*Wpk[13][21][0])+(ik[16][1][1]*s15)))));
        mm[13][19] = (((mk[18]*((Vpk[13][23][2]*Vpk[19][23][2])+((Vpk[13][23][0]
          *Vpk[19][23][0])+(Vpk[13][23][1]*Vpk[19][23][1]))))+((IkWpk[19][23][2]
          *Wpk[13][23][2])+((IkWpk[19][23][0]*Wpk[13][21][0])+(IkWpk[19][23][1]*
          Wpk[13][23][1]))))+temp[0]);
        mm[13][20] = 0.;
        mm[13][21] = (((mk[16]*((rk[16][2]*Vpk[13][21][0])-(rk[16][0]*
          Vpk[13][21][2])))-((ik[16][2][1]*Wpk[13][21][2])+((ik[16][0][1]*
          Wpk[13][21][0])+(ik[16][1][1]*s15))))+((mk[18]*((Vpk[13][23][2]*
          Vpk[21][23][2])+((Vpk[13][23][0]*Vpk[21][23][0])+(Vpk[13][23][1]*
          Vpk[21][23][1]))))+((IkWpk[21][23][2]*Wpk[13][23][2])+((
          IkWpk[21][23][0]*Wpk[13][21][0])+(IkWpk[21][23][1]*Wpk[13][23][1])))))
          ;
        mm[13][22] = 0.;
        mm[13][23] = ((mk[18]*((rk[18][2]*Vpk[13][23][1])-(rk[18][1]*
          Vpk[13][23][2])))+((ik[18][2][0]*Wpk[13][23][2])+((ik[18][0][0]*
          Wpk[13][21][0])+(ik[18][1][0]*Wpk[13][23][1]))));
        mm[13][24] = 0.;
        mm[13][25] = 0.;
        temp[0] = (((ik[9][0][0]+(mk[9]*((rk[9][1]*rk[9][1])+(rk[9][2]*rk[9][2])
          )))+((mk[11]*((Vpk[14][16][2]*Vpk[14][16][2])+((Vpk[14][16][0]*
          Vpk[14][16][0])+(Vpk[14][16][1]*Vpk[14][16][1]))))+((IkWpk[14][16][2]*
          s16)-(IkWpk[14][16][0]*c16))))+((mk[13]*((Vpk[14][18][2]*
          Vpk[14][18][2])+((Vpk[14][18][0]*Vpk[14][18][0])+(Vpk[14][18][1]*
          Vpk[14][18][1]))))+((IkWpk[14][18][0]*Wpk[14][18][0])+(
          IkWpk[14][18][2]*Wpk[14][18][2]))));
        mm[14][14] = (((mk[17]*((Vpk[14][22][2]*Vpk[14][22][2])+((Vpk[14][22][0]
          *Vpk[14][22][0])+(Vpk[14][22][1]*Vpk[14][22][1]))))+((IkWpk[14][22][2]
          *Wpk[14][22][2])+((IkWpk[14][22][0]*Wpk[14][20][0])+(IkWpk[14][22][1]*
          Wpk[14][22][1]))))+(((mk[15]*((Vpk[14][20][2]*Vpk[14][20][2])+((
          Vpk[14][20][0]*Vpk[14][20][0])+(Vpk[14][20][1]*Vpk[14][20][1]))))+((
          IkWpk[14][20][0]*Wpk[14][20][0])+(IkWpk[14][20][2]*Wpk[14][20][2])))+
          temp[0]));
        mm[14][15] = 0.;
        temp[0] = (((mk[15]*((Vpk[14][20][0]*Vpk[16][20][0])+(Vpk[14][20][2]*
          Vpk[16][20][2])))-((ik[15][0][1]*Wpk[14][20][0])+(ik[15][2][1]*
          Wpk[14][20][2])))+(((mk[11]*((rk[11][2]*Vpk[14][16][0])-(rk[11][0]*
          Vpk[14][16][2])))+((ik[11][0][1]*c16)-(ik[11][2][1]*s16)))+((mk[13]*((
          Vpk[14][18][0]*Vpk[16][18][0])+(Vpk[14][18][2]*Vpk[16][18][2])))-((
          ik[13][0][1]*Wpk[14][18][0])+(ik[13][2][1]*Wpk[14][18][2])))));
        mm[14][16] = (((mk[17]*((Vpk[14][22][2]*Vpk[16][22][2])+((Vpk[14][22][0]
          *Vpk[16][22][0])+(Vpk[14][22][1]*Vpk[16][22][1]))))+((IkWpk[16][22][2]
          *Wpk[14][22][2])+((IkWpk[16][22][0]*Wpk[14][20][0])+(IkWpk[16][22][1]*
          Wpk[14][22][1]))))+temp[0]);
        mm[14][17] = 0.;
        temp[0] = (((mk[13]*((rk[13][2]*Vpk[14][18][0])-(rk[13][0]*
          Vpk[14][18][2])))-((ik[13][0][1]*Wpk[14][18][0])+(ik[13][2][1]*
          Wpk[14][18][2])))+((mk[15]*((Vpk[14][20][0]*Vpk[18][20][0])+(
          Vpk[14][20][2]*Vpk[18][20][2])))-((ik[15][0][1]*Wpk[14][20][0])+(
          ik[15][2][1]*Wpk[14][20][2]))));
        mm[14][18] = (((mk[17]*((Vpk[14][22][2]*Vpk[18][22][2])+((Vpk[14][22][0]
          *Vpk[18][22][0])+(Vpk[14][22][1]*Vpk[18][22][1]))))+((IkWpk[18][22][2]
          *Wpk[14][22][2])+((IkWpk[18][22][0]*Wpk[14][20][0])+(IkWpk[18][22][1]*
          Wpk[14][22][1]))))+temp[0]);
        mm[14][19] = 0.;
        mm[14][20] = (((mk[15]*((rk[15][2]*Vpk[14][20][0])-(rk[15][0]*
          Vpk[14][20][2])))-((ik[15][0][1]*Wpk[14][20][0])+(ik[15][2][1]*
          Wpk[14][20][2])))+((mk[17]*((Vpk[14][22][2]*Vpk[20][22][2])+((
          Vpk[14][22][0]*Vpk[20][22][0])+(Vpk[14][22][1]*Vpk[20][22][1]))))+((
          IkWpk[20][22][2]*Wpk[14][22][2])+((IkWpk[20][22][0]*Wpk[14][20][0])+(
          IkWpk[20][22][1]*Wpk[14][22][1])))));
        mm[14][21] = 0.;
        mm[14][22] = ((mk[17]*((rk[17][1]*Vpk[14][22][2])-(rk[17][2]*
          Vpk[14][22][1])))-((ik[17][2][0]*Wpk[14][22][2])+((ik[17][0][0]*
          Wpk[14][20][0])+(ik[17][1][0]*Wpk[14][22][1]))));
        mm[14][23] = 0.;
        mm[14][24] = 0.;
        mm[14][25] = 0.;
        temp[0] = (((ik[10][0][0]+(mk[10]*((rk[10][1]*rk[10][1])+(rk[10][2]*
          rk[10][2]))))+((mk[12]*((Vpk[15][17][2]*Vpk[15][17][2])+((
          Vpk[15][17][0]*Vpk[15][17][0])+(Vpk[15][17][1]*Vpk[15][17][1]))))+((
          IkWpk[15][17][0]*c17)-(IkWpk[15][17][2]*s17))))+((mk[14]*((
          Vpk[15][19][2]*Vpk[15][19][2])+((Vpk[15][19][0]*Vpk[15][19][0])+(
          Vpk[15][19][1]*Vpk[15][19][1]))))+((IkWpk[15][19][0]*Wpk[15][19][0])+(
          IkWpk[15][19][2]*Wpk[15][19][2]))));
        mm[15][15] = (((mk[18]*((Vpk[15][23][2]*Vpk[15][23][2])+((Vpk[15][23][0]
          *Vpk[15][23][0])+(Vpk[15][23][1]*Vpk[15][23][1]))))+((IkWpk[15][23][2]
          *Wpk[15][23][2])+((IkWpk[15][23][0]*Wpk[15][21][0])+(IkWpk[15][23][1]*
          Wpk[15][23][1]))))+(((mk[16]*((Vpk[15][21][2]*Vpk[15][21][2])+((
          Vpk[15][21][0]*Vpk[15][21][0])+(Vpk[15][21][1]*Vpk[15][21][1]))))+((
          IkWpk[15][21][0]*Wpk[15][21][0])+(IkWpk[15][21][2]*Wpk[15][21][2])))+
          temp[0]));
        mm[15][16] = 0.;
        temp[0] = (((mk[16]*((Vpk[15][21][0]*Vpk[17][21][0])+(Vpk[15][21][2]*
          Vpk[17][21][2])))-((ik[16][0][1]*Wpk[15][21][0])+(ik[16][2][1]*
          Wpk[15][21][2])))+(((mk[12]*((rk[12][2]*Vpk[15][17][0])-(rk[12][0]*
          Vpk[15][17][2])))+((ik[12][2][1]*s17)-(ik[12][0][1]*c17)))+((mk[14]*((
          Vpk[15][19][0]*Vpk[17][19][0])+(Vpk[15][19][2]*Vpk[17][19][2])))-((
          ik[14][0][1]*Wpk[15][19][0])+(ik[14][2][1]*Wpk[15][19][2])))));
        mm[15][17] = (((mk[18]*((Vpk[15][23][2]*Vpk[17][23][2])+((Vpk[15][23][0]
          *Vpk[17][23][0])+(Vpk[15][23][1]*Vpk[17][23][1]))))+((IkWpk[17][23][2]
          *Wpk[15][23][2])+((IkWpk[17][23][0]*Wpk[15][21][0])+(IkWpk[17][23][1]*
          Wpk[15][23][1]))))+temp[0]);
        mm[15][18] = 0.;
        temp[0] = (((mk[14]*((rk[14][2]*Vpk[15][19][0])-(rk[14][0]*
          Vpk[15][19][2])))-((ik[14][0][1]*Wpk[15][19][0])+(ik[14][2][1]*
          Wpk[15][19][2])))+((mk[16]*((Vpk[15][21][0]*Vpk[19][21][0])+(
          Vpk[15][21][2]*Vpk[19][21][2])))-((ik[16][0][1]*Wpk[15][21][0])+(
          ik[16][2][1]*Wpk[15][21][2]))));
        mm[15][19] = (((mk[18]*((Vpk[15][23][2]*Vpk[19][23][2])+((Vpk[15][23][0]
          *Vpk[19][23][0])+(Vpk[15][23][1]*Vpk[19][23][1]))))+((IkWpk[19][23][2]
          *Wpk[15][23][2])+((IkWpk[19][23][0]*Wpk[15][21][0])+(IkWpk[19][23][1]*
          Wpk[15][23][1]))))+temp[0]);
        mm[15][20] = 0.;
        mm[15][21] = (((mk[16]*((rk[16][2]*Vpk[15][21][0])-(rk[16][0]*
          Vpk[15][21][2])))-((ik[16][0][1]*Wpk[15][21][0])+(ik[16][2][1]*
          Wpk[15][21][2])))+((mk[18]*((Vpk[15][23][2]*Vpk[21][23][2])+((
          Vpk[15][23][0]*Vpk[21][23][0])+(Vpk[15][23][1]*Vpk[21][23][1]))))+((
          IkWpk[21][23][2]*Wpk[15][23][2])+((IkWpk[21][23][0]*Wpk[15][21][0])+(
          IkWpk[21][23][1]*Wpk[15][23][1])))));
        mm[15][22] = 0.;
        mm[15][23] = ((mk[18]*((rk[18][2]*Vpk[15][23][1])-(rk[18][1]*
          Vpk[15][23][2])))+((ik[18][2][0]*Wpk[15][23][2])+((ik[18][0][0]*
          Wpk[15][21][0])+(ik[18][1][0]*Wpk[15][23][1]))));
        mm[15][24] = 0.;
        mm[15][25] = 0.;
        mm[16][16] = (((ik[15][1][1]+(mk[15]*((Vpk[16][20][0]*Vpk[16][20][0])+(
          Vpk[16][20][2]*Vpk[16][20][2]))))+((ik[11][1][1]+(mk[11]*((rk[11][0]*
          rk[11][0])+(rk[11][2]*rk[11][2]))))+(ik[13][1][1]+(mk[13]*((
          Vpk[16][18][0]*Vpk[16][18][0])+(Vpk[16][18][2]*Vpk[16][18][2]))))))+((
          mk[17]*((Vpk[16][22][2]*Vpk[16][22][2])+((Vpk[16][22][0]*
          Vpk[16][22][0])+(Vpk[16][22][1]*Vpk[16][22][1]))))-((IkWpk[16][22][1]*
          c22)+(IkWpk[16][22][2]*s22))));
        mm[16][17] = 0.;
        mm[16][18] = (((ik[13][1][1]+(mk[13]*((rk[13][2]*Vpk[16][18][0])-(
          rk[13][0]*Vpk[16][18][2]))))+(ik[15][1][1]+(mk[15]*((Vpk[16][20][0]*
          Vpk[18][20][0])+(Vpk[16][20][2]*Vpk[18][20][2])))))+((mk[17]*((
          Vpk[16][22][2]*Vpk[18][22][2])+((Vpk[16][22][0]*Vpk[18][22][0])+(
          Vpk[16][22][1]*Vpk[18][22][1]))))-((IkWpk[18][22][1]*c22)+(
          IkWpk[18][22][2]*s22))));
        mm[16][19] = 0.;
        mm[16][20] = ((ik[15][1][1]+(mk[15]*((rk[15][2]*Vpk[16][20][0])-(
          rk[15][0]*Vpk[16][20][2]))))+((mk[17]*((Vpk[16][22][2]*Vpk[20][22][2])
          +((Vpk[16][22][0]*Vpk[20][22][0])+(Vpk[16][22][1]*Vpk[20][22][1]))))-(
          (IkWpk[20][22][1]*c22)+(IkWpk[20][22][2]*s22))));
        mm[16][21] = 0.;
        mm[16][22] = ((mk[17]*((rk[17][1]*Vpk[16][22][2])-(rk[17][2]*
          Vpk[16][22][1])))+((ik[17][1][0]*c22)+(ik[17][2][0]*s22)));
        mm[16][23] = 0.;
        mm[16][24] = 0.;
        mm[16][25] = 0.;
        mm[17][17] = (((ik[16][1][1]+(mk[16]*((Vpk[17][21][0]*Vpk[17][21][0])+(
          Vpk[17][21][2]*Vpk[17][21][2]))))+((ik[12][1][1]+(mk[12]*((rk[12][0]*
          rk[12][0])+(rk[12][2]*rk[12][2]))))+(ik[14][1][1]+(mk[14]*((
          Vpk[17][19][0]*Vpk[17][19][0])+(Vpk[17][19][2]*Vpk[17][19][2]))))))+((
          mk[18]*((Vpk[17][23][2]*Vpk[17][23][2])+((Vpk[17][23][0]*
          Vpk[17][23][0])+(Vpk[17][23][1]*Vpk[17][23][1]))))+((IkWpk[17][23][2]*
          s23)-(IkWpk[17][23][1]*c23))));
        mm[17][18] = 0.;
        mm[17][19] = (((ik[14][1][1]+(mk[14]*((rk[14][2]*Vpk[17][19][0])-(
          rk[14][0]*Vpk[17][19][2]))))+(ik[16][1][1]+(mk[16]*((Vpk[17][21][0]*
          Vpk[19][21][0])+(Vpk[17][21][2]*Vpk[19][21][2])))))+((mk[18]*((
          Vpk[17][23][2]*Vpk[19][23][2])+((Vpk[17][23][0]*Vpk[19][23][0])+(
          Vpk[17][23][1]*Vpk[19][23][1]))))+((IkWpk[19][23][2]*s23)-(
          IkWpk[19][23][1]*c23))));
        mm[17][20] = 0.;
        mm[17][21] = ((ik[16][1][1]+(mk[16]*((rk[16][2]*Vpk[17][21][0])-(
          rk[16][0]*Vpk[17][21][2]))))+((mk[18]*((Vpk[17][23][2]*Vpk[21][23][2])
          +((Vpk[17][23][0]*Vpk[21][23][0])+(Vpk[17][23][1]*Vpk[21][23][1]))))+(
          (IkWpk[21][23][2]*s23)-(IkWpk[21][23][1]*c23))));
        mm[17][22] = 0.;
        mm[17][23] = ((mk[18]*((rk[18][2]*Vpk[17][23][1])-(rk[18][1]*
          Vpk[17][23][2])))+((ik[18][2][0]*s23)-(ik[18][1][0]*c23)));
        mm[17][24] = 0.;
        mm[17][25] = 0.;
        mm[18][18] = (((ik[13][1][1]+(mk[13]*((rk[13][0]*rk[13][0])+(rk[13][2]*
          rk[13][2]))))+(ik[15][1][1]+(mk[15]*((Vpk[18][20][0]*Vpk[18][20][0])+(
          Vpk[18][20][2]*Vpk[18][20][2])))))+((mk[17]*((Vpk[18][22][2]*
          Vpk[18][22][2])+((Vpk[18][22][0]*Vpk[18][22][0])+(Vpk[18][22][1]*
          Vpk[18][22][1]))))-((IkWpk[18][22][1]*c22)+(IkWpk[18][22][2]*s22))));
        mm[18][19] = 0.;
        mm[18][20] = ((ik[15][1][1]+(mk[15]*((rk[15][2]*Vpk[18][20][0])-(
          rk[15][0]*Vpk[18][20][2]))))+((mk[17]*((Vpk[18][22][2]*Vpk[20][22][2])
          +((Vpk[18][22][0]*Vpk[20][22][0])+(Vpk[18][22][1]*Vpk[20][22][1]))))-(
          (IkWpk[20][22][1]*c22)+(IkWpk[20][22][2]*s22))));
        mm[18][21] = 0.;
        mm[18][22] = ((mk[17]*((rk[17][1]*Vpk[18][22][2])-(rk[17][2]*
          Vpk[18][22][1])))+((ik[17][1][0]*c22)+(ik[17][2][0]*s22)));
        mm[18][23] = 0.;
        mm[18][24] = 0.;
        mm[18][25] = 0.;
        mm[19][19] = (((ik[14][1][1]+(mk[14]*((rk[14][0]*rk[14][0])+(rk[14][2]*
          rk[14][2]))))+(ik[16][1][1]+(mk[16]*((Vpk[19][21][0]*Vpk[19][21][0])+(
          Vpk[19][21][2]*Vpk[19][21][2])))))+((mk[18]*((Vpk[19][23][2]*
          Vpk[19][23][2])+((Vpk[19][23][0]*Vpk[19][23][0])+(Vpk[19][23][1]*
          Vpk[19][23][1]))))+((IkWpk[19][23][2]*s23)-(IkWpk[19][23][1]*c23))));
        mm[19][20] = 0.;
        mm[19][21] = ((ik[16][1][1]+(mk[16]*((rk[16][2]*Vpk[19][21][0])-(
          rk[16][0]*Vpk[19][21][2]))))+((mk[18]*((Vpk[19][23][2]*Vpk[21][23][2])
          +((Vpk[19][23][0]*Vpk[21][23][0])+(Vpk[19][23][1]*Vpk[21][23][1]))))+(
          (IkWpk[21][23][2]*s23)-(IkWpk[21][23][1]*c23))));
        mm[19][22] = 0.;
        mm[19][23] = ((mk[18]*((rk[18][2]*Vpk[19][23][1])-(rk[18][1]*
          Vpk[19][23][2])))+((ik[18][2][0]*s23)-(ik[18][1][0]*c23)));
        mm[19][24] = 0.;
        mm[19][25] = 0.;
        mm[20][20] = ((ik[15][1][1]+(mk[15]*((rk[15][0]*rk[15][0])+(rk[15][2]*
          rk[15][2]))))+((mk[17]*((Vpk[20][22][2]*Vpk[20][22][2])+((
          Vpk[20][22][0]*Vpk[20][22][0])+(Vpk[20][22][1]*Vpk[20][22][1]))))-((
          IkWpk[20][22][1]*c22)+(IkWpk[20][22][2]*s22))));
        mm[20][21] = 0.;
        mm[20][22] = ((mk[17]*((rk[17][1]*Vpk[20][22][2])-(rk[17][2]*
          Vpk[20][22][1])))+((ik[17][1][0]*c22)+(ik[17][2][0]*s22)));
        mm[20][23] = 0.;
        mm[20][24] = 0.;
        mm[20][25] = 0.;
        mm[21][21] = ((ik[16][1][1]+(mk[16]*((rk[16][0]*rk[16][0])+(rk[16][2]*
          rk[16][2]))))+((mk[18]*((Vpk[21][23][2]*Vpk[21][23][2])+((
          Vpk[21][23][0]*Vpk[21][23][0])+(Vpk[21][23][1]*Vpk[21][23][1]))))+((
          IkWpk[21][23][2]*s23)-(IkWpk[21][23][1]*c23))));
        mm[21][22] = 0.;
        mm[21][23] = ((mk[18]*((rk[18][2]*Vpk[21][23][1])-(rk[18][1]*
          Vpk[21][23][2])))+((ik[18][2][0]*s23)-(ik[18][1][0]*c23)));
        mm[21][24] = 0.;
        mm[21][25] = 0.;
        mm[22][22] = (ik[17][0][0]+(mk[17]*((rk[17][1]*rk[17][1])+(rk[17][2]*
          rk[17][2]))));
        mm[22][23] = 0.;
        mm[22][24] = 0.;
        mm[22][25] = 0.;
        mm[23][23] = (ik[18][0][0]+(mk[18]*((rk[18][1]*rk[18][1])+(rk[18][2]*
          rk[18][2]))));
        mm[23][24] = 0.;
        mm[23][25] = 0.;
        mm[24][24] = ((ik[19][2][2]+(mk[19]*((rk[19][0]*rk[19][0])+(rk[19][1]*
          rk[19][1]))))+((mk[20]*((Vpk[24][25][2]*Vpk[24][25][2])+((
          Vpk[24][25][0]*Vpk[24][25][0])+(Vpk[24][25][1]*Vpk[24][25][1]))))+((
          IkWpk[24][25][0]*s25)+(IkWpk[24][25][2]*c25))));
        mm[24][25] = ((mk[20]*((rk[20][2]*Vpk[24][25][0])-(rk[20][0]*
          Vpk[24][25][2])))-((ik[20][0][1]*s25)+(ik[20][2][1]*c25)));
        mm[25][25] = (ik[20][1][1]+(mk[20]*((rk[20][0]*rk[20][0])+(rk[20][2]*
          rk[20][2]))));
/*
Check for singular mass matrix
*/
        for (i = 0; i < 26; i++) {
            if (mm[i][i] < 1e-13) {
                sdseterr(routine,47);
            }
        }
        sderror(&dumroutine,&errnum);
        if (errnum == 0) {
            mmflg = 1;
        }
    }
/*
 Used 0.04 seconds CPU time,
 0 additional bytes of memory.
 Equations contain 3802 adds/subtracts/negates
                   5110 multiplies
                      0 divides
                    855 assignments
*/
}

void sddommldu(int routine)
{
    int i;
    int dumroutine,errnum;

    if (mmlduflg == 0) {
        sddomm(routine);
/*
Numerically decompose the mass matrix
*/
        sdldudcomp(26,26,mmap,1e-13,workss,works,mm,mlo,mdi);
/*
Check for singular mass matrix
*/
        for (i = 0; i < 26; i++) {
            if (mdi[i] <= 1e-13) {
                sdseterr(routine,47);
            }
        }
        sderror(&dumroutine,&errnum);
        if (errnum == 0) {
            mmlduflg = 1;
        }
    }
}

void sdlhs(int routine)
{
/* Compute all remaining state- and force-dependent quantities
*/

    roustate = 2;
    sddommldu(routine);
    sddofs0();
}

void sdmfrc(double imult[1])
{

}

void sdequivht(double tau[26])
{
/* Compute tree hinge torques to match effect of applied loads
*/
    double fstareq[26][3],tstareq[26][3];

    if ((roustate != 2) && (roustate != 3)) {
        sdseterr(56,23);
        return;
    }
/*
Compute fstareq (forces)
*/
    fstareq[5][0] = -(ufk[0][0]+(gk[3][0]*mk[0]));
    fstareq[5][1] = -(ufk[0][1]+(gk[3][1]*mk[0]));
    fstareq[5][2] = -(ufk[0][2]+(gk[3][2]*mk[0]));
    fstareq[6][0] = -(ufk[1][0]+(gk[6][0]*mk[1]));
    fstareq[6][1] = -(ufk[1][1]+(gk[3][1]*mk[1]));
    fstareq[6][2] = -(ufk[1][2]+(gk[6][2]*mk[1]));
    fstareq[7][0] = -(ufk[2][0]+(gk[7][0]*mk[2]));
    fstareq[7][1] = -(ufk[2][1]+(gk[3][1]*mk[2]));
    fstareq[7][2] = -(ufk[2][2]+(gk[7][2]*mk[2]));
    fstareq[8][0] = -(ufk[3][0]+(gk[6][0]*mk[3]));
    fstareq[8][1] = -(ufk[3][1]+(gk[8][1]*mk[3]));
    fstareq[8][2] = -(ufk[3][2]+(gk[8][2]*mk[3]));
    fstareq[9][0] = -(ufk[4][0]+(gk[7][0]*mk[4]));
    fstareq[9][1] = -(ufk[4][1]+(gk[9][1]*mk[4]));
    fstareq[9][2] = -(ufk[4][2]+(gk[9][2]*mk[4]));
    fstareq[10][0] = -(ufk[5][0]+(gk[10][0]*mk[5]));
    fstareq[10][1] = -(ufk[5][1]+(gk[10][1]*mk[5]));
    fstareq[10][2] = -(ufk[5][2]+(gk[8][2]*mk[5]));
    fstareq[11][0] = -(ufk[6][0]+(gk[11][0]*mk[6]));
    fstareq[11][1] = -(ufk[6][1]+(gk[11][1]*mk[6]));
    fstareq[11][2] = -(ufk[6][2]+(gk[9][2]*mk[6]));
    fstareq[12][0] = -(ufk[7][0]+(gk[12][0]*mk[7]));
    fstareq[12][1] = -(ufk[7][1]+(gk[12][1]*mk[7]));
    fstareq[12][2] = -(ufk[7][2]+(gk[3][2]*mk[7]));
    fstareq[13][0] = -(ufk[8][0]+(gk[13][0]*mk[8]));
    fstareq[13][1] = -(ufk[8][1]+(gk[13][1]*mk[8]));
    fstareq[13][2] = -(ufk[8][2]+(gk[3][2]*mk[8]));
    fstareq[14][0] = -(ufk[9][0]+(gk[12][0]*mk[9]));
    fstareq[14][1] = -(ufk[9][1]+(gk[14][1]*mk[9]));
    fstareq[14][2] = -(ufk[9][2]+(gk[14][2]*mk[9]));
    fstareq[15][0] = -(ufk[10][0]+(gk[13][0]*mk[10]));
    fstareq[15][1] = -(ufk[10][1]+(gk[15][1]*mk[10]));
    fstareq[15][2] = -(ufk[10][2]+(gk[15][2]*mk[10]));
    fstareq[16][0] = -(ufk[11][0]+(gk[16][0]*mk[11]));
    fstareq[16][1] = -(ufk[11][1]+(gk[14][1]*mk[11]));
    fstareq[16][2] = -(ufk[11][2]+(gk[16][2]*mk[11]));
    fstareq[17][0] = -(ufk[12][0]+(gk[17][0]*mk[12]));
    fstareq[17][1] = -(ufk[12][1]+(gk[15][1]*mk[12]));
    fstareq[17][2] = -(ufk[12][2]+(gk[17][2]*mk[12]));
    fstareq[18][0] = -(ufk[13][0]+(gk[18][0]*mk[13]));
    fstareq[18][1] = -(ufk[13][1]+(gk[14][1]*mk[13]));
    fstareq[18][2] = -(ufk[13][2]+(gk[18][2]*mk[13]));
    fstareq[19][0] = -(ufk[14][0]+(gk[19][0]*mk[14]));
    fstareq[19][1] = -(ufk[14][1]+(gk[15][1]*mk[14]));
    fstareq[19][2] = -(ufk[14][2]+(gk[19][2]*mk[14]));
    fstareq[20][0] = -(ufk[15][0]+(gk[20][0]*mk[15]));
    fstareq[20][1] = -(ufk[15][1]+(gk[14][1]*mk[15]));
    fstareq[20][2] = -(ufk[15][2]+(gk[20][2]*mk[15]));
    fstareq[21][0] = -(ufk[16][0]+(gk[21][0]*mk[16]));
    fstareq[21][1] = -(ufk[16][1]+(gk[15][1]*mk[16]));
    fstareq[21][2] = -(ufk[16][2]+(gk[21][2]*mk[16]));
    fstareq[22][0] = -(ufk[17][0]+(gk[20][0]*mk[17]));
    fstareq[22][1] = -(ufk[17][1]+(gk[22][1]*mk[17]));
    fstareq[22][2] = -(ufk[17][2]+(gk[22][2]*mk[17]));
    fstareq[23][0] = -(ufk[18][0]+(gk[21][0]*mk[18]));
    fstareq[23][1] = -(ufk[18][1]+(gk[23][1]*mk[18]));
    fstareq[23][2] = -(ufk[18][2]+(gk[23][2]*mk[18]));
    fstareq[24][0] = -(ufk[19][0]+(gk[24][0]*mk[19]));
    fstareq[24][1] = -(ufk[19][1]+(gk[24][1]*mk[19]));
    fstareq[24][2] = -(ufk[19][2]+(gk[3][2]*mk[19]));
    fstareq[25][0] = -(ufk[20][0]+(gk[25][0]*mk[20]));
    fstareq[25][1] = -(ufk[20][1]+(gk[24][1]*mk[20]));
    fstareq[25][2] = -(ufk[20][2]+(gk[25][2]*mk[20]));
/*
Compute tstareq (torques)
*/
/*
Compute taus (RHS ignoring constraints and inertial forces)
*/
    sddovpk();
    temp[0] = (((fstareq[8][2]*Vpk[0][8][2])+((fstareq[8][0]*Vpk[0][6][0])+(
      fstareq[8][1]*Vpk[0][8][1])))+(((fstareq[7][2]*Vpk[0][7][2])+((
      Cik[3][0][1]*fstareq[7][1])+(fstareq[7][0]*Vpk[0][7][0])))+(((Cik[3][0][2]
      *fstareq[5][2])+((Cik[3][0][0]*fstareq[5][0])+(Cik[3][0][1]*fstareq[5][1])
      ))+((fstareq[6][2]*Vpk[0][6][2])+((Cik[3][0][1]*fstareq[6][1])+(
      fstareq[6][0]*Vpk[0][6][0]))))));
    temp[1] = (((Cik[3][0][2]*fstareq[12][2])+((fstareq[12][0]*Vpk[0][12][0])+(
      fstareq[12][1]*Vpk[0][12][1])))+(((fstareq[11][2]*Vpk[0][9][2])+((
      fstareq[11][0]*Vpk[0][11][0])+(fstareq[11][1]*Vpk[0][11][1])))+(((
      fstareq[10][2]*Vpk[0][8][2])+((fstareq[10][0]*Vpk[0][10][0])+(
      fstareq[10][1]*Vpk[0][10][1])))+(((fstareq[9][2]*Vpk[0][9][2])+((
      fstareq[9][0]*Vpk[0][7][0])+(fstareq[9][1]*Vpk[0][9][1])))+temp[0]))));
    temp[2] = (((fstareq[16][2]*Vpk[0][16][2])+((fstareq[16][0]*Vpk[0][16][0])+(
      fstareq[16][1]*Vpk[0][14][1])))+(((fstareq[15][2]*Vpk[0][15][2])+((
      fstareq[15][0]*Vpk[0][13][0])+(fstareq[15][1]*Vpk[0][15][1])))+(((
      fstareq[14][2]*Vpk[0][14][2])+((fstareq[14][0]*Vpk[0][12][0])+(
      fstareq[14][1]*Vpk[0][14][1])))+(((Cik[3][0][2]*fstareq[13][2])+((
      fstareq[13][0]*Vpk[0][13][0])+(fstareq[13][1]*Vpk[0][13][1])))+temp[1]))))
      ;
    temp[3] = (((fstareq[20][2]*Vpk[0][20][2])+((fstareq[20][0]*Vpk[0][20][0])+(
      fstareq[20][1]*Vpk[0][14][1])))+(((fstareq[19][2]*Vpk[0][19][2])+((
      fstareq[19][0]*Vpk[0][19][0])+(fstareq[19][1]*Vpk[0][15][1])))+(((
      fstareq[18][2]*Vpk[0][18][2])+((fstareq[18][0]*Vpk[0][18][0])+(
      fstareq[18][1]*Vpk[0][14][1])))+(((fstareq[17][2]*Vpk[0][17][2])+((
      fstareq[17][0]*Vpk[0][17][0])+(fstareq[17][1]*Vpk[0][15][1])))+temp[2]))))
      ;
    temp[4] = (((Cik[3][0][2]*fstareq[24][2])+((fstareq[24][0]*Vpk[0][24][0])+(
      fstareq[24][1]*Vpk[0][24][1])))+(((fstareq[23][2]*Vpk[0][23][2])+((
      fstareq[23][0]*Vpk[0][21][0])+(fstareq[23][1]*Vpk[0][23][1])))+(((
      fstareq[22][2]*Vpk[0][22][2])+((fstareq[22][0]*Vpk[0][20][0])+(
      fstareq[22][1]*Vpk[0][22][1])))+(((fstareq[21][2]*Vpk[0][21][2])+((
      fstareq[21][0]*Vpk[0][21][0])+(fstareq[21][1]*Vpk[0][15][1])))+temp[3]))))
      ;
    tau[0] = (utau[0]-(((fstareq[25][2]*Vpk[0][25][2])+((fstareq[25][0]*
      Vpk[0][25][0])+(fstareq[25][1]*Vpk[0][24][1])))+temp[4]));
    temp[0] = (((fstareq[8][2]*Vpk[1][8][2])+((fstareq[8][0]*Vpk[1][6][0])+(
      fstareq[8][1]*Vpk[1][8][1])))+(((fstareq[7][2]*Vpk[1][7][2])+((
      Cik[3][1][1]*fstareq[7][1])+(fstareq[7][0]*Vpk[1][7][0])))+(((Cik[3][1][2]
      *fstareq[5][2])+((Cik[3][1][0]*fstareq[5][0])+(Cik[3][1][1]*fstareq[5][1])
      ))+((fstareq[6][2]*Vpk[1][6][2])+((Cik[3][1][1]*fstareq[6][1])+(
      fstareq[6][0]*Vpk[1][6][0]))))));
    temp[1] = (((Cik[3][1][2]*fstareq[12][2])+((fstareq[12][0]*Vpk[1][12][0])+(
      fstareq[12][1]*Vpk[1][12][1])))+(((fstareq[11][2]*Vpk[1][9][2])+((
      fstareq[11][0]*Vpk[1][11][0])+(fstareq[11][1]*Vpk[1][11][1])))+(((
      fstareq[10][2]*Vpk[1][8][2])+((fstareq[10][0]*Vpk[1][10][0])+(
      fstareq[10][1]*Vpk[1][10][1])))+(((fstareq[9][2]*Vpk[1][9][2])+((
      fstareq[9][0]*Vpk[1][7][0])+(fstareq[9][1]*Vpk[1][9][1])))+temp[0]))));
    temp[2] = (((fstareq[16][2]*Vpk[1][16][2])+((fstareq[16][0]*Vpk[1][16][0])+(
      fstareq[16][1]*Vpk[1][14][1])))+(((fstareq[15][2]*Vpk[1][15][2])+((
      fstareq[15][0]*Vpk[1][13][0])+(fstareq[15][1]*Vpk[1][15][1])))+(((
      fstareq[14][2]*Vpk[1][14][2])+((fstareq[14][0]*Vpk[1][12][0])+(
      fstareq[14][1]*Vpk[1][14][1])))+(((Cik[3][1][2]*fstareq[13][2])+((
      fstareq[13][0]*Vpk[1][13][0])+(fstareq[13][1]*Vpk[1][13][1])))+temp[1]))))
      ;
    temp[3] = (((fstareq[20][2]*Vpk[1][20][2])+((fstareq[20][0]*Vpk[1][20][0])+(
      fstareq[20][1]*Vpk[1][14][1])))+(((fstareq[19][2]*Vpk[1][19][2])+((
      fstareq[19][0]*Vpk[1][19][0])+(fstareq[19][1]*Vpk[1][15][1])))+(((
      fstareq[18][2]*Vpk[1][18][2])+((fstareq[18][0]*Vpk[1][18][0])+(
      fstareq[18][1]*Vpk[1][14][1])))+(((fstareq[17][2]*Vpk[1][17][2])+((
      fstareq[17][0]*Vpk[1][17][0])+(fstareq[17][1]*Vpk[1][15][1])))+temp[2]))))
      ;
    temp[4] = (((Cik[3][1][2]*fstareq[24][2])+((fstareq[24][0]*Vpk[1][24][0])+(
      fstareq[24][1]*Vpk[1][24][1])))+(((fstareq[23][2]*Vpk[1][23][2])+((
      fstareq[23][0]*Vpk[1][21][0])+(fstareq[23][1]*Vpk[1][23][1])))+(((
      fstareq[22][2]*Vpk[1][22][2])+((fstareq[22][0]*Vpk[1][20][0])+(
      fstareq[22][1]*Vpk[1][22][1])))+(((fstareq[21][2]*Vpk[1][21][2])+((
      fstareq[21][0]*Vpk[1][21][0])+(fstareq[21][1]*Vpk[1][15][1])))+temp[3]))))
      ;
    tau[1] = (utau[1]-(((fstareq[25][2]*Vpk[1][25][2])+((fstareq[25][0]*
      Vpk[1][25][0])+(fstareq[25][1]*Vpk[1][24][1])))+temp[4]));
    temp[0] = (((fstareq[8][2]*Vpk[2][8][2])+((fstareq[8][0]*Vpk[2][6][0])+(
      fstareq[8][1]*Vpk[2][8][1])))+(((fstareq[7][2]*Vpk[2][7][2])+((
      Cik[3][2][1]*fstareq[7][1])+(fstareq[7][0]*Vpk[2][7][0])))+(((Cik[3][2][2]
      *fstareq[5][2])+((Cik[3][2][0]*fstareq[5][0])+(Cik[3][2][1]*fstareq[5][1])
      ))+((fstareq[6][2]*Vpk[2][6][2])+((Cik[3][2][1]*fstareq[6][1])+(
      fstareq[6][0]*Vpk[2][6][0]))))));
    temp[1] = (((Cik[3][2][2]*fstareq[12][2])+((fstareq[12][0]*Vpk[2][12][0])+(
      fstareq[12][1]*Vpk[2][12][1])))+(((fstareq[11][2]*Vpk[2][9][2])+((
      fstareq[11][0]*Vpk[2][11][0])+(fstareq[11][1]*Vpk[2][11][1])))+(((
      fstareq[10][2]*Vpk[2][8][2])+((fstareq[10][0]*Vpk[2][10][0])+(
      fstareq[10][1]*Vpk[2][10][1])))+(((fstareq[9][2]*Vpk[2][9][2])+((
      fstareq[9][0]*Vpk[2][7][0])+(fstareq[9][1]*Vpk[2][9][1])))+temp[0]))));
    temp[2] = (((fstareq[16][2]*Vpk[2][16][2])+((fstareq[16][0]*Vpk[2][16][0])+(
      fstareq[16][1]*Vpk[2][14][1])))+(((fstareq[15][2]*Vpk[2][15][2])+((
      fstareq[15][0]*Vpk[2][13][0])+(fstareq[15][1]*Vpk[2][15][1])))+(((
      fstareq[14][2]*Vpk[2][14][2])+((fstareq[14][0]*Vpk[2][12][0])+(
      fstareq[14][1]*Vpk[2][14][1])))+(((Cik[3][2][2]*fstareq[13][2])+((
      fstareq[13][0]*Vpk[2][13][0])+(fstareq[13][1]*Vpk[2][13][1])))+temp[1]))))
      ;
    temp[3] = (((fstareq[20][2]*Vpk[2][20][2])+((fstareq[20][0]*Vpk[2][20][0])+(
      fstareq[20][1]*Vpk[2][14][1])))+(((fstareq[19][2]*Vpk[2][19][2])+((
      fstareq[19][0]*Vpk[2][19][0])+(fstareq[19][1]*Vpk[2][15][1])))+(((
      fstareq[18][2]*Vpk[2][18][2])+((fstareq[18][0]*Vpk[2][18][0])+(
      fstareq[18][1]*Vpk[2][14][1])))+(((fstareq[17][2]*Vpk[2][17][2])+((
      fstareq[17][0]*Vpk[2][17][0])+(fstareq[17][1]*Vpk[2][15][1])))+temp[2]))))
      ;
    temp[4] = (((Cik[3][2][2]*fstareq[24][2])+((fstareq[24][0]*Vpk[2][24][0])+(
      fstareq[24][1]*Vpk[2][24][1])))+(((fstareq[23][2]*Vpk[2][23][2])+((
      fstareq[23][0]*Vpk[2][21][0])+(fstareq[23][1]*Vpk[2][23][1])))+(((
      fstareq[22][2]*Vpk[2][22][2])+((fstareq[22][0]*Vpk[2][20][0])+(
      fstareq[22][1]*Vpk[2][22][1])))+(((fstareq[21][2]*Vpk[2][21][2])+((
      fstareq[21][0]*Vpk[2][21][0])+(fstareq[21][1]*Vpk[2][15][1])))+temp[3]))))
      ;
    tau[2] = (utau[2]-(((fstareq[25][2]*Vpk[2][25][2])+((fstareq[25][0]*
      Vpk[2][25][0])+(fstareq[25][1]*Vpk[2][24][1])))+temp[4]));
    temp[0] = ((((fstareq[7][2]*Vpk[3][7][2])+((fstareq[7][0]*Vpk[3][7][0])+(
      fstareq[7][1]*Vpk[3][7][1])))+((utk[2][2]*s7)-(utk[2][0]*c7)))+((((
      fstareq[5][1]*rk[0][2])-(fstareq[5][2]*rk[0][1]))-utk[0][0])+(((
      fstareq[6][2]*Vpk[3][6][2])+((fstareq[6][0]*Vpk[3][6][0])+(fstareq[6][1]*
      Vpk[3][6][1])))+((utk[1][2]*s6)-(utk[1][0]*c6)))));
    temp[1] = ((((fstareq[9][2]*Vpk[3][9][2])+((fstareq[9][0]*Vpk[3][9][0])+(
      fstareq[9][1]*Vpk[3][9][1])))-((utk[4][2]*Wpk[3][9][2])+((utk[4][0]*c7)+(
      utk[4][1]*Wpk[3][9][1]))))+((((fstareq[8][2]*Vpk[3][8][2])+((fstareq[8][0]
      *Vpk[3][8][0])+(fstareq[8][1]*Vpk[3][8][1])))-((utk[3][2]*Wpk[3][8][2])+((
      utk[3][0]*c6)+(utk[3][1]*Wpk[3][8][1]))))+temp[0]));
    temp[2] = ((((fstareq[11][2]*Vpk[3][11][2])+((fstareq[11][0]*Vpk[3][11][0])+
      (fstareq[11][1]*Vpk[3][11][1])))-((utk[6][2]*Wpk[3][9][2])+((utk[6][0]*
      Wpk[3][11][0])+(utk[6][1]*Wpk[3][11][1]))))+((((fstareq[10][2]*
      Vpk[3][10][2])+((fstareq[10][0]*Vpk[3][10][0])+(fstareq[10][1]*
      Vpk[3][10][1])))-((utk[5][2]*Wpk[3][8][2])+((utk[5][0]*Wpk[3][10][0])+(
      utk[5][1]*Wpk[3][10][1]))))+temp[1]));
    temp[3] = ((((fstareq[14][2]*Vpk[3][14][2])+((fstareq[14][0]*Vpk[3][14][0])+
      (fstareq[14][1]*Vpk[3][14][1])))-((utk[9][2]*Wpk[3][14][2])+((utk[9][0]*
      c12)+(utk[9][1]*Wpk[3][14][1]))))+((((fstareq[13][2]*Vpk[3][13][2])+((
      fstareq[13][0]*Vpk[3][13][0])+(fstareq[13][1]*Vpk[3][13][1])))+((utk[8][1]
      *s13)-(utk[8][0]*c13)))+((((fstareq[12][2]*Vpk[3][12][2])+((fstareq[12][0]
      *Vpk[3][12][0])+(fstareq[12][1]*Vpk[3][12][1])))-((utk[7][0]*c12)+(
      utk[7][1]*s12)))+temp[2])));
    temp[4] = ((((fstareq[16][2]*Vpk[3][16][2])+((fstareq[16][0]*Vpk[3][16][0])+
      (fstareq[16][1]*Vpk[3][16][1])))-((utk[11][2]*Wpk[3][16][2])+((utk[11][0]*
      Wpk[3][16][0])+(utk[11][1]*Wpk[3][14][1]))))+((((fstareq[15][2]*
      Vpk[3][15][2])+((fstareq[15][0]*Vpk[3][15][0])+(fstareq[15][1]*
      Vpk[3][15][1])))-((utk[10][2]*Wpk[3][15][2])+((utk[10][0]*c13)+(utk[10][1]
      *Wpk[3][15][1]))))+temp[3]));
    temp[5] = ((((fstareq[18][2]*Vpk[3][18][2])+((fstareq[18][0]*Vpk[3][18][0])+
      (fstareq[18][1]*Vpk[3][18][1])))-((utk[13][2]*Wpk[3][18][2])+((utk[13][0]*
      Wpk[3][18][0])+(utk[13][1]*Wpk[3][14][1]))))+((((fstareq[17][2]*
      Vpk[3][17][2])+((fstareq[17][0]*Vpk[3][17][0])+(fstareq[17][1]*
      Vpk[3][17][1])))-((utk[12][2]*Wpk[3][17][2])+((utk[12][0]*Wpk[3][17][0])+(
      utk[12][1]*Wpk[3][15][1]))))+temp[4]));
    temp[6] = ((((fstareq[20][2]*Vpk[3][20][2])+((fstareq[20][0]*Vpk[3][20][0])+
      (fstareq[20][1]*Vpk[3][20][1])))-((utk[15][2]*Wpk[3][20][2])+((utk[15][0]*
      Wpk[3][20][0])+(utk[15][1]*Wpk[3][14][1]))))+((((fstareq[19][2]*
      Vpk[3][19][2])+((fstareq[19][0]*Vpk[3][19][0])+(fstareq[19][1]*
      Vpk[3][19][1])))-((utk[14][2]*Wpk[3][19][2])+((utk[14][0]*Wpk[3][19][0])+(
      utk[14][1]*Wpk[3][15][1]))))+temp[5]));
    temp[7] = ((((fstareq[22][2]*Vpk[3][22][2])+((fstareq[22][0]*Vpk[3][22][0])+
      (fstareq[22][1]*Vpk[3][22][1])))-((utk[17][2]*Wpk[3][22][2])+((utk[17][0]*
      Wpk[3][20][0])+(utk[17][1]*Wpk[3][22][1]))))+((((fstareq[21][2]*
      Vpk[3][21][2])+((fstareq[21][0]*Vpk[3][21][0])+(fstareq[21][1]*
      Vpk[3][21][1])))-((utk[16][2]*Wpk[3][21][2])+((utk[16][0]*Wpk[3][21][0])+(
      utk[16][1]*Wpk[3][15][1]))))+temp[6]));
    temp[8] = ((((fstareq[24][2]*Vpk[3][24][2])+((fstareq[24][0]*Vpk[3][24][0])+
      (fstareq[24][1]*Vpk[3][24][1])))+((utk[19][1]*s24)-(utk[19][0]*c24)))+((((
      fstareq[23][2]*Vpk[3][23][2])+((fstareq[23][0]*Vpk[3][23][0])+(
      fstareq[23][1]*Vpk[3][23][1])))-((utk[18][2]*Wpk[3][23][2])+((utk[18][0]*
      Wpk[3][21][0])+(utk[18][1]*Wpk[3][23][1]))))+temp[7]));
    tau[3] = (utau[3]-((((fstareq[25][2]*Vpk[3][25][2])+((fstareq[25][0]*
      Vpk[3][25][0])+(fstareq[25][1]*Vpk[3][25][1])))+(((utk[20][1]*s24)-(
      utk[20][0]*Wpk[3][25][0]))-(utk[20][2]*Wpk[3][25][2])))+temp[8]));
    temp[0] = ((((fstareq[8][2]*Vpk[4][8][2])+((fstareq[8][0]*Vpk[4][8][0])+(
      fstareq[8][1]*Vpk[4][8][1])))-((utk[3][1]*c8)+(utk[3][2]*s8)))+((((
      fstareq[7][0]*Vpk[4][7][0])+(fstareq[7][2]*Vpk[4][7][2]))-utk[2][1])+((((
      fstareq[5][2]*rk[0][0])-(fstareq[5][0]*rk[0][2]))-utk[0][1])+(((
      fstareq[6][0]*Vpk[4][6][0])+(fstareq[6][2]*Vpk[4][6][2]))-utk[1][1]))));
    temp[1] = ((((fstareq[10][2]*Vpk[4][10][2])+((fstareq[10][0]*Vpk[4][10][0])+
      (fstareq[10][1]*Vpk[4][10][1])))-((utk[5][2]*s8)+((utk[5][0]*Wpk[4][10][0]
      )+(utk[5][1]*Wpk[4][10][1]))))+((((fstareq[9][2]*Vpk[4][9][2])+((
      fstareq[9][0]*Vpk[4][9][0])+(fstareq[9][1]*Vpk[4][9][1])))+((utk[4][2]*s9)
      -(utk[4][1]*c9)))+temp[0]));
    temp[2] = ((((fstareq[13][2]*Vpk[4][13][2])+((fstareq[13][0]*Vpk[4][13][0])+
      (fstareq[13][1]*Vpk[4][13][1])))-((utk[8][0]*s13)+(utk[8][1]*c13)))+((((
      fstareq[12][2]*Vpk[4][12][2])+((fstareq[12][0]*Vpk[4][12][0])+(
      fstareq[12][1]*Vpk[4][12][1])))+((utk[7][0]*s12)-(utk[7][1]*c12)))+((((
      fstareq[11][2]*Vpk[4][11][2])+((fstareq[11][0]*Vpk[4][11][0])+(
      fstareq[11][1]*Vpk[4][11][1])))+((utk[6][2]*s9)-((utk[6][0]*Wpk[4][11][0])
      +(utk[6][1]*Wpk[4][11][1]))))+temp[1])));
    temp[3] = ((((fstareq[15][2]*Vpk[4][15][2])+((fstareq[15][0]*Vpk[4][15][0])+
      (fstareq[15][1]*Vpk[4][15][1])))-((utk[10][2]*Wpk[4][15][2])+((utk[10][0]*
      s13)+(utk[10][1]*Wpk[4][15][1]))))+((((fstareq[14][2]*Vpk[4][14][2])+((
      fstareq[14][0]*Vpk[4][14][0])+(fstareq[14][1]*Vpk[4][14][1])))+(((
      utk[9][0]*s12)-(utk[9][1]*Wpk[4][14][1]))-(utk[9][2]*Wpk[4][14][2])))+
      temp[2]));
    temp[4] = ((((fstareq[17][2]*Vpk[4][17][2])+((fstareq[17][0]*Vpk[4][17][0])+
      (fstareq[17][1]*Vpk[4][17][1])))-((utk[12][2]*Wpk[4][17][2])+((utk[12][0]*
      Wpk[4][17][0])+(utk[12][1]*Wpk[4][15][1]))))+((((fstareq[16][2]*
      Vpk[4][16][2])+((fstareq[16][0]*Vpk[4][16][0])+(fstareq[16][1]*
      Vpk[4][16][1])))-((utk[11][2]*Wpk[4][16][2])+((utk[11][0]*Wpk[4][16][0])+(
      utk[11][1]*Wpk[4][14][1]))))+temp[3]));
    temp[5] = ((((fstareq[19][2]*Vpk[4][19][2])+((fstareq[19][0]*Vpk[4][19][0])+
      (fstareq[19][1]*Vpk[4][19][1])))-((utk[14][2]*Wpk[4][19][2])+((utk[14][0]*
      Wpk[4][19][0])+(utk[14][1]*Wpk[4][15][1]))))+((((fstareq[18][2]*
      Vpk[4][18][2])+((fstareq[18][0]*Vpk[4][18][0])+(fstareq[18][1]*
      Vpk[4][18][1])))-((utk[13][2]*Wpk[4][18][2])+((utk[13][0]*Wpk[4][18][0])+(
      utk[13][1]*Wpk[4][14][1]))))+temp[4]));
    temp[6] = ((((fstareq[21][2]*Vpk[4][21][2])+((fstareq[21][0]*Vpk[4][21][0])+
      (fstareq[21][1]*Vpk[4][21][1])))-((utk[16][2]*Wpk[4][21][2])+((utk[16][0]*
      Wpk[4][21][0])+(utk[16][1]*Wpk[4][15][1]))))+((((fstareq[20][2]*
      Vpk[4][20][2])+((fstareq[20][0]*Vpk[4][20][0])+(fstareq[20][1]*
      Vpk[4][20][1])))-((utk[15][2]*Wpk[4][20][2])+((utk[15][0]*Wpk[4][20][0])+(
      utk[15][1]*Wpk[4][14][1]))))+temp[5]));
    temp[7] = ((((fstareq[23][2]*Vpk[4][23][2])+((fstareq[23][0]*Vpk[4][23][0])+
      (fstareq[23][1]*Vpk[4][23][1])))-((utk[18][2]*Wpk[4][23][2])+((utk[18][0]*
      Wpk[4][21][0])+(utk[18][1]*Wpk[4][23][1]))))+((((fstareq[22][2]*
      Vpk[4][22][2])+((fstareq[22][0]*Vpk[4][22][0])+(fstareq[22][1]*
      Vpk[4][22][1])))-((utk[17][2]*Wpk[4][22][2])+((utk[17][0]*Wpk[4][20][0])+(
      utk[17][1]*Wpk[4][22][1]))))+temp[6]));
    tau[4] = (utau[4]-((((fstareq[25][2]*Vpk[4][25][2])+((fstareq[25][0]*
      Vpk[4][25][0])+(fstareq[25][1]*Vpk[4][25][1])))-((utk[20][2]*Wpk[4][25][2]
      )+((utk[20][0]*Wpk[4][25][0])+(utk[20][1]*c24))))+((((fstareq[24][2]*
      Vpk[4][24][2])+((fstareq[24][0]*Vpk[4][24][0])+(fstareq[24][1]*
      Vpk[4][24][1])))-((utk[19][0]*s24)+(utk[19][1]*c24)))+temp[7])));
    temp[0] = ((((fstareq[7][2]*Vpk[5][7][2])+((fstareq[7][0]*Vpk[5][7][0])+(
      fstareq[7][1]*Vpk[5][7][1])))-((utk[2][0]*s7)+(utk[2][2]*c7)))+((((
      fstareq[5][0]*rk[0][1])-(fstareq[5][1]*rk[0][0]))-utk[0][2])+(((
      fstareq[6][2]*Vpk[5][6][2])+((fstareq[6][0]*Vpk[5][6][0])+(fstareq[6][1]*
      Vpk[5][6][1])))-((utk[1][0]*s6)+(utk[1][2]*c6)))));
    temp[1] = ((((fstareq[9][2]*Vpk[5][9][2])+((fstareq[9][0]*Vpk[5][9][0])+(
      fstareq[9][1]*Vpk[5][9][1])))-((utk[4][2]*Wpk[5][9][2])+((utk[4][0]*s7)+(
      utk[4][1]*Wpk[5][9][1]))))+((((fstareq[8][2]*Vpk[5][8][2])+((fstareq[8][0]
      *Vpk[5][8][0])+(fstareq[8][1]*Vpk[5][8][1])))-((utk[3][2]*Wpk[5][8][2])+((
      utk[3][0]*s6)+(utk[3][1]*Wpk[5][8][1]))))+temp[0]));
    temp[2] = ((((fstareq[11][2]*Vpk[5][11][2])+((fstareq[11][0]*Vpk[5][11][0])+
      (fstareq[11][1]*Vpk[5][11][1])))-((utk[6][2]*Wpk[5][9][2])+((utk[6][0]*
      Wpk[5][11][0])+(utk[6][1]*Wpk[5][11][1]))))+((((fstareq[10][2]*
      Vpk[5][10][2])+((fstareq[10][0]*Vpk[5][10][0])+(fstareq[10][1]*
      Vpk[5][10][1])))-((utk[5][2]*Wpk[5][8][2])+((utk[5][0]*Wpk[5][10][0])+(
      utk[5][1]*Wpk[5][10][1]))))+temp[1]));
    temp[3] = ((((fstareq[15][2]*Vpk[5][15][2])+((fstareq[15][0]*Vpk[5][15][0])+
      (fstareq[15][1]*Vpk[5][15][1])))-((utk[10][1]*s15)+(utk[10][2]*c15)))+((((
      fstareq[14][2]*Vpk[5][14][2])+((fstareq[14][0]*Vpk[5][14][0])+(
      fstareq[14][1]*Vpk[5][14][1])))+((utk[9][1]*s14)-(utk[9][2]*c14)))+((((
      fstareq[13][0]*Vpk[5][13][0])+(fstareq[13][1]*Vpk[5][13][1]))-utk[8][2])+(
      (((fstareq[12][0]*Vpk[5][12][0])+(fstareq[12][1]*Vpk[5][12][1]))-utk[7][2]
      )+temp[2]))));
    temp[4] = ((((fstareq[17][2]*Vpk[5][17][2])+((fstareq[17][0]*Vpk[5][17][0])+
      (fstareq[17][1]*Vpk[5][17][1])))-((utk[12][2]*Wpk[5][17][2])+((utk[12][0]*
      Wpk[5][17][0])+(utk[12][1]*s15))))+((((fstareq[16][2]*Vpk[5][16][2])+((
      fstareq[16][0]*Vpk[5][16][0])+(fstareq[16][1]*Vpk[5][16][1])))+(((
      utk[11][1]*s14)-(utk[11][0]*Wpk[5][16][0]))-(utk[11][2]*Wpk[5][16][2])))+
      temp[3]));
    temp[5] = ((((fstareq[19][2]*Vpk[5][19][2])+((fstareq[19][0]*Vpk[5][19][0])+
      (fstareq[19][1]*Vpk[5][19][1])))-((utk[14][2]*Wpk[5][19][2])+((utk[14][0]*
      Wpk[5][19][0])+(utk[14][1]*s15))))+((((fstareq[18][2]*Vpk[5][18][2])+((
      fstareq[18][0]*Vpk[5][18][0])+(fstareq[18][1]*Vpk[5][18][1])))+(((
      utk[13][1]*s14)-(utk[13][0]*Wpk[5][18][0]))-(utk[13][2]*Wpk[5][18][2])))+
      temp[4]));
    temp[6] = ((((fstareq[21][2]*Vpk[5][21][2])+((fstareq[21][0]*Vpk[5][21][0])+
      (fstareq[21][1]*Vpk[5][21][1])))-((utk[16][2]*Wpk[5][21][2])+((utk[16][0]*
      Wpk[5][21][0])+(utk[16][1]*s15))))+((((fstareq[20][2]*Vpk[5][20][2])+((
      fstareq[20][0]*Vpk[5][20][0])+(fstareq[20][1]*Vpk[5][20][1])))+(((
      utk[15][1]*s14)-(utk[15][0]*Wpk[5][20][0]))-(utk[15][2]*Wpk[5][20][2])))+
      temp[5]));
    temp[7] = ((((fstareq[23][2]*Vpk[5][23][2])+((fstareq[23][0]*Vpk[5][23][0])+
      (fstareq[23][1]*Vpk[5][23][1])))-((utk[18][2]*Wpk[5][23][2])+((utk[18][0]*
      Wpk[5][21][0])+(utk[18][1]*Wpk[5][23][1]))))+((((fstareq[22][2]*
      Vpk[5][22][2])+((fstareq[22][0]*Vpk[5][22][0])+(fstareq[22][1]*
      Vpk[5][22][1])))-((utk[17][2]*Wpk[5][22][2])+((utk[17][0]*Wpk[5][20][0])+(
      utk[17][1]*Wpk[5][22][1]))))+temp[6]));
    tau[5] = (utau[5]-((((fstareq[25][2]*Vpk[5][25][2])+((fstareq[25][0]*
      Vpk[5][25][0])+(fstareq[25][1]*Vpk[5][25][1])))-((utk[20][0]*s25)+(
      utk[20][2]*c25)))+((((fstareq[24][0]*Vpk[5][24][0])+(fstareq[24][1]*
      Vpk[5][24][1]))-utk[19][2])+temp[7])));
    tau[6] = (utau[6]-(((utk[1][1]+((fstareq[6][0]*rk[1][2])-(fstareq[6][2]*
      rk[1][0])))+(((fstareq[8][2]*Vpk[6][8][2])+((fstareq[8][0]*Vpk[6][8][0])+(
      fstareq[8][1]*Vpk[6][8][1])))+((utk[3][1]*c8)+(utk[3][2]*s8))))+(((
      fstareq[10][2]*Vpk[6][10][2])+((fstareq[10][0]*Vpk[6][10][0])+(
      fstareq[10][1]*Vpk[6][10][1])))+((utk[5][2]*s8)-((utk[5][0]*Wpk[6][10][0])
      +(utk[5][1]*Wpk[6][10][1]))))));
    tau[7] = (utau[7]-(((utk[2][1]+((fstareq[7][0]*rk[2][2])-(fstareq[7][2]*
      rk[2][0])))+(((fstareq[9][2]*Vpk[7][9][2])+((fstareq[9][0]*Vpk[7][9][0])+(
      fstareq[9][1]*Vpk[7][9][1])))+((utk[4][1]*c9)-(utk[4][2]*s9))))+(((
      fstareq[11][2]*Vpk[7][11][2])+((fstareq[11][0]*Vpk[7][11][0])+(
      fstareq[11][1]*Vpk[7][11][1])))-((utk[6][2]*s9)+((utk[6][0]*Wpk[7][11][0])
      +(utk[6][1]*Wpk[7][11][1]))))));
    tau[8] = (utau[8]-((utk[3][0]+((fstareq[8][2]*rk[3][1])-(fstareq[8][1]*
      rk[3][2])))+(((fstareq[10][2]*Vpk[8][10][2])+((fstareq[10][0]*
      Vpk[8][10][0])+(fstareq[10][1]*Vpk[8][10][1])))+((utk[5][0]*c10)+(
      utk[5][1]*s10)))));
    tau[9] = (utau[9]-((((fstareq[9][1]*rk[4][2])-(fstareq[9][2]*rk[4][1]))-
      utk[4][0])+(((fstareq[11][2]*Vpk[9][11][2])+((fstareq[11][0]*Vpk[9][11][0]
      )+(fstareq[11][1]*Vpk[9][11][1])))+((utk[6][1]*s11)-(utk[6][0]*c11)))));
    tau[10] = (utau[10]-(utk[5][2]+((fstareq[10][1]*rk[5][0])-(fstareq[10][0]*
      rk[5][1]))));
    tau[11] = (utau[11]-(((fstareq[11][0]*rk[6][1])-(fstareq[11][1]*rk[6][0]))-
      utk[6][2]));
    temp[0] = (((utk[7][2]+((fstareq[12][1]*rk[7][0])-(fstareq[12][0]*rk[7][1]))
      )+(((fstareq[14][2]*Vpk[12][14][2])+((fstareq[14][0]*Vpk[12][14][0])+(
      fstareq[14][1]*Vpk[12][14][1])))+((utk[9][2]*c14)-(utk[9][1]*s14))))+(((
      fstareq[16][2]*Vpk[12][16][2])+((fstareq[16][0]*Vpk[12][16][0])+(
      fstareq[16][1]*Vpk[12][16][1])))-((utk[11][2]*Wpk[12][16][2])+((utk[11][0]
      *Wpk[12][16][0])+(utk[11][1]*s14)))));
    temp[1] = ((((fstareq[20][2]*Vpk[12][20][2])+((fstareq[20][0]*Vpk[12][20][0]
      )+(fstareq[20][1]*Vpk[12][20][1])))-((utk[15][2]*Wpk[12][20][2])+((
      utk[15][0]*Wpk[12][20][0])+(utk[15][1]*s14))))+((((fstareq[18][2]*
      Vpk[12][18][2])+((fstareq[18][0]*Vpk[12][18][0])+(fstareq[18][1]*
      Vpk[12][18][1])))-((utk[13][2]*Wpk[12][18][2])+((utk[13][0]*Wpk[12][18][0]
      )+(utk[13][1]*s14))))+temp[0]));
    tau[12] = (utau[12]-((((fstareq[22][2]*Vpk[12][22][2])+((fstareq[22][0]*
      Vpk[12][22][0])+(fstareq[22][1]*Vpk[12][22][1])))-((utk[17][2]*
      Wpk[12][22][2])+((utk[17][0]*Wpk[12][20][0])+(utk[17][1]*Wpk[12][22][1])))
      )+temp[1]));
    temp[0] = ((((fstareq[17][2]*Vpk[13][17][2])+((fstareq[17][0]*Vpk[13][17][0]
      )+(fstareq[17][1]*Vpk[13][17][1])))-((utk[12][2]*Wpk[13][17][2])+((
      utk[12][0]*Wpk[13][17][0])+(utk[12][1]*s15))))+((((fstareq[13][0]*rk[8][1]
      )-(fstareq[13][1]*rk[8][0]))-utk[8][2])+(((fstareq[15][2]*Vpk[13][15][2])+
      ((fstareq[15][0]*Vpk[13][15][0])+(fstareq[15][1]*Vpk[13][15][1])))-((
      utk[10][1]*s15)+(utk[10][2]*c15)))));
    temp[1] = ((((fstareq[21][2]*Vpk[13][21][2])+((fstareq[21][0]*Vpk[13][21][0]
      )+(fstareq[21][1]*Vpk[13][21][1])))-((utk[16][2]*Wpk[13][21][2])+((
      utk[16][0]*Wpk[13][21][0])+(utk[16][1]*s15))))+((((fstareq[19][2]*
      Vpk[13][19][2])+((fstareq[19][0]*Vpk[13][19][0])+(fstareq[19][1]*
      Vpk[13][19][1])))-((utk[14][2]*Wpk[13][19][2])+((utk[14][0]*Wpk[13][19][0]
      )+(utk[14][1]*s15))))+temp[0]));
    tau[13] = (utau[13]-((((fstareq[23][2]*Vpk[13][23][2])+((fstareq[23][0]*
      Vpk[13][23][0])+(fstareq[23][1]*Vpk[13][23][1])))-((utk[18][2]*
      Wpk[13][23][2])+((utk[18][0]*Wpk[13][21][0])+(utk[18][1]*Wpk[13][23][1])))
      )+temp[1]));
    temp[0] = (((utk[9][0]+((fstareq[14][2]*rk[9][1])-(fstareq[14][1]*rk[9][2]))
      )+(((fstareq[16][2]*Vpk[14][16][2])+((fstareq[16][0]*Vpk[14][16][0])+(
      fstareq[16][1]*Vpk[14][16][1])))+((utk[11][0]*c16)-(utk[11][2]*s16))))+(((
      fstareq[18][2]*Vpk[14][18][2])+((fstareq[18][0]*Vpk[14][18][0])+(
      fstareq[18][1]*Vpk[14][18][1])))-((utk[13][0]*Wpk[14][18][0])+(utk[13][2]*
      Wpk[14][18][2]))));
    tau[14] = (utau[14]-((((fstareq[22][2]*Vpk[14][22][2])+((fstareq[22][0]*
      Vpk[14][22][0])+(fstareq[22][1]*Vpk[14][22][1])))-((utk[17][2]*
      Wpk[14][22][2])+((utk[17][0]*Wpk[14][20][0])+(utk[17][1]*Wpk[14][22][1])))
      )+((((fstareq[20][2]*Vpk[14][20][2])+((fstareq[20][0]*Vpk[14][20][0])+(
      fstareq[20][1]*Vpk[14][20][1])))-((utk[15][0]*Wpk[14][20][0])+(utk[15][2]*
      Wpk[14][20][2])))+temp[0])));
    temp[0] = ((((fstareq[19][2]*Vpk[15][19][2])+((fstareq[19][0]*Vpk[15][19][0]
      )+(fstareq[19][1]*Vpk[15][19][1])))-((utk[14][0]*Wpk[15][19][0])+(
      utk[14][2]*Wpk[15][19][2])))+((((fstareq[15][1]*rk[10][2])-(fstareq[15][2]
      *rk[10][1]))-utk[10][0])+(((fstareq[17][2]*Vpk[15][17][2])+((
      fstareq[17][0]*Vpk[15][17][0])+(fstareq[17][1]*Vpk[15][17][1])))+((
      utk[12][2]*s17)-(utk[12][0]*c17)))));
    tau[15] = (utau[15]-((((fstareq[23][2]*Vpk[15][23][2])+((fstareq[23][0]*
      Vpk[15][23][0])+(fstareq[23][1]*Vpk[15][23][1])))-((utk[18][2]*
      Wpk[15][23][2])+((utk[18][0]*Wpk[15][21][0])+(utk[18][1]*Wpk[15][23][1])))
      )+((((fstareq[21][2]*Vpk[15][21][2])+((fstareq[21][0]*Vpk[15][21][0])+(
      fstareq[21][1]*Vpk[15][21][1])))-((utk[16][0]*Wpk[15][21][0])+(utk[16][2]*
      Wpk[15][21][2])))+temp[0])));
    tau[16] = (utau[16]-(((utk[15][1]+((fstareq[20][0]*Vpk[16][20][0])+(
      fstareq[20][2]*Vpk[16][20][2])))+((utk[11][1]+((fstareq[16][0]*rk[11][2])-
      (fstareq[16][2]*rk[11][0])))+(utk[13][1]+((fstareq[18][0]*Vpk[16][18][0])+
      (fstareq[18][2]*Vpk[16][18][2])))))+(((fstareq[22][2]*Vpk[16][22][2])+((
      fstareq[22][0]*Vpk[16][22][0])+(fstareq[22][1]*Vpk[16][22][1])))+((
      utk[17][1]*c22)+(utk[17][2]*s22)))));
    tau[17] = (utau[17]-(((utk[16][1]+((fstareq[21][0]*Vpk[17][21][0])+(
      fstareq[21][2]*Vpk[17][21][2])))+((utk[12][1]+((fstareq[17][0]*rk[12][2])-
      (fstareq[17][2]*rk[12][0])))+(utk[14][1]+((fstareq[19][0]*Vpk[17][19][0])+
      (fstareq[19][2]*Vpk[17][19][2])))))+(((fstareq[23][2]*Vpk[17][23][2])+((
      fstareq[23][0]*Vpk[17][23][0])+(fstareq[23][1]*Vpk[17][23][1])))+((
      utk[18][1]*c23)-(utk[18][2]*s23)))));
    tau[18] = (utau[18]-(((utk[13][1]+((fstareq[18][0]*rk[13][2])-(
      fstareq[18][2]*rk[13][0])))+(utk[15][1]+((fstareq[20][0]*Vpk[18][20][0])+(
      fstareq[20][2]*Vpk[18][20][2]))))+(((fstareq[22][2]*Vpk[18][22][2])+((
      fstareq[22][0]*Vpk[18][22][0])+(fstareq[22][1]*Vpk[18][22][1])))+((
      utk[17][1]*c22)+(utk[17][2]*s22)))));
    tau[19] = (utau[19]-(((utk[14][1]+((fstareq[19][0]*rk[14][2])-(
      fstareq[19][2]*rk[14][0])))+(utk[16][1]+((fstareq[21][0]*Vpk[19][21][0])+(
      fstareq[21][2]*Vpk[19][21][2]))))+(((fstareq[23][2]*Vpk[19][23][2])+((
      fstareq[23][0]*Vpk[19][23][0])+(fstareq[23][1]*Vpk[19][23][1])))+((
      utk[18][1]*c23)-(utk[18][2]*s23)))));
    tau[20] = (utau[20]-((utk[15][1]+((fstareq[20][0]*rk[15][2])-(fstareq[20][2]
      *rk[15][0])))+(((fstareq[22][2]*Vpk[20][22][2])+((fstareq[22][0]*
      Vpk[20][22][0])+(fstareq[22][1]*Vpk[20][22][1])))+((utk[17][1]*c22)+(
      utk[17][2]*s22)))));
    tau[21] = (utau[21]-((utk[16][1]+((fstareq[21][0]*rk[16][2])-(fstareq[21][2]
      *rk[16][0])))+(((fstareq[23][2]*Vpk[21][23][2])+((fstareq[23][0]*
      Vpk[21][23][0])+(fstareq[23][1]*Vpk[21][23][1])))+((utk[18][1]*c23)-(
      utk[18][2]*s23)))));
    tau[22] = (utau[22]-(utk[17][0]+((fstareq[22][2]*rk[17][1])-(fstareq[22][1]*
      rk[17][2]))));
    tau[23] = (utau[23]-(((fstareq[23][1]*rk[18][2])-(fstareq[23][2]*rk[18][1]))
      -utk[18][0]));
    tau[24] = (utau[24]-((((fstareq[24][0]*rk[19][1])-(fstareq[24][1]*rk[19][0])
      )-utk[19][2])+(((fstareq[25][2]*Vpk[24][25][2])+((fstareq[25][0]*
      Vpk[24][25][0])+(fstareq[25][1]*Vpk[24][25][1])))-((utk[20][0]*s25)+(
      utk[20][2]*c25)))));
    tau[25] = (utau[25]-(utk[20][1]+((fstareq[25][0]*rk[20][2])-(fstareq[25][2]*
      rk[20][0]))));
/*
Op counts below do not include called subroutines
*/
/*
 Used 0.01 seconds CPU time,
 0 additional bytes of memory.
 Equations contain  899 adds/subtracts/negates
                    802 multiplies
                      0 divides
                    135 assignments
*/
}

void sdfs0(void)
{

/*
Compute Fs (ignoring multiplier forces)
*/
    fs[0] = fs0[0];
    fs[1] = fs0[1];
    fs[2] = fs0[2];
    fs[3] = fs0[3];
    fs[4] = fs0[4];
    fs[5] = fs0[5];
    fs[6] = fs0[6];
    fs[7] = fs0[7];
    fs[8] = fs0[8];
    fs[9] = fs0[9];
    fs[10] = fs0[10];
    fs[11] = fs0[11];
    fs[12] = fs0[12];
    fs[13] = fs0[13];
    fs[14] = fs0[14];
    fs[15] = fs0[15];
    fs[16] = fs0[16];
    fs[17] = fs0[17];
    fs[18] = fs0[18];
    fs[19] = fs0[19];
    fs[20] = fs0[20];
    fs[21] = fs0[21];
    fs[22] = fs0[22];
    fs[23] = fs0[23];
    fs[24] = fs0[24];
    fs[25] = fs0[25];
/*
 Used -0.00 seconds CPU time,
 0 additional bytes of memory.
 Equations contain    0 adds/subtracts/negates
                      0 multiplies
                      0 divides
                     26 assignments
*/
}

void sdfsmult(void)
{
    int i;

/*
Compute Fs (multiplier-generated forces only)
*/
    for (i = 0; i < 26; i++) {
        fs[i] = 0.;
    }
/*
 Used -0.00 seconds CPU time,
 0 additional bytes of memory.
 Equations contain    0 adds/subtracts/negates
                      0 multiplies
                      0 divides
                     26 assignments
*/
}

void sdfsfull(void)
{

/*
Compute Fs (including all forces)
*/
    sdfsmult();
    fs[0] = (fs[0]+fs0[0]);
    fs[1] = (fs[1]+fs0[1]);
    fs[2] = (fs[2]+fs0[2]);
    fs[3] = (fs[3]+fs0[3]);
    fs[4] = (fs[4]+fs0[4]);
    fs[5] = (fs[5]+fs0[5]);
    fs[6] = (fs[6]+fs0[6]);
    fs[7] = (fs[7]+fs0[7]);
    fs[8] = (fs[8]+fs0[8]);
    fs[9] = (fs[9]+fs0[9]);
    fs[10] = (fs[10]+fs0[10]);
    fs[11] = (fs[11]+fs0[11]);
    fs[12] = (fs[12]+fs0[12]);
    fs[13] = (fs[13]+fs0[13]);
    fs[14] = (fs[14]+fs0[14]);
    fs[15] = (fs[15]+fs0[15]);
    fs[16] = (fs[16]+fs0[16]);
    fs[17] = (fs[17]+fs0[17]);
    fs[18] = (fs[18]+fs0[18]);
    fs[19] = (fs[19]+fs0[19]);
    fs[20] = (fs[20]+fs0[20]);
    fs[21] = (fs[21]+fs0[21]);
    fs[22] = (fs[22]+fs0[22]);
    fs[23] = (fs[23]+fs0[23]);
    fs[24] = (fs[24]+fs0[24]);
    fs[25] = (fs[25]+fs0[25]);
/*
 Used -0.00 seconds CPU time,
 0 additional bytes of memory.
 Equations contain   26 adds/subtracts/negates
                      0 multiplies
                      0 divides
                     26 assignments
*/
}

void sdfsgenmult(void)
{
    int i;

/*
Compute Fs (generic multiplier-generated forces)
*/
    for (i = 0; i < 26; i++) {
        fs[i] = 0.;
    }
/*
 Used -0.00 seconds CPU time,
 0 additional bytes of memory.
 Equations contain    0 adds/subtracts/negates
                      0 multiplies
                      0 divides
                     26 assignments
*/
}

void sdfsgenfull(void)
{

/*
Compute Fs (incl generic mult & other forces)
*/
    sdfsgenmult();
    fs[0] = (fs[0]+fs0[0]);
    fs[1] = (fs[1]+fs0[1]);
    fs[2] = (fs[2]+fs0[2]);
    fs[3] = (fs[3]+fs0[3]);
    fs[4] = (fs[4]+fs0[4]);
    fs[5] = (fs[5]+fs0[5]);
    fs[6] = (fs[6]+fs0[6]);
    fs[7] = (fs[7]+fs0[7]);
    fs[8] = (fs[8]+fs0[8]);
    fs[9] = (fs[9]+fs0[9]);
    fs[10] = (fs[10]+fs0[10]);
    fs[11] = (fs[11]+fs0[11]);
    fs[12] = (fs[12]+fs0[12]);
    fs[13] = (fs[13]+fs0[13]);
    fs[14] = (fs[14]+fs0[14]);
    fs[15] = (fs[15]+fs0[15]);
    fs[16] = (fs[16]+fs0[16]);
    fs[17] = (fs[17]+fs0[17]);
    fs[18] = (fs[18]+fs0[18]);
    fs[19] = (fs[19]+fs0[19]);
    fs[20] = (fs[20]+fs0[20]);
    fs[21] = (fs[21]+fs0[21]);
    fs[22] = (fs[22]+fs0[22]);
    fs[23] = (fs[23]+fs0[23]);
    fs[24] = (fs[24]+fs0[24]);
    fs[25] = (fs[25]+fs0[25]);
/*
 Used -0.00 seconds CPU time,
 0 additional bytes of memory.
 Equations contain   26 adds/subtracts/negates
                      0 multiplies
                      0 divides
                     26 assignments
*/
}

void sdfulltrq(double udotin[26],
    double multin[1],
    double trqout[26])
{
/* Compute hinge torques which would produce indicated udots
*/
    double fstarr[26][3],tstarr[26][3],Otkr[26][3],Atir[26][3],Atkr[26][3];

    if ((roustate != 2) && (roustate != 3)) {
        sdseterr(61,23);
        return;
    }
/*
Account for inertial accelerations and supplied udots
*/
    Otkr[6][0] = ((u[6]*wk[6][2])+((udotin[3]*c6)+(udotin[5]*s6)));
    Otkr[6][1] = (udotin[4]-udotin[6]);
    Otkr[6][2] = (((udotin[5]*c6)-(udotin[3]*s6))-(u[6]*wk[6][0]));
    Otkr[7][0] = ((u[7]*wk[7][2])+((udotin[3]*c7)+(udotin[5]*s7)));
    Otkr[7][1] = (udotin[4]-udotin[7]);
    Otkr[7][2] = (((udotin[5]*c7)-(udotin[3]*s7))-(u[7]*wk[7][0]));
    Otkr[8][0] = (Otkr[6][0]-udotin[8]);
    Otkr[8][1] = (((Otkr[6][1]*c8)-(Otkr[6][2]*s8))-(u[8]*wk[8][2]));
    Otkr[8][2] = ((u[8]*wk[8][1])+((Otkr[6][1]*s8)+(Otkr[6][2]*c8)));
    Otkr[9][0] = (Otkr[7][0]+udotin[9]);
    Otkr[9][1] = ((u[9]*wk[9][2])+((Otkr[7][1]*c9)+(Otkr[7][2]*s9)));
    Otkr[9][2] = (((Otkr[7][2]*c9)-(Otkr[7][1]*s9))-(u[9]*wk[9][1]));
    Otkr[10][0] = (((Otkr[8][0]*c10)-(Otkr[8][1]*s10))-(u[10]*wk[10][1]));
    Otkr[10][1] = ((u[10]*wk[10][0])+((Otkr[8][0]*s10)+(Otkr[8][1]*c10)));
    Otkr[10][2] = (Otkr[8][2]-udotin[10]);
    Otkr[11][0] = ((u[11]*wk[11][1])+((Otkr[9][0]*c11)+(Otkr[9][1]*s11)));
    Otkr[11][1] = (((Otkr[9][1]*c11)-(Otkr[9][0]*s11))-(u[11]*wk[11][0]));
    Otkr[11][2] = (Otkr[9][2]+udotin[11]);
    Otkr[12][0] = (((udotin[3]*c12)-(udotin[4]*s12))-(u[12]*wk[12][1]));
    Otkr[12][1] = ((u[12]*wk[12][0])+((udotin[3]*s12)+(udotin[4]*c12)));
    Otkr[12][2] = (udotin[5]-udotin[12]);
    Otkr[13][0] = ((u[13]*wk[13][1])+((udotin[3]*c13)+(udotin[4]*s13)));
    Otkr[13][1] = (((udotin[4]*c13)-(udotin[3]*s13))-(u[13]*wk[13][0]));
    Otkr[13][2] = (udotin[5]+udotin[13]);
    Otkr[14][0] = (Otkr[12][0]-udotin[14]);
    Otkr[14][1] = (((Otkr[12][1]*c14)-(Otkr[12][2]*s14))-(u[14]*wk[14][2]));
    Otkr[14][2] = ((u[14]*wk[14][1])+((Otkr[12][1]*s14)+(Otkr[12][2]*c14)));
    Otkr[15][0] = (Otkr[13][0]+udotin[15]);
    Otkr[15][1] = ((u[15]*wk[15][2])+((Otkr[13][1]*c15)+(Otkr[13][2]*s15)));
    Otkr[15][2] = (((Otkr[13][2]*c15)-(Otkr[13][1]*s15))-(u[15]*wk[15][1]));
    Otkr[16][0] = ((u[16]*wk[16][2])+((Otkr[14][0]*c16)+(Otkr[14][2]*s16)));
    Otkr[16][1] = (Otkr[14][1]-udotin[16]);
    Otkr[16][2] = (((Otkr[14][2]*c16)-(Otkr[14][0]*s16))-(u[16]*wk[16][0]));
    Otkr[17][0] = ((u[17]*wk[17][2])+((Otkr[15][0]*c17)+(Otkr[15][2]*s17)));
    Otkr[17][1] = (Otkr[15][1]-udotin[17]);
    Otkr[17][2] = (((Otkr[15][2]*c17)-(Otkr[15][0]*s17))-(u[17]*wk[17][0]));
    Otkr[18][0] = ((u[18]*wk[18][2])+((Otkr[16][0]*c18)+(Otkr[16][2]*s18)));
    Otkr[18][1] = (Otkr[16][1]-udotin[18]);
    Otkr[18][2] = (((Otkr[16][2]*c18)-(Otkr[16][0]*s18))-(u[18]*wk[18][0]));
    Otkr[19][0] = ((u[19]*wk[19][2])+((Otkr[17][0]*c19)+(Otkr[17][2]*s19)));
    Otkr[19][1] = (Otkr[17][1]-udotin[19]);
    Otkr[19][2] = (((Otkr[17][2]*c19)-(Otkr[17][0]*s19))-(u[19]*wk[19][0]));
    Otkr[20][0] = ((u[20]*wk[20][2])+((Otkr[18][0]*c20)+(Otkr[18][2]*s20)));
    Otkr[20][1] = (Otkr[18][1]-udotin[20]);
    Otkr[20][2] = (((Otkr[18][2]*c20)-(Otkr[18][0]*s20))-(u[20]*wk[20][0]));
    Otkr[21][0] = ((u[21]*wk[21][2])+((Otkr[19][0]*c21)+(Otkr[19][2]*s21)));
    Otkr[21][1] = (Otkr[19][1]-udotin[21]);
    Otkr[21][2] = (((Otkr[19][2]*c21)-(Otkr[19][0]*s21))-(u[21]*wk[21][0]));
    Otkr[22][0] = (Otkr[20][0]-udotin[22]);
    Otkr[22][1] = (((Otkr[20][1]*c22)-(Otkr[20][2]*s22))-(u[22]*wk[22][2]));
    Otkr[22][2] = ((u[22]*wk[22][1])+((Otkr[20][1]*s22)+(Otkr[20][2]*c22)));
    Otkr[23][0] = (Otkr[21][0]+udotin[23]);
    Otkr[23][1] = ((u[23]*wk[23][2])+((Otkr[21][1]*c23)+(Otkr[21][2]*s23)));
    Otkr[23][2] = (((Otkr[21][2]*c23)-(Otkr[21][1]*s23))-(u[23]*wk[23][1]));
    Otkr[24][0] = ((u[24]*wk[24][1])+((udotin[3]*c24)+(udotin[4]*s24)));
    Otkr[24][1] = (((udotin[4]*c24)-(udotin[3]*s24))-(u[24]*wk[24][0]));
    Otkr[24][2] = (udotin[5]+udotin[24]);
    Otkr[25][0] = ((u[25]*wk[25][2])+((Otkr[24][0]*c25)+(Otkr[24][2]*s25)));
    Otkr[25][1] = (Otkr[24][1]-udotin[25]);
    Otkr[25][2] = (((Otkr[24][2]*c25)-(Otkr[24][0]*s25))-(u[25]*wk[25][0]));
    Atkr[3][0] = ((Cik[3][2][0]*udotin[2])+((Cik[3][0][0]*udotin[0])+(
      Cik[3][1][0]*udotin[1])));
    Atkr[3][1] = ((Cik[3][2][1]*udotin[2])+((Cik[3][0][1]*udotin[0])+(
      Cik[3][1][1]*udotin[1])));
    Atkr[3][2] = ((Cik[3][2][2]*udotin[2])+((Cik[3][0][2]*udotin[0])+(
      Cik[3][1][2]*udotin[1])));
    Atkr[5][0] = (Atkr[3][0]+(((rk[0][1]*udotin[5])-(rk[0][2]*udotin[4]))+((u[4]
      *Wkrpk[5][2])-(u[5]*Wkrpk[5][1]))));
    Atkr[5][1] = (Atkr[3][1]+(((rk[0][2]*udotin[3])-(rk[0][0]*udotin[5]))+((u[5]
      *Wkrpk[5][0])-(u[3]*Wkrpk[5][2]))));
    Atkr[5][2] = (Atkr[3][2]+(((rk[0][0]*udotin[4])-(rk[0][1]*udotin[3]))+((u[3]
      *Wkrpk[5][1])-(u[4]*Wkrpk[5][0]))));
    Atir[6][0] = (Atkr[5][0]+(((ri[1][2]*udotin[4])-(ri[1][1]*udotin[5]))+((u[4]
      *Wirk[6][2])-(u[5]*Wirk[6][1]))));
    Atir[6][1] = (Atkr[5][1]+(((ri[1][0]*udotin[5])-(ri[1][2]*udotin[3]))+((u[5]
      *Wirk[6][0])-(u[3]*Wirk[6][2]))));
    Atir[6][2] = (Atkr[5][2]+(((ri[1][1]*udotin[3])-(ri[1][0]*udotin[4]))+((u[3]
      *Wirk[6][1])-(u[4]*Wirk[6][0]))));
    Atkr[6][0] = (((Atir[6][0]*c6)+(Atir[6][2]*s6))+(((Otkr[6][2]*rk[1][1])-(
      Otkr[6][1]*rk[1][2]))+((wk[6][1]*Wkrpk[6][2])-(wk[6][2]*Wkrpk[6][1]))));
    Atkr[6][1] = (Atir[6][1]+(((Otkr[6][0]*rk[1][2])-(Otkr[6][2]*rk[1][0]))+((
      wk[6][2]*Wkrpk[6][0])-(wk[6][0]*Wkrpk[6][2]))));
    Atkr[6][2] = (((Atir[6][2]*c6)-(Atir[6][0]*s6))+(((Otkr[6][1]*rk[1][0])-(
      Otkr[6][0]*rk[1][1]))+((wk[6][0]*Wkrpk[6][1])-(wk[6][1]*Wkrpk[6][0]))));
    Atir[7][0] = (Atkr[5][0]+(((ri[2][2]*udotin[4])-(ri[2][1]*udotin[5]))+((u[4]
      *Wirk[7][2])-(u[5]*Wirk[7][1]))));
    Atir[7][1] = (Atkr[5][1]+(((ri[2][0]*udotin[5])-(ri[2][2]*udotin[3]))+((u[5]
      *Wirk[7][0])-(u[3]*Wirk[7][2]))));
    Atir[7][2] = (Atkr[5][2]+(((ri[2][1]*udotin[3])-(ri[2][0]*udotin[4]))+((u[3]
      *Wirk[7][1])-(u[4]*Wirk[7][0]))));
    Atkr[7][0] = (((Atir[7][0]*c7)+(Atir[7][2]*s7))+(((Otkr[7][2]*rk[2][1])-(
      Otkr[7][1]*rk[2][2]))+((wk[7][1]*Wkrpk[7][2])-(wk[7][2]*Wkrpk[7][1]))));
    Atkr[7][1] = (Atir[7][1]+(((Otkr[7][0]*rk[2][2])-(Otkr[7][2]*rk[2][0]))+((
      wk[7][2]*Wkrpk[7][0])-(wk[7][0]*Wkrpk[7][2]))));
    Atkr[7][2] = (((Atir[7][2]*c7)-(Atir[7][0]*s7))+(((Otkr[7][1]*rk[2][0])-(
      Otkr[7][0]*rk[2][1]))+((wk[7][0]*Wkrpk[7][1])-(wk[7][1]*Wkrpk[7][0]))));
    Atir[8][0] = (Atkr[6][0]+(((Otkr[6][1]*ri[3][2])-(Otkr[6][2]*ri[3][1]))+((
      Wirk[8][2]*wk[6][1])-(Wirk[8][1]*wk[6][2]))));
    Atir[8][1] = (Atkr[6][1]+(((Otkr[6][2]*ri[3][0])-(Otkr[6][0]*ri[3][2]))+((
      Wirk[8][0]*wk[6][2])-(Wirk[8][2]*wk[6][0]))));
    Atir[8][2] = (Atkr[6][2]+(((Otkr[6][0]*ri[3][1])-(Otkr[6][1]*ri[3][0]))+((
      Wirk[8][1]*wk[6][0])-(Wirk[8][0]*wk[6][1]))));
    Atkr[8][0] = (Atir[8][0]+(((Otkr[8][2]*rk[3][1])-(Otkr[8][1]*rk[3][2]))+((
      wk[8][1]*Wkrpk[8][2])-(wk[8][2]*Wkrpk[8][1]))));
    Atkr[8][1] = (((Atir[8][1]*c8)-(Atir[8][2]*s8))+(((Otkr[8][0]*rk[3][2])-(
      Otkr[8][2]*rk[3][0]))+((wk[8][2]*Wkrpk[8][0])-(wk[8][0]*Wkrpk[8][2]))));
    Atkr[8][2] = (((Atir[8][1]*s8)+(Atir[8][2]*c8))+(((Otkr[8][1]*rk[3][0])-(
      Otkr[8][0]*rk[3][1]))+((wk[8][0]*Wkrpk[8][1])-(wk[8][1]*Wkrpk[8][0]))));
    Atir[9][0] = (Atkr[7][0]+(((Otkr[7][1]*ri[4][2])-(Otkr[7][2]*ri[4][1]))+((
      Wirk[9][2]*wk[7][1])-(Wirk[9][1]*wk[7][2]))));
    Atir[9][1] = (Atkr[7][1]+(((Otkr[7][2]*ri[4][0])-(Otkr[7][0]*ri[4][2]))+((
      Wirk[9][0]*wk[7][2])-(Wirk[9][2]*wk[7][0]))));
    Atir[9][2] = (Atkr[7][2]+(((Otkr[7][0]*ri[4][1])-(Otkr[7][1]*ri[4][0]))+((
      Wirk[9][1]*wk[7][0])-(Wirk[9][0]*wk[7][1]))));
    Atkr[9][0] = (Atir[9][0]+(((Otkr[9][2]*rk[4][1])-(Otkr[9][1]*rk[4][2]))+((
      wk[9][1]*Wkrpk[9][2])-(wk[9][2]*Wkrpk[9][1]))));
    Atkr[9][1] = (((Atir[9][1]*c9)+(Atir[9][2]*s9))+(((Otkr[9][0]*rk[4][2])-(
      Otkr[9][2]*rk[4][0]))+((wk[9][2]*Wkrpk[9][0])-(wk[9][0]*Wkrpk[9][2]))));
    Atkr[9][2] = (((Atir[9][2]*c9)-(Atir[9][1]*s9))+(((Otkr[9][1]*rk[4][0])-(
      Otkr[9][0]*rk[4][1]))+((wk[9][0]*Wkrpk[9][1])-(wk[9][1]*Wkrpk[9][0]))));
    Atir[10][0] = (Atkr[8][0]+(((Otkr[8][1]*ri[5][2])-(Otkr[8][2]*ri[5][1]))+((
      Wirk[10][2]*wk[8][1])-(Wirk[10][1]*wk[8][2]))));
    Atir[10][1] = (Atkr[8][1]+(((Otkr[8][2]*ri[5][0])-(Otkr[8][0]*ri[5][2]))+((
      Wirk[10][0]*wk[8][2])-(Wirk[10][2]*wk[8][0]))));
    Atir[10][2] = (Atkr[8][2]+(((Otkr[8][0]*ri[5][1])-(Otkr[8][1]*ri[5][0]))+((
      Wirk[10][1]*wk[8][0])-(Wirk[10][0]*wk[8][1]))));
    Atkr[10][0] = (((Atir[10][0]*c10)-(Atir[10][1]*s10))+(((Otkr[10][2]*rk[5][1]
      )-(Otkr[10][1]*rk[5][2]))+((wk[10][1]*Wkrpk[10][2])-(wk[10][2]*
      Wkrpk[10][1]))));
    Atkr[10][1] = (((Atir[10][0]*s10)+(Atir[10][1]*c10))+(((Otkr[10][0]*rk[5][2]
      )-(Otkr[10][2]*rk[5][0]))+((wk[10][2]*Wkrpk[10][0])-(wk[10][0]*
      Wkrpk[10][2]))));
    Atkr[10][2] = (Atir[10][2]+(((Otkr[10][1]*rk[5][0])-(Otkr[10][0]*rk[5][1]))+
      ((wk[10][0]*Wkrpk[10][1])-(wk[10][1]*Wkrpk[10][0]))));
    Atir[11][0] = (Atkr[9][0]+(((Otkr[9][1]*ri[6][2])-(Otkr[9][2]*ri[6][1]))+((
      Wirk[11][2]*wk[9][1])-(Wirk[11][1]*wk[9][2]))));
    Atir[11][1] = (Atkr[9][1]+(((Otkr[9][2]*ri[6][0])-(Otkr[9][0]*ri[6][2]))+((
      Wirk[11][0]*wk[9][2])-(Wirk[11][2]*wk[9][0]))));
    Atir[11][2] = (Atkr[9][2]+(((Otkr[9][0]*ri[6][1])-(Otkr[9][1]*ri[6][0]))+((
      Wirk[11][1]*wk[9][0])-(Wirk[11][0]*wk[9][1]))));
    Atkr[11][0] = (((Atir[11][0]*c11)+(Atir[11][1]*s11))+(((Otkr[11][2]*rk[6][1]
      )-(Otkr[11][1]*rk[6][2]))+((wk[11][1]*Wkrpk[11][2])-(wk[11][2]*
      Wkrpk[11][1]))));
    Atkr[11][1] = (((Atir[11][1]*c11)-(Atir[11][0]*s11))+(((Otkr[11][0]*rk[6][2]
      )-(Otkr[11][2]*rk[6][0]))+((wk[11][2]*Wkrpk[11][0])-(wk[11][0]*
      Wkrpk[11][2]))));
    Atkr[11][2] = (Atir[11][2]+(((Otkr[11][1]*rk[6][0])-(Otkr[11][0]*rk[6][1]))+
      ((wk[11][0]*Wkrpk[11][1])-(wk[11][1]*Wkrpk[11][0]))));
    Atir[12][0] = (Atkr[5][0]+(((ri[7][2]*udotin[4])-(ri[7][1]*udotin[5]))+((
      u[4]*Wirk[12][2])-(u[5]*Wirk[12][1]))));
    Atir[12][1] = (Atkr[5][1]+(((ri[7][0]*udotin[5])-(ri[7][2]*udotin[3]))+((
      u[5]*Wirk[12][0])-(u[3]*Wirk[12][2]))));
    Atir[12][2] = (Atkr[5][2]+(((ri[7][1]*udotin[3])-(ri[7][0]*udotin[4]))+((
      u[3]*Wirk[12][1])-(u[4]*Wirk[12][0]))));
    Atkr[12][0] = (((Atir[12][0]*c12)-(Atir[12][1]*s12))+(((Otkr[12][2]*rk[7][1]
      )-(Otkr[12][1]*rk[7][2]))+((wk[12][1]*Wkrpk[12][2])-(wk[12][2]*
      Wkrpk[12][1]))));
    Atkr[12][1] = (((Atir[12][0]*s12)+(Atir[12][1]*c12))+(((Otkr[12][0]*rk[7][2]
      )-(Otkr[12][2]*rk[7][0]))+((wk[12][2]*Wkrpk[12][0])-(wk[12][0]*
      Wkrpk[12][2]))));
    Atkr[12][2] = (Atir[12][2]+(((Otkr[12][1]*rk[7][0])-(Otkr[12][0]*rk[7][1]))+
      ((wk[12][0]*Wkrpk[12][1])-(wk[12][1]*Wkrpk[12][0]))));
    Atir[13][0] = (Atkr[5][0]+(((ri[8][2]*udotin[4])-(ri[8][1]*udotin[5]))+((
      u[4]*Wirk[13][2])-(u[5]*Wirk[13][1]))));
    Atir[13][1] = (Atkr[5][1]+(((ri[8][0]*udotin[5])-(ri[8][2]*udotin[3]))+((
      u[5]*Wirk[13][0])-(u[3]*Wirk[13][2]))));
    Atir[13][2] = (Atkr[5][2]+(((ri[8][1]*udotin[3])-(ri[8][0]*udotin[4]))+((
      u[3]*Wirk[13][1])-(u[4]*Wirk[13][0]))));
    Atkr[13][0] = (((Atir[13][0]*c13)+(Atir[13][1]*s13))+(((Otkr[13][2]*rk[8][1]
      )-(Otkr[13][1]*rk[8][2]))+((wk[13][1]*Wkrpk[13][2])-(wk[13][2]*
      Wkrpk[13][1]))));
    Atkr[13][1] = (((Atir[13][1]*c13)-(Atir[13][0]*s13))+(((Otkr[13][0]*rk[8][2]
      )-(Otkr[13][2]*rk[8][0]))+((wk[13][2]*Wkrpk[13][0])-(wk[13][0]*
      Wkrpk[13][2]))));
    Atkr[13][2] = (Atir[13][2]+(((Otkr[13][1]*rk[8][0])-(Otkr[13][0]*rk[8][1]))+
      ((wk[13][0]*Wkrpk[13][1])-(wk[13][1]*Wkrpk[13][0]))));
    Atir[14][0] = (Atkr[12][0]+(((Otkr[12][1]*ri[9][2])-(Otkr[12][2]*ri[9][1]))+
      ((Wirk[14][2]*wk[12][1])-(Wirk[14][1]*wk[12][2]))));
    Atir[14][1] = (Atkr[12][1]+(((Otkr[12][2]*ri[9][0])-(Otkr[12][0]*ri[9][2]))+
      ((Wirk[14][0]*wk[12][2])-(Wirk[14][2]*wk[12][0]))));
    Atir[14][2] = (Atkr[12][2]+(((Otkr[12][0]*ri[9][1])-(Otkr[12][1]*ri[9][0]))+
      ((Wirk[14][1]*wk[12][0])-(Wirk[14][0]*wk[12][1]))));
    Atkr[14][0] = (Atir[14][0]+(((Otkr[14][2]*rk[9][1])-(Otkr[14][1]*rk[9][2]))+
      ((wk[14][1]*Wkrpk[14][2])-(wk[14][2]*Wkrpk[14][1]))));
    Atkr[14][1] = (((Atir[14][1]*c14)-(Atir[14][2]*s14))+(((Otkr[14][0]*rk[9][2]
      )-(Otkr[14][2]*rk[9][0]))+((wk[14][2]*Wkrpk[14][0])-(wk[14][0]*
      Wkrpk[14][2]))));
    Atkr[14][2] = (((Atir[14][1]*s14)+(Atir[14][2]*c14))+(((Otkr[14][1]*rk[9][0]
      )-(Otkr[14][0]*rk[9][1]))+((wk[14][0]*Wkrpk[14][1])-(wk[14][1]*
      Wkrpk[14][0]))));
    Atir[15][0] = (Atkr[13][0]+(((Otkr[13][1]*ri[10][2])-(Otkr[13][2]*ri[10][1])
      )+((Wirk[15][2]*wk[13][1])-(Wirk[15][1]*wk[13][2]))));
    Atir[15][1] = (Atkr[13][1]+(((Otkr[13][2]*ri[10][0])-(Otkr[13][0]*ri[10][2])
      )+((Wirk[15][0]*wk[13][2])-(Wirk[15][2]*wk[13][0]))));
    Atir[15][2] = (Atkr[13][2]+(((Otkr[13][0]*ri[10][1])-(Otkr[13][1]*ri[10][0])
      )+((Wirk[15][1]*wk[13][0])-(Wirk[15][0]*wk[13][1]))));
    Atkr[15][0] = (Atir[15][0]+(((Otkr[15][2]*rk[10][1])-(Otkr[15][1]*rk[10][2])
      )+((wk[15][1]*Wkrpk[15][2])-(wk[15][2]*Wkrpk[15][1]))));
    Atkr[15][1] = (((Atir[15][1]*c15)+(Atir[15][2]*s15))+(((Otkr[15][0]*
      rk[10][2])-(Otkr[15][2]*rk[10][0]))+((wk[15][2]*Wkrpk[15][0])-(wk[15][0]*
      Wkrpk[15][2]))));
    Atkr[15][2] = (((Atir[15][2]*c15)-(Atir[15][1]*s15))+(((Otkr[15][1]*
      rk[10][0])-(Otkr[15][0]*rk[10][1]))+((wk[15][0]*Wkrpk[15][1])-(wk[15][1]*
      Wkrpk[15][0]))));
    Atir[16][0] = (Atkr[14][0]+(((Otkr[14][1]*ri[11][2])-(Otkr[14][2]*ri[11][1])
      )+((Wirk[16][2]*wk[14][1])-(Wirk[16][1]*wk[14][2]))));
    Atir[16][1] = (Atkr[14][1]+(((Otkr[14][2]*ri[11][0])-(Otkr[14][0]*ri[11][2])
      )+((Wirk[16][0]*wk[14][2])-(Wirk[16][2]*wk[14][0]))));
    Atir[16][2] = (Atkr[14][2]+(((Otkr[14][0]*ri[11][1])-(Otkr[14][1]*ri[11][0])
      )+((Wirk[16][1]*wk[14][0])-(Wirk[16][0]*wk[14][1]))));
    Atkr[16][0] = (((Atir[16][0]*c16)+(Atir[16][2]*s16))+(((Otkr[16][2]*
      rk[11][1])-(Otkr[16][1]*rk[11][2]))+((wk[16][1]*Wkrpk[16][2])-(wk[16][2]*
      Wkrpk[16][1]))));
    Atkr[16][1] = (Atir[16][1]+(((Otkr[16][0]*rk[11][2])-(Otkr[16][2]*rk[11][0])
      )+((wk[16][2]*Wkrpk[16][0])-(wk[16][0]*Wkrpk[16][2]))));
    Atkr[16][2] = (((Atir[16][2]*c16)-(Atir[16][0]*s16))+(((Otkr[16][1]*
      rk[11][0])-(Otkr[16][0]*rk[11][1]))+((wk[16][0]*Wkrpk[16][1])-(wk[16][1]*
      Wkrpk[16][0]))));
    Atir[17][0] = (Atkr[15][0]+(((Otkr[15][1]*ri[12][2])-(Otkr[15][2]*ri[12][1])
      )+((Wirk[17][2]*wk[15][1])-(Wirk[17][1]*wk[15][2]))));
    Atir[17][1] = (Atkr[15][1]+(((Otkr[15][2]*ri[12][0])-(Otkr[15][0]*ri[12][2])
      )+((Wirk[17][0]*wk[15][2])-(Wirk[17][2]*wk[15][0]))));
    Atir[17][2] = (Atkr[15][2]+(((Otkr[15][0]*ri[12][1])-(Otkr[15][1]*ri[12][0])
      )+((Wirk[17][1]*wk[15][0])-(Wirk[17][0]*wk[15][1]))));
    Atkr[17][0] = (((Atir[17][0]*c17)+(Atir[17][2]*s17))+(((Otkr[17][2]*
      rk[12][1])-(Otkr[17][1]*rk[12][2]))+((wk[17][1]*Wkrpk[17][2])-(wk[17][2]*
      Wkrpk[17][1]))));
    Atkr[17][1] = (Atir[17][1]+(((Otkr[17][0]*rk[12][2])-(Otkr[17][2]*rk[12][0])
      )+((wk[17][2]*Wkrpk[17][0])-(wk[17][0]*Wkrpk[17][2]))));
    Atkr[17][2] = (((Atir[17][2]*c17)-(Atir[17][0]*s17))+(((Otkr[17][1]*
      rk[12][0])-(Otkr[17][0]*rk[12][1]))+((wk[17][0]*Wkrpk[17][1])-(wk[17][1]*
      Wkrpk[17][0]))));
    Atir[18][0] = (Atkr[16][0]+(((Otkr[16][1]*ri[13][2])-(Otkr[16][2]*ri[13][1])
      )+((Wirk[18][2]*wk[16][1])-(Wirk[18][1]*wk[16][2]))));
    Atir[18][1] = (Atkr[16][1]+(((Otkr[16][2]*ri[13][0])-(Otkr[16][0]*ri[13][2])
      )+((Wirk[18][0]*wk[16][2])-(Wirk[18][2]*wk[16][0]))));
    Atir[18][2] = (Atkr[16][2]+(((Otkr[16][0]*ri[13][1])-(Otkr[16][1]*ri[13][0])
      )+((Wirk[18][1]*wk[16][0])-(Wirk[18][0]*wk[16][1]))));
    Atkr[18][0] = (((Atir[18][0]*c18)+(Atir[18][2]*s18))+(((Otkr[18][2]*
      rk[13][1])-(Otkr[18][1]*rk[13][2]))+((wk[18][1]*Wkrpk[18][2])-(wk[18][2]*
      Wkrpk[18][1]))));
    Atkr[18][1] = (Atir[18][1]+(((Otkr[18][0]*rk[13][2])-(Otkr[18][2]*rk[13][0])
      )+((wk[18][2]*Wkrpk[18][0])-(wk[18][0]*Wkrpk[18][2]))));
    Atkr[18][2] = (((Atir[18][2]*c18)-(Atir[18][0]*s18))+(((Otkr[18][1]*
      rk[13][0])-(Otkr[18][0]*rk[13][1]))+((wk[18][0]*Wkrpk[18][1])-(wk[18][1]*
      Wkrpk[18][0]))));
    Atir[19][0] = (Atkr[17][0]+(((Otkr[17][1]*ri[14][2])-(Otkr[17][2]*ri[14][1])
      )+((Wirk[19][2]*wk[17][1])-(Wirk[19][1]*wk[17][2]))));
    Atir[19][1] = (Atkr[17][1]+(((Otkr[17][2]*ri[14][0])-(Otkr[17][0]*ri[14][2])
      )+((Wirk[19][0]*wk[17][2])-(Wirk[19][2]*wk[17][0]))));
    Atir[19][2] = (Atkr[17][2]+(((Otkr[17][0]*ri[14][1])-(Otkr[17][1]*ri[14][0])
      )+((Wirk[19][1]*wk[17][0])-(Wirk[19][0]*wk[17][1]))));
    Atkr[19][0] = (((Atir[19][0]*c19)+(Atir[19][2]*s19))+(((Otkr[19][2]*
      rk[14][1])-(Otkr[19][1]*rk[14][2]))+((wk[19][1]*Wkrpk[19][2])-(wk[19][2]*
      Wkrpk[19][1]))));
    Atkr[19][1] = (Atir[19][1]+(((Otkr[19][0]*rk[14][2])-(Otkr[19][2]*rk[14][0])
      )+((wk[19][2]*Wkrpk[19][0])-(wk[19][0]*Wkrpk[19][2]))));
    Atkr[19][2] = (((Atir[19][2]*c19)-(Atir[19][0]*s19))+(((Otkr[19][1]*
      rk[14][0])-(Otkr[19][0]*rk[14][1]))+((wk[19][0]*Wkrpk[19][1])-(wk[19][1]*
      Wkrpk[19][0]))));
    Atir[20][0] = (Atkr[18][0]+(((Otkr[18][1]*ri[15][2])-(Otkr[18][2]*ri[15][1])
      )+((Wirk[20][2]*wk[18][1])-(Wirk[20][1]*wk[18][2]))));
    Atir[20][1] = (Atkr[18][1]+(((Otkr[18][2]*ri[15][0])-(Otkr[18][0]*ri[15][2])
      )+((Wirk[20][0]*wk[18][2])-(Wirk[20][2]*wk[18][0]))));
    Atir[20][2] = (Atkr[18][2]+(((Otkr[18][0]*ri[15][1])-(Otkr[18][1]*ri[15][0])
      )+((Wirk[20][1]*wk[18][0])-(Wirk[20][0]*wk[18][1]))));
    Atkr[20][0] = (((Atir[20][0]*c20)+(Atir[20][2]*s20))+(((Otkr[20][2]*
      rk[15][1])-(Otkr[20][1]*rk[15][2]))+((wk[20][1]*Wkrpk[20][2])-(wk[20][2]*
      Wkrpk[20][1]))));
    Atkr[20][1] = (Atir[20][1]+(((Otkr[20][0]*rk[15][2])-(Otkr[20][2]*rk[15][0])
      )+((wk[20][2]*Wkrpk[20][0])-(wk[20][0]*Wkrpk[20][2]))));
    Atkr[20][2] = (((Atir[20][2]*c20)-(Atir[20][0]*s20))+(((Otkr[20][1]*
      rk[15][0])-(Otkr[20][0]*rk[15][1]))+((wk[20][0]*Wkrpk[20][1])-(wk[20][1]*
      Wkrpk[20][0]))));
    Atir[21][0] = (Atkr[19][0]+(((Otkr[19][1]*ri[16][2])-(Otkr[19][2]*ri[16][1])
      )+((Wirk[21][2]*wk[19][1])-(Wirk[21][1]*wk[19][2]))));
    Atir[21][1] = (Atkr[19][1]+(((Otkr[19][2]*ri[16][0])-(Otkr[19][0]*ri[16][2])
      )+((Wirk[21][0]*wk[19][2])-(Wirk[21][2]*wk[19][0]))));
    Atir[21][2] = (Atkr[19][2]+(((Otkr[19][0]*ri[16][1])-(Otkr[19][1]*ri[16][0])
      )+((Wirk[21][1]*wk[19][0])-(Wirk[21][0]*wk[19][1]))));
    Atkr[21][0] = (((Atir[21][0]*c21)+(Atir[21][2]*s21))+(((Otkr[21][2]*
      rk[16][1])-(Otkr[21][1]*rk[16][2]))+((wk[21][1]*Wkrpk[21][2])-(wk[21][2]*
      Wkrpk[21][1]))));
    Atkr[21][1] = (Atir[21][1]+(((Otkr[21][0]*rk[16][2])-(Otkr[21][2]*rk[16][0])
      )+((wk[21][2]*Wkrpk[21][0])-(wk[21][0]*Wkrpk[21][2]))));
    Atkr[21][2] = (((Atir[21][2]*c21)-(Atir[21][0]*s21))+(((Otkr[21][1]*
      rk[16][0])-(Otkr[21][0]*rk[16][1]))+((wk[21][0]*Wkrpk[21][1])-(wk[21][1]*
      Wkrpk[21][0]))));
    Atir[22][0] = (Atkr[20][0]+(((Otkr[20][1]*ri[17][2])-(Otkr[20][2]*ri[17][1])
      )+((Wirk[22][2]*wk[20][1])-(Wirk[22][1]*wk[20][2]))));
    Atir[22][1] = (Atkr[20][1]+(((Otkr[20][2]*ri[17][0])-(Otkr[20][0]*ri[17][2])
      )+((Wirk[22][0]*wk[20][2])-(Wirk[22][2]*wk[20][0]))));
    Atir[22][2] = (Atkr[20][2]+(((Otkr[20][0]*ri[17][1])-(Otkr[20][1]*ri[17][0])
      )+((Wirk[22][1]*wk[20][0])-(Wirk[22][0]*wk[20][1]))));
    Atkr[22][0] = (Atir[22][0]+(((Otkr[22][2]*rk[17][1])-(Otkr[22][1]*rk[17][2])
      )+((wk[22][1]*Wkrpk[22][2])-(wk[22][2]*Wkrpk[22][1]))));
    Atkr[22][1] = (((Atir[22][1]*c22)-(Atir[22][2]*s22))+(((Otkr[22][0]*
      rk[17][2])-(Otkr[22][2]*rk[17][0]))+((wk[22][2]*Wkrpk[22][0])-(wk[22][0]*
      Wkrpk[22][2]))));
    Atkr[22][2] = (((Atir[22][1]*s22)+(Atir[22][2]*c22))+(((Otkr[22][1]*
      rk[17][0])-(Otkr[22][0]*rk[17][1]))+((wk[22][0]*Wkrpk[22][1])-(wk[22][1]*
      Wkrpk[22][0]))));
    Atir[23][0] = (Atkr[21][0]+(((Otkr[21][1]*ri[18][2])-(Otkr[21][2]*ri[18][1])
      )+((Wirk[23][2]*wk[21][1])-(Wirk[23][1]*wk[21][2]))));
    Atir[23][1] = (Atkr[21][1]+(((Otkr[21][2]*ri[18][0])-(Otkr[21][0]*ri[18][2])
      )+((Wirk[23][0]*wk[21][2])-(Wirk[23][2]*wk[21][0]))));
    Atir[23][2] = (Atkr[21][2]+(((Otkr[21][0]*ri[18][1])-(Otkr[21][1]*ri[18][0])
      )+((Wirk[23][1]*wk[21][0])-(Wirk[23][0]*wk[21][1]))));
    Atkr[23][0] = (Atir[23][0]+(((Otkr[23][2]*rk[18][1])-(Otkr[23][1]*rk[18][2])
      )+((wk[23][1]*Wkrpk[23][2])-(wk[23][2]*Wkrpk[23][1]))));
    Atkr[23][1] = (((Atir[23][1]*c23)+(Atir[23][2]*s23))+(((Otkr[23][0]*
      rk[18][2])-(Otkr[23][2]*rk[18][0]))+((wk[23][2]*Wkrpk[23][0])-(wk[23][0]*
      Wkrpk[23][2]))));
    Atkr[23][2] = (((Atir[23][2]*c23)-(Atir[23][1]*s23))+(((Otkr[23][1]*
      rk[18][0])-(Otkr[23][0]*rk[18][1]))+((wk[23][0]*Wkrpk[23][1])-(wk[23][1]*
      Wkrpk[23][0]))));
    Atir[24][0] = (Atkr[5][0]+(((ri[19][2]*udotin[4])-(ri[19][1]*udotin[5]))+((
      u[4]*Wirk[24][2])-(u[5]*Wirk[24][1]))));
    Atir[24][1] = (Atkr[5][1]+(((ri[19][0]*udotin[5])-(ri[19][2]*udotin[3]))+((
      u[5]*Wirk[24][0])-(u[3]*Wirk[24][2]))));
    Atir[24][2] = (Atkr[5][2]+(((ri[19][1]*udotin[3])-(ri[19][0]*udotin[4]))+((
      u[3]*Wirk[24][1])-(u[4]*Wirk[24][0]))));
    Atkr[24][0] = (((Atir[24][0]*c24)+(Atir[24][1]*s24))+(((Otkr[24][2]*
      rk[19][1])-(Otkr[24][1]*rk[19][2]))+((wk[24][1]*Wkrpk[24][2])-(wk[24][2]*
      Wkrpk[24][1]))));
    Atkr[24][1] = (((Atir[24][1]*c24)-(Atir[24][0]*s24))+(((Otkr[24][0]*
      rk[19][2])-(Otkr[24][2]*rk[19][0]))+((wk[24][2]*Wkrpk[24][0])-(wk[24][0]*
      Wkrpk[24][2]))));
    Atkr[24][2] = (Atir[24][2]+(((Otkr[24][1]*rk[19][0])-(Otkr[24][0]*rk[19][1])
      )+((wk[24][0]*Wkrpk[24][1])-(wk[24][1]*Wkrpk[24][0]))));
    Atir[25][0] = (Atkr[24][0]+(((Otkr[24][1]*ri[20][2])-(Otkr[24][2]*ri[20][1])
      )+((Wirk[25][2]*wk[24][1])-(Wirk[25][1]*wk[24][2]))));
    Atir[25][1] = (Atkr[24][1]+(((Otkr[24][2]*ri[20][0])-(Otkr[24][0]*ri[20][2])
      )+((Wirk[25][0]*wk[24][2])-(Wirk[25][2]*wk[24][0]))));
    Atir[25][2] = (Atkr[24][2]+(((Otkr[24][0]*ri[20][1])-(Otkr[24][1]*ri[20][0])
      )+((Wirk[25][1]*wk[24][0])-(Wirk[25][0]*wk[24][1]))));
    Atkr[25][0] = (((Atir[25][0]*c25)+(Atir[25][2]*s25))+(((Otkr[25][2]*
      rk[20][1])-(Otkr[25][1]*rk[20][2]))+((wk[25][1]*Wkrpk[25][2])-(wk[25][2]*
      Wkrpk[25][1]))));
    Atkr[25][1] = (Atir[25][1]+(((Otkr[25][0]*rk[20][2])-(Otkr[25][2]*rk[20][0])
      )+((wk[25][2]*Wkrpk[25][0])-(wk[25][0]*Wkrpk[25][2]))));
    Atkr[25][2] = (((Atir[25][2]*c25)-(Atir[25][0]*s25))+(((Otkr[25][1]*
      rk[20][0])-(Otkr[25][0]*rk[20][1]))+((wk[25][0]*Wkrpk[25][1])-(wk[25][1]*
      Wkrpk[25][0]))));
/*
Accumulate all forces and torques
*/
    fstarr[5][0] = (ufk[0][0]+(mk[0]*(gk[3][0]-Atkr[5][0])));
    fstarr[5][1] = (ufk[0][1]+(mk[0]*(gk[3][1]-Atkr[5][1])));
    fstarr[5][2] = (ufk[0][2]+(mk[0]*(gk[3][2]-Atkr[5][2])));
    fstarr[6][0] = (ufk[1][0]+(mk[1]*(gk[6][0]-Atkr[6][0])));
    fstarr[6][1] = (ufk[1][1]+(mk[1]*(gk[3][1]-Atkr[6][1])));
    fstarr[6][2] = (ufk[1][2]+(mk[1]*(gk[6][2]-Atkr[6][2])));
    fstarr[7][0] = (ufk[2][0]+(mk[2]*(gk[7][0]-Atkr[7][0])));
    fstarr[7][1] = (ufk[2][1]+(mk[2]*(gk[3][1]-Atkr[7][1])));
    fstarr[7][2] = (ufk[2][2]+(mk[2]*(gk[7][2]-Atkr[7][2])));
    fstarr[8][0] = (ufk[3][0]+(mk[3]*(gk[6][0]-Atkr[8][0])));
    fstarr[8][1] = (ufk[3][1]+(mk[3]*(gk[8][1]-Atkr[8][1])));
    fstarr[8][2] = (ufk[3][2]+(mk[3]*(gk[8][2]-Atkr[8][2])));
    fstarr[9][0] = (ufk[4][0]+(mk[4]*(gk[7][0]-Atkr[9][0])));
    fstarr[9][1] = (ufk[4][1]+(mk[4]*(gk[9][1]-Atkr[9][1])));
    fstarr[9][2] = (ufk[4][2]+(mk[4]*(gk[9][2]-Atkr[9][2])));
    fstarr[10][0] = (ufk[5][0]+(mk[5]*(gk[10][0]-Atkr[10][0])));
    fstarr[10][1] = (ufk[5][1]+(mk[5]*(gk[10][1]-Atkr[10][1])));
    fstarr[10][2] = (ufk[5][2]+(mk[5]*(gk[8][2]-Atkr[10][2])));
    fstarr[11][0] = (ufk[6][0]+(mk[6]*(gk[11][0]-Atkr[11][0])));
    fstarr[11][1] = (ufk[6][1]+(mk[6]*(gk[11][1]-Atkr[11][1])));
    fstarr[11][2] = (ufk[6][2]+(mk[6]*(gk[9][2]-Atkr[11][2])));
    fstarr[12][0] = (ufk[7][0]+(mk[7]*(gk[12][0]-Atkr[12][0])));
    fstarr[12][1] = (ufk[7][1]+(mk[7]*(gk[12][1]-Atkr[12][1])));
    fstarr[12][2] = (ufk[7][2]+(mk[7]*(gk[3][2]-Atkr[12][2])));
    fstarr[13][0] = (ufk[8][0]+(mk[8]*(gk[13][0]-Atkr[13][0])));
    fstarr[13][1] = (ufk[8][1]+(mk[8]*(gk[13][1]-Atkr[13][1])));
    fstarr[13][2] = (ufk[8][2]+(mk[8]*(gk[3][2]-Atkr[13][2])));
    fstarr[14][0] = (ufk[9][0]+(mk[9]*(gk[12][0]-Atkr[14][0])));
    fstarr[14][1] = (ufk[9][1]+(mk[9]*(gk[14][1]-Atkr[14][1])));
    fstarr[14][2] = (ufk[9][2]+(mk[9]*(gk[14][2]-Atkr[14][2])));
    fstarr[15][0] = (ufk[10][0]+(mk[10]*(gk[13][0]-Atkr[15][0])));
    fstarr[15][1] = (ufk[10][1]+(mk[10]*(gk[15][1]-Atkr[15][1])));
    fstarr[15][2] = (ufk[10][2]+(mk[10]*(gk[15][2]-Atkr[15][2])));
    fstarr[16][0] = (ufk[11][0]+(mk[11]*(gk[16][0]-Atkr[16][0])));
    fstarr[16][1] = (ufk[11][1]+(mk[11]*(gk[14][1]-Atkr[16][1])));
    fstarr[16][2] = (ufk[11][2]+(mk[11]*(gk[16][2]-Atkr[16][2])));
    fstarr[17][0] = (ufk[12][0]+(mk[12]*(gk[17][0]-Atkr[17][0])));
    fstarr[17][1] = (ufk[12][1]+(mk[12]*(gk[15][1]-Atkr[17][1])));
    fstarr[17][2] = (ufk[12][2]+(mk[12]*(gk[17][2]-Atkr[17][2])));
    fstarr[18][0] = (ufk[13][0]+(mk[13]*(gk[18][0]-Atkr[18][0])));
    fstarr[18][1] = (ufk[13][1]+(mk[13]*(gk[14][1]-Atkr[18][1])));
    fstarr[18][2] = (ufk[13][2]+(mk[13]*(gk[18][2]-Atkr[18][2])));
    fstarr[19][0] = (ufk[14][0]+(mk[14]*(gk[19][0]-Atkr[19][0])));
    fstarr[19][1] = (ufk[14][1]+(mk[14]*(gk[15][1]-Atkr[19][1])));
    fstarr[19][2] = (ufk[14][2]+(mk[14]*(gk[19][2]-Atkr[19][2])));
    fstarr[20][0] = (ufk[15][0]+(mk[15]*(gk[20][0]-Atkr[20][0])));
    fstarr[20][1] = (ufk[15][1]+(mk[15]*(gk[14][1]-Atkr[20][1])));
    fstarr[20][2] = (ufk[15][2]+(mk[15]*(gk[20][2]-Atkr[20][2])));
    fstarr[21][0] = (ufk[16][0]+(mk[16]*(gk[21][0]-Atkr[21][0])));
    fstarr[21][1] = (ufk[16][1]+(mk[16]*(gk[15][1]-Atkr[21][1])));
    fstarr[21][2] = (ufk[16][2]+(mk[16]*(gk[21][2]-Atkr[21][2])));
    fstarr[22][0] = (ufk[17][0]+(mk[17]*(gk[20][0]-Atkr[22][0])));
    fstarr[22][1] = (ufk[17][1]+(mk[17]*(gk[22][1]-Atkr[22][1])));
    fstarr[22][2] = (ufk[17][2]+(mk[17]*(gk[22][2]-Atkr[22][2])));
    fstarr[23][0] = (ufk[18][0]+(mk[18]*(gk[21][0]-Atkr[23][0])));
    fstarr[23][1] = (ufk[18][1]+(mk[18]*(gk[23][1]-Atkr[23][1])));
    fstarr[23][2] = (ufk[18][2]+(mk[18]*(gk[23][2]-Atkr[23][2])));
    fstarr[24][0] = (ufk[19][0]+(mk[19]*(gk[24][0]-Atkr[24][0])));
    fstarr[24][1] = (ufk[19][1]+(mk[19]*(gk[24][1]-Atkr[24][1])));
    fstarr[24][2] = (ufk[19][2]+(mk[19]*(gk[3][2]-Atkr[24][2])));
    fstarr[25][0] = (ufk[20][0]+(mk[20]*(gk[25][0]-Atkr[25][0])));
    fstarr[25][1] = (ufk[20][1]+(mk[20]*(gk[24][1]-Atkr[25][1])));
    fstarr[25][2] = (ufk[20][2]+(mk[20]*(gk[25][2]-Atkr[25][2])));
    tstarr[5][0] = (utk[0][0]-(WkIkWk[5][0]+((ik[0][0][2]*udotin[5])+((
      ik[0][0][0]*udotin[3])+(ik[0][0][1]*udotin[4])))));
    tstarr[5][1] = (utk[0][1]-(WkIkWk[5][1]+((ik[0][1][2]*udotin[5])+((
      ik[0][1][0]*udotin[3])+(ik[0][1][1]*udotin[4])))));
    tstarr[5][2] = (utk[0][2]-(WkIkWk[5][2]+((ik[0][2][2]*udotin[5])+((
      ik[0][2][0]*udotin[3])+(ik[0][2][1]*udotin[4])))));
    tstarr[6][0] = (utk[1][0]-(WkIkWk[6][0]+((ik[1][0][2]*Otkr[6][2])+((
      ik[1][0][0]*Otkr[6][0])+(ik[1][0][1]*Otkr[6][1])))));
    tstarr[6][1] = (utk[1][1]-(WkIkWk[6][1]+((ik[1][1][2]*Otkr[6][2])+((
      ik[1][1][0]*Otkr[6][0])+(ik[1][1][1]*Otkr[6][1])))));
    tstarr[6][2] = (utk[1][2]-(WkIkWk[6][2]+((ik[1][2][2]*Otkr[6][2])+((
      ik[1][2][0]*Otkr[6][0])+(ik[1][2][1]*Otkr[6][1])))));
    tstarr[7][0] = (utk[2][0]-(WkIkWk[7][0]+((ik[2][0][2]*Otkr[7][2])+((
      ik[2][0][0]*Otkr[7][0])+(ik[2][0][1]*Otkr[7][1])))));
    tstarr[7][1] = (utk[2][1]-(WkIkWk[7][1]+((ik[2][1][2]*Otkr[7][2])+((
      ik[2][1][0]*Otkr[7][0])+(ik[2][1][1]*Otkr[7][1])))));
    tstarr[7][2] = (utk[2][2]-(WkIkWk[7][2]+((ik[2][2][2]*Otkr[7][2])+((
      ik[2][2][0]*Otkr[7][0])+(ik[2][2][1]*Otkr[7][1])))));
    tstarr[8][0] = (utk[3][0]-(WkIkWk[8][0]+((ik[3][0][2]*Otkr[8][2])+((
      ik[3][0][0]*Otkr[8][0])+(ik[3][0][1]*Otkr[8][1])))));
    tstarr[8][1] = (utk[3][1]-(WkIkWk[8][1]+((ik[3][1][2]*Otkr[8][2])+((
      ik[3][1][0]*Otkr[8][0])+(ik[3][1][1]*Otkr[8][1])))));
    tstarr[8][2] = (utk[3][2]-(WkIkWk[8][2]+((ik[3][2][2]*Otkr[8][2])+((
      ik[3][2][0]*Otkr[8][0])+(ik[3][2][1]*Otkr[8][1])))));
    tstarr[9][0] = (utk[4][0]-(WkIkWk[9][0]+((ik[4][0][2]*Otkr[9][2])+((
      ik[4][0][0]*Otkr[9][0])+(ik[4][0][1]*Otkr[9][1])))));
    tstarr[9][1] = (utk[4][1]-(WkIkWk[9][1]+((ik[4][1][2]*Otkr[9][2])+((
      ik[4][1][0]*Otkr[9][0])+(ik[4][1][1]*Otkr[9][1])))));
    tstarr[9][2] = (utk[4][2]-(WkIkWk[9][2]+((ik[4][2][2]*Otkr[9][2])+((
      ik[4][2][0]*Otkr[9][0])+(ik[4][2][1]*Otkr[9][1])))));
    tstarr[10][0] = (utk[5][0]-(WkIkWk[10][0]+((ik[5][0][2]*Otkr[10][2])+((
      ik[5][0][0]*Otkr[10][0])+(ik[5][0][1]*Otkr[10][1])))));
    tstarr[10][1] = (utk[5][1]-(WkIkWk[10][1]+((ik[5][1][2]*Otkr[10][2])+((
      ik[5][1][0]*Otkr[10][0])+(ik[5][1][1]*Otkr[10][1])))));
    tstarr[10][2] = (utk[5][2]-(WkIkWk[10][2]+((ik[5][2][2]*Otkr[10][2])+((
      ik[5][2][0]*Otkr[10][0])+(ik[5][2][1]*Otkr[10][1])))));
    tstarr[11][0] = (utk[6][0]-(WkIkWk[11][0]+((ik[6][0][2]*Otkr[11][2])+((
      ik[6][0][0]*Otkr[11][0])+(ik[6][0][1]*Otkr[11][1])))));
    tstarr[11][1] = (utk[6][1]-(WkIkWk[11][1]+((ik[6][1][2]*Otkr[11][2])+((
      ik[6][1][0]*Otkr[11][0])+(ik[6][1][1]*Otkr[11][1])))));
    tstarr[11][2] = (utk[6][2]-(WkIkWk[11][2]+((ik[6][2][2]*Otkr[11][2])+((
      ik[6][2][0]*Otkr[11][0])+(ik[6][2][1]*Otkr[11][1])))));
    tstarr[12][0] = (utk[7][0]-(WkIkWk[12][0]+((ik[7][0][2]*Otkr[12][2])+((
      ik[7][0][0]*Otkr[12][0])+(ik[7][0][1]*Otkr[12][1])))));
    tstarr[12][1] = (utk[7][1]-(WkIkWk[12][1]+((ik[7][1][2]*Otkr[12][2])+((
      ik[7][1][0]*Otkr[12][0])+(ik[7][1][1]*Otkr[12][1])))));
    tstarr[12][2] = (utk[7][2]-(WkIkWk[12][2]+((ik[7][2][2]*Otkr[12][2])+((
      ik[7][2][0]*Otkr[12][0])+(ik[7][2][1]*Otkr[12][1])))));
    tstarr[13][0] = (utk[8][0]-(WkIkWk[13][0]+((ik[8][0][2]*Otkr[13][2])+((
      ik[8][0][0]*Otkr[13][0])+(ik[8][0][1]*Otkr[13][1])))));
    tstarr[13][1] = (utk[8][1]-(WkIkWk[13][1]+((ik[8][1][2]*Otkr[13][2])+((
      ik[8][1][0]*Otkr[13][0])+(ik[8][1][1]*Otkr[13][1])))));
    tstarr[13][2] = (utk[8][2]-(WkIkWk[13][2]+((ik[8][2][2]*Otkr[13][2])+((
      ik[8][2][0]*Otkr[13][0])+(ik[8][2][1]*Otkr[13][1])))));
    tstarr[14][0] = (utk[9][0]-(WkIkWk[14][0]+((ik[9][0][2]*Otkr[14][2])+((
      ik[9][0][0]*Otkr[14][0])+(ik[9][0][1]*Otkr[14][1])))));
    tstarr[14][1] = (utk[9][1]-(WkIkWk[14][1]+((ik[9][1][2]*Otkr[14][2])+((
      ik[9][1][0]*Otkr[14][0])+(ik[9][1][1]*Otkr[14][1])))));
    tstarr[14][2] = (utk[9][2]-(WkIkWk[14][2]+((ik[9][2][2]*Otkr[14][2])+((
      ik[9][2][0]*Otkr[14][0])+(ik[9][2][1]*Otkr[14][1])))));
    tstarr[15][0] = (utk[10][0]-(WkIkWk[15][0]+((ik[10][0][2]*Otkr[15][2])+((
      ik[10][0][0]*Otkr[15][0])+(ik[10][0][1]*Otkr[15][1])))));
    tstarr[15][1] = (utk[10][1]-(WkIkWk[15][1]+((ik[10][1][2]*Otkr[15][2])+((
      ik[10][1][0]*Otkr[15][0])+(ik[10][1][1]*Otkr[15][1])))));
    tstarr[15][2] = (utk[10][2]-(WkIkWk[15][2]+((ik[10][2][2]*Otkr[15][2])+((
      ik[10][2][0]*Otkr[15][0])+(ik[10][2][1]*Otkr[15][1])))));
    tstarr[16][0] = (utk[11][0]-(WkIkWk[16][0]+((ik[11][0][2]*Otkr[16][2])+((
      ik[11][0][0]*Otkr[16][0])+(ik[11][0][1]*Otkr[16][1])))));
    tstarr[16][1] = (utk[11][1]-(WkIkWk[16][1]+((ik[11][1][2]*Otkr[16][2])+((
      ik[11][1][0]*Otkr[16][0])+(ik[11][1][1]*Otkr[16][1])))));
    tstarr[16][2] = (utk[11][2]-(WkIkWk[16][2]+((ik[11][2][2]*Otkr[16][2])+((
      ik[11][2][0]*Otkr[16][0])+(ik[11][2][1]*Otkr[16][1])))));
    tstarr[17][0] = (utk[12][0]-(WkIkWk[17][0]+((ik[12][0][2]*Otkr[17][2])+((
      ik[12][0][0]*Otkr[17][0])+(ik[12][0][1]*Otkr[17][1])))));
    tstarr[17][1] = (utk[12][1]-(WkIkWk[17][1]+((ik[12][1][2]*Otkr[17][2])+((
      ik[12][1][0]*Otkr[17][0])+(ik[12][1][1]*Otkr[17][1])))));
    tstarr[17][2] = (utk[12][2]-(WkIkWk[17][2]+((ik[12][2][2]*Otkr[17][2])+((
      ik[12][2][0]*Otkr[17][0])+(ik[12][2][1]*Otkr[17][1])))));
    tstarr[18][0] = (utk[13][0]-(WkIkWk[18][0]+((ik[13][0][2]*Otkr[18][2])+((
      ik[13][0][0]*Otkr[18][0])+(ik[13][0][1]*Otkr[18][1])))));
    tstarr[18][1] = (utk[13][1]-(WkIkWk[18][1]+((ik[13][1][2]*Otkr[18][2])+((
      ik[13][1][0]*Otkr[18][0])+(ik[13][1][1]*Otkr[18][1])))));
    tstarr[18][2] = (utk[13][2]-(WkIkWk[18][2]+((ik[13][2][2]*Otkr[18][2])+((
      ik[13][2][0]*Otkr[18][0])+(ik[13][2][1]*Otkr[18][1])))));
    tstarr[19][0] = (utk[14][0]-(WkIkWk[19][0]+((ik[14][0][2]*Otkr[19][2])+((
      ik[14][0][0]*Otkr[19][0])+(ik[14][0][1]*Otkr[19][1])))));
    tstarr[19][1] = (utk[14][1]-(WkIkWk[19][1]+((ik[14][1][2]*Otkr[19][2])+((
      ik[14][1][0]*Otkr[19][0])+(ik[14][1][1]*Otkr[19][1])))));
    tstarr[19][2] = (utk[14][2]-(WkIkWk[19][2]+((ik[14][2][2]*Otkr[19][2])+((
      ik[14][2][0]*Otkr[19][0])+(ik[14][2][1]*Otkr[19][1])))));
    tstarr[20][0] = (utk[15][0]-(WkIkWk[20][0]+((ik[15][0][2]*Otkr[20][2])+((
      ik[15][0][0]*Otkr[20][0])+(ik[15][0][1]*Otkr[20][1])))));
    tstarr[20][1] = (utk[15][1]-(WkIkWk[20][1]+((ik[15][1][2]*Otkr[20][2])+((
      ik[15][1][0]*Otkr[20][0])+(ik[15][1][1]*Otkr[20][1])))));
    tstarr[20][2] = (utk[15][2]-(WkIkWk[20][2]+((ik[15][2][2]*Otkr[20][2])+((
      ik[15][2][0]*Otkr[20][0])+(ik[15][2][1]*Otkr[20][1])))));
    tstarr[21][0] = (utk[16][0]-(WkIkWk[21][0]+((ik[16][0][2]*Otkr[21][2])+((
      ik[16][0][0]*Otkr[21][0])+(ik[16][0][1]*Otkr[21][1])))));
    tstarr[21][1] = (utk[16][1]-(WkIkWk[21][1]+((ik[16][1][2]*Otkr[21][2])+((
      ik[16][1][0]*Otkr[21][0])+(ik[16][1][1]*Otkr[21][1])))));
    tstarr[21][2] = (utk[16][2]-(WkIkWk[21][2]+((ik[16][2][2]*Otkr[21][2])+((
      ik[16][2][0]*Otkr[21][0])+(ik[16][2][1]*Otkr[21][1])))));
    tstarr[22][0] = (utk[17][0]-(WkIkWk[22][0]+((ik[17][0][2]*Otkr[22][2])+((
      ik[17][0][0]*Otkr[22][0])+(ik[17][0][1]*Otkr[22][1])))));
    tstarr[22][1] = (utk[17][1]-(WkIkWk[22][1]+((ik[17][1][2]*Otkr[22][2])+((
      ik[17][1][0]*Otkr[22][0])+(ik[17][1][1]*Otkr[22][1])))));
    tstarr[22][2] = (utk[17][2]-(WkIkWk[22][2]+((ik[17][2][2]*Otkr[22][2])+((
      ik[17][2][0]*Otkr[22][0])+(ik[17][2][1]*Otkr[22][1])))));
    tstarr[23][0] = (utk[18][0]-(WkIkWk[23][0]+((ik[18][0][2]*Otkr[23][2])+((
      ik[18][0][0]*Otkr[23][0])+(ik[18][0][1]*Otkr[23][1])))));
    tstarr[23][1] = (utk[18][1]-(WkIkWk[23][1]+((ik[18][1][2]*Otkr[23][2])+((
      ik[18][1][0]*Otkr[23][0])+(ik[18][1][1]*Otkr[23][1])))));
    tstarr[23][2] = (utk[18][2]-(WkIkWk[23][2]+((ik[18][2][2]*Otkr[23][2])+((
      ik[18][2][0]*Otkr[23][0])+(ik[18][2][1]*Otkr[23][1])))));
    tstarr[24][0] = (utk[19][0]-(WkIkWk[24][0]+((ik[19][0][2]*Otkr[24][2])+((
      ik[19][0][0]*Otkr[24][0])+(ik[19][0][1]*Otkr[24][1])))));
    tstarr[24][1] = (utk[19][1]-(WkIkWk[24][1]+((ik[19][1][2]*Otkr[24][2])+((
      ik[19][1][0]*Otkr[24][0])+(ik[19][1][1]*Otkr[24][1])))));
    tstarr[24][2] = (utk[19][2]-(WkIkWk[24][2]+((ik[19][2][2]*Otkr[24][2])+((
      ik[19][2][0]*Otkr[24][0])+(ik[19][2][1]*Otkr[24][1])))));
    tstarr[25][0] = (utk[20][0]-(WkIkWk[25][0]+((ik[20][0][2]*Otkr[25][2])+((
      ik[20][0][0]*Otkr[25][0])+(ik[20][0][1]*Otkr[25][1])))));
    tstarr[25][1] = (utk[20][1]-(WkIkWk[25][1]+((ik[20][1][2]*Otkr[25][2])+((
      ik[20][1][0]*Otkr[25][0])+(ik[20][1][1]*Otkr[25][1])))));
    tstarr[25][2] = (utk[20][2]-(WkIkWk[25][2]+((ik[20][2][2]*Otkr[25][2])+((
      ik[20][2][0]*Otkr[25][0])+(ik[20][2][1]*Otkr[25][1])))));
/*
Now calculate the torques
*/
    sddovpk();
    temp[0] = (((fstarr[8][2]*Vpk[0][8][2])+((fstarr[8][0]*Vpk[0][6][0])+(
      fstarr[8][1]*Vpk[0][8][1])))+(((fstarr[7][2]*Vpk[0][7][2])+((Cik[3][0][1]*
      fstarr[7][1])+(fstarr[7][0]*Vpk[0][7][0])))+(((Cik[3][0][2]*fstarr[5][2])+
      ((Cik[3][0][0]*fstarr[5][0])+(Cik[3][0][1]*fstarr[5][1])))+((fstarr[6][2]*
      Vpk[0][6][2])+((Cik[3][0][1]*fstarr[6][1])+(fstarr[6][0]*Vpk[0][6][0])))))
      );
    temp[1] = (((Cik[3][0][2]*fstarr[12][2])+((fstarr[12][0]*Vpk[0][12][0])+(
      fstarr[12][1]*Vpk[0][12][1])))+(((fstarr[11][2]*Vpk[0][9][2])+((
      fstarr[11][0]*Vpk[0][11][0])+(fstarr[11][1]*Vpk[0][11][1])))+(((
      fstarr[10][2]*Vpk[0][8][2])+((fstarr[10][0]*Vpk[0][10][0])+(fstarr[10][1]*
      Vpk[0][10][1])))+(((fstarr[9][2]*Vpk[0][9][2])+((fstarr[9][0]*Vpk[0][7][0]
      )+(fstarr[9][1]*Vpk[0][9][1])))+temp[0]))));
    temp[2] = (((fstarr[16][2]*Vpk[0][16][2])+((fstarr[16][0]*Vpk[0][16][0])+(
      fstarr[16][1]*Vpk[0][14][1])))+(((fstarr[15][2]*Vpk[0][15][2])+((
      fstarr[15][0]*Vpk[0][13][0])+(fstarr[15][1]*Vpk[0][15][1])))+(((
      fstarr[14][2]*Vpk[0][14][2])+((fstarr[14][0]*Vpk[0][12][0])+(fstarr[14][1]
      *Vpk[0][14][1])))+(((Cik[3][0][2]*fstarr[13][2])+((fstarr[13][0]*
      Vpk[0][13][0])+(fstarr[13][1]*Vpk[0][13][1])))+temp[1]))));
    temp[3] = (((fstarr[20][2]*Vpk[0][20][2])+((fstarr[20][0]*Vpk[0][20][0])+(
      fstarr[20][1]*Vpk[0][14][1])))+(((fstarr[19][2]*Vpk[0][19][2])+((
      fstarr[19][0]*Vpk[0][19][0])+(fstarr[19][1]*Vpk[0][15][1])))+(((
      fstarr[18][2]*Vpk[0][18][2])+((fstarr[18][0]*Vpk[0][18][0])+(fstarr[18][1]
      *Vpk[0][14][1])))+(((fstarr[17][2]*Vpk[0][17][2])+((fstarr[17][0]*
      Vpk[0][17][0])+(fstarr[17][1]*Vpk[0][15][1])))+temp[2]))));
    temp[4] = (((Cik[3][0][2]*fstarr[24][2])+((fstarr[24][0]*Vpk[0][24][0])+(
      fstarr[24][1]*Vpk[0][24][1])))+(((fstarr[23][2]*Vpk[0][23][2])+((
      fstarr[23][0]*Vpk[0][21][0])+(fstarr[23][1]*Vpk[0][23][1])))+(((
      fstarr[22][2]*Vpk[0][22][2])+((fstarr[22][0]*Vpk[0][20][0])+(fstarr[22][1]
      *Vpk[0][22][1])))+(((fstarr[21][2]*Vpk[0][21][2])+((fstarr[21][0]*
      Vpk[0][21][0])+(fstarr[21][1]*Vpk[0][15][1])))+temp[3]))));
    trqout[0] = -(utau[0]+(((fstarr[25][2]*Vpk[0][25][2])+((fstarr[25][0]*
      Vpk[0][25][0])+(fstarr[25][1]*Vpk[0][24][1])))+temp[4]));
    temp[0] = (((fstarr[8][2]*Vpk[1][8][2])+((fstarr[8][0]*Vpk[1][6][0])+(
      fstarr[8][1]*Vpk[1][8][1])))+(((fstarr[7][2]*Vpk[1][7][2])+((Cik[3][1][1]*
      fstarr[7][1])+(fstarr[7][0]*Vpk[1][7][0])))+(((Cik[3][1][2]*fstarr[5][2])+
      ((Cik[3][1][0]*fstarr[5][0])+(Cik[3][1][1]*fstarr[5][1])))+((fstarr[6][2]*
      Vpk[1][6][2])+((Cik[3][1][1]*fstarr[6][1])+(fstarr[6][0]*Vpk[1][6][0])))))
      );
    temp[1] = (((Cik[3][1][2]*fstarr[12][2])+((fstarr[12][0]*Vpk[1][12][0])+(
      fstarr[12][1]*Vpk[1][12][1])))+(((fstarr[11][2]*Vpk[1][9][2])+((
      fstarr[11][0]*Vpk[1][11][0])+(fstarr[11][1]*Vpk[1][11][1])))+(((
      fstarr[10][2]*Vpk[1][8][2])+((fstarr[10][0]*Vpk[1][10][0])+(fstarr[10][1]*
      Vpk[1][10][1])))+(((fstarr[9][2]*Vpk[1][9][2])+((fstarr[9][0]*Vpk[1][7][0]
      )+(fstarr[9][1]*Vpk[1][9][1])))+temp[0]))));
    temp[2] = (((fstarr[16][2]*Vpk[1][16][2])+((fstarr[16][0]*Vpk[1][16][0])+(
      fstarr[16][1]*Vpk[1][14][1])))+(((fstarr[15][2]*Vpk[1][15][2])+((
      fstarr[15][0]*Vpk[1][13][0])+(fstarr[15][1]*Vpk[1][15][1])))+(((
      fstarr[14][2]*Vpk[1][14][2])+((fstarr[14][0]*Vpk[1][12][0])+(fstarr[14][1]
      *Vpk[1][14][1])))+(((Cik[3][1][2]*fstarr[13][2])+((fstarr[13][0]*
      Vpk[1][13][0])+(fstarr[13][1]*Vpk[1][13][1])))+temp[1]))));
    temp[3] = (((fstarr[20][2]*Vpk[1][20][2])+((fstarr[20][0]*Vpk[1][20][0])+(
      fstarr[20][1]*Vpk[1][14][1])))+(((fstarr[19][2]*Vpk[1][19][2])+((
      fstarr[19][0]*Vpk[1][19][0])+(fstarr[19][1]*Vpk[1][15][1])))+(((
      fstarr[18][2]*Vpk[1][18][2])+((fstarr[18][0]*Vpk[1][18][0])+(fstarr[18][1]
      *Vpk[1][14][1])))+(((fstarr[17][2]*Vpk[1][17][2])+((fstarr[17][0]*
      Vpk[1][17][0])+(fstarr[17][1]*Vpk[1][15][1])))+temp[2]))));
    temp[4] = (((Cik[3][1][2]*fstarr[24][2])+((fstarr[24][0]*Vpk[1][24][0])+(
      fstarr[24][1]*Vpk[1][24][1])))+(((fstarr[23][2]*Vpk[1][23][2])+((
      fstarr[23][0]*Vpk[1][21][0])+(fstarr[23][1]*Vpk[1][23][1])))+(((
      fstarr[22][2]*Vpk[1][22][2])+((fstarr[22][0]*Vpk[1][20][0])+(fstarr[22][1]
      *Vpk[1][22][1])))+(((fstarr[21][2]*Vpk[1][21][2])+((fstarr[21][0]*
      Vpk[1][21][0])+(fstarr[21][1]*Vpk[1][15][1])))+temp[3]))));
    trqout[1] = -(utau[1]+(((fstarr[25][2]*Vpk[1][25][2])+((fstarr[25][0]*
      Vpk[1][25][0])+(fstarr[25][1]*Vpk[1][24][1])))+temp[4]));
    temp[0] = (((fstarr[8][2]*Vpk[2][8][2])+((fstarr[8][0]*Vpk[2][6][0])+(
      fstarr[8][1]*Vpk[2][8][1])))+(((fstarr[7][2]*Vpk[2][7][2])+((Cik[3][2][1]*
      fstarr[7][1])+(fstarr[7][0]*Vpk[2][7][0])))+(((Cik[3][2][2]*fstarr[5][2])+
      ((Cik[3][2][0]*fstarr[5][0])+(Cik[3][2][1]*fstarr[5][1])))+((fstarr[6][2]*
      Vpk[2][6][2])+((Cik[3][2][1]*fstarr[6][1])+(fstarr[6][0]*Vpk[2][6][0])))))
      );
    temp[1] = (((Cik[3][2][2]*fstarr[12][2])+((fstarr[12][0]*Vpk[2][12][0])+(
      fstarr[12][1]*Vpk[2][12][1])))+(((fstarr[11][2]*Vpk[2][9][2])+((
      fstarr[11][0]*Vpk[2][11][0])+(fstarr[11][1]*Vpk[2][11][1])))+(((
      fstarr[10][2]*Vpk[2][8][2])+((fstarr[10][0]*Vpk[2][10][0])+(fstarr[10][1]*
      Vpk[2][10][1])))+(((fstarr[9][2]*Vpk[2][9][2])+((fstarr[9][0]*Vpk[2][7][0]
      )+(fstarr[9][1]*Vpk[2][9][1])))+temp[0]))));
    temp[2] = (((fstarr[16][2]*Vpk[2][16][2])+((fstarr[16][0]*Vpk[2][16][0])+(
      fstarr[16][1]*Vpk[2][14][1])))+(((fstarr[15][2]*Vpk[2][15][2])+((
      fstarr[15][0]*Vpk[2][13][0])+(fstarr[15][1]*Vpk[2][15][1])))+(((
      fstarr[14][2]*Vpk[2][14][2])+((fstarr[14][0]*Vpk[2][12][0])+(fstarr[14][1]
      *Vpk[2][14][1])))+(((Cik[3][2][2]*fstarr[13][2])+((fstarr[13][0]*
      Vpk[2][13][0])+(fstarr[13][1]*Vpk[2][13][1])))+temp[1]))));
    temp[3] = (((fstarr[20][2]*Vpk[2][20][2])+((fstarr[20][0]*Vpk[2][20][0])+(
      fstarr[20][1]*Vpk[2][14][1])))+(((fstarr[19][2]*Vpk[2][19][2])+((
      fstarr[19][0]*Vpk[2][19][0])+(fstarr[19][1]*Vpk[2][15][1])))+(((
      fstarr[18][2]*Vpk[2][18][2])+((fstarr[18][0]*Vpk[2][18][0])+(fstarr[18][1]
      *Vpk[2][14][1])))+(((fstarr[17][2]*Vpk[2][17][2])+((fstarr[17][0]*
      Vpk[2][17][0])+(fstarr[17][1]*Vpk[2][15][1])))+temp[2]))));
    temp[4] = (((Cik[3][2][2]*fstarr[24][2])+((fstarr[24][0]*Vpk[2][24][0])+(
      fstarr[24][1]*Vpk[2][24][1])))+(((fstarr[23][2]*Vpk[2][23][2])+((
      fstarr[23][0]*Vpk[2][21][0])+(fstarr[23][1]*Vpk[2][23][1])))+(((
      fstarr[22][2]*Vpk[2][22][2])+((fstarr[22][0]*Vpk[2][20][0])+(fstarr[22][1]
      *Vpk[2][22][1])))+(((fstarr[21][2]*Vpk[2][21][2])+((fstarr[21][0]*
      Vpk[2][21][0])+(fstarr[21][1]*Vpk[2][15][1])))+temp[3]))));
    trqout[2] = -(utau[2]+(((fstarr[25][2]*Vpk[2][25][2])+((fstarr[25][0]*
      Vpk[2][25][0])+(fstarr[25][1]*Vpk[2][24][1])))+temp[4]));
    temp[0] = (((tstarr[5][0]+((fstarr[5][1]*rk[0][2])-(fstarr[5][2]*rk[0][1])))
      +(((fstarr[6][2]*Vpk[3][6][2])+((fstarr[6][0]*Vpk[3][6][0])+(fstarr[6][1]*
      Vpk[3][6][1])))+((tstarr[6][0]*c6)-(tstarr[6][2]*s6))))+(((fstarr[7][2]*
      Vpk[3][7][2])+((fstarr[7][0]*Vpk[3][7][0])+(fstarr[7][1]*Vpk[3][7][1])))+(
      (tstarr[7][0]*c7)-(tstarr[7][2]*s7))));
    temp[1] = ((((fstarr[9][2]*Vpk[3][9][2])+((fstarr[9][0]*Vpk[3][9][0])+(
      fstarr[9][1]*Vpk[3][9][1])))+((tstarr[9][2]*Wpk[3][9][2])+((tstarr[9][0]*
      c7)+(tstarr[9][1]*Wpk[3][9][1]))))+((((fstarr[8][2]*Vpk[3][8][2])+((
      fstarr[8][0]*Vpk[3][8][0])+(fstarr[8][1]*Vpk[3][8][1])))+((tstarr[8][2]*
      Wpk[3][8][2])+((tstarr[8][0]*c6)+(tstarr[8][1]*Wpk[3][8][1]))))+temp[0]));
    temp[2] = ((((fstarr[11][2]*Vpk[3][11][2])+((fstarr[11][0]*Vpk[3][11][0])+(
      fstarr[11][1]*Vpk[3][11][1])))+((tstarr[11][2]*Wpk[3][9][2])+((
      tstarr[11][0]*Wpk[3][11][0])+(tstarr[11][1]*Wpk[3][11][1]))))+((((
      fstarr[10][2]*Vpk[3][10][2])+((fstarr[10][0]*Vpk[3][10][0])+(fstarr[10][1]
      *Vpk[3][10][1])))+((tstarr[10][2]*Wpk[3][8][2])+((tstarr[10][0]*
      Wpk[3][10][0])+(tstarr[10][1]*Wpk[3][10][1]))))+temp[1]));
    temp[3] = ((((fstarr[14][2]*Vpk[3][14][2])+((fstarr[14][0]*Vpk[3][14][0])+(
      fstarr[14][1]*Vpk[3][14][1])))+((tstarr[14][2]*Wpk[3][14][2])+((
      tstarr[14][0]*c12)+(tstarr[14][1]*Wpk[3][14][1]))))+((((fstarr[13][2]*
      Vpk[3][13][2])+((fstarr[13][0]*Vpk[3][13][0])+(fstarr[13][1]*Vpk[3][13][1]
      )))+((tstarr[13][0]*c13)-(tstarr[13][1]*s13)))+((((fstarr[12][2]*
      Vpk[3][12][2])+((fstarr[12][0]*Vpk[3][12][0])+(fstarr[12][1]*Vpk[3][12][1]
      )))+((tstarr[12][0]*c12)+(tstarr[12][1]*s12)))+temp[2])));
    temp[4] = ((((fstarr[16][2]*Vpk[3][16][2])+((fstarr[16][0]*Vpk[3][16][0])+(
      fstarr[16][1]*Vpk[3][16][1])))+((tstarr[16][2]*Wpk[3][16][2])+((
      tstarr[16][0]*Wpk[3][16][0])+(tstarr[16][1]*Wpk[3][14][1]))))+((((
      fstarr[15][2]*Vpk[3][15][2])+((fstarr[15][0]*Vpk[3][15][0])+(fstarr[15][1]
      *Vpk[3][15][1])))+((tstarr[15][2]*Wpk[3][15][2])+((tstarr[15][0]*c13)+(
      tstarr[15][1]*Wpk[3][15][1]))))+temp[3]));
    temp[5] = ((((fstarr[18][2]*Vpk[3][18][2])+((fstarr[18][0]*Vpk[3][18][0])+(
      fstarr[18][1]*Vpk[3][18][1])))+((tstarr[18][2]*Wpk[3][18][2])+((
      tstarr[18][0]*Wpk[3][18][0])+(tstarr[18][1]*Wpk[3][14][1]))))+((((
      fstarr[17][2]*Vpk[3][17][2])+((fstarr[17][0]*Vpk[3][17][0])+(fstarr[17][1]
      *Vpk[3][17][1])))+((tstarr[17][2]*Wpk[3][17][2])+((tstarr[17][0]*
      Wpk[3][17][0])+(tstarr[17][1]*Wpk[3][15][1]))))+temp[4]));
    temp[6] = ((((fstarr[20][2]*Vpk[3][20][2])+((fstarr[20][0]*Vpk[3][20][0])+(
      fstarr[20][1]*Vpk[3][20][1])))+((tstarr[20][2]*Wpk[3][20][2])+((
      tstarr[20][0]*Wpk[3][20][0])+(tstarr[20][1]*Wpk[3][14][1]))))+((((
      fstarr[19][2]*Vpk[3][19][2])+((fstarr[19][0]*Vpk[3][19][0])+(fstarr[19][1]
      *Vpk[3][19][1])))+((tstarr[19][2]*Wpk[3][19][2])+((tstarr[19][0]*
      Wpk[3][19][0])+(tstarr[19][1]*Wpk[3][15][1]))))+temp[5]));
    temp[7] = ((((fstarr[22][2]*Vpk[3][22][2])+((fstarr[22][0]*Vpk[3][22][0])+(
      fstarr[22][1]*Vpk[3][22][1])))+((tstarr[22][2]*Wpk[3][22][2])+((
      tstarr[22][0]*Wpk[3][20][0])+(tstarr[22][1]*Wpk[3][22][1]))))+((((
      fstarr[21][2]*Vpk[3][21][2])+((fstarr[21][0]*Vpk[3][21][0])+(fstarr[21][1]
      *Vpk[3][21][1])))+((tstarr[21][2]*Wpk[3][21][2])+((tstarr[21][0]*
      Wpk[3][21][0])+(tstarr[21][1]*Wpk[3][15][1]))))+temp[6]));
    temp[8] = ((((fstarr[24][2]*Vpk[3][24][2])+((fstarr[24][0]*Vpk[3][24][0])+(
      fstarr[24][1]*Vpk[3][24][1])))+((tstarr[24][0]*c24)-(tstarr[24][1]*s24)))+
      ((((fstarr[23][2]*Vpk[3][23][2])+((fstarr[23][0]*Vpk[3][23][0])+(
      fstarr[23][1]*Vpk[3][23][1])))+((tstarr[23][2]*Wpk[3][23][2])+((
      tstarr[23][0]*Wpk[3][21][0])+(tstarr[23][1]*Wpk[3][23][1]))))+temp[7]));
    trqout[3] = -(utau[3]+((((fstarr[25][2]*Vpk[3][25][2])+((fstarr[25][0]*
      Vpk[3][25][0])+(fstarr[25][1]*Vpk[3][25][1])))+((tstarr[25][2]*
      Wpk[3][25][2])+((tstarr[25][0]*Wpk[3][25][0])-(tstarr[25][1]*s24))))+
      temp[8]));
    temp[0] = (((tstarr[7][1]+((fstarr[7][0]*Vpk[4][7][0])+(fstarr[7][2]*
      Vpk[4][7][2])))+((tstarr[5][1]+((fstarr[5][2]*rk[0][0])-(fstarr[5][0]*
      rk[0][2])))+(tstarr[6][1]+((fstarr[6][0]*Vpk[4][6][0])+(fstarr[6][2]*
      Vpk[4][6][2])))))+(((fstarr[8][2]*Vpk[4][8][2])+((fstarr[8][0]*
      Vpk[4][8][0])+(fstarr[8][1]*Vpk[4][8][1])))+((tstarr[8][1]*c8)+(
      tstarr[8][2]*s8))));
    temp[1] = ((((fstarr[10][2]*Vpk[4][10][2])+((fstarr[10][0]*Vpk[4][10][0])+(
      fstarr[10][1]*Vpk[4][10][1])))+((tstarr[10][2]*s8)+((tstarr[10][0]*
      Wpk[4][10][0])+(tstarr[10][1]*Wpk[4][10][1]))))+((((fstarr[9][2]*
      Vpk[4][9][2])+((fstarr[9][0]*Vpk[4][9][0])+(fstarr[9][1]*Vpk[4][9][1])))+(
      (tstarr[9][1]*c9)-(tstarr[9][2]*s9)))+temp[0]));
    temp[2] = ((((fstarr[13][2]*Vpk[4][13][2])+((fstarr[13][0]*Vpk[4][13][0])+(
      fstarr[13][1]*Vpk[4][13][1])))+((tstarr[13][0]*s13)+(tstarr[13][1]*c13)))+
      ((((fstarr[12][2]*Vpk[4][12][2])+((fstarr[12][0]*Vpk[4][12][0])+(
      fstarr[12][1]*Vpk[4][12][1])))+((tstarr[12][1]*c12)-(tstarr[12][0]*s12)))+
      ((((fstarr[11][2]*Vpk[4][11][2])+((fstarr[11][0]*Vpk[4][11][0])+(
      fstarr[11][1]*Vpk[4][11][1])))+(((tstarr[11][0]*Wpk[4][11][0])+(
      tstarr[11][1]*Wpk[4][11][1]))-(tstarr[11][2]*s9)))+temp[1])));
    temp[3] = ((((fstarr[15][2]*Vpk[4][15][2])+((fstarr[15][0]*Vpk[4][15][0])+(
      fstarr[15][1]*Vpk[4][15][1])))+((tstarr[15][2]*Wpk[4][15][2])+((
      tstarr[15][0]*s13)+(tstarr[15][1]*Wpk[4][15][1]))))+((((fstarr[14][2]*
      Vpk[4][14][2])+((fstarr[14][0]*Vpk[4][14][0])+(fstarr[14][1]*Vpk[4][14][1]
      )))+((tstarr[14][2]*Wpk[4][14][2])+((tstarr[14][1]*Wpk[4][14][1])-(
      tstarr[14][0]*s12))))+temp[2]));
    temp[4] = ((((fstarr[17][2]*Vpk[4][17][2])+((fstarr[17][0]*Vpk[4][17][0])+(
      fstarr[17][1]*Vpk[4][17][1])))+((tstarr[17][2]*Wpk[4][17][2])+((
      tstarr[17][0]*Wpk[4][17][0])+(tstarr[17][1]*Wpk[4][15][1]))))+((((
      fstarr[16][2]*Vpk[4][16][2])+((fstarr[16][0]*Vpk[4][16][0])+(fstarr[16][1]
      *Vpk[4][16][1])))+((tstarr[16][2]*Wpk[4][16][2])+((tstarr[16][0]*
      Wpk[4][16][0])+(tstarr[16][1]*Wpk[4][14][1]))))+temp[3]));
    temp[5] = ((((fstarr[19][2]*Vpk[4][19][2])+((fstarr[19][0]*Vpk[4][19][0])+(
      fstarr[19][1]*Vpk[4][19][1])))+((tstarr[19][2]*Wpk[4][19][2])+((
      tstarr[19][0]*Wpk[4][19][0])+(tstarr[19][1]*Wpk[4][15][1]))))+((((
      fstarr[18][2]*Vpk[4][18][2])+((fstarr[18][0]*Vpk[4][18][0])+(fstarr[18][1]
      *Vpk[4][18][1])))+((tstarr[18][2]*Wpk[4][18][2])+((tstarr[18][0]*
      Wpk[4][18][0])+(tstarr[18][1]*Wpk[4][14][1]))))+temp[4]));
    temp[6] = ((((fstarr[21][2]*Vpk[4][21][2])+((fstarr[21][0]*Vpk[4][21][0])+(
      fstarr[21][1]*Vpk[4][21][1])))+((tstarr[21][2]*Wpk[4][21][2])+((
      tstarr[21][0]*Wpk[4][21][0])+(tstarr[21][1]*Wpk[4][15][1]))))+((((
      fstarr[20][2]*Vpk[4][20][2])+((fstarr[20][0]*Vpk[4][20][0])+(fstarr[20][1]
      *Vpk[4][20][1])))+((tstarr[20][2]*Wpk[4][20][2])+((tstarr[20][0]*
      Wpk[4][20][0])+(tstarr[20][1]*Wpk[4][14][1]))))+temp[5]));
    temp[7] = ((((fstarr[23][2]*Vpk[4][23][2])+((fstarr[23][0]*Vpk[4][23][0])+(
      fstarr[23][1]*Vpk[4][23][1])))+((tstarr[23][2]*Wpk[4][23][2])+((
      tstarr[23][0]*Wpk[4][21][0])+(tstarr[23][1]*Wpk[4][23][1]))))+((((
      fstarr[22][2]*Vpk[4][22][2])+((fstarr[22][0]*Vpk[4][22][0])+(fstarr[22][1]
      *Vpk[4][22][1])))+((tstarr[22][2]*Wpk[4][22][2])+((tstarr[22][0]*
      Wpk[4][20][0])+(tstarr[22][1]*Wpk[4][22][1]))))+temp[6]));
    trqout[4] = -(utau[4]+((((fstarr[25][2]*Vpk[4][25][2])+((fstarr[25][0]*
      Vpk[4][25][0])+(fstarr[25][1]*Vpk[4][25][1])))+((tstarr[25][2]*
      Wpk[4][25][2])+((tstarr[25][0]*Wpk[4][25][0])+(tstarr[25][1]*c24))))+((((
      fstarr[24][2]*Vpk[4][24][2])+((fstarr[24][0]*Vpk[4][24][0])+(fstarr[24][1]
      *Vpk[4][24][1])))+((tstarr[24][0]*s24)+(tstarr[24][1]*c24)))+temp[7])));
    temp[0] = (((tstarr[5][2]+((fstarr[5][0]*rk[0][1])-(fstarr[5][1]*rk[0][0])))
      +(((fstarr[6][2]*Vpk[5][6][2])+((fstarr[6][0]*Vpk[5][6][0])+(fstarr[6][1]*
      Vpk[5][6][1])))+((tstarr[6][0]*s6)+(tstarr[6][2]*c6))))+(((fstarr[7][2]*
      Vpk[5][7][2])+((fstarr[7][0]*Vpk[5][7][0])+(fstarr[7][1]*Vpk[5][7][1])))+(
      (tstarr[7][0]*s7)+(tstarr[7][2]*c7))));
    temp[1] = ((((fstarr[9][2]*Vpk[5][9][2])+((fstarr[9][0]*Vpk[5][9][0])+(
      fstarr[9][1]*Vpk[5][9][1])))+((tstarr[9][2]*Wpk[5][9][2])+((tstarr[9][0]*
      s7)+(tstarr[9][1]*Wpk[5][9][1]))))+((((fstarr[8][2]*Vpk[5][8][2])+((
      fstarr[8][0]*Vpk[5][8][0])+(fstarr[8][1]*Vpk[5][8][1])))+((tstarr[8][2]*
      Wpk[5][8][2])+((tstarr[8][0]*s6)+(tstarr[8][1]*Wpk[5][8][1]))))+temp[0]));
    temp[2] = ((((fstarr[11][2]*Vpk[5][11][2])+((fstarr[11][0]*Vpk[5][11][0])+(
      fstarr[11][1]*Vpk[5][11][1])))+((tstarr[11][2]*Wpk[5][9][2])+((
      tstarr[11][0]*Wpk[5][11][0])+(tstarr[11][1]*Wpk[5][11][1]))))+((((
      fstarr[10][2]*Vpk[5][10][2])+((fstarr[10][0]*Vpk[5][10][0])+(fstarr[10][1]
      *Vpk[5][10][1])))+((tstarr[10][2]*Wpk[5][8][2])+((tstarr[10][0]*
      Wpk[5][10][0])+(tstarr[10][1]*Wpk[5][10][1]))))+temp[1]));
    temp[3] = ((((fstarr[15][2]*Vpk[5][15][2])+((fstarr[15][0]*Vpk[5][15][0])+(
      fstarr[15][1]*Vpk[5][15][1])))+((tstarr[15][1]*s15)+(tstarr[15][2]*c15)))+
      (((tstarr[13][2]+((fstarr[13][0]*Vpk[5][13][0])+(fstarr[13][1]*
      Vpk[5][13][1])))+((tstarr[12][2]+((fstarr[12][0]*Vpk[5][12][0])+(
      fstarr[12][1]*Vpk[5][12][1])))+temp[2]))+(((fstarr[14][2]*Vpk[5][14][2])+(
      (fstarr[14][0]*Vpk[5][14][0])+(fstarr[14][1]*Vpk[5][14][1])))+((
      tstarr[14][2]*c14)-(tstarr[14][1]*s14)))));
    temp[4] = ((((fstarr[17][2]*Vpk[5][17][2])+((fstarr[17][0]*Vpk[5][17][0])+(
      fstarr[17][1]*Vpk[5][17][1])))+((tstarr[17][2]*Wpk[5][17][2])+((
      tstarr[17][0]*Wpk[5][17][0])+(tstarr[17][1]*s15))))+((((fstarr[16][2]*
      Vpk[5][16][2])+((fstarr[16][0]*Vpk[5][16][0])+(fstarr[16][1]*Vpk[5][16][1]
      )))+((tstarr[16][2]*Wpk[5][16][2])+((tstarr[16][0]*Wpk[5][16][0])-(
      tstarr[16][1]*s14))))+temp[3]));
    temp[5] = ((((fstarr[19][2]*Vpk[5][19][2])+((fstarr[19][0]*Vpk[5][19][0])+(
      fstarr[19][1]*Vpk[5][19][1])))+((tstarr[19][2]*Wpk[5][19][2])+((
      tstarr[19][0]*Wpk[5][19][0])+(tstarr[19][1]*s15))))+((((fstarr[18][2]*
      Vpk[5][18][2])+((fstarr[18][0]*Vpk[5][18][0])+(fstarr[18][1]*Vpk[5][18][1]
      )))+((tstarr[18][2]*Wpk[5][18][2])+((tstarr[18][0]*Wpk[5][18][0])-(
      tstarr[18][1]*s14))))+temp[4]));
    temp[6] = ((((fstarr[21][2]*Vpk[5][21][2])+((fstarr[21][0]*Vpk[5][21][0])+(
      fstarr[21][1]*Vpk[5][21][1])))+((tstarr[21][2]*Wpk[5][21][2])+((
      tstarr[21][0]*Wpk[5][21][0])+(tstarr[21][1]*s15))))+((((fstarr[20][2]*
      Vpk[5][20][2])+((fstarr[20][0]*Vpk[5][20][0])+(fstarr[20][1]*Vpk[5][20][1]
      )))+((tstarr[20][2]*Wpk[5][20][2])+((tstarr[20][0]*Wpk[5][20][0])-(
      tstarr[20][1]*s14))))+temp[5]));
    temp[7] = ((((fstarr[23][2]*Vpk[5][23][2])+((fstarr[23][0]*Vpk[5][23][0])+(
      fstarr[23][1]*Vpk[5][23][1])))+((tstarr[23][2]*Wpk[5][23][2])+((
      tstarr[23][0]*Wpk[5][21][0])+(tstarr[23][1]*Wpk[5][23][1]))))+((((
      fstarr[22][2]*Vpk[5][22][2])+((fstarr[22][0]*Vpk[5][22][0])+(fstarr[22][1]
      *Vpk[5][22][1])))+((tstarr[22][2]*Wpk[5][22][2])+((tstarr[22][0]*
      Wpk[5][20][0])+(tstarr[22][1]*Wpk[5][22][1]))))+temp[6]));
    trqout[5] = -(utau[5]+(((tstarr[24][2]+((fstarr[24][0]*Vpk[5][24][0])+(
      fstarr[24][1]*Vpk[5][24][1])))+temp[7])+(((fstarr[25][2]*Vpk[5][25][2])+((
      fstarr[25][0]*Vpk[5][25][0])+(fstarr[25][1]*Vpk[5][25][1])))+((
      tstarr[25][0]*s25)+(tstarr[25][2]*c25)))));
    trqout[6] = -(utau[6]+((((fstarr[10][2]*Vpk[6][10][2])+((fstarr[10][0]*
      Vpk[6][10][0])+(fstarr[10][1]*Vpk[6][10][1])))+(((tstarr[10][0]*
      Wpk[6][10][0])+(tstarr[10][1]*Wpk[6][10][1]))-(tstarr[10][2]*s8)))+((((
      fstarr[6][0]*rk[1][2])-(fstarr[6][2]*rk[1][0]))-tstarr[6][1])+(((
      fstarr[8][2]*Vpk[6][8][2])+((fstarr[8][0]*Vpk[6][8][0])+(fstarr[8][1]*
      Vpk[6][8][1])))-((tstarr[8][1]*c8)+(tstarr[8][2]*s8))))));
    trqout[7] = -(utau[7]+((((fstarr[11][2]*Vpk[7][11][2])+((fstarr[11][0]*
      Vpk[7][11][0])+(fstarr[11][1]*Vpk[7][11][1])))+((tstarr[11][2]*s9)+((
      tstarr[11][0]*Wpk[7][11][0])+(tstarr[11][1]*Wpk[7][11][1]))))+((((
      fstarr[7][0]*rk[2][2])-(fstarr[7][2]*rk[2][0]))-tstarr[7][1])+(((
      fstarr[9][2]*Vpk[7][9][2])+((fstarr[9][0]*Vpk[7][9][0])+(fstarr[9][1]*
      Vpk[7][9][1])))+((tstarr[9][2]*s9)-(tstarr[9][1]*c9))))));
    trqout[8] = -(utau[8]+((((fstarr[8][2]*rk[3][1])-(fstarr[8][1]*rk[3][2]))-
      tstarr[8][0])+(((fstarr[10][2]*Vpk[8][10][2])+((fstarr[10][0]*
      Vpk[8][10][0])+(fstarr[10][1]*Vpk[8][10][1])))-((tstarr[10][0]*c10)+(
      tstarr[10][1]*s10)))));
    trqout[9] = -(utau[9]+((tstarr[9][0]+((fstarr[9][1]*rk[4][2])-(fstarr[9][2]*
      rk[4][1])))+(((fstarr[11][2]*Vpk[9][11][2])+((fstarr[11][0]*Vpk[9][11][0])
      +(fstarr[11][1]*Vpk[9][11][1])))+((tstarr[11][0]*c11)-(tstarr[11][1]*s11))
      )));
    trqout[10] = -(utau[10]+(((fstarr[10][1]*rk[5][0])-(fstarr[10][0]*rk[5][1]))
      -tstarr[10][2]));
    trqout[11] = -(utau[11]+(tstarr[11][2]+((fstarr[11][0]*rk[6][1])-(
      fstarr[11][1]*rk[6][0]))));
    temp[0] = ((((fstarr[16][2]*Vpk[12][16][2])+((fstarr[16][0]*Vpk[12][16][0])+
      (fstarr[16][1]*Vpk[12][16][1])))+((tstarr[16][2]*Wpk[12][16][2])+((
      tstarr[16][0]*Wpk[12][16][0])+(tstarr[16][1]*s14))))+((((fstarr[12][1]*
      rk[7][0])-(fstarr[12][0]*rk[7][1]))-tstarr[12][2])+(((fstarr[14][2]*
      Vpk[12][14][2])+((fstarr[14][0]*Vpk[12][14][0])+(fstarr[14][1]*
      Vpk[12][14][1])))+((tstarr[14][1]*s14)-(tstarr[14][2]*c14)))));
    temp[1] = ((((fstarr[20][2]*Vpk[12][20][2])+((fstarr[20][0]*Vpk[12][20][0])+
      (fstarr[20][1]*Vpk[12][20][1])))+((tstarr[20][2]*Wpk[12][20][2])+((
      tstarr[20][0]*Wpk[12][20][0])+(tstarr[20][1]*s14))))+((((fstarr[18][2]*
      Vpk[12][18][2])+((fstarr[18][0]*Vpk[12][18][0])+(fstarr[18][1]*
      Vpk[12][18][1])))+((tstarr[18][2]*Wpk[12][18][2])+((tstarr[18][0]*
      Wpk[12][18][0])+(tstarr[18][1]*s14))))+temp[0]));
    trqout[12] = -(utau[12]+((((fstarr[22][2]*Vpk[12][22][2])+((fstarr[22][0]*
      Vpk[12][22][0])+(fstarr[22][1]*Vpk[12][22][1])))+((tstarr[22][2]*
      Wpk[12][22][2])+((tstarr[22][0]*Wpk[12][20][0])+(tstarr[22][1]*
      Wpk[12][22][1]))))+temp[1]));
    temp[0] = (((tstarr[13][2]+((fstarr[13][0]*rk[8][1])-(fstarr[13][1]*rk[8][0]
      )))+(((fstarr[15][2]*Vpk[13][15][2])+((fstarr[15][0]*Vpk[13][15][0])+(
      fstarr[15][1]*Vpk[13][15][1])))+((tstarr[15][1]*s15)+(tstarr[15][2]*c15)))
      )+(((fstarr[17][2]*Vpk[13][17][2])+((fstarr[17][0]*Vpk[13][17][0])+(
      fstarr[17][1]*Vpk[13][17][1])))+((tstarr[17][2]*Wpk[13][17][2])+((
      tstarr[17][0]*Wpk[13][17][0])+(tstarr[17][1]*s15)))));
    temp[1] = ((((fstarr[21][2]*Vpk[13][21][2])+((fstarr[21][0]*Vpk[13][21][0])+
      (fstarr[21][1]*Vpk[13][21][1])))+((tstarr[21][2]*Wpk[13][21][2])+((
      tstarr[21][0]*Wpk[13][21][0])+(tstarr[21][1]*s15))))+((((fstarr[19][2]*
      Vpk[13][19][2])+((fstarr[19][0]*Vpk[13][19][0])+(fstarr[19][1]*
      Vpk[13][19][1])))+((tstarr[19][2]*Wpk[13][19][2])+((tstarr[19][0]*
      Wpk[13][19][0])+(tstarr[19][1]*s15))))+temp[0]));
    trqout[13] = -(utau[13]+((((fstarr[23][2]*Vpk[13][23][2])+((fstarr[23][0]*
      Vpk[13][23][0])+(fstarr[23][1]*Vpk[13][23][1])))+((tstarr[23][2]*
      Wpk[13][23][2])+((tstarr[23][0]*Wpk[13][21][0])+(tstarr[23][1]*
      Wpk[13][23][1]))))+temp[1]));
    temp[0] = ((((fstarr[18][2]*Vpk[14][18][2])+((fstarr[18][0]*Vpk[14][18][0])+
      (fstarr[18][1]*Vpk[14][18][1])))+((tstarr[18][0]*Wpk[14][18][0])+(
      tstarr[18][2]*Wpk[14][18][2])))+((((fstarr[14][2]*rk[9][1])-(fstarr[14][1]
      *rk[9][2]))-tstarr[14][0])+(((fstarr[16][2]*Vpk[14][16][2])+((
      fstarr[16][0]*Vpk[14][16][0])+(fstarr[16][1]*Vpk[14][16][1])))+((
      tstarr[16][2]*s16)-(tstarr[16][0]*c16)))));
    trqout[14] = -(utau[14]+((((fstarr[22][2]*Vpk[14][22][2])+((fstarr[22][0]*
      Vpk[14][22][0])+(fstarr[22][1]*Vpk[14][22][1])))+((tstarr[22][2]*
      Wpk[14][22][2])+((tstarr[22][0]*Wpk[14][20][0])+(tstarr[22][1]*
      Wpk[14][22][1]))))+((((fstarr[20][2]*Vpk[14][20][2])+((fstarr[20][0]*
      Vpk[14][20][0])+(fstarr[20][1]*Vpk[14][20][1])))+((tstarr[20][0]*
      Wpk[14][20][0])+(tstarr[20][2]*Wpk[14][20][2])))+temp[0])));
    temp[0] = (((tstarr[15][0]+((fstarr[15][1]*rk[10][2])-(fstarr[15][2]*
      rk[10][1])))+(((fstarr[17][2]*Vpk[15][17][2])+((fstarr[17][0]*
      Vpk[15][17][0])+(fstarr[17][1]*Vpk[15][17][1])))+((tstarr[17][0]*c17)-(
      tstarr[17][2]*s17))))+(((fstarr[19][2]*Vpk[15][19][2])+((fstarr[19][0]*
      Vpk[15][19][0])+(fstarr[19][1]*Vpk[15][19][1])))+((tstarr[19][0]*
      Wpk[15][19][0])+(tstarr[19][2]*Wpk[15][19][2]))));
    trqout[15] = -(utau[15]+((((fstarr[23][2]*Vpk[15][23][2])+((fstarr[23][0]*
      Vpk[15][23][0])+(fstarr[23][1]*Vpk[15][23][1])))+((tstarr[23][2]*
      Wpk[15][23][2])+((tstarr[23][0]*Wpk[15][21][0])+(tstarr[23][1]*
      Wpk[15][23][1]))))+((((fstarr[21][2]*Vpk[15][21][2])+((fstarr[21][0]*
      Vpk[15][21][0])+(fstarr[21][1]*Vpk[15][21][1])))+((tstarr[21][0]*
      Wpk[15][21][0])+(tstarr[21][2]*Wpk[15][21][2])))+temp[0])));
    trqout[16] = -(utau[16]+((((fstarr[22][2]*Vpk[16][22][2])+((fstarr[22][0]*
      Vpk[16][22][0])+(fstarr[22][1]*Vpk[16][22][1])))-((tstarr[22][1]*c22)+(
      tstarr[22][2]*s22)))+((((fstarr[20][0]*Vpk[16][20][0])+(fstarr[20][2]*
      Vpk[16][20][2]))-tstarr[20][1])+((((fstarr[16][0]*rk[11][2])-(
      fstarr[16][2]*rk[11][0]))-tstarr[16][1])+(((fstarr[18][0]*Vpk[16][18][0])+
      (fstarr[18][2]*Vpk[16][18][2]))-tstarr[18][1])))));
    trqout[17] = -(utau[17]+((((fstarr[23][2]*Vpk[17][23][2])+((fstarr[23][0]*
      Vpk[17][23][0])+(fstarr[23][1]*Vpk[17][23][1])))+((tstarr[23][2]*s23)-(
      tstarr[23][1]*c23)))+((((fstarr[21][0]*Vpk[17][21][0])+(fstarr[21][2]*
      Vpk[17][21][2]))-tstarr[21][1])+((((fstarr[17][0]*rk[12][2])-(
      fstarr[17][2]*rk[12][0]))-tstarr[17][1])+(((fstarr[19][0]*Vpk[17][19][0])+
      (fstarr[19][2]*Vpk[17][19][2]))-tstarr[19][1])))));
    trqout[18] = -(utau[18]+((((fstarr[22][2]*Vpk[18][22][2])+((fstarr[22][0]*
      Vpk[18][22][0])+(fstarr[22][1]*Vpk[18][22][1])))-((tstarr[22][1]*c22)+(
      tstarr[22][2]*s22)))+((((fstarr[18][0]*rk[13][2])-(fstarr[18][2]*rk[13][0]
      ))-tstarr[18][1])+(((fstarr[20][0]*Vpk[18][20][0])+(fstarr[20][2]*
      Vpk[18][20][2]))-tstarr[20][1]))));
    trqout[19] = -(utau[19]+((((fstarr[23][2]*Vpk[19][23][2])+((fstarr[23][0]*
      Vpk[19][23][0])+(fstarr[23][1]*Vpk[19][23][1])))+((tstarr[23][2]*s23)-(
      tstarr[23][1]*c23)))+((((fstarr[19][0]*rk[14][2])-(fstarr[19][2]*rk[14][0]
      ))-tstarr[19][1])+(((fstarr[21][0]*Vpk[19][21][0])+(fstarr[21][2]*
      Vpk[19][21][2]))-tstarr[21][1]))));
    trqout[20] = -(utau[20]+((((fstarr[20][0]*rk[15][2])-(fstarr[20][2]*
      rk[15][0]))-tstarr[20][1])+(((fstarr[22][2]*Vpk[20][22][2])+((
      fstarr[22][0]*Vpk[20][22][0])+(fstarr[22][1]*Vpk[20][22][1])))-((
      tstarr[22][1]*c22)+(tstarr[22][2]*s22)))));
    trqout[21] = -(utau[21]+((((fstarr[21][0]*rk[16][2])-(fstarr[21][2]*
      rk[16][0]))-tstarr[21][1])+(((fstarr[23][2]*Vpk[21][23][2])+((
      fstarr[23][0]*Vpk[21][23][0])+(fstarr[23][1]*Vpk[21][23][1])))+((
      tstarr[23][2]*s23)-(tstarr[23][1]*c23)))));
    trqout[22] = -(utau[22]+(((fstarr[22][2]*rk[17][1])-(fstarr[22][1]*rk[17][2]
      ))-tstarr[22][0]));
    trqout[23] = -(utau[23]+(tstarr[23][0]+((fstarr[23][1]*rk[18][2])-(
      fstarr[23][2]*rk[18][1]))));
    trqout[24] = -(utau[24]+((tstarr[24][2]+((fstarr[24][0]*rk[19][1])-(
      fstarr[24][1]*rk[19][0])))+(((fstarr[25][2]*Vpk[24][25][2])+((
      fstarr[25][0]*Vpk[24][25][0])+(fstarr[25][1]*Vpk[24][25][1])))+((
      tstarr[25][0]*s25)+(tstarr[25][2]*c25)))));
    trqout[25] = -(utau[25]+(((fstarr[25][0]*rk[20][2])-(fstarr[25][2]*rk[20][0]
      ))-tstarr[25][1]));
/*
Op counts below do not include called subroutines
*/
/*
 Used 0.02 seconds CPU time,
 0 additional bytes of memory.
 Equations contain 1815 adds/subtracts/negates
                   1692 multiplies
                      0 divides
                    384 assignments
*/
}

void sdcomptrq(double udotin[26],
    double trqout[26])
{
/* Compute hinge torques to produce these udots, ignoring constraints
*/
    double multin[1];

    if ((roustate != 2) && (roustate != 3)) {
        sdseterr(60,23);
        return;
    }
    sdfulltrq(udotin,multin,trqout);
}

void sdmulttrq(double multin[1],
    double trqout[26])
{
/* Compute hinge trqs which would be produced by these mults.
*/
    int i;

    if ((roustate != 2) && (roustate != 3)) {
        sdseterr(65,23);
        return;
    }
    for (i = 0; i < 26; i++) {
        trqout[i] = 0.;
    }
}

void sdrhs(void)
{
/*
Generated 01-Mar-2006 15:25:51 by SD/FAST, Kane's formulation
(sdfast B.2.8 #30123) on machine ID unknown
Copyright (c) 1990-1997 Symbolic Dynamics, Inc.
Copyright (c) 1990-1997 Parametric Technology Corp.
RESTRICTED RIGHTS LEGEND: Use, duplication, or disclosure by the U.S.
Government is subject to restrictions as set forth in subparagraph
(c)(1)(ii) of the Rights in Technical Data and Computer Software
clause at DFARS 52.227-7013 and similar clauses in the FAR and NASA
FAR Supplement.  Symbolic Dynamics, Inc., Mountain View, CA 94041
*/

/*
Compute hinge torques for tree hinges
*/
    tauc[0] = utau[0];
    tauc[1] = utau[1];
    tauc[2] = utau[2];
    tauc[3] = utau[3];
    tauc[4] = utau[4];
    tauc[5] = utau[5];
    tauc[6] = utau[6];
    tauc[7] = utau[7];
    tauc[8] = utau[8];
    tauc[9] = utau[9];
    tauc[10] = utau[10];
    tauc[11] = utau[11];
    tauc[12] = utau[12];
    tauc[13] = utau[13];
    tauc[14] = utau[14];
    tauc[15] = utau[15];
    tauc[16] = utau[16];
    tauc[17] = utau[17];
    tauc[18] = utau[18];
    tauc[19] = utau[19];
    tauc[20] = utau[20];
    tauc[21] = utau[21];
    tauc[22] = utau[22];
    tauc[23] = utau[23];
    tauc[24] = utau[24];
    tauc[25] = utau[25];
    sddoiner();
/*
Compute onk & onb (angular accels in N)
*/
    Onkb[6][0] = ((udot[3]*c6)+(udot[5]*s6));
    Onkb[6][1] = (udot[4]-udot[6]);
    Onkb[6][2] = ((udot[5]*c6)-(udot[3]*s6));
    Onkb[7][0] = ((udot[3]*c7)+(udot[5]*s7));
    Onkb[7][1] = (udot[4]-udot[7]);
    Onkb[7][2] = ((udot[5]*c7)-(udot[3]*s7));
    Onkb[8][0] = (Onkb[6][0]-udot[8]);
    Onkb[8][1] = ((Onkb[6][1]*c8)-(Onkb[6][2]*s8));
    Onkb[8][2] = ((Onkb[6][1]*s8)+(Onkb[6][2]*c8));
    Onkb[9][0] = (Onkb[7][0]+udot[9]);
    Onkb[9][1] = ((Onkb[7][1]*c9)+(Onkb[7][2]*s9));
    Onkb[9][2] = ((Onkb[7][2]*c9)-(Onkb[7][1]*s9));
    Onkb[10][0] = ((Onkb[8][0]*c10)-(Onkb[8][1]*s10));
    Onkb[10][1] = ((Onkb[8][0]*s10)+(Onkb[8][1]*c10));
    Onkb[10][2] = (Onkb[8][2]-udot[10]);
    Onkb[11][0] = ((Onkb[9][0]*c11)+(Onkb[9][1]*s11));
    Onkb[11][1] = ((Onkb[9][1]*c11)-(Onkb[9][0]*s11));
    Onkb[11][2] = (Onkb[9][2]+udot[11]);
    Onkb[12][0] = ((udot[3]*c12)-(udot[4]*s12));
    Onkb[12][1] = ((udot[3]*s12)+(udot[4]*c12));
    Onkb[12][2] = (udot[5]-udot[12]);
    Onkb[13][0] = ((udot[3]*c13)+(udot[4]*s13));
    Onkb[13][1] = ((udot[4]*c13)-(udot[3]*s13));
    Onkb[13][2] = (udot[5]+udot[13]);
    Onkb[14][0] = (Onkb[12][0]-udot[14]);
    Onkb[14][1] = ((Onkb[12][1]*c14)-(Onkb[12][2]*s14));
    Onkb[14][2] = ((Onkb[12][1]*s14)+(Onkb[12][2]*c14));
    Onkb[15][0] = (Onkb[13][0]+udot[15]);
    Onkb[15][1] = ((Onkb[13][1]*c15)+(Onkb[13][2]*s15));
    Onkb[15][2] = ((Onkb[13][2]*c15)-(Onkb[13][1]*s15));
    Onkb[16][0] = ((Onkb[14][0]*c16)+(Onkb[14][2]*s16));
    Onkb[16][1] = (Onkb[14][1]-udot[16]);
    Onkb[16][2] = ((Onkb[14][2]*c16)-(Onkb[14][0]*s16));
    Onkb[17][0] = ((Onkb[15][0]*c17)+(Onkb[15][2]*s17));
    Onkb[17][1] = (Onkb[15][1]-udot[17]);
    Onkb[17][2] = ((Onkb[15][2]*c17)-(Onkb[15][0]*s17));
    Onkb[18][0] = ((Onkb[16][0]*c18)+(Onkb[16][2]*s18));
    Onkb[18][1] = (Onkb[16][1]-udot[18]);
    Onkb[18][2] = ((Onkb[16][2]*c18)-(Onkb[16][0]*s18));
    Onkb[19][0] = ((Onkb[17][0]*c19)+(Onkb[17][2]*s19));
    Onkb[19][1] = (Onkb[17][1]-udot[19]);
    Onkb[19][2] = ((Onkb[17][2]*c19)-(Onkb[17][0]*s19));
    Onkb[20][0] = ((Onkb[18][0]*c20)+(Onkb[18][2]*s20));
    Onkb[20][1] = (Onkb[18][1]-udot[20]);
    Onkb[20][2] = ((Onkb[18][2]*c20)-(Onkb[18][0]*s20));
    Onkb[21][0] = ((Onkb[19][0]*c21)+(Onkb[19][2]*s21));
    Onkb[21][1] = (Onkb[19][1]-udot[21]);
    Onkb[21][2] = ((Onkb[19][2]*c21)-(Onkb[19][0]*s21));
    Onkb[22][0] = (Onkb[20][0]-udot[22]);
    Onkb[22][1] = ((Onkb[20][1]*c22)-(Onkb[20][2]*s22));
    Onkb[22][2] = ((Onkb[20][1]*s22)+(Onkb[20][2]*c22));
    Onkb[23][0] = (Onkb[21][0]+udot[23]);
    Onkb[23][1] = ((Onkb[21][1]*c23)+(Onkb[21][2]*s23));
    Onkb[23][2] = ((Onkb[21][2]*c23)-(Onkb[21][1]*s23));
    Onkb[24][0] = ((udot[3]*c24)+(udot[4]*s24));
    Onkb[24][1] = ((udot[4]*c24)-(udot[3]*s24));
    Onkb[24][2] = (udot[5]+udot[24]);
    Onkb[25][0] = ((Onkb[24][0]*c25)+(Onkb[24][2]*s25));
    Onkb[25][1] = (Onkb[24][1]-udot[25]);
    Onkb[25][2] = ((Onkb[24][2]*c25)-(Onkb[24][0]*s25));
    onk[6][0] = (Onkb[6][0]+Otk[6][0]);
    onk[6][2] = (Onkb[6][2]+Otk[6][2]);
    onk[7][0] = (Onkb[7][0]+Otk[7][0]);
    onk[7][2] = (Onkb[7][2]+Otk[7][2]);
    onk[8][0] = (Onkb[8][0]+Otk[6][0]);
    onk[8][1] = (Onkb[8][1]+Otk[8][1]);
    onk[8][2] = (Onkb[8][2]+Otk[8][2]);
    onk[9][0] = (Onkb[9][0]+Otk[7][0]);
    onk[9][1] = (Onkb[9][1]+Otk[9][1]);
    onk[9][2] = (Onkb[9][2]+Otk[9][2]);
    onk[10][0] = (Onkb[10][0]+Otk[10][0]);
    onk[10][1] = (Onkb[10][1]+Otk[10][1]);
    onk[10][2] = (Onkb[10][2]+Otk[8][2]);
    onk[11][0] = (Onkb[11][0]+Otk[11][0]);
    onk[11][1] = (Onkb[11][1]+Otk[11][1]);
    onk[11][2] = (Onkb[11][2]+Otk[9][2]);
    onk[12][0] = (Onkb[12][0]+Otk[12][0]);
    onk[12][1] = (Onkb[12][1]+Otk[12][1]);
    onk[13][0] = (Onkb[13][0]+Otk[13][0]);
    onk[13][1] = (Onkb[13][1]+Otk[13][1]);
    onk[14][0] = (Onkb[14][0]+Otk[12][0]);
    onk[14][1] = (Onkb[14][1]+Otk[14][1]);
    onk[14][2] = (Onkb[14][2]+Otk[14][2]);
    onk[15][0] = (Onkb[15][0]+Otk[13][0]);
    onk[15][1] = (Onkb[15][1]+Otk[15][1]);
    onk[15][2] = (Onkb[15][2]+Otk[15][2]);
    onk[16][0] = (Onkb[16][0]+Otk[16][0]);
    onk[16][1] = (Onkb[16][1]+Otk[14][1]);
    onk[16][2] = (Onkb[16][2]+Otk[16][2]);
    onk[17][0] = (Onkb[17][0]+Otk[17][0]);
    onk[17][1] = (Onkb[17][1]+Otk[15][1]);
    onk[17][2] = (Onkb[17][2]+Otk[17][2]);
    onk[18][0] = (Onkb[18][0]+Otk[18][0]);
    onk[18][1] = (Onkb[18][1]+Otk[14][1]);
    onk[18][2] = (Onkb[18][2]+Otk[18][2]);
    onk[19][0] = (Onkb[19][0]+Otk[19][0]);
    onk[19][1] = (Onkb[19][1]+Otk[15][1]);
    onk[19][2] = (Onkb[19][2]+Otk[19][2]);
    onk[20][0] = (Onkb[20][0]+Otk[20][0]);
    onk[20][1] = (Onkb[20][1]+Otk[14][1]);
    onk[20][2] = (Onkb[20][2]+Otk[20][2]);
    onk[21][0] = (Onkb[21][0]+Otk[21][0]);
    onk[21][1] = (Onkb[21][1]+Otk[15][1]);
    onk[21][2] = (Onkb[21][2]+Otk[21][2]);
    onk[22][0] = (Onkb[22][0]+Otk[20][0]);
    onk[22][1] = (Onkb[22][1]+Otk[22][1]);
    onk[22][2] = (Onkb[22][2]+Otk[22][2]);
    onk[23][0] = (Onkb[23][0]+Otk[21][0]);
    onk[23][1] = (Onkb[23][1]+Otk[23][1]);
    onk[23][2] = (Onkb[23][2]+Otk[23][2]);
    onk[24][0] = (Onkb[24][0]+Otk[24][0]);
    onk[24][1] = (Onkb[24][1]+Otk[24][1]);
    onk[25][0] = (Onkb[25][0]+Otk[25][0]);
    onk[25][1] = (Onkb[25][1]+Otk[24][1]);
    onk[25][2] = (Onkb[25][2]+Otk[25][2]);
    onb[0][0] = udot[3];
    onb[0][1] = udot[4];
    onb[0][2] = udot[5];
    onb[1][0] = onk[6][0];
    onb[1][1] = Onkb[6][1];
    onb[1][2] = onk[6][2];
    onb[2][0] = onk[7][0];
    onb[2][1] = Onkb[7][1];
    onb[2][2] = onk[7][2];
    onb[3][0] = onk[8][0];
    onb[3][1] = onk[8][1];
    onb[3][2] = onk[8][2];
    onb[4][0] = onk[9][0];
    onb[4][1] = onk[9][1];
    onb[4][2] = onk[9][2];
    onb[5][0] = onk[10][0];
    onb[5][1] = onk[10][1];
    onb[5][2] = onk[10][2];
    onb[6][0] = onk[11][0];
    onb[6][1] = onk[11][1];
    onb[6][2] = onk[11][2];
    onb[7][0] = onk[12][0];
    onb[7][1] = onk[12][1];
    onb[7][2] = Onkb[12][2];
    onb[8][0] = onk[13][0];
    onb[8][1] = onk[13][1];
    onb[8][2] = Onkb[13][2];
    onb[9][0] = onk[14][0];
    onb[9][1] = onk[14][1];
    onb[9][2] = onk[14][2];
    onb[10][0] = onk[15][0];
    onb[10][1] = onk[15][1];
    onb[10][2] = onk[15][2];
    onb[11][0] = onk[16][0];
    onb[11][1] = onk[16][1];
    onb[11][2] = onk[16][2];
    onb[12][0] = onk[17][0];
    onb[12][1] = onk[17][1];
    onb[12][2] = onk[17][2];
    onb[13][0] = onk[18][0];
    onb[13][1] = onk[18][1];
    onb[13][2] = onk[18][2];
    onb[14][0] = onk[19][0];
    onb[14][1] = onk[19][1];
    onb[14][2] = onk[19][2];
    onb[15][0] = onk[20][0];
    onb[15][1] = onk[20][1];
    onb[15][2] = onk[20][2];
    onb[16][0] = onk[21][0];
    onb[16][1] = onk[21][1];
    onb[16][2] = onk[21][2];
    onb[17][0] = onk[22][0];
    onb[17][1] = onk[22][1];
    onb[17][2] = onk[22][2];
    onb[18][0] = onk[23][0];
    onb[18][1] = onk[23][1];
    onb[18][2] = onk[23][2];
    onb[19][0] = onk[24][0];
    onb[19][1] = onk[24][1];
    onb[19][2] = Onkb[24][2];
    onb[20][0] = onk[25][0];
    onb[20][1] = onk[25][1];
    onb[20][2] = onk[25][2];
/*
Compute acceleration dyadics
*/
    dyad[0][0][0] = w11w22[0];
    dyad[0][0][1] = (w0w1[0]-udot[5]);
    dyad[0][0][2] = (udot[4]+w0w2[0]);
    dyad[0][1][0] = (udot[5]+w0w1[0]);
    dyad[0][1][1] = w00w22[0];
    dyad[0][1][2] = (w1w2[0]-udot[3]);
    dyad[0][2][0] = (w0w2[0]-udot[4]);
    dyad[0][2][1] = (udot[3]+w1w2[0]);
    dyad[0][2][2] = w00w11[0];
    dyad[1][0][0] = w11w22[1];
    dyad[1][0][1] = (w0w1[1]-onk[6][2]);
    dyad[1][0][2] = (Onkb[6][1]+w0w2[1]);
    dyad[1][1][0] = (onk[6][2]+w0w1[1]);
    dyad[1][1][1] = w00w22[1];
    dyad[1][1][2] = (w1w2[1]-onk[6][0]);
    dyad[1][2][0] = (w0w2[1]-Onkb[6][1]);
    dyad[1][2][1] = (onk[6][0]+w1w2[1]);
    dyad[1][2][2] = w00w11[1];
    dyad[2][0][0] = w11w22[2];
    dyad[2][0][1] = (w0w1[2]-onk[7][2]);
    dyad[2][0][2] = (Onkb[7][1]+w0w2[2]);
    dyad[2][1][0] = (onk[7][2]+w0w1[2]);
    dyad[2][1][1] = w00w22[2];
    dyad[2][1][2] = (w1w2[2]-onk[7][0]);
    dyad[2][2][0] = (w0w2[2]-Onkb[7][1]);
    dyad[2][2][1] = (onk[7][0]+w1w2[2]);
    dyad[2][2][2] = w00w11[2];
    dyad[3][0][0] = w11w22[3];
    dyad[3][0][1] = (w0w1[3]-onk[8][2]);
    dyad[3][0][2] = (onk[8][1]+w0w2[3]);
    dyad[3][1][0] = (onk[8][2]+w0w1[3]);
    dyad[3][1][1] = w00w22[3];
    dyad[3][1][2] = (w1w2[3]-onk[8][0]);
    dyad[3][2][0] = (w0w2[3]-onk[8][1]);
    dyad[3][2][1] = (onk[8][0]+w1w2[3]);
    dyad[3][2][2] = w00w11[3];
    dyad[4][0][0] = w11w22[4];
    dyad[4][0][1] = (w0w1[4]-onk[9][2]);
    dyad[4][0][2] = (onk[9][1]+w0w2[4]);
    dyad[4][1][0] = (onk[9][2]+w0w1[4]);
    dyad[4][1][1] = w00w22[4];
    dyad[4][1][2] = (w1w2[4]-onk[9][0]);
    dyad[4][2][0] = (w0w2[4]-onk[9][1]);
    dyad[4][2][1] = (onk[9][0]+w1w2[4]);
    dyad[4][2][2] = w00w11[4];
    dyad[5][0][0] = w11w22[5];
    dyad[5][0][1] = (w0w1[5]-onk[10][2]);
    dyad[5][0][2] = (onk[10][1]+w0w2[5]);
    dyad[5][1][0] = (onk[10][2]+w0w1[5]);
    dyad[5][1][1] = w00w22[5];
    dyad[5][1][2] = (w1w2[5]-onk[10][0]);
    dyad[5][2][0] = (w0w2[5]-onk[10][1]);
    dyad[5][2][1] = (onk[10][0]+w1w2[5]);
    dyad[5][2][2] = w00w11[5];
    dyad[6][0][0] = w11w22[6];
    dyad[6][0][1] = (w0w1[6]-onk[11][2]);
    dyad[6][0][2] = (onk[11][1]+w0w2[6]);
    dyad[6][1][0] = (onk[11][2]+w0w1[6]);
    dyad[6][1][1] = w00w22[6];
    dyad[6][1][2] = (w1w2[6]-onk[11][0]);
    dyad[6][2][0] = (w0w2[6]-onk[11][1]);
    dyad[6][2][1] = (onk[11][0]+w1w2[6]);
    dyad[6][2][2] = w00w11[6];
    dyad[7][0][0] = w11w22[7];
    dyad[7][0][1] = (w0w1[7]-Onkb[12][2]);
    dyad[7][0][2] = (onk[12][1]+w0w2[7]);
    dyad[7][1][0] = (Onkb[12][2]+w0w1[7]);
    dyad[7][1][1] = w00w22[7];
    dyad[7][1][2] = (w1w2[7]-onk[12][0]);
    dyad[7][2][0] = (w0w2[7]-onk[12][1]);
    dyad[7][2][1] = (onk[12][0]+w1w2[7]);
    dyad[7][2][2] = w00w11[7];
    dyad[8][0][0] = w11w22[8];
    dyad[8][0][1] = (w0w1[8]-Onkb[13][2]);
    dyad[8][0][2] = (onk[13][1]+w0w2[8]);
    dyad[8][1][0] = (Onkb[13][2]+w0w1[8]);
    dyad[8][1][1] = w00w22[8];
    dyad[8][1][2] = (w1w2[8]-onk[13][0]);
    dyad[8][2][0] = (w0w2[8]-onk[13][1]);
    dyad[8][2][1] = (onk[13][0]+w1w2[8]);
    dyad[8][2][2] = w00w11[8];
    dyad[9][0][0] = w11w22[9];
    dyad[9][0][1] = (w0w1[9]-onk[14][2]);
    dyad[9][0][2] = (onk[14][1]+w0w2[9]);
    dyad[9][1][0] = (onk[14][2]+w0w1[9]);
    dyad[9][1][1] = w00w22[9];
    dyad[9][1][2] = (w1w2[9]-onk[14][0]);
    dyad[9][2][0] = (w0w2[9]-onk[14][1]);
    dyad[9][2][1] = (onk[14][0]+w1w2[9]);
    dyad[9][2][2] = w00w11[9];
    dyad[10][0][0] = w11w22[10];
    dyad[10][0][1] = (w0w1[10]-onk[15][2]);
    dyad[10][0][2] = (onk[15][1]+w0w2[10]);
    dyad[10][1][0] = (onk[15][2]+w0w1[10]);
    dyad[10][1][1] = w00w22[10];
    dyad[10][1][2] = (w1w2[10]-onk[15][0]);
    dyad[10][2][0] = (w0w2[10]-onk[15][1]);
    dyad[10][2][1] = (onk[15][0]+w1w2[10]);
    dyad[10][2][2] = w00w11[10];
    dyad[11][0][0] = w11w22[11];
    dyad[11][0][1] = (w0w1[11]-onk[16][2]);
    dyad[11][0][2] = (onk[16][1]+w0w2[11]);
    dyad[11][1][0] = (onk[16][2]+w0w1[11]);
    dyad[11][1][1] = w00w22[11];
    dyad[11][1][2] = (w1w2[11]-onk[16][0]);
    dyad[11][2][0] = (w0w2[11]-onk[16][1]);
    dyad[11][2][1] = (onk[16][0]+w1w2[11]);
    dyad[11][2][2] = w00w11[11];
    dyad[12][0][0] = w11w22[12];
    dyad[12][0][1] = (w0w1[12]-onk[17][2]);
    dyad[12][0][2] = (onk[17][1]+w0w2[12]);
    dyad[12][1][0] = (onk[17][2]+w0w1[12]);
    dyad[12][1][1] = w00w22[12];
    dyad[12][1][2] = (w1w2[12]-onk[17][0]);
    dyad[12][2][0] = (w0w2[12]-onk[17][1]);
    dyad[12][2][1] = (onk[17][0]+w1w2[12]);
    dyad[12][2][2] = w00w11[12];
    dyad[13][0][0] = w11w22[13];
    dyad[13][0][1] = (w0w1[13]-onk[18][2]);
    dyad[13][0][2] = (onk[18][1]+w0w2[13]);
    dyad[13][1][0] = (onk[18][2]+w0w1[13]);
    dyad[13][1][1] = w00w22[13];
    dyad[13][1][2] = (w1w2[13]-onk[18][0]);
    dyad[13][2][0] = (w0w2[13]-onk[18][1]);
    dyad[13][2][1] = (onk[18][0]+w1w2[13]);
    dyad[13][2][2] = w00w11[13];
    dyad[14][0][0] = w11w22[14];
    dyad[14][0][1] = (w0w1[14]-onk[19][2]);
    dyad[14][0][2] = (onk[19][1]+w0w2[14]);
    dyad[14][1][0] = (onk[19][2]+w0w1[14]);
    dyad[14][1][1] = w00w22[14];
    dyad[14][1][2] = (w1w2[14]-onk[19][0]);
    dyad[14][2][0] = (w0w2[14]-onk[19][1]);
    dyad[14][2][1] = (onk[19][0]+w1w2[14]);
    dyad[14][2][2] = w00w11[14];
    dyad[15][0][0] = w11w22[15];
    dyad[15][0][1] = (w0w1[15]-onk[20][2]);
    dyad[15][0][2] = (onk[20][1]+w0w2[15]);
    dyad[15][1][0] = (onk[20][2]+w0w1[15]);
    dyad[15][1][1] = w00w22[15];
    dyad[15][1][2] = (w1w2[15]-onk[20][0]);
    dyad[15][2][0] = (w0w2[15]-onk[20][1]);
    dyad[15][2][1] = (onk[20][0]+w1w2[15]);
    dyad[15][2][2] = w00w11[15];
    dyad[16][0][0] = w11w22[16];
    dyad[16][0][1] = (w0w1[16]-onk[21][2]);
    dyad[16][0][2] = (onk[21][1]+w0w2[16]);
    dyad[16][1][0] = (onk[21][2]+w0w1[16]);
    dyad[16][1][1] = w00w22[16];
    dyad[16][1][2] = (w1w2[16]-onk[21][0]);
    dyad[16][2][0] = (w0w2[16]-onk[21][1]);
    dyad[16][2][1] = (onk[21][0]+w1w2[16]);
    dyad[16][2][2] = w00w11[16];
    dyad[17][0][0] = w11w22[17];
    dyad[17][0][1] = (w0w1[17]-onk[22][2]);
    dyad[17][0][2] = (onk[22][1]+w0w2[17]);
    dyad[17][1][0] = (onk[22][2]+w0w1[17]);
    dyad[17][1][1] = w00w22[17];
    dyad[17][1][2] = (w1w2[17]-onk[22][0]);
    dyad[17][2][0] = (w0w2[17]-onk[22][1]);
    dyad[17][2][1] = (onk[22][0]+w1w2[17]);
    dyad[17][2][2] = w00w11[17];
    dyad[18][0][0] = w11w22[18];
    dyad[18][0][1] = (w0w1[18]-onk[23][2]);
    dyad[18][0][2] = (onk[23][1]+w0w2[18]);
    dyad[18][1][0] = (onk[23][2]+w0w1[18]);
    dyad[18][1][1] = w00w22[18];
    dyad[18][1][2] = (w1w2[18]-onk[23][0]);
    dyad[18][2][0] = (w0w2[18]-onk[23][1]);
    dyad[18][2][1] = (onk[23][0]+w1w2[18]);
    dyad[18][2][2] = w00w11[18];
    dyad[19][0][0] = w11w22[19];
    dyad[19][0][1] = (w0w1[19]-Onkb[24][2]);
    dyad[19][0][2] = (onk[24][1]+w0w2[19]);
    dyad[19][1][0] = (Onkb[24][2]+w0w1[19]);
    dyad[19][1][1] = w00w22[19];
    dyad[19][1][2] = (w1w2[19]-onk[24][0]);
    dyad[19][2][0] = (w0w2[19]-onk[24][1]);
    dyad[19][2][1] = (onk[24][0]+w1w2[19]);
    dyad[19][2][2] = w00w11[19];
    dyad[20][0][0] = w11w22[20];
    dyad[20][0][1] = (w0w1[20]-onk[25][2]);
    dyad[20][0][2] = (onk[25][1]+w0w2[20]);
    dyad[20][1][0] = (onk[25][2]+w0w1[20]);
    dyad[20][1][1] = w00w22[20];
    dyad[20][1][2] = (w1w2[20]-onk[25][0]);
    dyad[20][2][0] = (w0w2[20]-onk[25][1]);
    dyad[20][2][1] = (onk[25][0]+w1w2[20]);
    dyad[20][2][2] = w00w11[20];
/*
Compute ank & anb (mass center linear accels in N)
*/
    Ankb[3][0] = ((Cik[3][2][0]*udot[2])+((Cik[3][0][0]*udot[0])+(Cik[3][1][0]*
      udot[1])));
    Ankb[3][1] = ((Cik[3][2][1]*udot[2])+((Cik[3][0][1]*udot[0])+(Cik[3][1][1]*
      udot[1])));
    Ankb[3][2] = ((Cik[3][2][2]*udot[2])+((Cik[3][0][2]*udot[0])+(Cik[3][1][2]*
      udot[1])));
    Ankb[5][0] = (Ankb[3][0]+((rk[0][1]*udot[5])-(rk[0][2]*udot[4])));
    Ankb[5][1] = (Ankb[3][1]+((rk[0][2]*udot[3])-(rk[0][0]*udot[5])));
    Ankb[5][2] = (Ankb[3][2]+((rk[0][0]*udot[4])-(rk[0][1]*udot[3])));
    AOnkri[6][0] = (Ankb[5][0]+((ri[1][2]*udot[4])-(ri[1][1]*udot[5])));
    AOnkri[6][1] = (Ankb[5][1]+((ri[1][0]*udot[5])-(ri[1][2]*udot[3])));
    AOnkri[6][2] = (Ankb[5][2]+((ri[1][1]*udot[3])-(ri[1][0]*udot[4])));
    Ankb[6][0] = (((AOnkri[6][0]*c6)+(AOnkri[6][2]*s6))+((Onkb[6][2]*rk[1][1])-(
      Onkb[6][1]*rk[1][2])));
    Ankb[6][1] = (AOnkri[6][1]+((Onkb[6][0]*rk[1][2])-(Onkb[6][2]*rk[1][0])));
    Ankb[6][2] = (((AOnkri[6][2]*c6)-(AOnkri[6][0]*s6))+((Onkb[6][1]*rk[1][0])-(
      Onkb[6][0]*rk[1][1])));
    AOnkri[7][0] = (Ankb[5][0]+((ri[2][2]*udot[4])-(ri[2][1]*udot[5])));
    AOnkri[7][1] = (Ankb[5][1]+((ri[2][0]*udot[5])-(ri[2][2]*udot[3])));
    AOnkri[7][2] = (Ankb[5][2]+((ri[2][1]*udot[3])-(ri[2][0]*udot[4])));
    Ankb[7][0] = (((AOnkri[7][0]*c7)+(AOnkri[7][2]*s7))+((Onkb[7][2]*rk[2][1])-(
      Onkb[7][1]*rk[2][2])));
    Ankb[7][1] = (AOnkri[7][1]+((Onkb[7][0]*rk[2][2])-(Onkb[7][2]*rk[2][0])));
    Ankb[7][2] = (((AOnkri[7][2]*c7)-(AOnkri[7][0]*s7))+((Onkb[7][1]*rk[2][0])-(
      Onkb[7][0]*rk[2][1])));
    AOnkri[8][0] = (Ankb[6][0]+((Onkb[6][1]*ri[3][2])-(Onkb[6][2]*ri[3][1])));
    AOnkri[8][1] = (Ankb[6][1]+((Onkb[6][2]*ri[3][0])-(Onkb[6][0]*ri[3][2])));
    AOnkri[8][2] = (Ankb[6][2]+((Onkb[6][0]*ri[3][1])-(Onkb[6][1]*ri[3][0])));
    Ankb[8][0] = (AOnkri[8][0]+((Onkb[8][2]*rk[3][1])-(Onkb[8][1]*rk[3][2])));
    Ankb[8][1] = (((AOnkri[8][1]*c8)-(AOnkri[8][2]*s8))+((Onkb[8][0]*rk[3][2])-(
      Onkb[8][2]*rk[3][0])));
    Ankb[8][2] = (((AOnkri[8][1]*s8)+(AOnkri[8][2]*c8))+((Onkb[8][1]*rk[3][0])-(
      Onkb[8][0]*rk[3][1])));
    AOnkri[9][0] = (Ankb[7][0]+((Onkb[7][1]*ri[4][2])-(Onkb[7][2]*ri[4][1])));
    AOnkri[9][1] = (Ankb[7][1]+((Onkb[7][2]*ri[4][0])-(Onkb[7][0]*ri[4][2])));
    AOnkri[9][2] = (Ankb[7][2]+((Onkb[7][0]*ri[4][1])-(Onkb[7][1]*ri[4][0])));
    Ankb[9][0] = (AOnkri[9][0]+((Onkb[9][2]*rk[4][1])-(Onkb[9][1]*rk[4][2])));
    Ankb[9][1] = (((AOnkri[9][1]*c9)+(AOnkri[9][2]*s9))+((Onkb[9][0]*rk[4][2])-(
      Onkb[9][2]*rk[4][0])));
    Ankb[9][2] = (((AOnkri[9][2]*c9)-(AOnkri[9][1]*s9))+((Onkb[9][1]*rk[4][0])-(
      Onkb[9][0]*rk[4][1])));
    AOnkri[10][0] = (Ankb[8][0]+((Onkb[8][1]*ri[5][2])-(Onkb[8][2]*ri[5][1])));
    AOnkri[10][1] = (Ankb[8][1]+((Onkb[8][2]*ri[5][0])-(Onkb[8][0]*ri[5][2])));
    AOnkri[10][2] = (Ankb[8][2]+((Onkb[8][0]*ri[5][1])-(Onkb[8][1]*ri[5][0])));
    Ankb[10][0] = (((AOnkri[10][0]*c10)-(AOnkri[10][1]*s10))+((Onkb[10][2]*
      rk[5][1])-(Onkb[10][1]*rk[5][2])));
    Ankb[10][1] = (((AOnkri[10][0]*s10)+(AOnkri[10][1]*c10))+((Onkb[10][0]*
      rk[5][2])-(Onkb[10][2]*rk[5][0])));
    Ankb[10][2] = (AOnkri[10][2]+((Onkb[10][1]*rk[5][0])-(Onkb[10][0]*rk[5][1]))
      );
    AOnkri[11][0] = (Ankb[9][0]+((Onkb[9][1]*ri[6][2])-(Onkb[9][2]*ri[6][1])));
    AOnkri[11][1] = (Ankb[9][1]+((Onkb[9][2]*ri[6][0])-(Onkb[9][0]*ri[6][2])));
    AOnkri[11][2] = (Ankb[9][2]+((Onkb[9][0]*ri[6][1])-(Onkb[9][1]*ri[6][0])));
    Ankb[11][0] = (((AOnkri[11][0]*c11)+(AOnkri[11][1]*s11))+((Onkb[11][2]*
      rk[6][1])-(Onkb[11][1]*rk[6][2])));
    Ankb[11][1] = (((AOnkri[11][1]*c11)-(AOnkri[11][0]*s11))+((Onkb[11][0]*
      rk[6][2])-(Onkb[11][2]*rk[6][0])));
    Ankb[11][2] = (AOnkri[11][2]+((Onkb[11][1]*rk[6][0])-(Onkb[11][0]*rk[6][1]))
      );
    AOnkri[12][0] = (Ankb[5][0]+((ri[7][2]*udot[4])-(ri[7][1]*udot[5])));
    AOnkri[12][1] = (Ankb[5][1]+((ri[7][0]*udot[5])-(ri[7][2]*udot[3])));
    AOnkri[12][2] = (Ankb[5][2]+((ri[7][1]*udot[3])-(ri[7][0]*udot[4])));
    Ankb[12][0] = (((AOnkri[12][0]*c12)-(AOnkri[12][1]*s12))+((Onkb[12][2]*
      rk[7][1])-(Onkb[12][1]*rk[7][2])));
    Ankb[12][1] = (((AOnkri[12][0]*s12)+(AOnkri[12][1]*c12))+((Onkb[12][0]*
      rk[7][2])-(Onkb[12][2]*rk[7][0])));
    Ankb[12][2] = (AOnkri[12][2]+((Onkb[12][1]*rk[7][0])-(Onkb[12][0]*rk[7][1]))
      );
    AOnkri[13][0] = (Ankb[5][0]+((ri[8][2]*udot[4])-(ri[8][1]*udot[5])));
    AOnkri[13][1] = (Ankb[5][1]+((ri[8][0]*udot[5])-(ri[8][2]*udot[3])));
    AOnkri[13][2] = (Ankb[5][2]+((ri[8][1]*udot[3])-(ri[8][0]*udot[4])));
    Ankb[13][0] = (((AOnkri[13][0]*c13)+(AOnkri[13][1]*s13))+((Onkb[13][2]*
      rk[8][1])-(Onkb[13][1]*rk[8][2])));
    Ankb[13][1] = (((AOnkri[13][1]*c13)-(AOnkri[13][0]*s13))+((Onkb[13][0]*
      rk[8][2])-(Onkb[13][2]*rk[8][0])));
    Ankb[13][2] = (AOnkri[13][2]+((Onkb[13][1]*rk[8][0])-(Onkb[13][0]*rk[8][1]))
      );
    AOnkri[14][0] = (Ankb[12][0]+((Onkb[12][1]*ri[9][2])-(Onkb[12][2]*ri[9][1]))
      );
    AOnkri[14][1] = (Ankb[12][1]+((Onkb[12][2]*ri[9][0])-(Onkb[12][0]*ri[9][2]))
      );
    AOnkri[14][2] = (Ankb[12][2]+((Onkb[12][0]*ri[9][1])-(Onkb[12][1]*ri[9][0]))
      );
    Ankb[14][0] = (AOnkri[14][0]+((Onkb[14][2]*rk[9][1])-(Onkb[14][1]*rk[9][2]))
      );
    Ankb[14][1] = (((AOnkri[14][1]*c14)-(AOnkri[14][2]*s14))+((Onkb[14][0]*
      rk[9][2])-(Onkb[14][2]*rk[9][0])));
    Ankb[14][2] = (((AOnkri[14][1]*s14)+(AOnkri[14][2]*c14))+((Onkb[14][1]*
      rk[9][0])-(Onkb[14][0]*rk[9][1])));
    AOnkri[15][0] = (Ankb[13][0]+((Onkb[13][1]*ri[10][2])-(Onkb[13][2]*ri[10][1]
      )));
    AOnkri[15][1] = (Ankb[13][1]+((Onkb[13][2]*ri[10][0])-(Onkb[13][0]*ri[10][2]
      )));
    AOnkri[15][2] = (Ankb[13][2]+((Onkb[13][0]*ri[10][1])-(Onkb[13][1]*ri[10][0]
      )));
    Ankb[15][0] = (AOnkri[15][0]+((Onkb[15][2]*rk[10][1])-(Onkb[15][1]*rk[10][2]
      )));
    Ankb[15][1] = (((AOnkri[15][1]*c15)+(AOnkri[15][2]*s15))+((Onkb[15][0]*
      rk[10][2])-(Onkb[15][2]*rk[10][0])));
    Ankb[15][2] = (((AOnkri[15][2]*c15)-(AOnkri[15][1]*s15))+((Onkb[15][1]*
      rk[10][0])-(Onkb[15][0]*rk[10][1])));
    AOnkri[16][0] = (Ankb[14][0]+((Onkb[14][1]*ri[11][2])-(Onkb[14][2]*ri[11][1]
      )));
    AOnkri[16][1] = (Ankb[14][1]+((Onkb[14][2]*ri[11][0])-(Onkb[14][0]*ri[11][2]
      )));
    AOnkri[16][2] = (Ankb[14][2]+((Onkb[14][0]*ri[11][1])-(Onkb[14][1]*ri[11][0]
      )));
    Ankb[16][0] = (((AOnkri[16][0]*c16)+(AOnkri[16][2]*s16))+((Onkb[16][2]*
      rk[11][1])-(Onkb[16][1]*rk[11][2])));
    Ankb[16][1] = (AOnkri[16][1]+((Onkb[16][0]*rk[11][2])-(Onkb[16][2]*rk[11][0]
      )));
    Ankb[16][2] = (((AOnkri[16][2]*c16)-(AOnkri[16][0]*s16))+((Onkb[16][1]*
      rk[11][0])-(Onkb[16][0]*rk[11][1])));
    AOnkri[17][0] = (Ankb[15][0]+((Onkb[15][1]*ri[12][2])-(Onkb[15][2]*ri[12][1]
      )));
    AOnkri[17][1] = (Ankb[15][1]+((Onkb[15][2]*ri[12][0])-(Onkb[15][0]*ri[12][2]
      )));
    AOnkri[17][2] = (Ankb[15][2]+((Onkb[15][0]*ri[12][1])-(Onkb[15][1]*ri[12][0]
      )));
    Ankb[17][0] = (((AOnkri[17][0]*c17)+(AOnkri[17][2]*s17))+((Onkb[17][2]*
      rk[12][1])-(Onkb[17][1]*rk[12][2])));
    Ankb[17][1] = (AOnkri[17][1]+((Onkb[17][0]*rk[12][2])-(Onkb[17][2]*rk[12][0]
      )));
    Ankb[17][2] = (((AOnkri[17][2]*c17)-(AOnkri[17][0]*s17))+((Onkb[17][1]*
      rk[12][0])-(Onkb[17][0]*rk[12][1])));
    AOnkri[18][0] = (Ankb[16][0]+((Onkb[16][1]*ri[13][2])-(Onkb[16][2]*ri[13][1]
      )));
    AOnkri[18][1] = (Ankb[16][1]+((Onkb[16][2]*ri[13][0])-(Onkb[16][0]*ri[13][2]
      )));
    AOnkri[18][2] = (Ankb[16][2]+((Onkb[16][0]*ri[13][1])-(Onkb[16][1]*ri[13][0]
      )));
    Ankb[18][0] = (((AOnkri[18][0]*c18)+(AOnkri[18][2]*s18))+((Onkb[18][2]*
      rk[13][1])-(Onkb[18][1]*rk[13][2])));
    Ankb[18][1] = (AOnkri[18][1]+((Onkb[18][0]*rk[13][2])-(Onkb[18][2]*rk[13][0]
      )));
    Ankb[18][2] = (((AOnkri[18][2]*c18)-(AOnkri[18][0]*s18))+((Onkb[18][1]*
      rk[13][0])-(Onkb[18][0]*rk[13][1])));
    AOnkri[19][0] = (Ankb[17][0]+((Onkb[17][1]*ri[14][2])-(Onkb[17][2]*ri[14][1]
      )));
    AOnkri[19][1] = (Ankb[17][1]+((Onkb[17][2]*ri[14][0])-(Onkb[17][0]*ri[14][2]
      )));
    AOnkri[19][2] = (Ankb[17][2]+((Onkb[17][0]*ri[14][1])-(Onkb[17][1]*ri[14][0]
      )));
    Ankb[19][0] = (((AOnkri[19][0]*c19)+(AOnkri[19][2]*s19))+((Onkb[19][2]*
      rk[14][1])-(Onkb[19][1]*rk[14][2])));
    Ankb[19][1] = (AOnkri[19][1]+((Onkb[19][0]*rk[14][2])-(Onkb[19][2]*rk[14][0]
      )));
    Ankb[19][2] = (((AOnkri[19][2]*c19)-(AOnkri[19][0]*s19))+((Onkb[19][1]*
      rk[14][0])-(Onkb[19][0]*rk[14][1])));
    AOnkri[20][0] = (Ankb[18][0]+((Onkb[18][1]*ri[15][2])-(Onkb[18][2]*ri[15][1]
      )));
    AOnkri[20][1] = (Ankb[18][1]+((Onkb[18][2]*ri[15][0])-(Onkb[18][0]*ri[15][2]
      )));
    AOnkri[20][2] = (Ankb[18][2]+((Onkb[18][0]*ri[15][1])-(Onkb[18][1]*ri[15][0]
      )));
    Ankb[20][0] = (((AOnkri[20][0]*c20)+(AOnkri[20][2]*s20))+((Onkb[20][2]*
      rk[15][1])-(Onkb[20][1]*rk[15][2])));
    Ankb[20][1] = (AOnkri[20][1]+((Onkb[20][0]*rk[15][2])-(Onkb[20][2]*rk[15][0]
      )));
    Ankb[20][2] = (((AOnkri[20][2]*c20)-(AOnkri[20][0]*s20))+((Onkb[20][1]*
      rk[15][0])-(Onkb[20][0]*rk[15][1])));
    AOnkri[21][0] = (Ankb[19][0]+((Onkb[19][1]*ri[16][2])-(Onkb[19][2]*ri[16][1]
      )));
    AOnkri[21][1] = (Ankb[19][1]+((Onkb[19][2]*ri[16][0])-(Onkb[19][0]*ri[16][2]
      )));
    AOnkri[21][2] = (Ankb[19][2]+((Onkb[19][0]*ri[16][1])-(Onkb[19][1]*ri[16][0]
      )));
    Ankb[21][0] = (((AOnkri[21][0]*c21)+(AOnkri[21][2]*s21))+((Onkb[21][2]*
      rk[16][1])-(Onkb[21][1]*rk[16][2])));
    Ankb[21][1] = (AOnkri[21][1]+((Onkb[21][0]*rk[16][2])-(Onkb[21][2]*rk[16][0]
      )));
    Ankb[21][2] = (((AOnkri[21][2]*c21)-(AOnkri[21][0]*s21))+((Onkb[21][1]*
      rk[16][0])-(Onkb[21][0]*rk[16][1])));
    AOnkri[22][0] = (Ankb[20][0]+((Onkb[20][1]*ri[17][2])-(Onkb[20][2]*ri[17][1]
      )));
    AOnkri[22][1] = (Ankb[20][1]+((Onkb[20][2]*ri[17][0])-(Onkb[20][0]*ri[17][2]
      )));
    AOnkri[22][2] = (Ankb[20][2]+((Onkb[20][0]*ri[17][1])-(Onkb[20][1]*ri[17][0]
      )));
    Ankb[22][0] = (AOnkri[22][0]+((Onkb[22][2]*rk[17][1])-(Onkb[22][1]*rk[17][2]
      )));
    Ankb[22][1] = (((AOnkri[22][1]*c22)-(AOnkri[22][2]*s22))+((Onkb[22][0]*
      rk[17][2])-(Onkb[22][2]*rk[17][0])));
    Ankb[22][2] = (((AOnkri[22][1]*s22)+(AOnkri[22][2]*c22))+((Onkb[22][1]*
      rk[17][0])-(Onkb[22][0]*rk[17][1])));
    AOnkri[23][0] = (Ankb[21][0]+((Onkb[21][1]*ri[18][2])-(Onkb[21][2]*ri[18][1]
      )));
    AOnkri[23][1] = (Ankb[21][1]+((Onkb[21][2]*ri[18][0])-(Onkb[21][0]*ri[18][2]
      )));
    AOnkri[23][2] = (Ankb[21][2]+((Onkb[21][0]*ri[18][1])-(Onkb[21][1]*ri[18][0]
      )));
    Ankb[23][0] = (AOnkri[23][0]+((Onkb[23][2]*rk[18][1])-(Onkb[23][1]*rk[18][2]
      )));
    Ankb[23][1] = (((AOnkri[23][1]*c23)+(AOnkri[23][2]*s23))+((Onkb[23][0]*
      rk[18][2])-(Onkb[23][2]*rk[18][0])));
    Ankb[23][2] = (((AOnkri[23][2]*c23)-(AOnkri[23][1]*s23))+((Onkb[23][1]*
      rk[18][0])-(Onkb[23][0]*rk[18][1])));
    AOnkri[24][0] = (Ankb[5][0]+((ri[19][2]*udot[4])-(ri[19][1]*udot[5])));
    AOnkri[24][1] = (Ankb[5][1]+((ri[19][0]*udot[5])-(ri[19][2]*udot[3])));
    AOnkri[24][2] = (Ankb[5][2]+((ri[19][1]*udot[3])-(ri[19][0]*udot[4])));
    Ankb[24][0] = (((AOnkri[24][0]*c24)+(AOnkri[24][1]*s24))+((Onkb[24][2]*
      rk[19][1])-(Onkb[24][1]*rk[19][2])));
    Ankb[24][1] = (((AOnkri[24][1]*c24)-(AOnkri[24][0]*s24))+((Onkb[24][0]*
      rk[19][2])-(Onkb[24][2]*rk[19][0])));
    Ankb[24][2] = (AOnkri[24][2]+((Onkb[24][1]*rk[19][0])-(Onkb[24][0]*rk[19][1]
      )));
    AOnkri[25][0] = (Ankb[24][0]+((Onkb[24][1]*ri[20][2])-(Onkb[24][2]*ri[20][1]
      )));
    AOnkri[25][1] = (Ankb[24][1]+((Onkb[24][2]*ri[20][0])-(Onkb[24][0]*ri[20][2]
      )));
    AOnkri[25][2] = (Ankb[24][2]+((Onkb[24][0]*ri[20][1])-(Onkb[24][1]*ri[20][0]
      )));
    Ankb[25][0] = (((AOnkri[25][0]*c25)+(AOnkri[25][2]*s25))+((Onkb[25][2]*
      rk[20][1])-(Onkb[25][1]*rk[20][2])));
    Ankb[25][1] = (AOnkri[25][1]+((Onkb[25][0]*rk[20][2])-(Onkb[25][2]*rk[20][0]
      )));
    Ankb[25][2] = (((AOnkri[25][2]*c25)-(AOnkri[25][0]*s25))+((Onkb[25][1]*
      rk[20][0])-(Onkb[25][0]*rk[20][1])));
    AnkAtk[5][0] = (Ankb[5][0]+Atk[5][0]);
    AnkAtk[5][1] = (Ankb[5][1]+Atk[5][1]);
    AnkAtk[5][2] = (Ankb[5][2]+Atk[5][2]);
    ank[5][0] = ((AnkAtk[5][2]*Cik[3][0][2])+((AnkAtk[5][0]*Cik[3][0][0])+(
      AnkAtk[5][1]*Cik[3][0][1])));
    ank[5][1] = ((AnkAtk[5][2]*Cik[3][1][2])+((AnkAtk[5][0]*Cik[3][1][0])+(
      AnkAtk[5][1]*Cik[3][1][1])));
    ank[5][2] = ((AnkAtk[5][2]*Cik[3][2][2])+((AnkAtk[5][0]*Cik[3][2][0])+(
      AnkAtk[5][1]*Cik[3][2][1])));
    AnkAtk[6][0] = (Ankb[6][0]+Atk[6][0]);
    AnkAtk[6][1] = (Ankb[6][1]+Atk[6][1]);
    AnkAtk[6][2] = (Ankb[6][2]+Atk[6][2]);
    ank[6][0] = ((AnkAtk[6][2]*cnk[6][0][2])+((AnkAtk[6][0]*cnk[6][0][0])+(
      AnkAtk[6][1]*Cik[3][0][1])));
    ank[6][1] = ((AnkAtk[6][2]*cnk[6][1][2])+((AnkAtk[6][0]*cnk[6][1][0])+(
      AnkAtk[6][1]*Cik[3][1][1])));
    ank[6][2] = ((AnkAtk[6][2]*cnk[6][2][2])+((AnkAtk[6][0]*cnk[6][2][0])+(
      AnkAtk[6][1]*Cik[3][2][1])));
    AnkAtk[7][0] = (Ankb[7][0]+Atk[7][0]);
    AnkAtk[7][1] = (Ankb[7][1]+Atk[7][1]);
    AnkAtk[7][2] = (Ankb[7][2]+Atk[7][2]);
    ank[7][0] = ((AnkAtk[7][2]*cnk[7][0][2])+((AnkAtk[7][0]*cnk[7][0][0])+(
      AnkAtk[7][1]*Cik[3][0][1])));
    ank[7][1] = ((AnkAtk[7][2]*cnk[7][1][2])+((AnkAtk[7][0]*cnk[7][1][0])+(
      AnkAtk[7][1]*Cik[3][1][1])));
    ank[7][2] = ((AnkAtk[7][2]*cnk[7][2][2])+((AnkAtk[7][0]*cnk[7][2][0])+(
      AnkAtk[7][1]*Cik[3][2][1])));
    AnkAtk[8][0] = (Ankb[8][0]+Atk[8][0]);
    AnkAtk[8][1] = (Ankb[8][1]+Atk[8][1]);
    AnkAtk[8][2] = (Ankb[8][2]+Atk[8][2]);
    ank[8][0] = ((AnkAtk[8][2]*cnk[8][0][2])+((AnkAtk[8][0]*cnk[6][0][0])+(
      AnkAtk[8][1]*cnk[8][0][1])));
    ank[8][1] = ((AnkAtk[8][2]*cnk[8][1][2])+((AnkAtk[8][0]*cnk[6][1][0])+(
      AnkAtk[8][1]*cnk[8][1][1])));
    ank[8][2] = ((AnkAtk[8][2]*cnk[8][2][2])+((AnkAtk[8][0]*cnk[6][2][0])+(
      AnkAtk[8][1]*cnk[8][2][1])));
    AnkAtk[9][0] = (Ankb[9][0]+Atk[9][0]);
    AnkAtk[9][1] = (Ankb[9][1]+Atk[9][1]);
    AnkAtk[9][2] = (Ankb[9][2]+Atk[9][2]);
    ank[9][0] = ((AnkAtk[9][2]*cnk[9][0][2])+((AnkAtk[9][0]*cnk[7][0][0])+(
      AnkAtk[9][1]*cnk[9][0][1])));
    ank[9][1] = ((AnkAtk[9][2]*cnk[9][1][2])+((AnkAtk[9][0]*cnk[7][1][0])+(
      AnkAtk[9][1]*cnk[9][1][1])));
    ank[9][2] = ((AnkAtk[9][2]*cnk[9][2][2])+((AnkAtk[9][0]*cnk[7][2][0])+(
      AnkAtk[9][1]*cnk[9][2][1])));
    AnkAtk[10][0] = (Ankb[10][0]+Atk[10][0]);
    AnkAtk[10][1] = (Ankb[10][1]+Atk[10][1]);
    AnkAtk[10][2] = (Ankb[10][2]+Atk[10][2]);
    ank[10][0] = ((AnkAtk[10][2]*cnk[8][0][2])+((AnkAtk[10][0]*cnk[10][0][0])+(
      AnkAtk[10][1]*cnk[10][0][1])));
    ank[10][1] = ((AnkAtk[10][2]*cnk[8][1][2])+((AnkAtk[10][0]*cnk[10][1][0])+(
      AnkAtk[10][1]*cnk[10][1][1])));
    ank[10][2] = ((AnkAtk[10][2]*cnk[8][2][2])+((AnkAtk[10][0]*cnk[10][2][0])+(
      AnkAtk[10][1]*cnk[10][2][1])));
    AnkAtk[11][0] = (Ankb[11][0]+Atk[11][0]);
    AnkAtk[11][1] = (Ankb[11][1]+Atk[11][1]);
    AnkAtk[11][2] = (Ankb[11][2]+Atk[11][2]);
    ank[11][0] = ((AnkAtk[11][2]*cnk[9][0][2])+((AnkAtk[11][0]*cnk[11][0][0])+(
      AnkAtk[11][1]*cnk[11][0][1])));
    ank[11][1] = ((AnkAtk[11][2]*cnk[9][1][2])+((AnkAtk[11][0]*cnk[11][1][0])+(
      AnkAtk[11][1]*cnk[11][1][1])));
    ank[11][2] = ((AnkAtk[11][2]*cnk[9][2][2])+((AnkAtk[11][0]*cnk[11][2][0])+(
      AnkAtk[11][1]*cnk[11][2][1])));
    AnkAtk[12][0] = (Ankb[12][0]+Atk[12][0]);
    AnkAtk[12][1] = (Ankb[12][1]+Atk[12][1]);
    AnkAtk[12][2] = (Ankb[12][2]+Atk[12][2]);
    ank[12][0] = ((AnkAtk[12][2]*Cik[3][0][2])+((AnkAtk[12][0]*cnk[12][0][0])+(
      AnkAtk[12][1]*cnk[12][0][1])));
    ank[12][1] = ((AnkAtk[12][2]*Cik[3][1][2])+((AnkAtk[12][0]*cnk[12][1][0])+(
      AnkAtk[12][1]*cnk[12][1][1])));
    ank[12][2] = ((AnkAtk[12][2]*Cik[3][2][2])+((AnkAtk[12][0]*cnk[12][2][0])+(
      AnkAtk[12][1]*cnk[12][2][1])));
    AnkAtk[13][0] = (Ankb[13][0]+Atk[13][0]);
    AnkAtk[13][1] = (Ankb[13][1]+Atk[13][1]);
    AnkAtk[13][2] = (Ankb[13][2]+Atk[13][2]);
    ank[13][0] = ((AnkAtk[13][2]*Cik[3][0][2])+((AnkAtk[13][0]*cnk[13][0][0])+(
      AnkAtk[13][1]*cnk[13][0][1])));
    ank[13][1] = ((AnkAtk[13][2]*Cik[3][1][2])+((AnkAtk[13][0]*cnk[13][1][0])+(
      AnkAtk[13][1]*cnk[13][1][1])));
    ank[13][2] = ((AnkAtk[13][2]*Cik[3][2][2])+((AnkAtk[13][0]*cnk[13][2][0])+(
      AnkAtk[13][1]*cnk[13][2][1])));
    AnkAtk[14][0] = (Ankb[14][0]+Atk[14][0]);
    AnkAtk[14][1] = (Ankb[14][1]+Atk[14][1]);
    AnkAtk[14][2] = (Ankb[14][2]+Atk[14][2]);
    ank[14][0] = ((AnkAtk[14][2]*cnk[14][0][2])+((AnkAtk[14][0]*cnk[12][0][0])+(
      AnkAtk[14][1]*cnk[14][0][1])));
    ank[14][1] = ((AnkAtk[14][2]*cnk[14][1][2])+((AnkAtk[14][0]*cnk[12][1][0])+(
      AnkAtk[14][1]*cnk[14][1][1])));
    ank[14][2] = ((AnkAtk[14][2]*cnk[14][2][2])+((AnkAtk[14][0]*cnk[12][2][0])+(
      AnkAtk[14][1]*cnk[14][2][1])));
    AnkAtk[15][0] = (Ankb[15][0]+Atk[15][0]);
    AnkAtk[15][1] = (Ankb[15][1]+Atk[15][1]);
    AnkAtk[15][2] = (Ankb[15][2]+Atk[15][2]);
    ank[15][0] = ((AnkAtk[15][2]*cnk[15][0][2])+((AnkAtk[15][0]*cnk[13][0][0])+(
      AnkAtk[15][1]*cnk[15][0][1])));
    ank[15][1] = ((AnkAtk[15][2]*cnk[15][1][2])+((AnkAtk[15][0]*cnk[13][1][0])+(
      AnkAtk[15][1]*cnk[15][1][1])));
    ank[15][2] = ((AnkAtk[15][2]*cnk[15][2][2])+((AnkAtk[15][0]*cnk[13][2][0])+(
      AnkAtk[15][1]*cnk[15][2][1])));
    AnkAtk[16][0] = (Ankb[16][0]+Atk[16][0]);
    AnkAtk[16][1] = (Ankb[16][1]+Atk[16][1]);
    AnkAtk[16][2] = (Ankb[16][2]+Atk[16][2]);
    ank[16][0] = ((AnkAtk[16][2]*cnk[16][0][2])+((AnkAtk[16][0]*cnk[16][0][0])+(
      AnkAtk[16][1]*cnk[14][0][1])));
    ank[16][1] = ((AnkAtk[16][2]*cnk[16][1][2])+((AnkAtk[16][0]*cnk[16][1][0])+(
      AnkAtk[16][1]*cnk[14][1][1])));
    ank[16][2] = ((AnkAtk[16][2]*cnk[16][2][2])+((AnkAtk[16][0]*cnk[16][2][0])+(
      AnkAtk[16][1]*cnk[14][2][1])));
    AnkAtk[17][0] = (Ankb[17][0]+Atk[17][0]);
    AnkAtk[17][1] = (Ankb[17][1]+Atk[17][1]);
    AnkAtk[17][2] = (Ankb[17][2]+Atk[17][2]);
    ank[17][0] = ((AnkAtk[17][2]*cnk[17][0][2])+((AnkAtk[17][0]*cnk[17][0][0])+(
      AnkAtk[17][1]*cnk[15][0][1])));
    ank[17][1] = ((AnkAtk[17][2]*cnk[17][1][2])+((AnkAtk[17][0]*cnk[17][1][0])+(
      AnkAtk[17][1]*cnk[15][1][1])));
    ank[17][2] = ((AnkAtk[17][2]*cnk[17][2][2])+((AnkAtk[17][0]*cnk[17][2][0])+(
      AnkAtk[17][1]*cnk[15][2][1])));
    AnkAtk[18][0] = (Ankb[18][0]+Atk[18][0]);
    AnkAtk[18][1] = (Ankb[18][1]+Atk[18][1]);
    AnkAtk[18][2] = (Ankb[18][2]+Atk[18][2]);
    ank[18][0] = ((AnkAtk[18][2]*cnk[18][0][2])+((AnkAtk[18][0]*cnk[18][0][0])+(
      AnkAtk[18][1]*cnk[14][0][1])));
    ank[18][1] = ((AnkAtk[18][2]*cnk[18][1][2])+((AnkAtk[18][0]*cnk[18][1][0])+(
      AnkAtk[18][1]*cnk[14][1][1])));
    ank[18][2] = ((AnkAtk[18][2]*cnk[18][2][2])+((AnkAtk[18][0]*cnk[18][2][0])+(
      AnkAtk[18][1]*cnk[14][2][1])));
    AnkAtk[19][0] = (Ankb[19][0]+Atk[19][0]);
    AnkAtk[19][1] = (Ankb[19][1]+Atk[19][1]);
    AnkAtk[19][2] = (Ankb[19][2]+Atk[19][2]);
    ank[19][0] = ((AnkAtk[19][2]*cnk[19][0][2])+((AnkAtk[19][0]*cnk[19][0][0])+(
      AnkAtk[19][1]*cnk[15][0][1])));
    ank[19][1] = ((AnkAtk[19][2]*cnk[19][1][2])+((AnkAtk[19][0]*cnk[19][1][0])+(
      AnkAtk[19][1]*cnk[15][1][1])));
    ank[19][2] = ((AnkAtk[19][2]*cnk[19][2][2])+((AnkAtk[19][0]*cnk[19][2][0])+(
      AnkAtk[19][1]*cnk[15][2][1])));
    AnkAtk[20][0] = (Ankb[20][0]+Atk[20][0]);
    AnkAtk[20][1] = (Ankb[20][1]+Atk[20][1]);
    AnkAtk[20][2] = (Ankb[20][2]+Atk[20][2]);
    ank[20][0] = ((AnkAtk[20][2]*cnk[20][0][2])+((AnkAtk[20][0]*cnk[20][0][0])+(
      AnkAtk[20][1]*cnk[14][0][1])));
    ank[20][1] = ((AnkAtk[20][2]*cnk[20][1][2])+((AnkAtk[20][0]*cnk[20][1][0])+(
      AnkAtk[20][1]*cnk[14][1][1])));
    ank[20][2] = ((AnkAtk[20][2]*cnk[20][2][2])+((AnkAtk[20][0]*cnk[20][2][0])+(
      AnkAtk[20][1]*cnk[14][2][1])));
    AnkAtk[21][0] = (Ankb[21][0]+Atk[21][0]);
    AnkAtk[21][1] = (Ankb[21][1]+Atk[21][1]);
    AnkAtk[21][2] = (Ankb[21][2]+Atk[21][2]);
    ank[21][0] = ((AnkAtk[21][2]*cnk[21][0][2])+((AnkAtk[21][0]*cnk[21][0][0])+(
      AnkAtk[21][1]*cnk[15][0][1])));
    ank[21][1] = ((AnkAtk[21][2]*cnk[21][1][2])+((AnkAtk[21][0]*cnk[21][1][0])+(
      AnkAtk[21][1]*cnk[15][1][1])));
    ank[21][2] = ((AnkAtk[21][2]*cnk[21][2][2])+((AnkAtk[21][0]*cnk[21][2][0])+(
      AnkAtk[21][1]*cnk[15][2][1])));
    AnkAtk[22][0] = (Ankb[22][0]+Atk[22][0]);
    AnkAtk[22][1] = (Ankb[22][1]+Atk[22][1]);
    AnkAtk[22][2] = (Ankb[22][2]+Atk[22][2]);
    ank[22][0] = ((AnkAtk[22][2]*cnk[22][0][2])+((AnkAtk[22][0]*cnk[20][0][0])+(
      AnkAtk[22][1]*cnk[22][0][1])));
    ank[22][1] = ((AnkAtk[22][2]*cnk[22][1][2])+((AnkAtk[22][0]*cnk[20][1][0])+(
      AnkAtk[22][1]*cnk[22][1][1])));
    ank[22][2] = ((AnkAtk[22][2]*cnk[22][2][2])+((AnkAtk[22][0]*cnk[20][2][0])+(
      AnkAtk[22][1]*cnk[22][2][1])));
    AnkAtk[23][0] = (Ankb[23][0]+Atk[23][0]);
    AnkAtk[23][1] = (Ankb[23][1]+Atk[23][1]);
    AnkAtk[23][2] = (Ankb[23][2]+Atk[23][2]);
    ank[23][0] = ((AnkAtk[23][2]*cnk[23][0][2])+((AnkAtk[23][0]*cnk[21][0][0])+(
      AnkAtk[23][1]*cnk[23][0][1])));
    ank[23][1] = ((AnkAtk[23][2]*cnk[23][1][2])+((AnkAtk[23][0]*cnk[21][1][0])+(
      AnkAtk[23][1]*cnk[23][1][1])));
    ank[23][2] = ((AnkAtk[23][2]*cnk[23][2][2])+((AnkAtk[23][0]*cnk[21][2][0])+(
      AnkAtk[23][1]*cnk[23][2][1])));
    AnkAtk[24][0] = (Ankb[24][0]+Atk[24][0]);
    AnkAtk[24][1] = (Ankb[24][1]+Atk[24][1]);
    AnkAtk[24][2] = (Ankb[24][2]+Atk[24][2]);
    ank[24][0] = ((AnkAtk[24][2]*Cik[3][0][2])+((AnkAtk[24][0]*cnk[24][0][0])+(
      AnkAtk[24][1]*cnk[24][0][1])));
    ank[24][1] = ((AnkAtk[24][2]*Cik[3][1][2])+((AnkAtk[24][0]*cnk[24][1][0])+(
      AnkAtk[24][1]*cnk[24][1][1])));
    ank[24][2] = ((AnkAtk[24][2]*Cik[3][2][2])+((AnkAtk[24][0]*cnk[24][2][0])+(
      AnkAtk[24][1]*cnk[24][2][1])));
    AnkAtk[25][0] = (Ankb[25][0]+Atk[25][0]);
    AnkAtk[25][1] = (Ankb[25][1]+Atk[25][1]);
    AnkAtk[25][2] = (Ankb[25][2]+Atk[25][2]);
    ank[25][0] = ((AnkAtk[25][2]*cnk[25][0][2])+((AnkAtk[25][0]*cnk[25][0][0])+(
      AnkAtk[25][1]*cnk[24][0][1])));
    ank[25][1] = ((AnkAtk[25][2]*cnk[25][1][2])+((AnkAtk[25][0]*cnk[25][1][0])+(
      AnkAtk[25][1]*cnk[24][1][1])));
    ank[25][2] = ((AnkAtk[25][2]*cnk[25][2][2])+((AnkAtk[25][0]*cnk[25][2][0])+(
      AnkAtk[25][1]*cnk[24][2][1])));
    anb[0][0] = ank[5][0];
    anb[0][1] = ank[5][1];
    anb[0][2] = ank[5][2];
    anb[1][0] = ank[6][0];
    anb[1][1] = ank[6][1];
    anb[1][2] = ank[6][2];
    anb[2][0] = ank[7][0];
    anb[2][1] = ank[7][1];
    anb[2][2] = ank[7][2];
    anb[3][0] = ank[8][0];
    anb[3][1] = ank[8][1];
    anb[3][2] = ank[8][2];
    anb[4][0] = ank[9][0];
    anb[4][1] = ank[9][1];
    anb[4][2] = ank[9][2];
    anb[5][0] = ank[10][0];
    anb[5][1] = ank[10][1];
    anb[5][2] = ank[10][2];
    anb[6][0] = ank[11][0];
    anb[6][1] = ank[11][1];
    anb[6][2] = ank[11][2];
    anb[7][0] = ank[12][0];
    anb[7][1] = ank[12][1];
    anb[7][2] = ank[12][2];
    anb[8][0] = ank[13][0];
    anb[8][1] = ank[13][1];
    anb[8][2] = ank[13][2];
    anb[9][0] = ank[14][0];
    anb[9][1] = ank[14][1];
    anb[9][2] = ank[14][2];
    anb[10][0] = ank[15][0];
    anb[10][1] = ank[15][1];
    anb[10][2] = ank[15][2];
    anb[11][0] = ank[16][0];
    anb[11][1] = ank[16][1];
    anb[11][2] = ank[16][2];
    anb[12][0] = ank[17][0];
    anb[12][1] = ank[17][1];
    anb[12][2] = ank[17][2];
    anb[13][0] = ank[18][0];
    anb[13][1] = ank[18][1];
    anb[13][2] = ank[18][2];
    anb[14][0] = ank[19][0];
    anb[14][1] = ank[19][1];
    anb[14][2] = ank[19][2];
    anb[15][0] = ank[20][0];
    anb[15][1] = ank[20][1];
    anb[15][2] = ank[20][2];
    anb[16][0] = ank[21][0];
    anb[16][1] = ank[21][1];
    anb[16][2] = ank[21][2];
    anb[17][0] = ank[22][0];
    anb[17][1] = ank[22][1];
    anb[17][2] = ank[22][2];
    anb[18][0] = ank[23][0];
    anb[18][1] = ank[23][1];
    anb[18][2] = ank[23][2];
    anb[19][0] = ank[24][0];
    anb[19][1] = ank[24][1];
    anb[19][2] = ank[24][2];
    anb[20][0] = ank[25][0];
    anb[20][1] = ank[25][1];
    anb[20][2] = ank[25][2];
    roustate = 3;
/*
 Used 0.01 seconds CPU time,
 0 additional bytes of memory.
 Equations contain  722 adds/subtracts/negates
                    604 multiplies
                      0 divides
                    708 assignments
*/
}

void sdmassmat(double mmat[26][26])
{
/* Return the system mass matrix (LHS)
*/
    int i,j;

    if ((roustate != 2) && (roustate != 3)) {
        sdseterr(57,23);
        return;
    }
    sddomm(57);
    for (i = 0; i < 26; i++) {
        for (j = i; j <= 25; j++) {
            mmat[i][j] = mm[i][j];
            mmat[j][i] = mm[i][j];
        }
    }
}

void sdfrcmat(double fmat[26])
{
/* Return the system force matrix (RHS), excluding constraints
*/
    int i;

    if ((roustate != 2) && (roustate != 3)) {
        sdseterr(58,23);
        return;
    }
    sddofs0();
    for (i = 0; i < 26; i++) {
        fmat[i] = fs0[i];
    }
}

void sdpseudo(double lqout[1],
    double luout[1])
{
/*
Return pseudo-coordinates for loop joints.

*/
/*
There are no loop joints in this system.

*/
}

void sdpsqdot(double lqdout[1])
{
/*
Return pseudo-coordinate derivatives for loop joints.

*/
/*
There are no loop joints in this system.

*/
}

void sdpsudot(double ludout[1])
{
/*
Return pseudo-coordinate accelerations for loop joints.

*/
/*
There are no loop joints in this system.

*/
}

void sdperr(double errs[1])
{

}

void sdverr(double errs[1])
{

}

void sdaerr(double errs[1])
{

}
int 
sdchkbnum(int routine,
    int bnum)
{

    if ((bnum < -1) || (bnum > 20)) {
        sdseterr(routine,15);
        return 1;
    }
    return 0;
}
int 
sdchkjnum(int routine,
    int jnum)
{

    if ((jnum < 0) || (jnum > 20)) {
        sdseterr(routine,16);
        return 1;
    }
    return 0;
}
int 
sdchkucnum(int routine,
    int ucnum)
{

    if ((ucnum < 0) || (ucnum > -1)) {
        sdseterr(routine,21);
        return 1;
    }
    return 0;
}
int 
sdchkjaxis(int routine,
    int jnum,
    int axnum)
{
    int maxax;

    if (sdchkjnum(routine,jnum) != 0) {
        return 1;
    }
    if ((axnum < 0) || (axnum > 6)) {
        sdseterr(routine,17);
        return 1;
    }
    maxax = njntdof[jnum]-1;
    if ((jtype[jnum] == 4) || (jtype[jnum] == 6) || (jtype[jnum] == 21)) {
        maxax = maxax+1;
    }
    if (axnum > maxax) {
        sdseterr(routine,18);
        return 1;
    }
    return 0;
}
int 
sdchkjpin(int routine,
    int jnum,
    int pinno)
{
    int maxax,pinok;

    if (sdchkjnum(routine,jnum) != 0) {
        return 1;
    }
    if ((pinno < 0) || (pinno > 5)) {
        sdseterr(routine,17);
        return 1;
    }
    if (njntdof[jnum] >= 3) {
        maxax = 2;
    } else {
        maxax = njntdof[jnum]-1;
    }
    if (jtype[jnum] == 4) {
        maxax = -1;
    }
    if (jtype[jnum] == 7) {
        maxax = 0;
    }
    pinok = 0;
    if (pinno <= maxax) {
        pinok = 1;
    }
    if (pinok == 0) {
        sdseterr(routine,18);
        return 1;
    }
    return 0;
}
int 
sdindx(int joint,
    int axis)
{
    int offs,gotit;

    if (sdchkjaxis(36,joint,axis) != 0) {
        return 0;
    }
    gotit = 0;
    if (jtype[joint] == 4) {
        if (axis == 3) {
            offs = ballq[joint];
            gotit = 1;
        }
    } else {
        if ((jtype[joint] == 6) || (jtype[joint] == 21)) {
            if (axis == 6) {
                offs = ballq[joint];
                gotit = 1;
            }
        }
    }
    if (gotit == 0) {
        offs = firstq[joint]+axis;
    }
    return offs;
}

void sdpresacc(int joint,
    int axis,
    double prval)
{

}

void sdpresvel(int joint,
    int axis,
    double prval)
{

}

void sdprespos(int joint,
    int axis,
    double prval)
{

}

void sdgetht(int joint,
    int axis,
    double *torque)
{

    if (sdchkjaxis(30,joint,axis) != 0) {
        return;
    }
    if (roustate != 3) {
        sdseterr(30,24);
        return;
    }
    *torque = tauc[sdindx(joint,axis)];
}

void sdhinget(int joint,
    int axis,
    double torque)
{

    if (sdchkjaxis(10,joint,axis) != 0) {
        return;
    }
    if (roustate != 2) {
        sdseterr(10,23);
        return;
    }
    if (mfrcflg != 0) {
        mtau[sdindx(joint,axis)] = mtau[sdindx(joint,axis)]+torque;
    } else {
        fs0flg = 0;
        utau[sdindx(joint,axis)] = utau[sdindx(joint,axis)]+torque;
    }
}

void sdpointf(int body,
    double point[3],
    double force[3])
{
    double torque[3];

    if (sdchkbnum(11,body) != 0) {
        return;
    }
    if (roustate != 2) {
        sdseterr(11,23);
        return;
    }
    if (body == -1) {
        return;
    }
    torque[0] = point[1]*force[2]-point[2]*force[1];
    torque[1] = point[2]*force[0]-point[0]*force[2];
    torque[2] = point[0]*force[1]-point[1]*force[0];
    if (mfrcflg != 0) {
        mfk[body][0] = mfk[body][0]+force[0];
        mtk[body][0] = mtk[body][0]+torque[0];
        mfk[body][1] = mfk[body][1]+force[1];
        mtk[body][1] = mtk[body][1]+torque[1];
        mfk[body][2] = mfk[body][2]+force[2];
        mtk[body][2] = mtk[body][2]+torque[2];
    } else {
        fs0flg = 0;
        ufk[body][0] = ufk[body][0]+force[0];
        utk[body][0] = utk[body][0]+torque[0];
        ufk[body][1] = ufk[body][1]+force[1];
        utk[body][1] = utk[body][1]+torque[1];
        ufk[body][2] = ufk[body][2]+force[2];
        utk[body][2] = utk[body][2]+torque[2];
    }
}

void sdbodyt(int body,
    double torque[3])
{

    if (sdchkbnum(12,body) != 0) {
        return;
    }
    if (roustate != 2) {
        sdseterr(12,23);
        return;
    }
    if (body == -1) {
        return;
    }
    if (mfrcflg != 0) {
        mtk[body][0] = mtk[body][0]+torque[0];
        mtk[body][1] = mtk[body][1]+torque[1];
        mtk[body][2] = mtk[body][2]+torque[2];
    } else {
        fs0flg = 0;
        utk[body][0] = utk[body][0]+torque[0];
        utk[body][1] = utk[body][1]+torque[1];
        utk[body][2] = utk[body][2]+torque[2];
    }
}

void sddoww(int routine)
{

    roustate = 2;
    if (wwflg == 0) {
        wwflg = 1;
    }
/*
 Used 0.00 seconds CPU time,
 0 additional bytes of memory.
 Equations contain    0 adds/subtracts/negates
                      0 multiplies
                      0 divides
                      0 assignments
*/
}

void sdxudot0(int routine,
    double oudot0[26])
{
/*
Compute unconstrained equations
*/
    int i;

    sdlhs(routine);
/*
Solve equations for udots
*/
    sdfs0();
    sdldubslv(26,26,mmap,works,mlo,mdi,fs,udot);
    for (i = 0; i <= 25; i++) {
        oudot0[i] = udot[i];
    }
/*
 Used 0.00 seconds CPU time,
 0 additional bytes of memory.
 Equations contain    0 adds/subtracts/negates
                      0 multiplies
                      0 divides
                     26 assignments
*/
}

void sdudot0(double oudot0[26])
{

    if ((roustate != 2) && (roustate != 3)) {
        sdseterr(66,23);
        return;
    }
    sdxudot0(66,oudot0);
}

void sdsetudot(double iudot[26])
{
/*
Assign udots and advance to stage Dynamics Ready
*/
    int i;

    if ((roustate != 2) && (roustate != 3)) {
        sdseterr(68,23);
        return;
    }
    for (i = 0; i <= 25; i++) {
        udot[i] = iudot[i];
    }
    sdrhs();
}

void sdxudotm(int routine,
    double imult[1],
    double oudotm[26])
{
/*
Compute udots due only to multipliers
*/
    int i;

    sdlhs(routine);
    for (i = 0; i <= 25; i++) {
        udot[i] = 0.;
    }
    for (i = 0; i <= 25; i++) {
        oudotm[i] = udot[i];
    }
/*
 Used 0.00 seconds CPU time,
 0 additional bytes of memory.
 Equations contain    0 adds/subtracts/negates
                      0 multiplies
                      0 divides
                     52 assignments
*/
}

void sdudotm(double imult[1],
    double oudotm[26])
{

    if ((roustate != 2) && (roustate != 3)) {
        sdseterr(67,23);
        return;
    }
    sdxudotm(67,imult,oudotm);
}

void sdderiv(double oqdot[27],
    double oudot[26])
{
/*
This is the derivative section for a 21-body ground-based
system with 26 hinge degree(s) of freedom.
*/
    int i;
    double udot0[26],udot1[26];

    if ((roustate != 2) && (roustate != 3)) {
        sdseterr(17,23);
        return;
    }
    if (stabvelq == 1) {
        sdseterr(17,32);
    }
    if (stabposq == 1) {
        sdseterr(17,33);
    }
    wsiz = 0;
/*
Compute unconstrained equations
*/
    sdxudot0(17,udot0);
    sdrhs();
    wrank = 0;
    for (i = 0; i <= 26; i++) {
        oqdot[i] = qdot[i];
    }
    for (i = 0; i <= 25; i++) {
        oudot[i] = udot[i];
    }
/*
 Used 0.00 seconds CPU time,
 0 additional bytes of memory.
 Equations contain    0 adds/subtracts/negates
                      0 multiplies
                      0 divides
                     53 assignments
*/
}
/*
Compute residuals for use with DAE integrator
*/

void sdresid(double eqdot[27],
    double eudot[26],
    double emults[1],
    double resid[53])
{
    int i;
    double uderrs[26];

    if ((roustate != 2) && (roustate != 3)) {
        sdseterr(16,23);
        return;
    }
    if (stabposq == 1) {
        sdseterr(16,33);
    }
    sdfulltrq(eudot,emults,uderrs);
    for (i = 0; i < 27; i++) {
        resid[i] = eqdot[i]-qdot[i];
    }
    for (i = 0; i < 26; i++) {
        resid[27+i] = uderrs[i];
    }
    for (i = 0; i < 26; i++) {
        udot[i] = eudot[i];
    }
    sdrhs();
/*
 Used 0.00 seconds CPU time,
 0 additional bytes of memory.
 Equations contain   27 adds/subtracts/negates
                      0 multiplies
                      0 divides
                     79 assignments
*/
}

void sdmult(double omults[1],
    int *owrank,
    int omultmap[1])
{

    if (roustate != 3) {
        sdseterr(34,24);
        return;
    }
    *owrank = wrank;
}

void sdreac(double force[21][3],
    double torque[21][3])
{
/*
Generated 01-Mar-2006 15:25:51 by SD/FAST, Kane's formulation
(sdfast B.2.8 #30123) on machine ID unknown
Copyright (c) 1990-1997 Symbolic Dynamics, Inc.
Copyright (c) 1990-1997 Parametric Technology Corp.
RESTRICTED RIGHTS LEGEND: Use, duplication, or disclosure by the U.S.
Government is subject to restrictions as set forth in subparagraph
(c)(1)(ii) of the Rights in Technical Data and Computer Software
clause at DFARS 52.227-7013 and similar clauses in the FAR and NASA
FAR Supplement.  Symbolic Dynamics, Inc., Mountain View, CA 94041
*/

    if (roustate != 3) {
        sdseterr(31,24);
        return;
    }
/*
Compute reaction forces for non-weld tree joints
*/
    fc[25][0] = ((mk[20]*(AnkAtk[25][0]-gk[25][0]))-ufk[20][0]);
    fc[25][1] = ((mk[20]*(AnkAtk[25][1]-gk[24][1]))-ufk[20][1]);
    fc[25][2] = ((mk[20]*(AnkAtk[25][2]-gk[25][2]))-ufk[20][2]);
    tc[25][0] = ((WkIkWk[25][0]+((ik[20][0][2]*onk[25][2])+((ik[20][0][0]*
      onk[25][0])+(ik[20][0][1]*onk[25][1]))))-(utk[20][0]+((fc[25][2]*rk[20][1]
      )-(fc[25][1]*rk[20][2]))));
    tc[25][1] = ((WkIkWk[25][1]+((ik[20][1][2]*onk[25][2])+((ik[20][1][0]*
      onk[25][0])+(ik[20][1][1]*onk[25][1]))))-(utk[20][1]+((fc[25][0]*rk[20][2]
      )-(fc[25][2]*rk[20][0]))));
    tc[25][2] = ((WkIkWk[25][2]+((ik[20][2][2]*onk[25][2])+((ik[20][2][0]*
      onk[25][0])+(ik[20][2][1]*onk[25][1]))))-(utk[20][2]+((fc[25][1]*rk[20][0]
      )-(fc[25][0]*rk[20][1]))));
    fccikt[25][0] = ((fc[25][0]*c25)-(fc[25][2]*s25));
    fccikt[25][1] = fc[25][1];
    fccikt[25][2] = ((fc[25][0]*s25)+(fc[25][2]*c25));
    ffk[24][0] = (ufk[19][0]-fccikt[25][0]);
    ffk[24][1] = (ufk[19][1]-fccikt[25][1]);
    ffk[24][2] = (ufk[19][2]-fccikt[25][2]);
    ttk[24][0] = (utk[19][0]-(((fccikt[25][2]*ri[20][1])-(fccikt[25][1]*
      ri[20][2]))+((tc[25][0]*c25)-(tc[25][2]*s25))));
    ttk[24][1] = (utk[19][1]-(tc[25][1]+((fccikt[25][0]*ri[20][2])-(
      fccikt[25][2]*ri[20][0]))));
    ttk[24][2] = (utk[19][2]-(((fccikt[25][1]*ri[20][0])-(fccikt[25][0]*
      ri[20][1]))+((tc[25][0]*s25)+(tc[25][2]*c25))));
    fc[24][0] = ((mk[19]*(AnkAtk[24][0]-gk[24][0]))-ffk[24][0]);
    fc[24][1] = ((mk[19]*(AnkAtk[24][1]-gk[24][1]))-ffk[24][1]);
    fc[24][2] = ((mk[19]*(AnkAtk[24][2]-gk[3][2]))-ffk[24][2]);
    tc[24][0] = ((WkIkWk[24][0]+((ik[19][0][2]*Onkb[24][2])+((ik[19][0][0]*
      onk[24][0])+(ik[19][0][1]*onk[24][1]))))-(ttk[24][0]+((fc[24][2]*rk[19][1]
      )-(fc[24][1]*rk[19][2]))));
    tc[24][1] = ((WkIkWk[24][1]+((ik[19][1][2]*Onkb[24][2])+((ik[19][1][0]*
      onk[24][0])+(ik[19][1][1]*onk[24][1]))))-(ttk[24][1]+((fc[24][0]*rk[19][2]
      )-(fc[24][2]*rk[19][0]))));
    tc[24][2] = ((WkIkWk[24][2]+((ik[19][2][2]*Onkb[24][2])+((ik[19][2][0]*
      onk[24][0])+(ik[19][2][1]*onk[24][1]))))-(ttk[24][2]+((fc[24][1]*rk[19][0]
      )-(fc[24][0]*rk[19][1]))));
    fccikt[24][0] = ((fc[24][0]*c24)-(fc[24][1]*s24));
    fccikt[24][1] = ((fc[24][0]*s24)+(fc[24][1]*c24));
    fccikt[24][2] = fc[24][2];
    ffk[5][0] = (ufk[0][0]-fccikt[24][0]);
    ffk[5][1] = (ufk[0][1]-fccikt[24][1]);
    ffk[5][2] = (ufk[0][2]-fccikt[24][2]);
    ttk[5][0] = (utk[0][0]-(((fccikt[24][2]*ri[19][1])-(fccikt[24][1]*ri[19][2])
      )+((tc[24][0]*c24)-(tc[24][1]*s24))));
    ttk[5][1] = (utk[0][1]-(((fccikt[24][0]*ri[19][2])-(fccikt[24][2]*ri[19][0])
      )+((tc[24][0]*s24)+(tc[24][1]*c24))));
    ttk[5][2] = (utk[0][2]-(tc[24][2]+((fccikt[24][1]*ri[19][0])-(fccikt[24][0]*
      ri[19][1]))));
    fc[23][0] = ((mk[18]*(AnkAtk[23][0]-gk[21][0]))-ufk[18][0]);
    fc[23][1] = ((mk[18]*(AnkAtk[23][1]-gk[23][1]))-ufk[18][1]);
    fc[23][2] = ((mk[18]*(AnkAtk[23][2]-gk[23][2]))-ufk[18][2]);
    tc[23][0] = ((WkIkWk[23][0]+((ik[18][0][2]*onk[23][2])+((ik[18][0][0]*
      onk[23][0])+(ik[18][0][1]*onk[23][1]))))-(utk[18][0]+((fc[23][2]*rk[18][1]
      )-(fc[23][1]*rk[18][2]))));
    tc[23][1] = ((WkIkWk[23][1]+((ik[18][1][2]*onk[23][2])+((ik[18][1][0]*
      onk[23][0])+(ik[18][1][1]*onk[23][1]))))-(utk[18][1]+((fc[23][0]*rk[18][2]
      )-(fc[23][2]*rk[18][0]))));
    tc[23][2] = ((WkIkWk[23][2]+((ik[18][2][2]*onk[23][2])+((ik[18][2][0]*
      onk[23][0])+(ik[18][2][1]*onk[23][1]))))-(utk[18][2]+((fc[23][1]*rk[18][0]
      )-(fc[23][0]*rk[18][1]))));
    fccikt[23][0] = fc[23][0];
    fccikt[23][1] = ((fc[23][1]*c23)-(fc[23][2]*s23));
    fccikt[23][2] = ((fc[23][1]*s23)+(fc[23][2]*c23));
    ffk[21][0] = (ufk[16][0]-fccikt[23][0]);
    ffk[21][1] = (ufk[16][1]-fccikt[23][1]);
    ffk[21][2] = (ufk[16][2]-fccikt[23][2]);
    ttk[21][0] = (utk[16][0]-(tc[23][0]+((fccikt[23][2]*ri[18][1])-(
      fccikt[23][1]*ri[18][2]))));
    ttk[21][1] = (utk[16][1]-(((fccikt[23][0]*ri[18][2])-(fccikt[23][2]*
      ri[18][0]))+((tc[23][1]*c23)-(tc[23][2]*s23))));
    ttk[21][2] = (utk[16][2]-(((fccikt[23][1]*ri[18][0])-(fccikt[23][0]*
      ri[18][1]))+((tc[23][1]*s23)+(tc[23][2]*c23))));
    fc[22][0] = ((mk[17]*(AnkAtk[22][0]-gk[20][0]))-ufk[17][0]);
    fc[22][1] = ((mk[17]*(AnkAtk[22][1]-gk[22][1]))-ufk[17][1]);
    fc[22][2] = ((mk[17]*(AnkAtk[22][2]-gk[22][2]))-ufk[17][2]);
    tc[22][0] = ((WkIkWk[22][0]+((ik[17][0][2]*onk[22][2])+((ik[17][0][0]*
      onk[22][0])+(ik[17][0][1]*onk[22][1]))))-(utk[17][0]+((fc[22][2]*rk[17][1]
      )-(fc[22][1]*rk[17][2]))));
    tc[22][1] = ((WkIkWk[22][1]+((ik[17][1][2]*onk[22][2])+((ik[17][1][0]*
      onk[22][0])+(ik[17][1][1]*onk[22][1]))))-(utk[17][1]+((fc[22][0]*rk[17][2]
      )-(fc[22][2]*rk[17][0]))));
    tc[22][2] = ((WkIkWk[22][2]+((ik[17][2][2]*onk[22][2])+((ik[17][2][0]*
      onk[22][0])+(ik[17][2][1]*onk[22][1]))))-(utk[17][2]+((fc[22][1]*rk[17][0]
      )-(fc[22][0]*rk[17][1]))));
    fccikt[22][0] = fc[22][0];
    fccikt[22][1] = ((fc[22][1]*c22)+(fc[22][2]*s22));
    fccikt[22][2] = ((fc[22][2]*c22)-(fc[22][1]*s22));
    ffk[20][0] = (ufk[15][0]-fccikt[22][0]);
    ffk[20][1] = (ufk[15][1]-fccikt[22][1]);
    ffk[20][2] = (ufk[15][2]-fccikt[22][2]);
    ttk[20][0] = (utk[15][0]-(tc[22][0]+((fccikt[22][2]*ri[17][1])-(
      fccikt[22][1]*ri[17][2]))));
    ttk[20][1] = (utk[15][1]-(((fccikt[22][0]*ri[17][2])-(fccikt[22][2]*
      ri[17][0]))+((tc[22][1]*c22)+(tc[22][2]*s22))));
    ttk[20][2] = (utk[15][2]-(((fccikt[22][1]*ri[17][0])-(fccikt[22][0]*
      ri[17][1]))+((tc[22][2]*c22)-(tc[22][1]*s22))));
    fc[21][0] = ((mk[16]*(AnkAtk[21][0]-gk[21][0]))-ffk[21][0]);
    fc[21][1] = ((mk[16]*(AnkAtk[21][1]-gk[15][1]))-ffk[21][1]);
    fc[21][2] = ((mk[16]*(AnkAtk[21][2]-gk[21][2]))-ffk[21][2]);
    tc[21][0] = ((WkIkWk[21][0]+((ik[16][0][2]*onk[21][2])+((ik[16][0][0]*
      onk[21][0])+(ik[16][0][1]*onk[21][1]))))-(ttk[21][0]+((fc[21][2]*rk[16][1]
      )-(fc[21][1]*rk[16][2]))));
    tc[21][1] = ((WkIkWk[21][1]+((ik[16][1][2]*onk[21][2])+((ik[16][1][0]*
      onk[21][0])+(ik[16][1][1]*onk[21][1]))))-(ttk[21][1]+((fc[21][0]*rk[16][2]
      )-(fc[21][2]*rk[16][0]))));
    tc[21][2] = ((WkIkWk[21][2]+((ik[16][2][2]*onk[21][2])+((ik[16][2][0]*
      onk[21][0])+(ik[16][2][1]*onk[21][1]))))-(ttk[21][2]+((fc[21][1]*rk[16][0]
      )-(fc[21][0]*rk[16][1]))));
    fccikt[21][0] = ((fc[21][0]*c21)-(fc[21][2]*s21));
    fccikt[21][1] = fc[21][1];
    fccikt[21][2] = ((fc[21][0]*s21)+(fc[21][2]*c21));
    ffk[19][0] = (ufk[14][0]-fccikt[21][0]);
    ffk[19][1] = (ufk[14][1]-fccikt[21][1]);
    ffk[19][2] = (ufk[14][2]-fccikt[21][2]);
    ttk[19][0] = (utk[14][0]-(((fccikt[21][2]*ri[16][1])-(fccikt[21][1]*
      ri[16][2]))+((tc[21][0]*c21)-(tc[21][2]*s21))));
    ttk[19][1] = (utk[14][1]-(tc[21][1]+((fccikt[21][0]*ri[16][2])-(
      fccikt[21][2]*ri[16][0]))));
    ttk[19][2] = (utk[14][2]-(((fccikt[21][1]*ri[16][0])-(fccikt[21][0]*
      ri[16][1]))+((tc[21][0]*s21)+(tc[21][2]*c21))));
    fc[20][0] = ((mk[15]*(AnkAtk[20][0]-gk[20][0]))-ffk[20][0]);
    fc[20][1] = ((mk[15]*(AnkAtk[20][1]-gk[14][1]))-ffk[20][1]);
    fc[20][2] = ((mk[15]*(AnkAtk[20][2]-gk[20][2]))-ffk[20][2]);
    tc[20][0] = ((WkIkWk[20][0]+((ik[15][0][2]*onk[20][2])+((ik[15][0][0]*
      onk[20][0])+(ik[15][0][1]*onk[20][1]))))-(ttk[20][0]+((fc[20][2]*rk[15][1]
      )-(fc[20][1]*rk[15][2]))));
    tc[20][1] = ((WkIkWk[20][1]+((ik[15][1][2]*onk[20][2])+((ik[15][1][0]*
      onk[20][0])+(ik[15][1][1]*onk[20][1]))))-(ttk[20][1]+((fc[20][0]*rk[15][2]
      )-(fc[20][2]*rk[15][0]))));
    tc[20][2] = ((WkIkWk[20][2]+((ik[15][2][2]*onk[20][2])+((ik[15][2][0]*
      onk[20][0])+(ik[15][2][1]*onk[20][1]))))-(ttk[20][2]+((fc[20][1]*rk[15][0]
      )-(fc[20][0]*rk[15][1]))));
    fccikt[20][0] = ((fc[20][0]*c20)-(fc[20][2]*s20));
    fccikt[20][1] = fc[20][1];
    fccikt[20][2] = ((fc[20][0]*s20)+(fc[20][2]*c20));
    ffk[18][0] = (ufk[13][0]-fccikt[20][0]);
    ffk[18][1] = (ufk[13][1]-fccikt[20][1]);
    ffk[18][2] = (ufk[13][2]-fccikt[20][2]);
    ttk[18][0] = (utk[13][0]-(((fccikt[20][2]*ri[15][1])-(fccikt[20][1]*
      ri[15][2]))+((tc[20][0]*c20)-(tc[20][2]*s20))));
    ttk[18][1] = (utk[13][1]-(tc[20][1]+((fccikt[20][0]*ri[15][2])-(
      fccikt[20][2]*ri[15][0]))));
    ttk[18][2] = (utk[13][2]-(((fccikt[20][1]*ri[15][0])-(fccikt[20][0]*
      ri[15][1]))+((tc[20][0]*s20)+(tc[20][2]*c20))));
    fc[19][0] = ((mk[14]*(AnkAtk[19][0]-gk[19][0]))-ffk[19][0]);
    fc[19][1] = ((mk[14]*(AnkAtk[19][1]-gk[15][1]))-ffk[19][1]);
    fc[19][2] = ((mk[14]*(AnkAtk[19][2]-gk[19][2]))-ffk[19][2]);
    tc[19][0] = ((WkIkWk[19][0]+((ik[14][0][2]*onk[19][2])+((ik[14][0][0]*
      onk[19][0])+(ik[14][0][1]*onk[19][1]))))-(ttk[19][0]+((fc[19][2]*rk[14][1]
      )-(fc[19][1]*rk[14][2]))));
    tc[19][1] = ((WkIkWk[19][1]+((ik[14][1][2]*onk[19][2])+((ik[14][1][0]*
      onk[19][0])+(ik[14][1][1]*onk[19][1]))))-(ttk[19][1]+((fc[19][0]*rk[14][2]
      )-(fc[19][2]*rk[14][0]))));
    tc[19][2] = ((WkIkWk[19][2]+((ik[14][2][2]*onk[19][2])+((ik[14][2][0]*
      onk[19][0])+(ik[14][2][1]*onk[19][1]))))-(ttk[19][2]+((fc[19][1]*rk[14][0]
      )-(fc[19][0]*rk[14][1]))));
    fccikt[19][0] = ((fc[19][0]*c19)-(fc[19][2]*s19));
    fccikt[19][1] = fc[19][1];
    fccikt[19][2] = ((fc[19][0]*s19)+(fc[19][2]*c19));
    ffk[17][0] = (ufk[12][0]-fccikt[19][0]);
    ffk[17][1] = (ufk[12][1]-fccikt[19][1]);
    ffk[17][2] = (ufk[12][2]-fccikt[19][2]);
    ttk[17][0] = (utk[12][0]-(((fccikt[19][2]*ri[14][1])-(fccikt[19][1]*
      ri[14][2]))+((tc[19][0]*c19)-(tc[19][2]*s19))));
    ttk[17][1] = (utk[12][1]-(tc[19][1]+((fccikt[19][0]*ri[14][2])-(
      fccikt[19][2]*ri[14][0]))));
    ttk[17][2] = (utk[12][2]-(((fccikt[19][1]*ri[14][0])-(fccikt[19][0]*
      ri[14][1]))+((tc[19][0]*s19)+(tc[19][2]*c19))));
    fc[18][0] = ((mk[13]*(AnkAtk[18][0]-gk[18][0]))-ffk[18][0]);
    fc[18][1] = ((mk[13]*(AnkAtk[18][1]-gk[14][1]))-ffk[18][1]);
    fc[18][2] = ((mk[13]*(AnkAtk[18][2]-gk[18][2]))-ffk[18][2]);
    tc[18][0] = ((WkIkWk[18][0]+((ik[13][0][2]*onk[18][2])+((ik[13][0][0]*
      onk[18][0])+(ik[13][0][1]*onk[18][1]))))-(ttk[18][0]+((fc[18][2]*rk[13][1]
      )-(fc[18][1]*rk[13][2]))));
    tc[18][1] = ((WkIkWk[18][1]+((ik[13][1][2]*onk[18][2])+((ik[13][1][0]*
      onk[18][0])+(ik[13][1][1]*onk[18][1]))))-(ttk[18][1]+((fc[18][0]*rk[13][2]
      )-(fc[18][2]*rk[13][0]))));
    tc[18][2] = ((WkIkWk[18][2]+((ik[13][2][2]*onk[18][2])+((ik[13][2][0]*
      onk[18][0])+(ik[13][2][1]*onk[18][1]))))-(ttk[18][2]+((fc[18][1]*rk[13][0]
      )-(fc[18][0]*rk[13][1]))));
    fccikt[18][0] = ((fc[18][0]*c18)-(fc[18][2]*s18));
    fccikt[18][1] = fc[18][1];
    fccikt[18][2] = ((fc[18][0]*s18)+(fc[18][2]*c18));
    ffk[16][0] = (ufk[11][0]-fccikt[18][0]);
    ffk[16][1] = (ufk[11][1]-fccikt[18][1]);
    ffk[16][2] = (ufk[11][2]-fccikt[18][2]);
    ttk[16][0] = (utk[11][0]-(((fccikt[18][2]*ri[13][1])-(fccikt[18][1]*
      ri[13][2]))+((tc[18][0]*c18)-(tc[18][2]*s18))));
    ttk[16][1] = (utk[11][1]-(tc[18][1]+((fccikt[18][0]*ri[13][2])-(
      fccikt[18][2]*ri[13][0]))));
    ttk[16][2] = (utk[11][2]-(((fccikt[18][1]*ri[13][0])-(fccikt[18][0]*
      ri[13][1]))+((tc[18][0]*s18)+(tc[18][2]*c18))));
    fc[17][0] = ((mk[12]*(AnkAtk[17][0]-gk[17][0]))-ffk[17][0]);
    fc[17][1] = ((mk[12]*(AnkAtk[17][1]-gk[15][1]))-ffk[17][1]);
    fc[17][2] = ((mk[12]*(AnkAtk[17][2]-gk[17][2]))-ffk[17][2]);
    tc[17][0] = ((WkIkWk[17][0]+((ik[12][0][2]*onk[17][2])+((ik[12][0][0]*
      onk[17][0])+(ik[12][0][1]*onk[17][1]))))-(ttk[17][0]+((fc[17][2]*rk[12][1]
      )-(fc[17][1]*rk[12][2]))));
    tc[17][1] = ((WkIkWk[17][1]+((ik[12][1][2]*onk[17][2])+((ik[12][1][0]*
      onk[17][0])+(ik[12][1][1]*onk[17][1]))))-(ttk[17][1]+((fc[17][0]*rk[12][2]
      )-(fc[17][2]*rk[12][0]))));
    tc[17][2] = ((WkIkWk[17][2]+((ik[12][2][2]*onk[17][2])+((ik[12][2][0]*
      onk[17][0])+(ik[12][2][1]*onk[17][1]))))-(ttk[17][2]+((fc[17][1]*rk[12][0]
      )-(fc[17][0]*rk[12][1]))));
    fccikt[17][0] = ((fc[17][0]*c17)-(fc[17][2]*s17));
    fccikt[17][1] = fc[17][1];
    fccikt[17][2] = ((fc[17][0]*s17)+(fc[17][2]*c17));
    ffk[15][0] = (ufk[10][0]-fccikt[17][0]);
    ffk[15][1] = (ufk[10][1]-fccikt[17][1]);
    ffk[15][2] = (ufk[10][2]-fccikt[17][2]);
    ttk[15][0] = (utk[10][0]-(((fccikt[17][2]*ri[12][1])-(fccikt[17][1]*
      ri[12][2]))+((tc[17][0]*c17)-(tc[17][2]*s17))));
    ttk[15][1] = (utk[10][1]-(tc[17][1]+((fccikt[17][0]*ri[12][2])-(
      fccikt[17][2]*ri[12][0]))));
    ttk[15][2] = (utk[10][2]-(((fccikt[17][1]*ri[12][0])-(fccikt[17][0]*
      ri[12][1]))+((tc[17][0]*s17)+(tc[17][2]*c17))));
    fc[16][0] = ((mk[11]*(AnkAtk[16][0]-gk[16][0]))-ffk[16][0]);
    fc[16][1] = ((mk[11]*(AnkAtk[16][1]-gk[14][1]))-ffk[16][1]);
    fc[16][2] = ((mk[11]*(AnkAtk[16][2]-gk[16][2]))-ffk[16][2]);
    tc[16][0] = ((WkIkWk[16][0]+((ik[11][0][2]*onk[16][2])+((ik[11][0][0]*
      onk[16][0])+(ik[11][0][1]*onk[16][1]))))-(ttk[16][0]+((fc[16][2]*rk[11][1]
      )-(fc[16][1]*rk[11][2]))));
    tc[16][1] = ((WkIkWk[16][1]+((ik[11][1][2]*onk[16][2])+((ik[11][1][0]*
      onk[16][0])+(ik[11][1][1]*onk[16][1]))))-(ttk[16][1]+((fc[16][0]*rk[11][2]
      )-(fc[16][2]*rk[11][0]))));
    tc[16][2] = ((WkIkWk[16][2]+((ik[11][2][2]*onk[16][2])+((ik[11][2][0]*
      onk[16][0])+(ik[11][2][1]*onk[16][1]))))-(ttk[16][2]+((fc[16][1]*rk[11][0]
      )-(fc[16][0]*rk[11][1]))));
    fccikt[16][0] = ((fc[16][0]*c16)-(fc[16][2]*s16));
    fccikt[16][1] = fc[16][1];
    fccikt[16][2] = ((fc[16][0]*s16)+(fc[16][2]*c16));
    ffk[14][0] = (ufk[9][0]-fccikt[16][0]);
    ffk[14][1] = (ufk[9][1]-fccikt[16][1]);
    ffk[14][2] = (ufk[9][2]-fccikt[16][2]);
    ttk[14][0] = (utk[9][0]-(((fccikt[16][2]*ri[11][1])-(fccikt[16][1]*ri[11][2]
      ))+((tc[16][0]*c16)-(tc[16][2]*s16))));
    ttk[14][1] = (utk[9][1]-(tc[16][1]+((fccikt[16][0]*ri[11][2])-(fccikt[16][2]
      *ri[11][0]))));
    ttk[14][2] = (utk[9][2]-(((fccikt[16][1]*ri[11][0])-(fccikt[16][0]*ri[11][1]
      ))+((tc[16][0]*s16)+(tc[16][2]*c16))));
    fc[15][0] = ((mk[10]*(AnkAtk[15][0]-gk[13][0]))-ffk[15][0]);
    fc[15][1] = ((mk[10]*(AnkAtk[15][1]-gk[15][1]))-ffk[15][1]);
    fc[15][2] = ((mk[10]*(AnkAtk[15][2]-gk[15][2]))-ffk[15][2]);
    tc[15][0] = ((WkIkWk[15][0]+((ik[10][0][2]*onk[15][2])+((ik[10][0][0]*
      onk[15][0])+(ik[10][0][1]*onk[15][1]))))-(ttk[15][0]+((fc[15][2]*rk[10][1]
      )-(fc[15][1]*rk[10][2]))));
    tc[15][1] = ((WkIkWk[15][1]+((ik[10][1][2]*onk[15][2])+((ik[10][1][0]*
      onk[15][0])+(ik[10][1][1]*onk[15][1]))))-(ttk[15][1]+((fc[15][0]*rk[10][2]
      )-(fc[15][2]*rk[10][0]))));
    tc[15][2] = ((WkIkWk[15][2]+((ik[10][2][2]*onk[15][2])+((ik[10][2][0]*
      onk[15][0])+(ik[10][2][1]*onk[15][1]))))-(ttk[15][2]+((fc[15][1]*rk[10][0]
      )-(fc[15][0]*rk[10][1]))));
    fccikt[15][0] = fc[15][0];
    fccikt[15][1] = ((fc[15][1]*c15)-(fc[15][2]*s15));
    fccikt[15][2] = ((fc[15][1]*s15)+(fc[15][2]*c15));
    ffk[13][0] = (ufk[8][0]-fccikt[15][0]);
    ffk[13][1] = (ufk[8][1]-fccikt[15][1]);
    ffk[13][2] = (ufk[8][2]-fccikt[15][2]);
    ttk[13][0] = (utk[8][0]-(tc[15][0]+((fccikt[15][2]*ri[10][1])-(fccikt[15][1]
      *ri[10][2]))));
    ttk[13][1] = (utk[8][1]-(((fccikt[15][0]*ri[10][2])-(fccikt[15][2]*ri[10][0]
      ))+((tc[15][1]*c15)-(tc[15][2]*s15))));
    ttk[13][2] = (utk[8][2]-(((fccikt[15][1]*ri[10][0])-(fccikt[15][0]*ri[10][1]
      ))+((tc[15][1]*s15)+(tc[15][2]*c15))));
    fc[14][0] = ((mk[9]*(AnkAtk[14][0]-gk[12][0]))-ffk[14][0]);
    fc[14][1] = ((mk[9]*(AnkAtk[14][1]-gk[14][1]))-ffk[14][1]);
    fc[14][2] = ((mk[9]*(AnkAtk[14][2]-gk[14][2]))-ffk[14][2]);
    tc[14][0] = ((WkIkWk[14][0]+((ik[9][0][2]*onk[14][2])+((ik[9][0][0]*
      onk[14][0])+(ik[9][0][1]*onk[14][1]))))-(ttk[14][0]+((fc[14][2]*rk[9][1])-
      (fc[14][1]*rk[9][2]))));
    tc[14][1] = ((WkIkWk[14][1]+((ik[9][1][2]*onk[14][2])+((ik[9][1][0]*
      onk[14][0])+(ik[9][1][1]*onk[14][1]))))-(ttk[14][1]+((fc[14][0]*rk[9][2])-
      (fc[14][2]*rk[9][0]))));
    tc[14][2] = ((WkIkWk[14][2]+((ik[9][2][2]*onk[14][2])+((ik[9][2][0]*
      onk[14][0])+(ik[9][2][1]*onk[14][1]))))-(ttk[14][2]+((fc[14][1]*rk[9][0])-
      (fc[14][0]*rk[9][1]))));
    fccikt[14][0] = fc[14][0];
    fccikt[14][1] = ((fc[14][1]*c14)+(fc[14][2]*s14));
    fccikt[14][2] = ((fc[14][2]*c14)-(fc[14][1]*s14));
    ffk[12][0] = (ufk[7][0]-fccikt[14][0]);
    ffk[12][1] = (ufk[7][1]-fccikt[14][1]);
    ffk[12][2] = (ufk[7][2]-fccikt[14][2]);
    ttk[12][0] = (utk[7][0]-(tc[14][0]+((fccikt[14][2]*ri[9][1])-(fccikt[14][1]*
      ri[9][2]))));
    ttk[12][1] = (utk[7][1]-(((fccikt[14][0]*ri[9][2])-(fccikt[14][2]*ri[9][0]))
      +((tc[14][1]*c14)+(tc[14][2]*s14))));
    ttk[12][2] = (utk[7][2]-(((fccikt[14][1]*ri[9][0])-(fccikt[14][0]*ri[9][1]))
      +((tc[14][2]*c14)-(tc[14][1]*s14))));
    fc[13][0] = ((mk[8]*(AnkAtk[13][0]-gk[13][0]))-ffk[13][0]);
    fc[13][1] = ((mk[8]*(AnkAtk[13][1]-gk[13][1]))-ffk[13][1]);
    fc[13][2] = ((mk[8]*(AnkAtk[13][2]-gk[3][2]))-ffk[13][2]);
    tc[13][0] = ((WkIkWk[13][0]+((ik[8][0][2]*Onkb[13][2])+((ik[8][0][0]*
      onk[13][0])+(ik[8][0][1]*onk[13][1]))))-(ttk[13][0]+((fc[13][2]*rk[8][1])-
      (fc[13][1]*rk[8][2]))));
    tc[13][1] = ((WkIkWk[13][1]+((ik[8][1][2]*Onkb[13][2])+((ik[8][1][0]*
      onk[13][0])+(ik[8][1][1]*onk[13][1]))))-(ttk[13][1]+((fc[13][0]*rk[8][2])-
      (fc[13][2]*rk[8][0]))));
    tc[13][2] = ((WkIkWk[13][2]+((ik[8][2][2]*Onkb[13][2])+((ik[8][2][0]*
      onk[13][0])+(ik[8][2][1]*onk[13][1]))))-(ttk[13][2]+((fc[13][1]*rk[8][0])-
      (fc[13][0]*rk[8][1]))));
    fccikt[13][0] = ((fc[13][0]*c13)-(fc[13][1]*s13));
    fccikt[13][1] = ((fc[13][0]*s13)+(fc[13][1]*c13));
    fccikt[13][2] = fc[13][2];
    ffk[5][0] = (ffk[5][0]-fccikt[13][0]);
    ffk[5][1] = (ffk[5][1]-fccikt[13][1]);
    ffk[5][2] = (ffk[5][2]-fccikt[13][2]);
    ttk[5][0] = (ttk[5][0]-(((fccikt[13][2]*ri[8][1])-(fccikt[13][1]*ri[8][2]))+
      ((tc[13][0]*c13)-(tc[13][1]*s13))));
    ttk[5][1] = (ttk[5][1]-(((fccikt[13][0]*ri[8][2])-(fccikt[13][2]*ri[8][0]))+
      ((tc[13][0]*s13)+(tc[13][1]*c13))));
    ttk[5][2] = (ttk[5][2]-(tc[13][2]+((fccikt[13][1]*ri[8][0])-(fccikt[13][0]*
      ri[8][1]))));
    fc[12][0] = ((mk[7]*(AnkAtk[12][0]-gk[12][0]))-ffk[12][0]);
    fc[12][1] = ((mk[7]*(AnkAtk[12][1]-gk[12][1]))-ffk[12][1]);
    fc[12][2] = ((mk[7]*(AnkAtk[12][2]-gk[3][2]))-ffk[12][2]);
    tc[12][0] = ((WkIkWk[12][0]+((ik[7][0][2]*Onkb[12][2])+((ik[7][0][0]*
      onk[12][0])+(ik[7][0][1]*onk[12][1]))))-(ttk[12][0]+((fc[12][2]*rk[7][1])-
      (fc[12][1]*rk[7][2]))));
    tc[12][1] = ((WkIkWk[12][1]+((ik[7][1][2]*Onkb[12][2])+((ik[7][1][0]*
      onk[12][0])+(ik[7][1][1]*onk[12][1]))))-(ttk[12][1]+((fc[12][0]*rk[7][2])-
      (fc[12][2]*rk[7][0]))));
    tc[12][2] = ((WkIkWk[12][2]+((ik[7][2][2]*Onkb[12][2])+((ik[7][2][0]*
      onk[12][0])+(ik[7][2][1]*onk[12][1]))))-(ttk[12][2]+((fc[12][1]*rk[7][0])-
      (fc[12][0]*rk[7][1]))));
    fccikt[12][0] = ((fc[12][0]*c12)+(fc[12][1]*s12));
    fccikt[12][1] = ((fc[12][1]*c12)-(fc[12][0]*s12));
    fccikt[12][2] = fc[12][2];
    ffk[5][0] = (ffk[5][0]-fccikt[12][0]);
    ffk[5][1] = (ffk[5][1]-fccikt[12][1]);
    ffk[5][2] = (ffk[5][2]-fccikt[12][2]);
    ttk[5][0] = (ttk[5][0]-(((fccikt[12][2]*ri[7][1])-(fccikt[12][1]*ri[7][2]))+
      ((tc[12][0]*c12)+(tc[12][1]*s12))));
    ttk[5][1] = (ttk[5][1]-(((fccikt[12][0]*ri[7][2])-(fccikt[12][2]*ri[7][0]))+
      ((tc[12][1]*c12)-(tc[12][0]*s12))));
    ttk[5][2] = (ttk[5][2]-(tc[12][2]+((fccikt[12][1]*ri[7][0])-(fccikt[12][0]*
      ri[7][1]))));
    fc[11][0] = ((mk[6]*(AnkAtk[11][0]-gk[11][0]))-ufk[6][0]);
    fc[11][1] = ((mk[6]*(AnkAtk[11][1]-gk[11][1]))-ufk[6][1]);
    fc[11][2] = ((mk[6]*(AnkAtk[11][2]-gk[9][2]))-ufk[6][2]);
    tc[11][0] = ((WkIkWk[11][0]+((ik[6][0][2]*onk[11][2])+((ik[6][0][0]*
      onk[11][0])+(ik[6][0][1]*onk[11][1]))))-(utk[6][0]+((fc[11][2]*rk[6][1])-(
      fc[11][1]*rk[6][2]))));
    tc[11][1] = ((WkIkWk[11][1]+((ik[6][1][2]*onk[11][2])+((ik[6][1][0]*
      onk[11][0])+(ik[6][1][1]*onk[11][1]))))-(utk[6][1]+((fc[11][0]*rk[6][2])-(
      fc[11][2]*rk[6][0]))));
    tc[11][2] = ((WkIkWk[11][2]+((ik[6][2][2]*onk[11][2])+((ik[6][2][0]*
      onk[11][0])+(ik[6][2][1]*onk[11][1]))))-(utk[6][2]+((fc[11][1]*rk[6][0])-(
      fc[11][0]*rk[6][1]))));
    fccikt[11][0] = ((fc[11][0]*c11)-(fc[11][1]*s11));
    fccikt[11][1] = ((fc[11][0]*s11)+(fc[11][1]*c11));
    fccikt[11][2] = fc[11][2];
    ffk[9][0] = (ufk[4][0]-fccikt[11][0]);
    ffk[9][1] = (ufk[4][1]-fccikt[11][1]);
    ffk[9][2] = (ufk[4][2]-fccikt[11][2]);
    ttk[9][0] = (utk[4][0]-(((fccikt[11][2]*ri[6][1])-(fccikt[11][1]*ri[6][2]))+
      ((tc[11][0]*c11)-(tc[11][1]*s11))));
    ttk[9][1] = (utk[4][1]-(((fccikt[11][0]*ri[6][2])-(fccikt[11][2]*ri[6][0]))+
      ((tc[11][0]*s11)+(tc[11][1]*c11))));
    ttk[9][2] = (utk[4][2]-(tc[11][2]+((fccikt[11][1]*ri[6][0])-(fccikt[11][0]*
      ri[6][1]))));
    fc[10][0] = ((mk[5]*(AnkAtk[10][0]-gk[10][0]))-ufk[5][0]);
    fc[10][1] = ((mk[5]*(AnkAtk[10][1]-gk[10][1]))-ufk[5][1]);
    fc[10][2] = ((mk[5]*(AnkAtk[10][2]-gk[8][2]))-ufk[5][2]);
    tc[10][0] = ((WkIkWk[10][0]+((ik[5][0][2]*onk[10][2])+((ik[5][0][0]*
      onk[10][0])+(ik[5][0][1]*onk[10][1]))))-(utk[5][0]+((fc[10][2]*rk[5][1])-(
      fc[10][1]*rk[5][2]))));
    tc[10][1] = ((WkIkWk[10][1]+((ik[5][1][2]*onk[10][2])+((ik[5][1][0]*
      onk[10][0])+(ik[5][1][1]*onk[10][1]))))-(utk[5][1]+((fc[10][0]*rk[5][2])-(
      fc[10][2]*rk[5][0]))));
    tc[10][2] = ((WkIkWk[10][2]+((ik[5][2][2]*onk[10][2])+((ik[5][2][0]*
      onk[10][0])+(ik[5][2][1]*onk[10][1]))))-(utk[5][2]+((fc[10][1]*rk[5][0])-(
      fc[10][0]*rk[5][1]))));
    fccikt[10][0] = ((fc[10][0]*c10)+(fc[10][1]*s10));
    fccikt[10][1] = ((fc[10][1]*c10)-(fc[10][0]*s10));
    fccikt[10][2] = fc[10][2];
    ffk[8][0] = (ufk[3][0]-fccikt[10][0]);
    ffk[8][1] = (ufk[3][1]-fccikt[10][1]);
    ffk[8][2] = (ufk[3][2]-fccikt[10][2]);
    ttk[8][0] = (utk[3][0]-(((fccikt[10][2]*ri[5][1])-(fccikt[10][1]*ri[5][2]))+
      ((tc[10][0]*c10)+(tc[10][1]*s10))));
    ttk[8][1] = (utk[3][1]-(((fccikt[10][0]*ri[5][2])-(fccikt[10][2]*ri[5][0]))+
      ((tc[10][1]*c10)-(tc[10][0]*s10))));
    ttk[8][2] = (utk[3][2]-(tc[10][2]+((fccikt[10][1]*ri[5][0])-(fccikt[10][0]*
      ri[5][1]))));
    fc[9][0] = ((mk[4]*(AnkAtk[9][0]-gk[7][0]))-ffk[9][0]);
    fc[9][1] = ((mk[4]*(AnkAtk[9][1]-gk[9][1]))-ffk[9][1]);
    fc[9][2] = ((mk[4]*(AnkAtk[9][2]-gk[9][2]))-ffk[9][2]);
    tc[9][0] = ((WkIkWk[9][0]+((ik[4][0][2]*onk[9][2])+((ik[4][0][0]*onk[9][0])+
      (ik[4][0][1]*onk[9][1]))))-(ttk[9][0]+((fc[9][2]*rk[4][1])-(fc[9][1]*
      rk[4][2]))));
    tc[9][1] = ((WkIkWk[9][1]+((ik[4][1][2]*onk[9][2])+((ik[4][1][0]*onk[9][0])+
      (ik[4][1][1]*onk[9][1]))))-(ttk[9][1]+((fc[9][0]*rk[4][2])-(fc[9][2]*
      rk[4][0]))));
    tc[9][2] = ((WkIkWk[9][2]+((ik[4][2][2]*onk[9][2])+((ik[4][2][0]*onk[9][0])+
      (ik[4][2][1]*onk[9][1]))))-(ttk[9][2]+((fc[9][1]*rk[4][0])-(fc[9][0]*
      rk[4][1]))));
    fccikt[9][0] = fc[9][0];
    fccikt[9][1] = ((fc[9][1]*c9)-(fc[9][2]*s9));
    fccikt[9][2] = ((fc[9][1]*s9)+(fc[9][2]*c9));
    ffk[7][0] = (ufk[2][0]-fccikt[9][0]);
    ffk[7][1] = (ufk[2][1]-fccikt[9][1]);
    ffk[7][2] = (ufk[2][2]-fccikt[9][2]);
    ttk[7][0] = (utk[2][0]-(tc[9][0]+((fccikt[9][2]*ri[4][1])-(fccikt[9][1]*
      ri[4][2]))));
    ttk[7][1] = (utk[2][1]-(((fccikt[9][0]*ri[4][2])-(fccikt[9][2]*ri[4][0]))+((
      tc[9][1]*c9)-(tc[9][2]*s9))));
    ttk[7][2] = (utk[2][2]-(((fccikt[9][1]*ri[4][0])-(fccikt[9][0]*ri[4][1]))+((
      tc[9][1]*s9)+(tc[9][2]*c9))));
    fc[8][0] = ((mk[3]*(AnkAtk[8][0]-gk[6][0]))-ffk[8][0]);
    fc[8][1] = ((mk[3]*(AnkAtk[8][1]-gk[8][1]))-ffk[8][1]);
    fc[8][2] = ((mk[3]*(AnkAtk[8][2]-gk[8][2]))-ffk[8][2]);
    tc[8][0] = ((WkIkWk[8][0]+((ik[3][0][2]*onk[8][2])+((ik[3][0][0]*onk[8][0])+
      (ik[3][0][1]*onk[8][1]))))-(ttk[8][0]+((fc[8][2]*rk[3][1])-(fc[8][1]*
      rk[3][2]))));
    tc[8][1] = ((WkIkWk[8][1]+((ik[3][1][2]*onk[8][2])+((ik[3][1][0]*onk[8][0])+
      (ik[3][1][1]*onk[8][1]))))-(ttk[8][1]+((fc[8][0]*rk[3][2])-(fc[8][2]*
      rk[3][0]))));
    tc[8][2] = ((WkIkWk[8][2]+((ik[3][2][2]*onk[8][2])+((ik[3][2][0]*onk[8][0])+
      (ik[3][2][1]*onk[8][1]))))-(ttk[8][2]+((fc[8][1]*rk[3][0])-(fc[8][0]*
      rk[3][1]))));
    fccikt[8][0] = fc[8][0];
    fccikt[8][1] = ((fc[8][1]*c8)+(fc[8][2]*s8));
    fccikt[8][2] = ((fc[8][2]*c8)-(fc[8][1]*s8));
    ffk[6][0] = (ufk[1][0]-fccikt[8][0]);
    ffk[6][1] = (ufk[1][1]-fccikt[8][1]);
    ffk[6][2] = (ufk[1][2]-fccikt[8][2]);
    ttk[6][0] = (utk[1][0]-(tc[8][0]+((fccikt[8][2]*ri[3][1])-(fccikt[8][1]*
      ri[3][2]))));
    ttk[6][1] = (utk[1][1]-(((fccikt[8][0]*ri[3][2])-(fccikt[8][2]*ri[3][0]))+((
      tc[8][1]*c8)+(tc[8][2]*s8))));
    ttk[6][2] = (utk[1][2]-(((fccikt[8][1]*ri[3][0])-(fccikt[8][0]*ri[3][1]))+((
      tc[8][2]*c8)-(tc[8][1]*s8))));
    fc[7][0] = ((mk[2]*(AnkAtk[7][0]-gk[7][0]))-ffk[7][0]);
    fc[7][1] = ((mk[2]*(AnkAtk[7][1]-gk[3][1]))-ffk[7][1]);
    fc[7][2] = ((mk[2]*(AnkAtk[7][2]-gk[7][2]))-ffk[7][2]);
    tc[7][0] = ((WkIkWk[7][0]+((ik[2][0][2]*onk[7][2])+((ik[2][0][0]*onk[7][0])+
      (ik[2][0][1]*Onkb[7][1]))))-(ttk[7][0]+((fc[7][2]*rk[2][1])-(fc[7][1]*
      rk[2][2]))));
    tc[7][1] = ((WkIkWk[7][1]+((ik[2][1][2]*onk[7][2])+((ik[2][1][0]*onk[7][0])+
      (ik[2][1][1]*Onkb[7][1]))))-(ttk[7][1]+((fc[7][0]*rk[2][2])-(fc[7][2]*
      rk[2][0]))));
    tc[7][2] = ((WkIkWk[7][2]+((ik[2][2][2]*onk[7][2])+((ik[2][2][0]*onk[7][0])+
      (ik[2][2][1]*Onkb[7][1]))))-(ttk[7][2]+((fc[7][1]*rk[2][0])-(fc[7][0]*
      rk[2][1]))));
    fccikt[7][0] = ((fc[7][0]*c7)-(fc[7][2]*s7));
    fccikt[7][1] = fc[7][1];
    fccikt[7][2] = ((fc[7][0]*s7)+(fc[7][2]*c7));
    ffk[5][0] = (ffk[5][0]-fccikt[7][0]);
    ffk[5][1] = (ffk[5][1]-fccikt[7][1]);
    ffk[5][2] = (ffk[5][2]-fccikt[7][2]);
    ttk[5][0] = (ttk[5][0]-(((fccikt[7][2]*ri[2][1])-(fccikt[7][1]*ri[2][2]))+((
      tc[7][0]*c7)-(tc[7][2]*s7))));
    ttk[5][1] = (ttk[5][1]-(tc[7][1]+((fccikt[7][0]*ri[2][2])-(fccikt[7][2]*
      ri[2][0]))));
    ttk[5][2] = (ttk[5][2]-(((fccikt[7][1]*ri[2][0])-(fccikt[7][0]*ri[2][1]))+((
      tc[7][0]*s7)+(tc[7][2]*c7))));
    fc[6][0] = ((mk[1]*(AnkAtk[6][0]-gk[6][0]))-ffk[6][0]);
    fc[6][1] = ((mk[1]*(AnkAtk[6][1]-gk[3][1]))-ffk[6][1]);
    fc[6][2] = ((mk[1]*(AnkAtk[6][2]-gk[6][2]))-ffk[6][2]);
    tc[6][0] = ((WkIkWk[6][0]+((ik[1][0][2]*onk[6][2])+((ik[1][0][0]*onk[6][0])+
      (ik[1][0][1]*Onkb[6][1]))))-(ttk[6][0]+((fc[6][2]*rk[1][1])-(fc[6][1]*
      rk[1][2]))));
    tc[6][1] = ((WkIkWk[6][1]+((ik[1][1][2]*onk[6][2])+((ik[1][1][0]*onk[6][0])+
      (ik[1][1][1]*Onkb[6][1]))))-(ttk[6][1]+((fc[6][0]*rk[1][2])-(fc[6][2]*
      rk[1][0]))));
    tc[6][2] = ((WkIkWk[6][2]+((ik[1][2][2]*onk[6][2])+((ik[1][2][0]*onk[6][0])+
      (ik[1][2][1]*Onkb[6][1]))))-(ttk[6][2]+((fc[6][1]*rk[1][0])-(fc[6][0]*
      rk[1][1]))));
    fccikt[6][0] = ((fc[6][0]*c6)-(fc[6][2]*s6));
    fccikt[6][1] = fc[6][1];
    fccikt[6][2] = ((fc[6][0]*s6)+(fc[6][2]*c6));
    ffk[5][0] = (ffk[5][0]-fccikt[6][0]);
    ffk[5][1] = (ffk[5][1]-fccikt[6][1]);
    ffk[5][2] = (ffk[5][2]-fccikt[6][2]);
    ttk[5][0] = (ttk[5][0]-(((fccikt[6][2]*ri[1][1])-(fccikt[6][1]*ri[1][2]))+((
      tc[6][0]*c6)-(tc[6][2]*s6))));
    ttk[5][1] = (ttk[5][1]-(tc[6][1]+((fccikt[6][0]*ri[1][2])-(fccikt[6][2]*
      ri[1][0]))));
    ttk[5][2] = (ttk[5][2]-(((fccikt[6][1]*ri[1][0])-(fccikt[6][0]*ri[1][1]))+((
      tc[6][0]*s6)+(tc[6][2]*c6))));
    fc[5][0] = ((mk[0]*(AnkAtk[5][0]-gk[3][0]))-ffk[5][0]);
    fc[5][1] = ((mk[0]*(AnkAtk[5][1]-gk[3][1]))-ffk[5][1]);
    fc[5][2] = ((mk[0]*(AnkAtk[5][2]-gk[3][2]))-ffk[5][2]);
    tc[5][0] = ((WkIkWk[5][0]+((ik[0][0][2]*udot[5])+((ik[0][0][0]*udot[3])+(
      ik[0][0][1]*udot[4]))))-(ttk[5][0]+((fc[5][2]*rk[0][1])-(fc[5][1]*rk[0][2]
      ))));
    tc[5][1] = ((WkIkWk[5][1]+((ik[0][1][2]*udot[5])+((ik[0][1][0]*udot[3])+(
      ik[0][1][1]*udot[4]))))-(ttk[5][1]+((fc[5][0]*rk[0][2])-(fc[5][2]*rk[0][0]
      ))));
    tc[5][2] = ((WkIkWk[5][2]+((ik[0][2][2]*udot[5])+((ik[0][2][0]*udot[3])+(
      ik[0][2][1]*udot[4]))))-(ttk[5][2]+((fc[5][1]*rk[0][0])-(fc[5][0]*rk[0][1]
      ))));
    fccikt[5][0] = fc[5][0];
    fccikt[5][1] = fc[5][1];
    fccikt[5][2] = fc[5][2];
    ffk[4][0] = -fccikt[5][0];
    ffk[4][1] = -fccikt[5][1];
    ffk[4][2] = -fccikt[5][2];
    ttk[4][0] = -tc[5][0];
    ttk[4][1] = -tc[5][1];
    ttk[4][2] = -tc[5][2];
    fc[4][0] = -ffk[4][0];
    fc[4][1] = -ffk[4][1];
    fc[4][2] = -ffk[4][2];
    tc[4][0] = -ttk[4][0];
    tc[4][1] = -ttk[4][1];
    tc[4][2] = -ttk[4][2];
    fccikt[4][0] = fc[4][0];
    fccikt[4][1] = fc[4][1];
    fccikt[4][2] = fc[4][2];
    ffk[3][0] = -fccikt[4][0];
    ffk[3][1] = -fccikt[4][1];
    ffk[3][2] = -fccikt[4][2];
    ttk[3][0] = -tc[4][0];
    ttk[3][1] = -tc[4][1];
    ttk[3][2] = -tc[4][2];
    fc[3][0] = -ffk[3][0];
    fc[3][1] = -ffk[3][1];
    fc[3][2] = -ffk[3][2];
    tc[3][0] = -ttk[3][0];
    tc[3][1] = -ttk[3][1];
    tc[3][2] = -ttk[3][2];
    fccikt[3][0] = ((Cik[3][0][2]*fc[3][2])+((Cik[3][0][0]*fc[3][0])+(
      Cik[3][0][1]*fc[3][1])));
    fccikt[3][1] = ((Cik[3][1][2]*fc[3][2])+((Cik[3][1][0]*fc[3][0])+(
      Cik[3][1][1]*fc[3][1])));
    fccikt[3][2] = ((Cik[3][2][2]*fc[3][2])+((Cik[3][2][0]*fc[3][0])+(
      Cik[3][2][1]*fc[3][1])));
    ffk[2][0] = -fccikt[3][0];
    ffk[2][1] = -fccikt[3][1];
    ffk[2][2] = -fccikt[3][2];
    ttk[2][0] = -((Cik[3][0][2]*tc[3][2])+((Cik[3][0][0]*tc[3][0])+(Cik[3][0][1]
      *tc[3][1])));
    ttk[2][1] = -((Cik[3][1][2]*tc[3][2])+((Cik[3][1][0]*tc[3][0])+(Cik[3][1][1]
      *tc[3][1])));
    ttk[2][2] = -((Cik[3][2][2]*tc[3][2])+((Cik[3][2][0]*tc[3][0])+(Cik[3][2][1]
      *tc[3][1])));
    fc[2][0] = -ffk[2][0];
    fc[2][1] = -ffk[2][1];
    fc[2][2] = -ffk[2][2];
    tc[2][0] = -ttk[2][0];
    tc[2][1] = -ttk[2][1];
    tc[2][2] = -ttk[2][2];
    fccikt[2][0] = fc[2][0];
    fccikt[2][1] = fc[2][1];
    fccikt[2][2] = fc[2][2];
    ffk[1][0] = -fccikt[2][0];
    ffk[1][1] = -fccikt[2][1];
    ffk[1][2] = -fccikt[2][2];
    ttk[1][0] = -(tc[2][0]-(fccikt[2][1]*q[2]));
    ttk[1][1] = -(tc[2][1]+(fccikt[2][0]*q[2]));
    ttk[1][2] = -tc[2][2];
    fc[1][0] = -ffk[1][0];
    fc[1][1] = -ffk[1][1];
    fc[1][2] = -ffk[1][2];
    tc[1][0] = -ttk[1][0];
    tc[1][1] = -ttk[1][1];
    tc[1][2] = -ttk[1][2];
    fccikt[1][0] = fc[1][0];
    fccikt[1][1] = fc[1][1];
    fccikt[1][2] = fc[1][2];
    ffk[0][0] = -fccikt[1][0];
    ffk[0][1] = -fccikt[1][1];
    ffk[0][2] = -fccikt[1][2];
    ttk[0][0] = -(tc[1][0]+(fccikt[1][2]*q[1]));
    ttk[0][1] = -tc[1][1];
    ttk[0][2] = -(tc[1][2]-(fccikt[1][0]*q[1]));
    fc[0][0] = -ffk[0][0];
    fc[0][1] = -ffk[0][1];
    fc[0][2] = -ffk[0][2];
    tc[0][0] = -ttk[0][0];
    tc[0][1] = -ttk[0][1];
    tc[0][2] = -ttk[0][2];
    force[0][0] = fc[5][0];
    torque[0][0] = tc[5][0];
    force[0][1] = fc[5][1];
    torque[0][1] = tc[5][1];
    force[0][2] = fc[5][2];
    torque[0][2] = tc[5][2];
    force[1][0] = fc[6][0];
    torque[1][0] = tc[6][0];
    force[1][1] = fc[6][1];
    torque[1][1] = tc[6][1];
    force[1][2] = fc[6][2];
    torque[1][2] = tc[6][2];
    force[2][0] = fc[7][0];
    torque[2][0] = tc[7][0];
    force[2][1] = fc[7][1];
    torque[2][1] = tc[7][1];
    force[2][2] = fc[7][2];
    torque[2][2] = tc[7][2];
    force[3][0] = fc[8][0];
    torque[3][0] = tc[8][0];
    force[3][1] = fc[8][1];
    torque[3][1] = tc[8][1];
    force[3][2] = fc[8][2];
    torque[3][2] = tc[8][2];
    force[4][0] = fc[9][0];
    torque[4][0] = tc[9][0];
    force[4][1] = fc[9][1];
    torque[4][1] = tc[9][1];
    force[4][2] = fc[9][2];
    torque[4][2] = tc[9][2];
    force[5][0] = fc[10][0];
    torque[5][0] = tc[10][0];
    force[5][1] = fc[10][1];
    torque[5][1] = tc[10][1];
    force[5][2] = fc[10][2];
    torque[5][2] = tc[10][2];
    force[6][0] = fc[11][0];
    torque[6][0] = tc[11][0];
    force[6][1] = fc[11][1];
    torque[6][1] = tc[11][1];
    force[6][2] = fc[11][2];
    torque[6][2] = tc[11][2];
    force[7][0] = fc[12][0];
    torque[7][0] = tc[12][0];
    force[7][1] = fc[12][1];
    torque[7][1] = tc[12][1];
    force[7][2] = fc[12][2];
    torque[7][2] = tc[12][2];
    force[8][0] = fc[13][0];
    torque[8][0] = tc[13][0];
    force[8][1] = fc[13][1];
    torque[8][1] = tc[13][1];
    force[8][2] = fc[13][2];
    torque[8][2] = tc[13][2];
    force[9][0] = fc[14][0];
    torque[9][0] = tc[14][0];
    force[9][1] = fc[14][1];
    torque[9][1] = tc[14][1];
    force[9][2] = fc[14][2];
    torque[9][2] = tc[14][2];
    force[10][0] = fc[15][0];
    torque[10][0] = tc[15][0];
    force[10][1] = fc[15][1];
    torque[10][1] = tc[15][1];
    force[10][2] = fc[15][2];
    torque[10][2] = tc[15][2];
    force[11][0] = fc[16][0];
    torque[11][0] = tc[16][0];
    force[11][1] = fc[16][1];
    torque[11][1] = tc[16][1];
    force[11][2] = fc[16][2];
    torque[11][2] = tc[16][2];
    force[12][0] = fc[17][0];
    torque[12][0] = tc[17][0];
    force[12][1] = fc[17][1];
    torque[12][1] = tc[17][1];
    force[12][2] = fc[17][2];
    torque[12][2] = tc[17][2];
    force[13][0] = fc[18][0];
    torque[13][0] = tc[18][0];
    force[13][1] = fc[18][1];
    torque[13][1] = tc[18][1];
    force[13][2] = fc[18][2];
    torque[13][2] = tc[18][2];
    force[14][0] = fc[19][0];
    torque[14][0] = tc[19][0];
    force[14][1] = fc[19][1];
    torque[14][1] = tc[19][1];
    force[14][2] = fc[19][2];
    torque[14][2] = tc[19][2];
    force[15][0] = fc[20][0];
    torque[15][0] = tc[20][0];
    force[15][1] = fc[20][1];
    torque[15][1] = tc[20][1];
    force[15][2] = fc[20][2];
    torque[15][2] = tc[20][2];
    force[16][0] = fc[21][0];
    torque[16][0] = tc[21][0];
    force[16][1] = fc[21][1];
    torque[16][1] = tc[21][1];
    force[16][2] = fc[21][2];
    torque[16][2] = tc[21][2];
    force[17][0] = fc[22][0];
    torque[17][0] = tc[22][0];
    force[17][1] = fc[22][1];
    torque[17][1] = tc[22][1];
    force[17][2] = fc[22][2];
    torque[17][2] = tc[22][2];
    force[18][0] = fc[23][0];
    torque[18][0] = tc[23][0];
    force[18][1] = fc[23][1];
    torque[18][1] = tc[23][1];
    force[18][2] = fc[23][2];
    torque[18][2] = tc[23][2];
    force[19][0] = fc[24][0];
    torque[19][0] = tc[24][0];
    force[19][1] = fc[24][1];
    torque[19][1] = tc[24][1];
    force[19][2] = fc[24][2];
    torque[19][2] = tc[24][2];
    force[20][0] = fc[25][0];
    torque[20][0] = tc[25][0];
    force[20][1] = fc[25][1];
    torque[20][1] = tc[25][1];
    force[20][2] = fc[25][2];
    torque[20][2] = tc[25][2];
/*
Compute reaction forces for tree weld joints
*/
/*
 Used 0.01 seconds CPU time,
 0 additional bytes of memory.
 Equations contain  900 adds/subtracts/negates
                    680 multiplies
                      0 divides
                    507 assignments
*/
}

void sdmom(double lm[3],
    double am[3],
    double *ke)
{
/*
Compute system linear and angular momentum, and kinetic energy.

Generated 01-Mar-2006 15:25:51 by SD/FAST, Kane's formulation
(sdfast B.2.8 #30123) on machine ID unknown
Copyright (c) 1990-1997 Symbolic Dynamics, Inc.
Copyright (c) 1990-1997 Parametric Technology Corp.
RESTRICTED RIGHTS LEGEND: Use, duplication, or disclosure by the U.S.
Government is subject to restrictions as set forth in subparagraph
(c)(1)(ii) of the Rights in Technical Data and Computer Software
clause at DFARS 52.227-7013 and similar clauses in the FAR and NASA
FAR Supplement.  Symbolic Dynamics, Inc., Mountain View, CA 94041
*/
    double lk[21][3],hnk[21][3];

    if ((roustate != 2) && (roustate != 3)) {
        sdseterr(19,23);
        return;
    }
    lk[0][0] = (mk[0]*vnk[5][0]);
    lk[0][1] = (mk[0]*vnk[5][1]);
    lk[0][2] = (mk[0]*vnk[5][2]);
    lk[1][0] = (mk[1]*vnk[6][0]);
    lk[1][1] = (mk[1]*vnk[6][1]);
    lk[1][2] = (mk[1]*vnk[6][2]);
    lk[2][0] = (mk[2]*vnk[7][0]);
    lk[2][1] = (mk[2]*vnk[7][1]);
    lk[2][2] = (mk[2]*vnk[7][2]);
    lk[3][0] = (mk[3]*vnk[8][0]);
    lk[3][1] = (mk[3]*vnk[8][1]);
    lk[3][2] = (mk[3]*vnk[8][2]);
    lk[4][0] = (mk[4]*vnk[9][0]);
    lk[4][1] = (mk[4]*vnk[9][1]);
    lk[4][2] = (mk[4]*vnk[9][2]);
    lk[5][0] = (mk[5]*vnk[10][0]);
    lk[5][1] = (mk[5]*vnk[10][1]);
    lk[5][2] = (mk[5]*vnk[10][2]);
    lk[6][0] = (mk[6]*vnk[11][0]);
    lk[6][1] = (mk[6]*vnk[11][1]);
    lk[6][2] = (mk[6]*vnk[11][2]);
    lk[7][0] = (mk[7]*vnk[12][0]);
    lk[7][1] = (mk[7]*vnk[12][1]);
    lk[7][2] = (mk[7]*vnk[12][2]);
    lk[8][0] = (mk[8]*vnk[13][0]);
    lk[8][1] = (mk[8]*vnk[13][1]);
    lk[8][2] = (mk[8]*vnk[13][2]);
    lk[9][0] = (mk[9]*vnk[14][0]);
    lk[9][1] = (mk[9]*vnk[14][1]);
    lk[9][2] = (mk[9]*vnk[14][2]);
    lk[10][0] = (mk[10]*vnk[15][0]);
    lk[10][1] = (mk[10]*vnk[15][1]);
    lk[10][2] = (mk[10]*vnk[15][2]);
    lk[11][0] = (mk[11]*vnk[16][0]);
    lk[11][1] = (mk[11]*vnk[16][1]);
    lk[11][2] = (mk[11]*vnk[16][2]);
    lk[12][0] = (mk[12]*vnk[17][0]);
    lk[12][1] = (mk[12]*vnk[17][1]);
    lk[12][2] = (mk[12]*vnk[17][2]);
    lk[13][0] = (mk[13]*vnk[18][0]);
    lk[13][1] = (mk[13]*vnk[18][1]);
    lk[13][2] = (mk[13]*vnk[18][2]);
    lk[14][0] = (mk[14]*vnk[19][0]);
    lk[14][1] = (mk[14]*vnk[19][1]);
    lk[14][2] = (mk[14]*vnk[19][2]);
    lk[15][0] = (mk[15]*vnk[20][0]);
    lk[15][1] = (mk[15]*vnk[20][1]);
    lk[15][2] = (mk[15]*vnk[20][2]);
    lk[16][0] = (mk[16]*vnk[21][0]);
    lk[16][1] = (mk[16]*vnk[21][1]);
    lk[16][2] = (mk[16]*vnk[21][2]);
    lk[17][0] = (mk[17]*vnk[22][0]);
    lk[17][1] = (mk[17]*vnk[22][1]);
    lk[17][2] = (mk[17]*vnk[22][2]);
    lk[18][0] = (mk[18]*vnk[23][0]);
    lk[18][1] = (mk[18]*vnk[23][1]);
    lk[18][2] = (mk[18]*vnk[23][2]);
    lk[19][0] = (mk[19]*vnk[24][0]);
    lk[19][1] = (mk[19]*vnk[24][1]);
    lk[19][2] = (mk[19]*vnk[24][2]);
    lk[20][0] = (mk[20]*vnk[25][0]);
    lk[20][1] = (mk[20]*vnk[25][1]);
    lk[20][2] = (mk[20]*vnk[25][2]);
    hnk[0][0] = ((ik[0][0][2]*u[5])+((ik[0][0][0]*u[3])+(ik[0][0][1]*u[4])));
    hnk[0][1] = ((ik[0][1][2]*u[5])+((ik[0][1][0]*u[3])+(ik[0][1][1]*u[4])));
    hnk[0][2] = ((ik[0][2][2]*u[5])+((ik[0][2][0]*u[3])+(ik[0][2][1]*u[4])));
    hnk[1][0] = ((ik[1][0][2]*wk[6][2])+((ik[1][0][0]*wk[6][0])+(ik[1][0][1]*
      wk[6][1])));
    hnk[1][1] = ((ik[1][1][2]*wk[6][2])+((ik[1][1][0]*wk[6][0])+(ik[1][1][1]*
      wk[6][1])));
    hnk[1][2] = ((ik[1][2][2]*wk[6][2])+((ik[1][2][0]*wk[6][0])+(ik[1][2][1]*
      wk[6][1])));
    hnk[2][0] = ((ik[2][0][2]*wk[7][2])+((ik[2][0][0]*wk[7][0])+(ik[2][0][1]*
      wk[7][1])));
    hnk[2][1] = ((ik[2][1][2]*wk[7][2])+((ik[2][1][0]*wk[7][0])+(ik[2][1][1]*
      wk[7][1])));
    hnk[2][2] = ((ik[2][2][2]*wk[7][2])+((ik[2][2][0]*wk[7][0])+(ik[2][2][1]*
      wk[7][1])));
    hnk[3][0] = ((ik[3][0][2]*wk[8][2])+((ik[3][0][0]*wk[8][0])+(ik[3][0][1]*
      wk[8][1])));
    hnk[3][1] = ((ik[3][1][2]*wk[8][2])+((ik[3][1][0]*wk[8][0])+(ik[3][1][1]*
      wk[8][1])));
    hnk[3][2] = ((ik[3][2][2]*wk[8][2])+((ik[3][2][0]*wk[8][0])+(ik[3][2][1]*
      wk[8][1])));
    hnk[4][0] = ((ik[4][0][2]*wk[9][2])+((ik[4][0][0]*wk[9][0])+(ik[4][0][1]*
      wk[9][1])));
    hnk[4][1] = ((ik[4][1][2]*wk[9][2])+((ik[4][1][0]*wk[9][0])+(ik[4][1][1]*
      wk[9][1])));
    hnk[4][2] = ((ik[4][2][2]*wk[9][2])+((ik[4][2][0]*wk[9][0])+(ik[4][2][1]*
      wk[9][1])));
    hnk[5][0] = ((ik[5][0][2]*wk[10][2])+((ik[5][0][0]*wk[10][0])+(ik[5][0][1]*
      wk[10][1])));
    hnk[5][1] = ((ik[5][1][2]*wk[10][2])+((ik[5][1][0]*wk[10][0])+(ik[5][1][1]*
      wk[10][1])));
    hnk[5][2] = ((ik[5][2][2]*wk[10][2])+((ik[5][2][0]*wk[10][0])+(ik[5][2][1]*
      wk[10][1])));
    hnk[6][0] = ((ik[6][0][2]*wk[11][2])+((ik[6][0][0]*wk[11][0])+(ik[6][0][1]*
      wk[11][1])));
    hnk[6][1] = ((ik[6][1][2]*wk[11][2])+((ik[6][1][0]*wk[11][0])+(ik[6][1][1]*
      wk[11][1])));
    hnk[6][2] = ((ik[6][2][2]*wk[11][2])+((ik[6][2][0]*wk[11][0])+(ik[6][2][1]*
      wk[11][1])));
    hnk[7][0] = ((ik[7][0][2]*wk[12][2])+((ik[7][0][0]*wk[12][0])+(ik[7][0][1]*
      wk[12][1])));
    hnk[7][1] = ((ik[7][1][2]*wk[12][2])+((ik[7][1][0]*wk[12][0])+(ik[7][1][1]*
      wk[12][1])));
    hnk[7][2] = ((ik[7][2][2]*wk[12][2])+((ik[7][2][0]*wk[12][0])+(ik[7][2][1]*
      wk[12][1])));
    hnk[8][0] = ((ik[8][0][2]*wk[13][2])+((ik[8][0][0]*wk[13][0])+(ik[8][0][1]*
      wk[13][1])));
    hnk[8][1] = ((ik[8][1][2]*wk[13][2])+((ik[8][1][0]*wk[13][0])+(ik[8][1][1]*
      wk[13][1])));
    hnk[8][2] = ((ik[8][2][2]*wk[13][2])+((ik[8][2][0]*wk[13][0])+(ik[8][2][1]*
      wk[13][1])));
    hnk[9][0] = ((ik[9][0][2]*wk[14][2])+((ik[9][0][0]*wk[14][0])+(ik[9][0][1]*
      wk[14][1])));
    hnk[9][1] = ((ik[9][1][2]*wk[14][2])+((ik[9][1][0]*wk[14][0])+(ik[9][1][1]*
      wk[14][1])));
    hnk[9][2] = ((ik[9][2][2]*wk[14][2])+((ik[9][2][0]*wk[14][0])+(ik[9][2][1]*
      wk[14][1])));
    hnk[10][0] = ((ik[10][0][2]*wk[15][2])+((ik[10][0][0]*wk[15][0])+(
      ik[10][0][1]*wk[15][1])));
    hnk[10][1] = ((ik[10][1][2]*wk[15][2])+((ik[10][1][0]*wk[15][0])+(
      ik[10][1][1]*wk[15][1])));
    hnk[10][2] = ((ik[10][2][2]*wk[15][2])+((ik[10][2][0]*wk[15][0])+(
      ik[10][2][1]*wk[15][1])));
    hnk[11][0] = ((ik[11][0][2]*wk[16][2])+((ik[11][0][0]*wk[16][0])+(
      ik[11][0][1]*wk[16][1])));
    hnk[11][1] = ((ik[11][1][2]*wk[16][2])+((ik[11][1][0]*wk[16][0])+(
      ik[11][1][1]*wk[16][1])));
    hnk[11][2] = ((ik[11][2][2]*wk[16][2])+((ik[11][2][0]*wk[16][0])+(
      ik[11][2][1]*wk[16][1])));
    hnk[12][0] = ((ik[12][0][2]*wk[17][2])+((ik[12][0][0]*wk[17][0])+(
      ik[12][0][1]*wk[17][1])));
    hnk[12][1] = ((ik[12][1][2]*wk[17][2])+((ik[12][1][0]*wk[17][0])+(
      ik[12][1][1]*wk[17][1])));
    hnk[12][2] = ((ik[12][2][2]*wk[17][2])+((ik[12][2][0]*wk[17][0])+(
      ik[12][2][1]*wk[17][1])));
    hnk[13][0] = ((ik[13][0][2]*wk[18][2])+((ik[13][0][0]*wk[18][0])+(
      ik[13][0][1]*wk[18][1])));
    hnk[13][1] = ((ik[13][1][2]*wk[18][2])+((ik[13][1][0]*wk[18][0])+(
      ik[13][1][1]*wk[18][1])));
    hnk[13][2] = ((ik[13][2][2]*wk[18][2])+((ik[13][2][0]*wk[18][0])+(
      ik[13][2][1]*wk[18][1])));
    hnk[14][0] = ((ik[14][0][2]*wk[19][2])+((ik[14][0][0]*wk[19][0])+(
      ik[14][0][1]*wk[19][1])));
    hnk[14][1] = ((ik[14][1][2]*wk[19][2])+((ik[14][1][0]*wk[19][0])+(
      ik[14][1][1]*wk[19][1])));
    hnk[14][2] = ((ik[14][2][2]*wk[19][2])+((ik[14][2][0]*wk[19][0])+(
      ik[14][2][1]*wk[19][1])));
    hnk[15][0] = ((ik[15][0][2]*wk[20][2])+((ik[15][0][0]*wk[20][0])+(
      ik[15][0][1]*wk[20][1])));
    hnk[15][1] = ((ik[15][1][2]*wk[20][2])+((ik[15][1][0]*wk[20][0])+(
      ik[15][1][1]*wk[20][1])));
    hnk[15][2] = ((ik[15][2][2]*wk[20][2])+((ik[15][2][0]*wk[20][0])+(
      ik[15][2][1]*wk[20][1])));
    hnk[16][0] = ((ik[16][0][2]*wk[21][2])+((ik[16][0][0]*wk[21][0])+(
      ik[16][0][1]*wk[21][1])));
    hnk[16][1] = ((ik[16][1][2]*wk[21][2])+((ik[16][1][0]*wk[21][0])+(
      ik[16][1][1]*wk[21][1])));
    hnk[16][2] = ((ik[16][2][2]*wk[21][2])+((ik[16][2][0]*wk[21][0])+(
      ik[16][2][1]*wk[21][1])));
    hnk[17][0] = ((ik[17][0][2]*wk[22][2])+((ik[17][0][0]*wk[22][0])+(
      ik[17][0][1]*wk[22][1])));
    hnk[17][1] = ((ik[17][1][2]*wk[22][2])+((ik[17][1][0]*wk[22][0])+(
      ik[17][1][1]*wk[22][1])));
    hnk[17][2] = ((ik[17][2][2]*wk[22][2])+((ik[17][2][0]*wk[22][0])+(
      ik[17][2][1]*wk[22][1])));
    hnk[18][0] = ((ik[18][0][2]*wk[23][2])+((ik[18][0][0]*wk[23][0])+(
      ik[18][0][1]*wk[23][1])));
    hnk[18][1] = ((ik[18][1][2]*wk[23][2])+((ik[18][1][0]*wk[23][0])+(
      ik[18][1][1]*wk[23][1])));
    hnk[18][2] = ((ik[18][2][2]*wk[23][2])+((ik[18][2][0]*wk[23][0])+(
      ik[18][2][1]*wk[23][1])));
    hnk[19][0] = ((ik[19][0][2]*wk[24][2])+((ik[19][0][0]*wk[24][0])+(
      ik[19][0][1]*wk[24][1])));
    hnk[19][1] = ((ik[19][1][2]*wk[24][2])+((ik[19][1][0]*wk[24][0])+(
      ik[19][1][1]*wk[24][1])));
    hnk[19][2] = ((ik[19][2][2]*wk[24][2])+((ik[19][2][0]*wk[24][0])+(
      ik[19][2][1]*wk[24][1])));
    hnk[20][0] = ((ik[20][0][2]*wk[25][2])+((ik[20][0][0]*wk[25][0])+(
      ik[20][0][1]*wk[25][1])));
    hnk[20][1] = ((ik[20][1][2]*wk[25][2])+((ik[20][1][0]*wk[25][0])+(
      ik[20][1][1]*wk[25][1])));
    hnk[20][2] = ((ik[20][2][2]*wk[25][2])+((ik[20][2][0]*wk[25][0])+(
      ik[20][2][1]*wk[25][1])));
    lm[0] = (lk[20][0]+(lk[19][0]+(lk[18][0]+(lk[17][0]+(lk[16][0]+(lk[15][0]+(
      lk[14][0]+(lk[13][0]+(lk[12][0]+(lk[11][0]+(lk[10][0]+(lk[9][0]+(lk[8][0]+
      (lk[7][0]+(lk[6][0]+(lk[5][0]+(lk[4][0]+(lk[3][0]+(lk[2][0]+(lk[0][0]+
      lk[1][0]))))))))))))))))))));
    lm[1] = (lk[20][1]+(lk[19][1]+(lk[18][1]+(lk[17][1]+(lk[16][1]+(lk[15][1]+(
      lk[14][1]+(lk[13][1]+(lk[12][1]+(lk[11][1]+(lk[10][1]+(lk[9][1]+(lk[8][1]+
      (lk[7][1]+(lk[6][1]+(lk[5][1]+(lk[4][1]+(lk[3][1]+(lk[2][1]+(lk[0][1]+
      lk[1][1]))))))))))))))))))));
    lm[2] = (lk[20][2]+(lk[19][2]+(lk[18][2]+(lk[17][2]+(lk[16][2]+(lk[15][2]+(
      lk[14][2]+(lk[13][2]+(lk[12][2]+(lk[11][2]+(lk[10][2]+(lk[9][2]+(lk[8][2]+
      (lk[7][2]+(lk[6][2]+(lk[5][2]+(lk[4][2]+(lk[3][2]+(lk[2][2]+(lk[0][2]+
      lk[1][2]))))))))))))))))))));
    temp[0] = ((((cnk[7][0][2]*hnk[2][2])+((Cik[3][0][1]*hnk[2][1])+(
      cnk[7][0][0]*hnk[2][0])))+((lk[2][2]*rnk[7][1])-(lk[2][1]*rnk[7][2])))+(((
      (Cik[3][0][2]*hnk[0][2])+((Cik[3][0][0]*hnk[0][0])+(Cik[3][0][1]*hnk[0][1]
      )))+((lk[0][2]*rnk[5][1])-(lk[0][1]*rnk[5][2])))+(((cnk[6][0][2]*hnk[1][2]
      )+((Cik[3][0][1]*hnk[1][1])+(cnk[6][0][0]*hnk[1][0])))+((lk[1][2]*
      rnk[6][1])-(lk[1][1]*rnk[6][2])))));
    temp[1] = ((((cnk[9][0][2]*hnk[4][2])+((cnk[7][0][0]*hnk[4][0])+(
      cnk[9][0][1]*hnk[4][1])))+((lk[4][2]*rnk[9][1])-(lk[4][1]*rnk[9][2])))+(((
      (cnk[8][0][2]*hnk[3][2])+((cnk[6][0][0]*hnk[3][0])+(cnk[8][0][1]*hnk[3][1]
      )))+((lk[3][2]*rnk[8][1])-(lk[3][1]*rnk[8][2])))+temp[0]));
    temp[2] = ((((cnk[9][0][2]*hnk[6][2])+((cnk[11][0][0]*hnk[6][0])+(
      cnk[11][0][1]*hnk[6][1])))+((lk[6][2]*rnk[11][1])-(lk[6][1]*rnk[11][2])))+
      ((((cnk[8][0][2]*hnk[5][2])+((cnk[10][0][0]*hnk[5][0])+(cnk[10][0][1]*
      hnk[5][1])))+((lk[5][2]*rnk[10][1])-(lk[5][1]*rnk[10][2])))+temp[1]));
    temp[3] = ((((Cik[3][0][2]*hnk[8][2])+((cnk[13][0][0]*hnk[8][0])+(
      cnk[13][0][1]*hnk[8][1])))+((lk[8][2]*rnk[13][1])-(lk[8][1]*rnk[13][2])))+
      ((((Cik[3][0][2]*hnk[7][2])+((cnk[12][0][0]*hnk[7][0])+(cnk[12][0][1]*
      hnk[7][1])))+((lk[7][2]*rnk[12][1])-(lk[7][1]*rnk[12][2])))+temp[2]));
    temp[4] = ((((cnk[15][0][2]*hnk[10][2])+((cnk[13][0][0]*hnk[10][0])+(
      cnk[15][0][1]*hnk[10][1])))+((lk[10][2]*rnk[15][1])-(lk[10][1]*rnk[15][2])
      ))+((((cnk[14][0][2]*hnk[9][2])+((cnk[12][0][0]*hnk[9][0])+(cnk[14][0][1]*
      hnk[9][1])))+((lk[9][2]*rnk[14][1])-(lk[9][1]*rnk[14][2])))+temp[3]));
    temp[5] = ((((cnk[17][0][2]*hnk[12][2])+((cnk[15][0][1]*hnk[12][1])+(
      cnk[17][0][0]*hnk[12][0])))+((lk[12][2]*rnk[17][1])-(lk[12][1]*rnk[17][2])
      ))+((((cnk[16][0][2]*hnk[11][2])+((cnk[14][0][1]*hnk[11][1])+(
      cnk[16][0][0]*hnk[11][0])))+((lk[11][2]*rnk[16][1])-(lk[11][1]*rnk[16][2])
      ))+temp[4]));
    temp[6] = ((((cnk[19][0][2]*hnk[14][2])+((cnk[15][0][1]*hnk[14][1])+(
      cnk[19][0][0]*hnk[14][0])))+((lk[14][2]*rnk[19][1])-(lk[14][1]*rnk[19][2])
      ))+((((cnk[18][0][2]*hnk[13][2])+((cnk[14][0][1]*hnk[13][1])+(
      cnk[18][0][0]*hnk[13][0])))+((lk[13][2]*rnk[18][1])-(lk[13][1]*rnk[18][2])
      ))+temp[5]));
    temp[7] = ((((cnk[21][0][2]*hnk[16][2])+((cnk[15][0][1]*hnk[16][1])+(
      cnk[21][0][0]*hnk[16][0])))+((lk[16][2]*rnk[21][1])-(lk[16][1]*rnk[21][2])
      ))+((((cnk[20][0][2]*hnk[15][2])+((cnk[14][0][1]*hnk[15][1])+(
      cnk[20][0][0]*hnk[15][0])))+((lk[15][2]*rnk[20][1])-(lk[15][1]*rnk[20][2])
      ))+temp[6]));
    temp[8] = ((((cnk[23][0][2]*hnk[18][2])+((cnk[21][0][0]*hnk[18][0])+(
      cnk[23][0][1]*hnk[18][1])))+((lk[18][2]*rnk[23][1])-(lk[18][1]*rnk[23][2])
      ))+((((cnk[22][0][2]*hnk[17][2])+((cnk[20][0][0]*hnk[17][0])+(
      cnk[22][0][1]*hnk[17][1])))+((lk[17][2]*rnk[22][1])-(lk[17][1]*rnk[22][2])
      ))+temp[7]));
    am[0] = (((((cnk[25][0][2]*hnk[20][2])+((cnk[24][0][1]*hnk[20][1])+(
      cnk[25][0][0]*hnk[20][0])))+((lk[20][2]*rnk[25][1])-(lk[20][1]*rnk[25][2])
      ))+((((Cik[3][0][2]*hnk[19][2])+((cnk[24][0][0]*hnk[19][0])+(cnk[24][0][1]
      *hnk[19][1])))+((lk[19][2]*rnk[24][1])-(lk[19][1]*rnk[24][2])))+temp[8]))-
      ((com[1]*lm[2])-(com[2]*lm[1])));
    temp[0] = ((((cnk[7][1][2]*hnk[2][2])+((Cik[3][1][1]*hnk[2][1])+(
      cnk[7][1][0]*hnk[2][0])))+((lk[2][0]*rnk[7][2])-(lk[2][2]*rnk[7][0])))+(((
      (Cik[3][1][2]*hnk[0][2])+((Cik[3][1][0]*hnk[0][0])+(Cik[3][1][1]*hnk[0][1]
      )))+((lk[0][0]*rnk[5][2])-(lk[0][2]*rnk[5][0])))+(((cnk[6][1][2]*hnk[1][2]
      )+((Cik[3][1][1]*hnk[1][1])+(cnk[6][1][0]*hnk[1][0])))+((lk[1][0]*
      rnk[6][2])-(lk[1][2]*rnk[6][0])))));
    temp[1] = ((((cnk[9][1][2]*hnk[4][2])+((cnk[7][1][0]*hnk[4][0])+(
      cnk[9][1][1]*hnk[4][1])))+((lk[4][0]*rnk[9][2])-(lk[4][2]*rnk[9][0])))+(((
      (cnk[8][1][2]*hnk[3][2])+((cnk[6][1][0]*hnk[3][0])+(cnk[8][1][1]*hnk[3][1]
      )))+((lk[3][0]*rnk[8][2])-(lk[3][2]*rnk[8][0])))+temp[0]));
    temp[2] = ((((cnk[9][1][2]*hnk[6][2])+((cnk[11][1][0]*hnk[6][0])+(
      cnk[11][1][1]*hnk[6][1])))+((lk[6][0]*rnk[11][2])-(lk[6][2]*rnk[11][0])))+
      ((((cnk[8][1][2]*hnk[5][2])+((cnk[10][1][0]*hnk[5][0])+(cnk[10][1][1]*
      hnk[5][1])))+((lk[5][0]*rnk[10][2])-(lk[5][2]*rnk[10][0])))+temp[1]));
    temp[3] = ((((Cik[3][1][2]*hnk[8][2])+((cnk[13][1][0]*hnk[8][0])+(
      cnk[13][1][1]*hnk[8][1])))+((lk[8][0]*rnk[13][2])-(lk[8][2]*rnk[13][0])))+
      ((((Cik[3][1][2]*hnk[7][2])+((cnk[12][1][0]*hnk[7][0])+(cnk[12][1][1]*
      hnk[7][1])))+((lk[7][0]*rnk[12][2])-(lk[7][2]*rnk[12][0])))+temp[2]));
    temp[4] = ((((cnk[15][1][2]*hnk[10][2])+((cnk[13][1][0]*hnk[10][0])+(
      cnk[15][1][1]*hnk[10][1])))+((lk[10][0]*rnk[15][2])-(lk[10][2]*rnk[15][0])
      ))+((((cnk[14][1][2]*hnk[9][2])+((cnk[12][1][0]*hnk[9][0])+(cnk[14][1][1]*
      hnk[9][1])))+((lk[9][0]*rnk[14][2])-(lk[9][2]*rnk[14][0])))+temp[3]));
    temp[5] = ((((cnk[17][1][2]*hnk[12][2])+((cnk[15][1][1]*hnk[12][1])+(
      cnk[17][1][0]*hnk[12][0])))+((lk[12][0]*rnk[17][2])-(lk[12][2]*rnk[17][0])
      ))+((((cnk[16][1][2]*hnk[11][2])+((cnk[14][1][1]*hnk[11][1])+(
      cnk[16][1][0]*hnk[11][0])))+((lk[11][0]*rnk[16][2])-(lk[11][2]*rnk[16][0])
      ))+temp[4]));
    temp[6] = ((((cnk[19][1][2]*hnk[14][2])+((cnk[15][1][1]*hnk[14][1])+(
      cnk[19][1][0]*hnk[14][0])))+((lk[14][0]*rnk[19][2])-(lk[14][2]*rnk[19][0])
      ))+((((cnk[18][1][2]*hnk[13][2])+((cnk[14][1][1]*hnk[13][1])+(
      cnk[18][1][0]*hnk[13][0])))+((lk[13][0]*rnk[18][2])-(lk[13][2]*rnk[18][0])
      ))+temp[5]));
    temp[7] = ((((cnk[21][1][2]*hnk[16][2])+((cnk[15][1][1]*hnk[16][1])+(
      cnk[21][1][0]*hnk[16][0])))+((lk[16][0]*rnk[21][2])-(lk[16][2]*rnk[21][0])
      ))+((((cnk[20][1][2]*hnk[15][2])+((cnk[14][1][1]*hnk[15][1])+(
      cnk[20][1][0]*hnk[15][0])))+((lk[15][0]*rnk[20][2])-(lk[15][2]*rnk[20][0])
      ))+temp[6]));
    temp[8] = ((((cnk[23][1][2]*hnk[18][2])+((cnk[21][1][0]*hnk[18][0])+(
      cnk[23][1][1]*hnk[18][1])))+((lk[18][0]*rnk[23][2])-(lk[18][2]*rnk[23][0])
      ))+((((cnk[22][1][2]*hnk[17][2])+((cnk[20][1][0]*hnk[17][0])+(
      cnk[22][1][1]*hnk[17][1])))+((lk[17][0]*rnk[22][2])-(lk[17][2]*rnk[22][0])
      ))+temp[7]));
    am[1] = (((((cnk[25][1][2]*hnk[20][2])+((cnk[24][1][1]*hnk[20][1])+(
      cnk[25][1][0]*hnk[20][0])))+((lk[20][0]*rnk[25][2])-(lk[20][2]*rnk[25][0])
      ))+((((Cik[3][1][2]*hnk[19][2])+((cnk[24][1][0]*hnk[19][0])+(cnk[24][1][1]
      *hnk[19][1])))+((lk[19][0]*rnk[24][2])-(lk[19][2]*rnk[24][0])))+temp[8]))-
      ((com[2]*lm[0])-(com[0]*lm[2])));
    temp[0] = ((((cnk[7][2][2]*hnk[2][2])+((Cik[3][2][1]*hnk[2][1])+(
      cnk[7][2][0]*hnk[2][0])))+((lk[2][1]*rnk[7][0])-(lk[2][0]*rnk[7][1])))+(((
      (Cik[3][2][2]*hnk[0][2])+((Cik[3][2][0]*hnk[0][0])+(Cik[3][2][1]*hnk[0][1]
      )))+((lk[0][1]*rnk[5][0])-(lk[0][0]*rnk[5][1])))+(((cnk[6][2][2]*hnk[1][2]
      )+((Cik[3][2][1]*hnk[1][1])+(cnk[6][2][0]*hnk[1][0])))+((lk[1][1]*
      rnk[6][0])-(lk[1][0]*rnk[6][1])))));
    temp[1] = ((((cnk[9][2][2]*hnk[4][2])+((cnk[7][2][0]*hnk[4][0])+(
      cnk[9][2][1]*hnk[4][1])))+((lk[4][1]*rnk[9][0])-(lk[4][0]*rnk[9][1])))+(((
      (cnk[8][2][2]*hnk[3][2])+((cnk[6][2][0]*hnk[3][0])+(cnk[8][2][1]*hnk[3][1]
      )))+((lk[3][1]*rnk[8][0])-(lk[3][0]*rnk[8][1])))+temp[0]));
    temp[2] = ((((cnk[9][2][2]*hnk[6][2])+((cnk[11][2][0]*hnk[6][0])+(
      cnk[11][2][1]*hnk[6][1])))+((lk[6][1]*rnk[11][0])-(lk[6][0]*rnk[11][1])))+
      ((((cnk[8][2][2]*hnk[5][2])+((cnk[10][2][0]*hnk[5][0])+(cnk[10][2][1]*
      hnk[5][1])))+((lk[5][1]*rnk[10][0])-(lk[5][0]*rnk[10][1])))+temp[1]));
    temp[3] = ((((Cik[3][2][2]*hnk[8][2])+((cnk[13][2][0]*hnk[8][0])+(
      cnk[13][2][1]*hnk[8][1])))+((lk[8][1]*rnk[13][0])-(lk[8][0]*rnk[13][1])))+
      ((((Cik[3][2][2]*hnk[7][2])+((cnk[12][2][0]*hnk[7][0])+(cnk[12][2][1]*
      hnk[7][1])))+((lk[7][1]*rnk[12][0])-(lk[7][0]*rnk[12][1])))+temp[2]));
    temp[4] = ((((cnk[15][2][2]*hnk[10][2])+((cnk[13][2][0]*hnk[10][0])+(
      cnk[15][2][1]*hnk[10][1])))+((lk[10][1]*rnk[15][0])-(lk[10][0]*rnk[15][1])
      ))+((((cnk[14][2][2]*hnk[9][2])+((cnk[12][2][0]*hnk[9][0])+(cnk[14][2][1]*
      hnk[9][1])))+((lk[9][1]*rnk[14][0])-(lk[9][0]*rnk[14][1])))+temp[3]));
    temp[5] = ((((cnk[17][2][2]*hnk[12][2])+((cnk[15][2][1]*hnk[12][1])+(
      cnk[17][2][0]*hnk[12][0])))+((lk[12][1]*rnk[17][0])-(lk[12][0]*rnk[17][1])
      ))+((((cnk[16][2][2]*hnk[11][2])+((cnk[14][2][1]*hnk[11][1])+(
      cnk[16][2][0]*hnk[11][0])))+((lk[11][1]*rnk[16][0])-(lk[11][0]*rnk[16][1])
      ))+temp[4]));
    temp[6] = ((((cnk[19][2][2]*hnk[14][2])+((cnk[15][2][1]*hnk[14][1])+(
      cnk[19][2][0]*hnk[14][0])))+((lk[14][1]*rnk[19][0])-(lk[14][0]*rnk[19][1])
      ))+((((cnk[18][2][2]*hnk[13][2])+((cnk[14][2][1]*hnk[13][1])+(
      cnk[18][2][0]*hnk[13][0])))+((lk[13][1]*rnk[18][0])-(lk[13][0]*rnk[18][1])
      ))+temp[5]));
    temp[7] = ((((cnk[21][2][2]*hnk[16][2])+((cnk[15][2][1]*hnk[16][1])+(
      cnk[21][2][0]*hnk[16][0])))+((lk[16][1]*rnk[21][0])-(lk[16][0]*rnk[21][1])
      ))+((((cnk[20][2][2]*hnk[15][2])+((cnk[14][2][1]*hnk[15][1])+(
      cnk[20][2][0]*hnk[15][0])))+((lk[15][1]*rnk[20][0])-(lk[15][0]*rnk[20][1])
      ))+temp[6]));
    temp[8] = ((((cnk[23][2][2]*hnk[18][2])+((cnk[21][2][0]*hnk[18][0])+(
      cnk[23][2][1]*hnk[18][1])))+((lk[18][1]*rnk[23][0])-(lk[18][0]*rnk[23][1])
      ))+((((cnk[22][2][2]*hnk[17][2])+((cnk[20][2][0]*hnk[17][0])+(
      cnk[22][2][1]*hnk[17][1])))+((lk[17][1]*rnk[22][0])-(lk[17][0]*rnk[22][1])
      ))+temp[7]));
    am[2] = (((((cnk[25][2][2]*hnk[20][2])+((cnk[24][2][1]*hnk[20][1])+(
      cnk[25][2][0]*hnk[20][0])))+((lk[20][1]*rnk[25][0])-(lk[20][0]*rnk[25][1])
      ))+((((Cik[3][2][2]*hnk[19][2])+((cnk[24][2][0]*hnk[19][0])+(cnk[24][2][1]
      *hnk[19][1])))+((lk[19][1]*rnk[24][0])-(lk[19][0]*rnk[24][1])))+temp[8]))-
      ((com[0]*lm[1])-(com[1]*lm[0])));
    temp[0] = ((((hnk[0][2]*u[5])+((hnk[0][0]*u[3])+(hnk[0][1]*u[4])))+((
      lk[0][2]*vnk[5][2])+((lk[0][0]*vnk[5][0])+(lk[0][1]*vnk[5][1]))))+(((
      hnk[1][2]*wk[6][2])+((hnk[1][0]*wk[6][0])+(hnk[1][1]*wk[6][1])))+((
      lk[1][2]*vnk[6][2])+((lk[1][0]*vnk[6][0])+(lk[1][1]*vnk[6][1])))));
    temp[1] = ((((hnk[3][2]*wk[8][2])+((hnk[3][0]*wk[8][0])+(hnk[3][1]*wk[8][1])
      ))+((lk[3][2]*vnk[8][2])+((lk[3][0]*vnk[8][0])+(lk[3][1]*vnk[8][1]))))+(((
      (hnk[2][2]*wk[7][2])+((hnk[2][0]*wk[7][0])+(hnk[2][1]*wk[7][1])))+((
      lk[2][2]*vnk[7][2])+((lk[2][0]*vnk[7][0])+(lk[2][1]*vnk[7][1]))))+temp[0])
      );
    temp[2] = ((((hnk[5][2]*wk[10][2])+((hnk[5][0]*wk[10][0])+(hnk[5][1]*
      wk[10][1])))+((lk[5][2]*vnk[10][2])+((lk[5][0]*vnk[10][0])+(lk[5][1]*
      vnk[10][1]))))+((((hnk[4][2]*wk[9][2])+((hnk[4][0]*wk[9][0])+(hnk[4][1]*
      wk[9][1])))+((lk[4][2]*vnk[9][2])+((lk[4][0]*vnk[9][0])+(lk[4][1]*
      vnk[9][1]))))+temp[1]));
    temp[3] = ((((hnk[7][2]*wk[12][2])+((hnk[7][0]*wk[12][0])+(hnk[7][1]*
      wk[12][1])))+((lk[7][2]*vnk[12][2])+((lk[7][0]*vnk[12][0])+(lk[7][1]*
      vnk[12][1]))))+((((hnk[6][2]*wk[11][2])+((hnk[6][0]*wk[11][0])+(hnk[6][1]*
      wk[11][1])))+((lk[6][2]*vnk[11][2])+((lk[6][0]*vnk[11][0])+(lk[6][1]*
      vnk[11][1]))))+temp[2]));
    temp[4] = ((((hnk[9][2]*wk[14][2])+((hnk[9][0]*wk[14][0])+(hnk[9][1]*
      wk[14][1])))+((lk[9][2]*vnk[14][2])+((lk[9][0]*vnk[14][0])+(lk[9][1]*
      vnk[14][1]))))+((((hnk[8][2]*wk[13][2])+((hnk[8][0]*wk[13][0])+(hnk[8][1]*
      wk[13][1])))+((lk[8][2]*vnk[13][2])+((lk[8][0]*vnk[13][0])+(lk[8][1]*
      vnk[13][1]))))+temp[3]));
    temp[5] = ((((hnk[11][2]*wk[16][2])+((hnk[11][0]*wk[16][0])+(hnk[11][1]*
      wk[16][1])))+((lk[11][2]*vnk[16][2])+((lk[11][0]*vnk[16][0])+(lk[11][1]*
      vnk[16][1]))))+((((hnk[10][2]*wk[15][2])+((hnk[10][0]*wk[15][0])+(
      hnk[10][1]*wk[15][1])))+((lk[10][2]*vnk[15][2])+((lk[10][0]*vnk[15][0])+(
      lk[10][1]*vnk[15][1]))))+temp[4]));
    temp[6] = ((((hnk[13][2]*wk[18][2])+((hnk[13][0]*wk[18][0])+(hnk[13][1]*
      wk[18][1])))+((lk[13][2]*vnk[18][2])+((lk[13][0]*vnk[18][0])+(lk[13][1]*
      vnk[18][1]))))+((((hnk[12][2]*wk[17][2])+((hnk[12][0]*wk[17][0])+(
      hnk[12][1]*wk[17][1])))+((lk[12][2]*vnk[17][2])+((lk[12][0]*vnk[17][0])+(
      lk[12][1]*vnk[17][1]))))+temp[5]));
    temp[7] = ((((hnk[15][2]*wk[20][2])+((hnk[15][0]*wk[20][0])+(hnk[15][1]*
      wk[20][1])))+((lk[15][2]*vnk[20][2])+((lk[15][0]*vnk[20][0])+(lk[15][1]*
      vnk[20][1]))))+((((hnk[14][2]*wk[19][2])+((hnk[14][0]*wk[19][0])+(
      hnk[14][1]*wk[19][1])))+((lk[14][2]*vnk[19][2])+((lk[14][0]*vnk[19][0])+(
      lk[14][1]*vnk[19][1]))))+temp[6]));
    temp[8] = ((((hnk[17][2]*wk[22][2])+((hnk[17][0]*wk[22][0])+(hnk[17][1]*
      wk[22][1])))+((lk[17][2]*vnk[22][2])+((lk[17][0]*vnk[22][0])+(lk[17][1]*
      vnk[22][1]))))+((((hnk[16][2]*wk[21][2])+((hnk[16][0]*wk[21][0])+(
      hnk[16][1]*wk[21][1])))+((lk[16][2]*vnk[21][2])+((lk[16][0]*vnk[21][0])+(
      lk[16][1]*vnk[21][1]))))+temp[7]));
    temp[9] = ((((hnk[19][2]*wk[24][2])+((hnk[19][0]*wk[24][0])+(hnk[19][1]*
      wk[24][1])))+((lk[19][2]*vnk[24][2])+((lk[19][0]*vnk[24][0])+(lk[19][1]*
      vnk[24][1]))))+((((hnk[18][2]*wk[23][2])+((hnk[18][0]*wk[23][0])+(
      hnk[18][1]*wk[23][1])))+((lk[18][2]*vnk[23][2])+((lk[18][0]*vnk[23][0])+(
      lk[18][1]*vnk[23][1]))))+temp[8]));
    *ke = (.5*((((hnk[20][2]*wk[25][2])+((hnk[20][0]*wk[25][0])+(hnk[20][1]*
      wk[25][1])))+((lk[20][2]*vnk[25][2])+((lk[20][0]*vnk[25][0])+(lk[20][1]*
      vnk[25][1]))))+temp[9]));
/*
 Used 0.01 seconds CPU time,
 0 additional bytes of memory.
 Equations contain  629 adds/subtracts/negates
                    700 multiplies
                      0 divides
                    170 assignments
*/
}

void sdsys(double *mtoto,
    double cm[3],
    double icm[3][3])
{
/*
Compute system total mass, and instantaneous center of mass and
inertia matrix.

Generated 01-Mar-2006 15:25:51 by SD/FAST, Kane's formulation
(sdfast B.2.8 #30123) on machine ID unknown
Copyright (c) 1990-1997 Symbolic Dynamics, Inc.
Copyright (c) 1990-1997 Parametric Technology Corp.
RESTRICTED RIGHTS LEGEND: Use, duplication, or disclosure by the U.S.
Government is subject to restrictions as set forth in subparagraph
(c)(1)(ii) of the Rights in Technical Data and Computer Software
clause at DFARS 52.227-7013 and similar clauses in the FAR and NASA
FAR Supplement.  Symbolic Dynamics, Inc., Mountain View, CA 94041
*/
    double ikcnkt[26][3][3];

    if ((roustate != 2) && (roustate != 3)) {
        sdseterr(20,23);
        return;
    }
    *mtoto = mtot;
    cm[0] = com[0];
    cm[1] = com[1];
    cm[2] = com[2];
    ikcnkt[5][0][0] = ((Cik[3][0][2]*ik[0][0][2])+((Cik[3][0][0]*ik[0][0][0])+(
      Cik[3][0][1]*ik[0][0][1])));
    ikcnkt[5][0][1] = ((Cik[3][1][2]*ik[0][0][2])+((Cik[3][1][0]*ik[0][0][0])+(
      Cik[3][1][1]*ik[0][0][1])));
    ikcnkt[5][0][2] = ((Cik[3][2][2]*ik[0][0][2])+((Cik[3][2][0]*ik[0][0][0])+(
      Cik[3][2][1]*ik[0][0][1])));
    ikcnkt[5][1][0] = ((Cik[3][0][2]*ik[0][1][2])+((Cik[3][0][0]*ik[0][1][0])+(
      Cik[3][0][1]*ik[0][1][1])));
    ikcnkt[5][1][1] = ((Cik[3][1][2]*ik[0][1][2])+((Cik[3][1][0]*ik[0][1][0])+(
      Cik[3][1][1]*ik[0][1][1])));
    ikcnkt[5][1][2] = ((Cik[3][2][2]*ik[0][1][2])+((Cik[3][2][0]*ik[0][1][0])+(
      Cik[3][2][1]*ik[0][1][1])));
    ikcnkt[5][2][0] = ((Cik[3][0][2]*ik[0][2][2])+((Cik[3][0][0]*ik[0][2][0])+(
      Cik[3][0][1]*ik[0][2][1])));
    ikcnkt[5][2][1] = ((Cik[3][1][2]*ik[0][2][2])+((Cik[3][1][0]*ik[0][2][0])+(
      Cik[3][1][1]*ik[0][2][1])));
    ikcnkt[5][2][2] = ((Cik[3][2][2]*ik[0][2][2])+((Cik[3][2][0]*ik[0][2][0])+(
      Cik[3][2][1]*ik[0][2][1])));
    ikcnkt[6][0][0] = ((cnk[6][0][2]*ik[1][0][2])+((Cik[3][0][1]*ik[1][0][1])+(
      cnk[6][0][0]*ik[1][0][0])));
    ikcnkt[6][0][1] = ((cnk[6][1][2]*ik[1][0][2])+((Cik[3][1][1]*ik[1][0][1])+(
      cnk[6][1][0]*ik[1][0][0])));
    ikcnkt[6][0][2] = ((cnk[6][2][2]*ik[1][0][2])+((Cik[3][2][1]*ik[1][0][1])+(
      cnk[6][2][0]*ik[1][0][0])));
    ikcnkt[6][1][0] = ((cnk[6][0][2]*ik[1][1][2])+((Cik[3][0][1]*ik[1][1][1])+(
      cnk[6][0][0]*ik[1][1][0])));
    ikcnkt[6][1][1] = ((cnk[6][1][2]*ik[1][1][2])+((Cik[3][1][1]*ik[1][1][1])+(
      cnk[6][1][0]*ik[1][1][0])));
    ikcnkt[6][1][2] = ((cnk[6][2][2]*ik[1][1][2])+((Cik[3][2][1]*ik[1][1][1])+(
      cnk[6][2][0]*ik[1][1][0])));
    ikcnkt[6][2][0] = ((cnk[6][0][2]*ik[1][2][2])+((Cik[3][0][1]*ik[1][2][1])+(
      cnk[6][0][0]*ik[1][2][0])));
    ikcnkt[6][2][1] = ((cnk[6][1][2]*ik[1][2][2])+((Cik[3][1][1]*ik[1][2][1])+(
      cnk[6][1][0]*ik[1][2][0])));
    ikcnkt[6][2][2] = ((cnk[6][2][2]*ik[1][2][2])+((Cik[3][2][1]*ik[1][2][1])+(
      cnk[6][2][0]*ik[1][2][0])));
    ikcnkt[7][0][0] = ((cnk[7][0][2]*ik[2][0][2])+((Cik[3][0][1]*ik[2][0][1])+(
      cnk[7][0][0]*ik[2][0][0])));
    ikcnkt[7][0][1] = ((cnk[7][1][2]*ik[2][0][2])+((Cik[3][1][1]*ik[2][0][1])+(
      cnk[7][1][0]*ik[2][0][0])));
    ikcnkt[7][0][2] = ((cnk[7][2][2]*ik[2][0][2])+((Cik[3][2][1]*ik[2][0][1])+(
      cnk[7][2][0]*ik[2][0][0])));
    ikcnkt[7][1][0] = ((cnk[7][0][2]*ik[2][1][2])+((Cik[3][0][1]*ik[2][1][1])+(
      cnk[7][0][0]*ik[2][1][0])));
    ikcnkt[7][1][1] = ((cnk[7][1][2]*ik[2][1][2])+((Cik[3][1][1]*ik[2][1][1])+(
      cnk[7][1][0]*ik[2][1][0])));
    ikcnkt[7][1][2] = ((cnk[7][2][2]*ik[2][1][2])+((Cik[3][2][1]*ik[2][1][1])+(
      cnk[7][2][0]*ik[2][1][0])));
    ikcnkt[7][2][0] = ((cnk[7][0][2]*ik[2][2][2])+((Cik[3][0][1]*ik[2][2][1])+(
      cnk[7][0][0]*ik[2][2][0])));
    ikcnkt[7][2][1] = ((cnk[7][1][2]*ik[2][2][2])+((Cik[3][1][1]*ik[2][2][1])+(
      cnk[7][1][0]*ik[2][2][0])));
    ikcnkt[7][2][2] = ((cnk[7][2][2]*ik[2][2][2])+((Cik[3][2][1]*ik[2][2][1])+(
      cnk[7][2][0]*ik[2][2][0])));
    ikcnkt[8][0][0] = ((cnk[8][0][2]*ik[3][0][2])+((cnk[6][0][0]*ik[3][0][0])+(
      cnk[8][0][1]*ik[3][0][1])));
    ikcnkt[8][0][1] = ((cnk[8][1][2]*ik[3][0][2])+((cnk[6][1][0]*ik[3][0][0])+(
      cnk[8][1][1]*ik[3][0][1])));
    ikcnkt[8][0][2] = ((cnk[8][2][2]*ik[3][0][2])+((cnk[6][2][0]*ik[3][0][0])+(
      cnk[8][2][1]*ik[3][0][1])));
    ikcnkt[8][1][0] = ((cnk[8][0][2]*ik[3][1][2])+((cnk[6][0][0]*ik[3][1][0])+(
      cnk[8][0][1]*ik[3][1][1])));
    ikcnkt[8][1][1] = ((cnk[8][1][2]*ik[3][1][2])+((cnk[6][1][0]*ik[3][1][0])+(
      cnk[8][1][1]*ik[3][1][1])));
    ikcnkt[8][1][2] = ((cnk[8][2][2]*ik[3][1][2])+((cnk[6][2][0]*ik[3][1][0])+(
      cnk[8][2][1]*ik[3][1][1])));
    ikcnkt[8][2][0] = ((cnk[8][0][2]*ik[3][2][2])+((cnk[6][0][0]*ik[3][2][0])+(
      cnk[8][0][1]*ik[3][2][1])));
    ikcnkt[8][2][1] = ((cnk[8][1][2]*ik[3][2][2])+((cnk[6][1][0]*ik[3][2][0])+(
      cnk[8][1][1]*ik[3][2][1])));
    ikcnkt[8][2][2] = ((cnk[8][2][2]*ik[3][2][2])+((cnk[6][2][0]*ik[3][2][0])+(
      cnk[8][2][1]*ik[3][2][1])));
    ikcnkt[9][0][0] = ((cnk[9][0][2]*ik[4][0][2])+((cnk[7][0][0]*ik[4][0][0])+(
      cnk[9][0][1]*ik[4][0][1])));
    ikcnkt[9][0][1] = ((cnk[9][1][2]*ik[4][0][2])+((cnk[7][1][0]*ik[4][0][0])+(
      cnk[9][1][1]*ik[4][0][1])));
    ikcnkt[9][0][2] = ((cnk[9][2][2]*ik[4][0][2])+((cnk[7][2][0]*ik[4][0][0])+(
      cnk[9][2][1]*ik[4][0][1])));
    ikcnkt[9][1][0] = ((cnk[9][0][2]*ik[4][1][2])+((cnk[7][0][0]*ik[4][1][0])+(
      cnk[9][0][1]*ik[4][1][1])));
    ikcnkt[9][1][1] = ((cnk[9][1][2]*ik[4][1][2])+((cnk[7][1][0]*ik[4][1][0])+(
      cnk[9][1][1]*ik[4][1][1])));
    ikcnkt[9][1][2] = ((cnk[9][2][2]*ik[4][1][2])+((cnk[7][2][0]*ik[4][1][0])+(
      cnk[9][2][1]*ik[4][1][1])));
    ikcnkt[9][2][0] = ((cnk[9][0][2]*ik[4][2][2])+((cnk[7][0][0]*ik[4][2][0])+(
      cnk[9][0][1]*ik[4][2][1])));
    ikcnkt[9][2][1] = ((cnk[9][1][2]*ik[4][2][2])+((cnk[7][1][0]*ik[4][2][0])+(
      cnk[9][1][1]*ik[4][2][1])));
    ikcnkt[9][2][2] = ((cnk[9][2][2]*ik[4][2][2])+((cnk[7][2][0]*ik[4][2][0])+(
      cnk[9][2][1]*ik[4][2][1])));
    ikcnkt[10][0][0] = ((cnk[8][0][2]*ik[5][0][2])+((cnk[10][0][0]*ik[5][0][0])+
      (cnk[10][0][1]*ik[5][0][1])));
    ikcnkt[10][0][1] = ((cnk[8][1][2]*ik[5][0][2])+((cnk[10][1][0]*ik[5][0][0])+
      (cnk[10][1][1]*ik[5][0][1])));
    ikcnkt[10][0][2] = ((cnk[8][2][2]*ik[5][0][2])+((cnk[10][2][0]*ik[5][0][0])+
      (cnk[10][2][1]*ik[5][0][1])));
    ikcnkt[10][1][0] = ((cnk[8][0][2]*ik[5][1][2])+((cnk[10][0][0]*ik[5][1][0])+
      (cnk[10][0][1]*ik[5][1][1])));
    ikcnkt[10][1][1] = ((cnk[8][1][2]*ik[5][1][2])+((cnk[10][1][0]*ik[5][1][0])+
      (cnk[10][1][1]*ik[5][1][1])));
    ikcnkt[10][1][2] = ((cnk[8][2][2]*ik[5][1][2])+((cnk[10][2][0]*ik[5][1][0])+
      (cnk[10][2][1]*ik[5][1][1])));
    ikcnkt[10][2][0] = ((cnk[8][0][2]*ik[5][2][2])+((cnk[10][0][0]*ik[5][2][0])+
      (cnk[10][0][1]*ik[5][2][1])));
    ikcnkt[10][2][1] = ((cnk[8][1][2]*ik[5][2][2])+((cnk[10][1][0]*ik[5][2][0])+
      (cnk[10][1][1]*ik[5][2][1])));
    ikcnkt[10][2][2] = ((cnk[8][2][2]*ik[5][2][2])+((cnk[10][2][0]*ik[5][2][0])+
      (cnk[10][2][1]*ik[5][2][1])));
    ikcnkt[11][0][0] = ((cnk[9][0][2]*ik[6][0][2])+((cnk[11][0][0]*ik[6][0][0])+
      (cnk[11][0][1]*ik[6][0][1])));
    ikcnkt[11][0][1] = ((cnk[9][1][2]*ik[6][0][2])+((cnk[11][1][0]*ik[6][0][0])+
      (cnk[11][1][1]*ik[6][0][1])));
    ikcnkt[11][0][2] = ((cnk[9][2][2]*ik[6][0][2])+((cnk[11][2][0]*ik[6][0][0])+
      (cnk[11][2][1]*ik[6][0][1])));
    ikcnkt[11][1][0] = ((cnk[9][0][2]*ik[6][1][2])+((cnk[11][0][0]*ik[6][1][0])+
      (cnk[11][0][1]*ik[6][1][1])));
    ikcnkt[11][1][1] = ((cnk[9][1][2]*ik[6][1][2])+((cnk[11][1][0]*ik[6][1][0])+
      (cnk[11][1][1]*ik[6][1][1])));
    ikcnkt[11][1][2] = ((cnk[9][2][2]*ik[6][1][2])+((cnk[11][2][0]*ik[6][1][0])+
      (cnk[11][2][1]*ik[6][1][1])));
    ikcnkt[11][2][0] = ((cnk[9][0][2]*ik[6][2][2])+((cnk[11][0][0]*ik[6][2][0])+
      (cnk[11][0][1]*ik[6][2][1])));
    ikcnkt[11][2][1] = ((cnk[9][1][2]*ik[6][2][2])+((cnk[11][1][0]*ik[6][2][0])+
      (cnk[11][1][1]*ik[6][2][1])));
    ikcnkt[11][2][2] = ((cnk[9][2][2]*ik[6][2][2])+((cnk[11][2][0]*ik[6][2][0])+
      (cnk[11][2][1]*ik[6][2][1])));
    ikcnkt[12][0][0] = ((Cik[3][0][2]*ik[7][0][2])+((cnk[12][0][0]*ik[7][0][0])+
      (cnk[12][0][1]*ik[7][0][1])));
    ikcnkt[12][0][1] = ((Cik[3][1][2]*ik[7][0][2])+((cnk[12][1][0]*ik[7][0][0])+
      (cnk[12][1][1]*ik[7][0][1])));
    ikcnkt[12][0][2] = ((Cik[3][2][2]*ik[7][0][2])+((cnk[12][2][0]*ik[7][0][0])+
      (cnk[12][2][1]*ik[7][0][1])));
    ikcnkt[12][1][0] = ((Cik[3][0][2]*ik[7][1][2])+((cnk[12][0][0]*ik[7][1][0])+
      (cnk[12][0][1]*ik[7][1][1])));
    ikcnkt[12][1][1] = ((Cik[3][1][2]*ik[7][1][2])+((cnk[12][1][0]*ik[7][1][0])+
      (cnk[12][1][1]*ik[7][1][1])));
    ikcnkt[12][1][2] = ((Cik[3][2][2]*ik[7][1][2])+((cnk[12][2][0]*ik[7][1][0])+
      (cnk[12][2][1]*ik[7][1][1])));
    ikcnkt[12][2][0] = ((Cik[3][0][2]*ik[7][2][2])+((cnk[12][0][0]*ik[7][2][0])+
      (cnk[12][0][1]*ik[7][2][1])));
    ikcnkt[12][2][1] = ((Cik[3][1][2]*ik[7][2][2])+((cnk[12][1][0]*ik[7][2][0])+
      (cnk[12][1][1]*ik[7][2][1])));
    ikcnkt[12][2][2] = ((Cik[3][2][2]*ik[7][2][2])+((cnk[12][2][0]*ik[7][2][0])+
      (cnk[12][2][1]*ik[7][2][1])));
    ikcnkt[13][0][0] = ((Cik[3][0][2]*ik[8][0][2])+((cnk[13][0][0]*ik[8][0][0])+
      (cnk[13][0][1]*ik[8][0][1])));
    ikcnkt[13][0][1] = ((Cik[3][1][2]*ik[8][0][2])+((cnk[13][1][0]*ik[8][0][0])+
      (cnk[13][1][1]*ik[8][0][1])));
    ikcnkt[13][0][2] = ((Cik[3][2][2]*ik[8][0][2])+((cnk[13][2][0]*ik[8][0][0])+
      (cnk[13][2][1]*ik[8][0][1])));
    ikcnkt[13][1][0] = ((Cik[3][0][2]*ik[8][1][2])+((cnk[13][0][0]*ik[8][1][0])+
      (cnk[13][0][1]*ik[8][1][1])));
    ikcnkt[13][1][1] = ((Cik[3][1][2]*ik[8][1][2])+((cnk[13][1][0]*ik[8][1][0])+
      (cnk[13][1][1]*ik[8][1][1])));
    ikcnkt[13][1][2] = ((Cik[3][2][2]*ik[8][1][2])+((cnk[13][2][0]*ik[8][1][0])+
      (cnk[13][2][1]*ik[8][1][1])));
    ikcnkt[13][2][0] = ((Cik[3][0][2]*ik[8][2][2])+((cnk[13][0][0]*ik[8][2][0])+
      (cnk[13][0][1]*ik[8][2][1])));
    ikcnkt[13][2][1] = ((Cik[3][1][2]*ik[8][2][2])+((cnk[13][1][0]*ik[8][2][0])+
      (cnk[13][1][1]*ik[8][2][1])));
    ikcnkt[13][2][2] = ((Cik[3][2][2]*ik[8][2][2])+((cnk[13][2][0]*ik[8][2][0])+
      (cnk[13][2][1]*ik[8][2][1])));
    ikcnkt[14][0][0] = ((cnk[14][0][2]*ik[9][0][2])+((cnk[12][0][0]*ik[9][0][0])
      +(cnk[14][0][1]*ik[9][0][1])));
    ikcnkt[14][0][1] = ((cnk[14][1][2]*ik[9][0][2])+((cnk[12][1][0]*ik[9][0][0])
      +(cnk[14][1][1]*ik[9][0][1])));
    ikcnkt[14][0][2] = ((cnk[14][2][2]*ik[9][0][2])+((cnk[12][2][0]*ik[9][0][0])
      +(cnk[14][2][1]*ik[9][0][1])));
    ikcnkt[14][1][0] = ((cnk[14][0][2]*ik[9][1][2])+((cnk[12][0][0]*ik[9][1][0])
      +(cnk[14][0][1]*ik[9][1][1])));
    ikcnkt[14][1][1] = ((cnk[14][1][2]*ik[9][1][2])+((cnk[12][1][0]*ik[9][1][0])
      +(cnk[14][1][1]*ik[9][1][1])));
    ikcnkt[14][1][2] = ((cnk[14][2][2]*ik[9][1][2])+((cnk[12][2][0]*ik[9][1][0])
      +(cnk[14][2][1]*ik[9][1][1])));
    ikcnkt[14][2][0] = ((cnk[14][0][2]*ik[9][2][2])+((cnk[12][0][0]*ik[9][2][0])
      +(cnk[14][0][1]*ik[9][2][1])));
    ikcnkt[14][2][1] = ((cnk[14][1][2]*ik[9][2][2])+((cnk[12][1][0]*ik[9][2][0])
      +(cnk[14][1][1]*ik[9][2][1])));
    ikcnkt[14][2][2] = ((cnk[14][2][2]*ik[9][2][2])+((cnk[12][2][0]*ik[9][2][0])
      +(cnk[14][2][1]*ik[9][2][1])));
    ikcnkt[15][0][0] = ((cnk[15][0][2]*ik[10][0][2])+((cnk[13][0][0]*
      ik[10][0][0])+(cnk[15][0][1]*ik[10][0][1])));
    ikcnkt[15][0][1] = ((cnk[15][1][2]*ik[10][0][2])+((cnk[13][1][0]*
      ik[10][0][0])+(cnk[15][1][1]*ik[10][0][1])));
    ikcnkt[15][0][2] = ((cnk[15][2][2]*ik[10][0][2])+((cnk[13][2][0]*
      ik[10][0][0])+(cnk[15][2][1]*ik[10][0][1])));
    ikcnkt[15][1][0] = ((cnk[15][0][2]*ik[10][1][2])+((cnk[13][0][0]*
      ik[10][1][0])+(cnk[15][0][1]*ik[10][1][1])));
    ikcnkt[15][1][1] = ((cnk[15][1][2]*ik[10][1][2])+((cnk[13][1][0]*
      ik[10][1][0])+(cnk[15][1][1]*ik[10][1][1])));
    ikcnkt[15][1][2] = ((cnk[15][2][2]*ik[10][1][2])+((cnk[13][2][0]*
      ik[10][1][0])+(cnk[15][2][1]*ik[10][1][1])));
    ikcnkt[15][2][0] = ((cnk[15][0][2]*ik[10][2][2])+((cnk[13][0][0]*
      ik[10][2][0])+(cnk[15][0][1]*ik[10][2][1])));
    ikcnkt[15][2][1] = ((cnk[15][1][2]*ik[10][2][2])+((cnk[13][1][0]*
      ik[10][2][0])+(cnk[15][1][1]*ik[10][2][1])));
    ikcnkt[15][2][2] = ((cnk[15][2][2]*ik[10][2][2])+((cnk[13][2][0]*
      ik[10][2][0])+(cnk[15][2][1]*ik[10][2][1])));
    ikcnkt[16][0][0] = ((cnk[16][0][2]*ik[11][0][2])+((cnk[14][0][1]*
      ik[11][0][1])+(cnk[16][0][0]*ik[11][0][0])));
    ikcnkt[16][0][1] = ((cnk[16][1][2]*ik[11][0][2])+((cnk[14][1][1]*
      ik[11][0][1])+(cnk[16][1][0]*ik[11][0][0])));
    ikcnkt[16][0][2] = ((cnk[16][2][2]*ik[11][0][2])+((cnk[14][2][1]*
      ik[11][0][1])+(cnk[16][2][0]*ik[11][0][0])));
    ikcnkt[16][1][0] = ((cnk[16][0][2]*ik[11][1][2])+((cnk[14][0][1]*
      ik[11][1][1])+(cnk[16][0][0]*ik[11][1][0])));
    ikcnkt[16][1][1] = ((cnk[16][1][2]*ik[11][1][2])+((cnk[14][1][1]*
      ik[11][1][1])+(cnk[16][1][0]*ik[11][1][0])));
    ikcnkt[16][1][2] = ((cnk[16][2][2]*ik[11][1][2])+((cnk[14][2][1]*
      ik[11][1][1])+(cnk[16][2][0]*ik[11][1][0])));
    ikcnkt[16][2][0] = ((cnk[16][0][2]*ik[11][2][2])+((cnk[14][0][1]*
      ik[11][2][1])+(cnk[16][0][0]*ik[11][2][0])));
    ikcnkt[16][2][1] = ((cnk[16][1][2]*ik[11][2][2])+((cnk[14][1][1]*
      ik[11][2][1])+(cnk[16][1][0]*ik[11][2][0])));
    ikcnkt[16][2][2] = ((cnk[16][2][2]*ik[11][2][2])+((cnk[14][2][1]*
      ik[11][2][1])+(cnk[16][2][0]*ik[11][2][0])));
    ikcnkt[17][0][0] = ((cnk[17][0][2]*ik[12][0][2])+((cnk[15][0][1]*
      ik[12][0][1])+(cnk[17][0][0]*ik[12][0][0])));
    ikcnkt[17][0][1] = ((cnk[17][1][2]*ik[12][0][2])+((cnk[15][1][1]*
      ik[12][0][1])+(cnk[17][1][0]*ik[12][0][0])));
    ikcnkt[17][0][2] = ((cnk[17][2][2]*ik[12][0][2])+((cnk[15][2][1]*
      ik[12][0][1])+(cnk[17][2][0]*ik[12][0][0])));
    ikcnkt[17][1][0] = ((cnk[17][0][2]*ik[12][1][2])+((cnk[15][0][1]*
      ik[12][1][1])+(cnk[17][0][0]*ik[12][1][0])));
    ikcnkt[17][1][1] = ((cnk[17][1][2]*ik[12][1][2])+((cnk[15][1][1]*
      ik[12][1][1])+(cnk[17][1][0]*ik[12][1][0])));
    ikcnkt[17][1][2] = ((cnk[17][2][2]*ik[12][1][2])+((cnk[15][2][1]*
      ik[12][1][1])+(cnk[17][2][0]*ik[12][1][0])));
    ikcnkt[17][2][0] = ((cnk[17][0][2]*ik[12][2][2])+((cnk[15][0][1]*
      ik[12][2][1])+(cnk[17][0][0]*ik[12][2][0])));
    ikcnkt[17][2][1] = ((cnk[17][1][2]*ik[12][2][2])+((cnk[15][1][1]*
      ik[12][2][1])+(cnk[17][1][0]*ik[12][2][0])));
    ikcnkt[17][2][2] = ((cnk[17][2][2]*ik[12][2][2])+((cnk[15][2][1]*
      ik[12][2][1])+(cnk[17][2][0]*ik[12][2][0])));
    ikcnkt[18][0][0] = ((cnk[18][0][2]*ik[13][0][2])+((cnk[14][0][1]*
      ik[13][0][1])+(cnk[18][0][0]*ik[13][0][0])));
    ikcnkt[18][0][1] = ((cnk[18][1][2]*ik[13][0][2])+((cnk[14][1][1]*
      ik[13][0][1])+(cnk[18][1][0]*ik[13][0][0])));
    ikcnkt[18][0][2] = ((cnk[18][2][2]*ik[13][0][2])+((cnk[14][2][1]*
      ik[13][0][1])+(cnk[18][2][0]*ik[13][0][0])));
    ikcnkt[18][1][0] = ((cnk[18][0][2]*ik[13][1][2])+((cnk[14][0][1]*
      ik[13][1][1])+(cnk[18][0][0]*ik[13][1][0])));
    ikcnkt[18][1][1] = ((cnk[18][1][2]*ik[13][1][2])+((cnk[14][1][1]*
      ik[13][1][1])+(cnk[18][1][0]*ik[13][1][0])));
    ikcnkt[18][1][2] = ((cnk[18][2][2]*ik[13][1][2])+((cnk[14][2][1]*
      ik[13][1][1])+(cnk[18][2][0]*ik[13][1][0])));
    ikcnkt[18][2][0] = ((cnk[18][0][2]*ik[13][2][2])+((cnk[14][0][1]*
      ik[13][2][1])+(cnk[18][0][0]*ik[13][2][0])));
    ikcnkt[18][2][1] = ((cnk[18][1][2]*ik[13][2][2])+((cnk[14][1][1]*
      ik[13][2][1])+(cnk[18][1][0]*ik[13][2][0])));
    ikcnkt[18][2][2] = ((cnk[18][2][2]*ik[13][2][2])+((cnk[14][2][1]*
      ik[13][2][1])+(cnk[18][2][0]*ik[13][2][0])));
    ikcnkt[19][0][0] = ((cnk[19][0][2]*ik[14][0][2])+((cnk[15][0][1]*
      ik[14][0][1])+(cnk[19][0][0]*ik[14][0][0])));
    ikcnkt[19][0][1] = ((cnk[19][1][2]*ik[14][0][2])+((cnk[15][1][1]*
      ik[14][0][1])+(cnk[19][1][0]*ik[14][0][0])));
    ikcnkt[19][0][2] = ((cnk[19][2][2]*ik[14][0][2])+((cnk[15][2][1]*
      ik[14][0][1])+(cnk[19][2][0]*ik[14][0][0])));
    ikcnkt[19][1][0] = ((cnk[19][0][2]*ik[14][1][2])+((cnk[15][0][1]*
      ik[14][1][1])+(cnk[19][0][0]*ik[14][1][0])));
    ikcnkt[19][1][1] = ((cnk[19][1][2]*ik[14][1][2])+((cnk[15][1][1]*
      ik[14][1][1])+(cnk[19][1][0]*ik[14][1][0])));
    ikcnkt[19][1][2] = ((cnk[19][2][2]*ik[14][1][2])+((cnk[15][2][1]*
      ik[14][1][1])+(cnk[19][2][0]*ik[14][1][0])));
    ikcnkt[19][2][0] = ((cnk[19][0][2]*ik[14][2][2])+((cnk[15][0][1]*
      ik[14][2][1])+(cnk[19][0][0]*ik[14][2][0])));
    ikcnkt[19][2][1] = ((cnk[19][1][2]*ik[14][2][2])+((cnk[15][1][1]*
      ik[14][2][1])+(cnk[19][1][0]*ik[14][2][0])));
    ikcnkt[19][2][2] = ((cnk[19][2][2]*ik[14][2][2])+((cnk[15][2][1]*
      ik[14][2][1])+(cnk[19][2][0]*ik[14][2][0])));
    ikcnkt[20][0][0] = ((cnk[20][0][2]*ik[15][0][2])+((cnk[14][0][1]*
      ik[15][0][1])+(cnk[20][0][0]*ik[15][0][0])));
    ikcnkt[20][0][1] = ((cnk[20][1][2]*ik[15][0][2])+((cnk[14][1][1]*
      ik[15][0][1])+(cnk[20][1][0]*ik[15][0][0])));
    ikcnkt[20][0][2] = ((cnk[20][2][2]*ik[15][0][2])+((cnk[14][2][1]*
      ik[15][0][1])+(cnk[20][2][0]*ik[15][0][0])));
    ikcnkt[20][1][0] = ((cnk[20][0][2]*ik[15][1][2])+((cnk[14][0][1]*
      ik[15][1][1])+(cnk[20][0][0]*ik[15][1][0])));
    ikcnkt[20][1][1] = ((cnk[20][1][2]*ik[15][1][2])+((cnk[14][1][1]*
      ik[15][1][1])+(cnk[20][1][0]*ik[15][1][0])));
    ikcnkt[20][1][2] = ((cnk[20][2][2]*ik[15][1][2])+((cnk[14][2][1]*
      ik[15][1][1])+(cnk[20][2][0]*ik[15][1][0])));
    ikcnkt[20][2][0] = ((cnk[20][0][2]*ik[15][2][2])+((cnk[14][0][1]*
      ik[15][2][1])+(cnk[20][0][0]*ik[15][2][0])));
    ikcnkt[20][2][1] = ((cnk[20][1][2]*ik[15][2][2])+((cnk[14][1][1]*
      ik[15][2][1])+(cnk[20][1][0]*ik[15][2][0])));
    ikcnkt[20][2][2] = ((cnk[20][2][2]*ik[15][2][2])+((cnk[14][2][1]*
      ik[15][2][1])+(cnk[20][2][0]*ik[15][2][0])));
    ikcnkt[21][0][0] = ((cnk[21][0][2]*ik[16][0][2])+((cnk[15][0][1]*
      ik[16][0][1])+(cnk[21][0][0]*ik[16][0][0])));
    ikcnkt[21][0][1] = ((cnk[21][1][2]*ik[16][0][2])+((cnk[15][1][1]*
      ik[16][0][1])+(cnk[21][1][0]*ik[16][0][0])));
    ikcnkt[21][0][2] = ((cnk[21][2][2]*ik[16][0][2])+((cnk[15][2][1]*
      ik[16][0][1])+(cnk[21][2][0]*ik[16][0][0])));
    ikcnkt[21][1][0] = ((cnk[21][0][2]*ik[16][1][2])+((cnk[15][0][1]*
      ik[16][1][1])+(cnk[21][0][0]*ik[16][1][0])));
    ikcnkt[21][1][1] = ((cnk[21][1][2]*ik[16][1][2])+((cnk[15][1][1]*
      ik[16][1][1])+(cnk[21][1][0]*ik[16][1][0])));
    ikcnkt[21][1][2] = ((cnk[21][2][2]*ik[16][1][2])+((cnk[15][2][1]*
      ik[16][1][1])+(cnk[21][2][0]*ik[16][1][0])));
    ikcnkt[21][2][0] = ((cnk[21][0][2]*ik[16][2][2])+((cnk[15][0][1]*
      ik[16][2][1])+(cnk[21][0][0]*ik[16][2][0])));
    ikcnkt[21][2][1] = ((cnk[21][1][2]*ik[16][2][2])+((cnk[15][1][1]*
      ik[16][2][1])+(cnk[21][1][0]*ik[16][2][0])));
    ikcnkt[21][2][2] = ((cnk[21][2][2]*ik[16][2][2])+((cnk[15][2][1]*
      ik[16][2][1])+(cnk[21][2][0]*ik[16][2][0])));
    ikcnkt[22][0][0] = ((cnk[22][0][2]*ik[17][0][2])+((cnk[20][0][0]*
      ik[17][0][0])+(cnk[22][0][1]*ik[17][0][1])));
    ikcnkt[22][0][1] = ((cnk[22][1][2]*ik[17][0][2])+((cnk[20][1][0]*
      ik[17][0][0])+(cnk[22][1][1]*ik[17][0][1])));
    ikcnkt[22][0][2] = ((cnk[22][2][2]*ik[17][0][2])+((cnk[20][2][0]*
      ik[17][0][0])+(cnk[22][2][1]*ik[17][0][1])));
    ikcnkt[22][1][0] = ((cnk[22][0][2]*ik[17][1][2])+((cnk[20][0][0]*
      ik[17][1][0])+(cnk[22][0][1]*ik[17][1][1])));
    ikcnkt[22][1][1] = ((cnk[22][1][2]*ik[17][1][2])+((cnk[20][1][0]*
      ik[17][1][0])+(cnk[22][1][1]*ik[17][1][1])));
    ikcnkt[22][1][2] = ((cnk[22][2][2]*ik[17][1][2])+((cnk[20][2][0]*
      ik[17][1][0])+(cnk[22][2][1]*ik[17][1][1])));
    ikcnkt[22][2][0] = ((cnk[22][0][2]*ik[17][2][2])+((cnk[20][0][0]*
      ik[17][2][0])+(cnk[22][0][1]*ik[17][2][1])));
    ikcnkt[22][2][1] = ((cnk[22][1][2]*ik[17][2][2])+((cnk[20][1][0]*
      ik[17][2][0])+(cnk[22][1][1]*ik[17][2][1])));
    ikcnkt[22][2][2] = ((cnk[22][2][2]*ik[17][2][2])+((cnk[20][2][0]*
      ik[17][2][0])+(cnk[22][2][1]*ik[17][2][1])));
    ikcnkt[23][0][0] = ((cnk[23][0][2]*ik[18][0][2])+((cnk[21][0][0]*
      ik[18][0][0])+(cnk[23][0][1]*ik[18][0][1])));
    ikcnkt[23][0][1] = ((cnk[23][1][2]*ik[18][0][2])+((cnk[21][1][0]*
      ik[18][0][0])+(cnk[23][1][1]*ik[18][0][1])));
    ikcnkt[23][0][2] = ((cnk[23][2][2]*ik[18][0][2])+((cnk[21][2][0]*
      ik[18][0][0])+(cnk[23][2][1]*ik[18][0][1])));
    ikcnkt[23][1][0] = ((cnk[23][0][2]*ik[18][1][2])+((cnk[21][0][0]*
      ik[18][1][0])+(cnk[23][0][1]*ik[18][1][1])));
    ikcnkt[23][1][1] = ((cnk[23][1][2]*ik[18][1][2])+((cnk[21][1][0]*
      ik[18][1][0])+(cnk[23][1][1]*ik[18][1][1])));
    ikcnkt[23][1][2] = ((cnk[23][2][2]*ik[18][1][2])+((cnk[21][2][0]*
      ik[18][1][0])+(cnk[23][2][1]*ik[18][1][1])));
    ikcnkt[23][2][0] = ((cnk[23][0][2]*ik[18][2][2])+((cnk[21][0][0]*
      ik[18][2][0])+(cnk[23][0][1]*ik[18][2][1])));
    ikcnkt[23][2][1] = ((cnk[23][1][2]*ik[18][2][2])+((cnk[21][1][0]*
      ik[18][2][0])+(cnk[23][1][1]*ik[18][2][1])));
    ikcnkt[23][2][2] = ((cnk[23][2][2]*ik[18][2][2])+((cnk[21][2][0]*
      ik[18][2][0])+(cnk[23][2][1]*ik[18][2][1])));
    ikcnkt[24][0][0] = ((Cik[3][0][2]*ik[19][0][2])+((cnk[24][0][0]*ik[19][0][0]
      )+(cnk[24][0][1]*ik[19][0][1])));
    ikcnkt[24][0][1] = ((Cik[3][1][2]*ik[19][0][2])+((cnk[24][1][0]*ik[19][0][0]
      )+(cnk[24][1][1]*ik[19][0][1])));
    ikcnkt[24][0][2] = ((Cik[3][2][2]*ik[19][0][2])+((cnk[24][2][0]*ik[19][0][0]
      )+(cnk[24][2][1]*ik[19][0][1])));
    ikcnkt[24][1][0] = ((Cik[3][0][2]*ik[19][1][2])+((cnk[24][0][0]*ik[19][1][0]
      )+(cnk[24][0][1]*ik[19][1][1])));
    ikcnkt[24][1][1] = ((Cik[3][1][2]*ik[19][1][2])+((cnk[24][1][0]*ik[19][1][0]
      )+(cnk[24][1][1]*ik[19][1][1])));
    ikcnkt[24][1][2] = ((Cik[3][2][2]*ik[19][1][2])+((cnk[24][2][0]*ik[19][1][0]
      )+(cnk[24][2][1]*ik[19][1][1])));
    ikcnkt[24][2][0] = ((Cik[3][0][2]*ik[19][2][2])+((cnk[24][0][0]*ik[19][2][0]
      )+(cnk[24][0][1]*ik[19][2][1])));
    ikcnkt[24][2][1] = ((Cik[3][1][2]*ik[19][2][2])+((cnk[24][1][0]*ik[19][2][0]
      )+(cnk[24][1][1]*ik[19][2][1])));
    ikcnkt[24][2][2] = ((Cik[3][2][2]*ik[19][2][2])+((cnk[24][2][0]*ik[19][2][0]
      )+(cnk[24][2][1]*ik[19][2][1])));
    ikcnkt[25][0][0] = ((cnk[25][0][2]*ik[20][0][2])+((cnk[24][0][1]*
      ik[20][0][1])+(cnk[25][0][0]*ik[20][0][0])));
    ikcnkt[25][0][1] = ((cnk[25][1][2]*ik[20][0][2])+((cnk[24][1][1]*
      ik[20][0][1])+(cnk[25][1][0]*ik[20][0][0])));
    ikcnkt[25][0][2] = ((cnk[25][2][2]*ik[20][0][2])+((cnk[24][2][1]*
      ik[20][0][1])+(cnk[25][2][0]*ik[20][0][0])));
    ikcnkt[25][1][0] = ((cnk[25][0][2]*ik[20][1][2])+((cnk[24][0][1]*
      ik[20][1][1])+(cnk[25][0][0]*ik[20][1][0])));
    ikcnkt[25][1][1] = ((cnk[25][1][2]*ik[20][1][2])+((cnk[24][1][1]*
      ik[20][1][1])+(cnk[25][1][0]*ik[20][1][0])));
    ikcnkt[25][1][2] = ((cnk[25][2][2]*ik[20][1][2])+((cnk[24][2][1]*
      ik[20][1][1])+(cnk[25][2][0]*ik[20][1][0])));
    ikcnkt[25][2][0] = ((cnk[25][0][2]*ik[20][2][2])+((cnk[24][0][1]*
      ik[20][2][1])+(cnk[25][0][0]*ik[20][2][0])));
    ikcnkt[25][2][1] = ((cnk[25][1][2]*ik[20][2][2])+((cnk[24][1][1]*
      ik[20][2][1])+(cnk[25][1][0]*ik[20][2][0])));
    ikcnkt[25][2][2] = ((cnk[25][2][2]*ik[20][2][2])+((cnk[24][2][1]*
      ik[20][2][1])+(cnk[25][2][0]*ik[20][2][0])));
    temp[0] = (((mk[0]*((rnk[5][1]*rnk[5][1])+(rnk[5][2]*rnk[5][2])))+((
      Cik[3][0][2]*ikcnkt[5][2][0])+((Cik[3][0][0]*ikcnkt[5][0][0])+(
      Cik[3][0][1]*ikcnkt[5][1][0]))))+((mk[1]*((rnk[6][1]*rnk[6][1])+(rnk[6][2]
      *rnk[6][2])))+((cnk[6][0][2]*ikcnkt[6][2][0])+((Cik[3][0][1]*
      ikcnkt[6][1][0])+(cnk[6][0][0]*ikcnkt[6][0][0])))));
    temp[1] = (((mk[3]*((rnk[8][1]*rnk[8][1])+(rnk[8][2]*rnk[8][2])))+((
      cnk[8][0][2]*ikcnkt[8][2][0])+((cnk[6][0][0]*ikcnkt[8][0][0])+(
      cnk[8][0][1]*ikcnkt[8][1][0]))))+(((mk[2]*((rnk[7][1]*rnk[7][1])+(
      rnk[7][2]*rnk[7][2])))+((cnk[7][0][2]*ikcnkt[7][2][0])+((Cik[3][0][1]*
      ikcnkt[7][1][0])+(cnk[7][0][0]*ikcnkt[7][0][0]))))+temp[0]));
    temp[2] = (((mk[5]*((rnk[10][1]*rnk[10][1])+(rnk[10][2]*rnk[10][2])))+((
      cnk[8][0][2]*ikcnkt[10][2][0])+((cnk[10][0][0]*ikcnkt[10][0][0])+(
      cnk[10][0][1]*ikcnkt[10][1][0]))))+(((mk[4]*((rnk[9][1]*rnk[9][1])+(
      rnk[9][2]*rnk[9][2])))+((cnk[9][0][2]*ikcnkt[9][2][0])+((cnk[7][0][0]*
      ikcnkt[9][0][0])+(cnk[9][0][1]*ikcnkt[9][1][0]))))+temp[1]));
    temp[3] = (((mk[7]*((rnk[12][1]*rnk[12][1])+(rnk[12][2]*rnk[12][2])))+((
      Cik[3][0][2]*ikcnkt[12][2][0])+((cnk[12][0][0]*ikcnkt[12][0][0])+(
      cnk[12][0][1]*ikcnkt[12][1][0]))))+(((mk[6]*((rnk[11][1]*rnk[11][1])+(
      rnk[11][2]*rnk[11][2])))+((cnk[9][0][2]*ikcnkt[11][2][0])+((cnk[11][0][0]*
      ikcnkt[11][0][0])+(cnk[11][0][1]*ikcnkt[11][1][0]))))+temp[2]));
    temp[4] = (((mk[9]*((rnk[14][1]*rnk[14][1])+(rnk[14][2]*rnk[14][2])))+((
      cnk[14][0][2]*ikcnkt[14][2][0])+((cnk[12][0][0]*ikcnkt[14][0][0])+(
      cnk[14][0][1]*ikcnkt[14][1][0]))))+(((mk[8]*((rnk[13][1]*rnk[13][1])+(
      rnk[13][2]*rnk[13][2])))+((Cik[3][0][2]*ikcnkt[13][2][0])+((cnk[13][0][0]*
      ikcnkt[13][0][0])+(cnk[13][0][1]*ikcnkt[13][1][0]))))+temp[3]));
    temp[5] = (((mk[11]*((rnk[16][1]*rnk[16][1])+(rnk[16][2]*rnk[16][2])))+((
      cnk[16][0][2]*ikcnkt[16][2][0])+((cnk[14][0][1]*ikcnkt[16][1][0])+(
      cnk[16][0][0]*ikcnkt[16][0][0]))))+(((mk[10]*((rnk[15][1]*rnk[15][1])+(
      rnk[15][2]*rnk[15][2])))+((cnk[15][0][2]*ikcnkt[15][2][0])+((cnk[13][0][0]
      *ikcnkt[15][0][0])+(cnk[15][0][1]*ikcnkt[15][1][0]))))+temp[4]));
    temp[6] = (((mk[13]*((rnk[18][1]*rnk[18][1])+(rnk[18][2]*rnk[18][2])))+((
      cnk[18][0][2]*ikcnkt[18][2][0])+((cnk[14][0][1]*ikcnkt[18][1][0])+(
      cnk[18][0][0]*ikcnkt[18][0][0]))))+(((mk[12]*((rnk[17][1]*rnk[17][1])+(
      rnk[17][2]*rnk[17][2])))+((cnk[17][0][2]*ikcnkt[17][2][0])+((cnk[15][0][1]
      *ikcnkt[17][1][0])+(cnk[17][0][0]*ikcnkt[17][0][0]))))+temp[5]));
    temp[7] = (((mk[15]*((rnk[20][1]*rnk[20][1])+(rnk[20][2]*rnk[20][2])))+((
      cnk[20][0][2]*ikcnkt[20][2][0])+((cnk[14][0][1]*ikcnkt[20][1][0])+(
      cnk[20][0][0]*ikcnkt[20][0][0]))))+(((mk[14]*((rnk[19][1]*rnk[19][1])+(
      rnk[19][2]*rnk[19][2])))+((cnk[19][0][2]*ikcnkt[19][2][0])+((cnk[15][0][1]
      *ikcnkt[19][1][0])+(cnk[19][0][0]*ikcnkt[19][0][0]))))+temp[6]));
    temp[8] = (((mk[17]*((rnk[22][1]*rnk[22][1])+(rnk[22][2]*rnk[22][2])))+((
      cnk[22][0][2]*ikcnkt[22][2][0])+((cnk[20][0][0]*ikcnkt[22][0][0])+(
      cnk[22][0][1]*ikcnkt[22][1][0]))))+(((mk[16]*((rnk[21][1]*rnk[21][1])+(
      rnk[21][2]*rnk[21][2])))+((cnk[21][0][2]*ikcnkt[21][2][0])+((cnk[15][0][1]
      *ikcnkt[21][1][0])+(cnk[21][0][0]*ikcnkt[21][0][0]))))+temp[7]));
    temp[9] = (((mk[19]*((rnk[24][1]*rnk[24][1])+(rnk[24][2]*rnk[24][2])))+((
      Cik[3][0][2]*ikcnkt[24][2][0])+((cnk[24][0][0]*ikcnkt[24][0][0])+(
      cnk[24][0][1]*ikcnkt[24][1][0]))))+(((mk[18]*((rnk[23][1]*rnk[23][1])+(
      rnk[23][2]*rnk[23][2])))+((cnk[23][0][2]*ikcnkt[23][2][0])+((cnk[21][0][0]
      *ikcnkt[23][0][0])+(cnk[23][0][1]*ikcnkt[23][1][0]))))+temp[8]));
    icm[0][0] = ((((mk[20]*((rnk[25][1]*rnk[25][1])+(rnk[25][2]*rnk[25][2])))+((
      cnk[25][0][2]*ikcnkt[25][2][0])+((cnk[24][0][1]*ikcnkt[25][1][0])+(
      cnk[25][0][0]*ikcnkt[25][0][0]))))+temp[9])-(mtot*((com[1]*com[1])+(com[2]
      *com[2]))));
    temp[0] = ((((cnk[7][0][2]*ikcnkt[7][2][1])+((Cik[3][0][1]*ikcnkt[7][1][1])+
      (cnk[7][0][0]*ikcnkt[7][0][1])))-(mk[2]*(rnk[7][0]*rnk[7][1])))+((((
      Cik[3][0][2]*ikcnkt[5][2][1])+((Cik[3][0][0]*ikcnkt[5][0][1])+(
      Cik[3][0][1]*ikcnkt[5][1][1])))-(mk[0]*(rnk[5][0]*rnk[5][1])))+(((
      cnk[6][0][2]*ikcnkt[6][2][1])+((Cik[3][0][1]*ikcnkt[6][1][1])+(
      cnk[6][0][0]*ikcnkt[6][0][1])))-(mk[1]*(rnk[6][0]*rnk[6][1])))));
    temp[1] = ((((cnk[8][0][2]*ikcnkt[10][2][1])+((cnk[10][0][0]*
      ikcnkt[10][0][1])+(cnk[10][0][1]*ikcnkt[10][1][1])))-(mk[5]*(rnk[10][0]*
      rnk[10][1])))+((((cnk[9][0][2]*ikcnkt[9][2][1])+((cnk[7][0][0]*
      ikcnkt[9][0][1])+(cnk[9][0][1]*ikcnkt[9][1][1])))-(mk[4]*(rnk[9][0]*
      rnk[9][1])))+((((cnk[8][0][2]*ikcnkt[8][2][1])+((cnk[6][0][0]*
      ikcnkt[8][0][1])+(cnk[8][0][1]*ikcnkt[8][1][1])))-(mk[3]*(rnk[8][0]*
      rnk[8][1])))+temp[0])));
    temp[2] = ((((Cik[3][0][2]*ikcnkt[13][2][1])+((cnk[13][0][0]*
      ikcnkt[13][0][1])+(cnk[13][0][1]*ikcnkt[13][1][1])))-(mk[8]*(rnk[13][0]*
      rnk[13][1])))+((((Cik[3][0][2]*ikcnkt[12][2][1])+((cnk[12][0][0]*
      ikcnkt[12][0][1])+(cnk[12][0][1]*ikcnkt[12][1][1])))-(mk[7]*(rnk[12][0]*
      rnk[12][1])))+((((cnk[9][0][2]*ikcnkt[11][2][1])+((cnk[11][0][0]*
      ikcnkt[11][0][1])+(cnk[11][0][1]*ikcnkt[11][1][1])))-(mk[6]*(rnk[11][0]*
      rnk[11][1])))+temp[1])));
    temp[3] = ((((cnk[16][0][2]*ikcnkt[16][2][1])+((cnk[14][0][1]*
      ikcnkt[16][1][1])+(cnk[16][0][0]*ikcnkt[16][0][1])))-(mk[11]*(rnk[16][0]*
      rnk[16][1])))+((((cnk[15][0][2]*ikcnkt[15][2][1])+((cnk[13][0][0]*
      ikcnkt[15][0][1])+(cnk[15][0][1]*ikcnkt[15][1][1])))-(mk[10]*(rnk[15][0]*
      rnk[15][1])))+((((cnk[14][0][2]*ikcnkt[14][2][1])+((cnk[12][0][0]*
      ikcnkt[14][0][1])+(cnk[14][0][1]*ikcnkt[14][1][1])))-(mk[9]*(rnk[14][0]*
      rnk[14][1])))+temp[2])));
    temp[4] = ((((cnk[19][0][2]*ikcnkt[19][2][1])+((cnk[15][0][1]*
      ikcnkt[19][1][1])+(cnk[19][0][0]*ikcnkt[19][0][1])))-(mk[14]*(rnk[19][0]*
      rnk[19][1])))+((((cnk[18][0][2]*ikcnkt[18][2][1])+((cnk[14][0][1]*
      ikcnkt[18][1][1])+(cnk[18][0][0]*ikcnkt[18][0][1])))-(mk[13]*(rnk[18][0]*
      rnk[18][1])))+((((cnk[17][0][2]*ikcnkt[17][2][1])+((cnk[15][0][1]*
      ikcnkt[17][1][1])+(cnk[17][0][0]*ikcnkt[17][0][1])))-(mk[12]*(rnk[17][0]*
      rnk[17][1])))+temp[3])));
    temp[5] = ((((cnk[22][0][2]*ikcnkt[22][2][1])+((cnk[20][0][0]*
      ikcnkt[22][0][1])+(cnk[22][0][1]*ikcnkt[22][1][1])))-(mk[17]*(rnk[22][0]*
      rnk[22][1])))+((((cnk[21][0][2]*ikcnkt[21][2][1])+((cnk[15][0][1]*
      ikcnkt[21][1][1])+(cnk[21][0][0]*ikcnkt[21][0][1])))-(mk[16]*(rnk[21][0]*
      rnk[21][1])))+((((cnk[20][0][2]*ikcnkt[20][2][1])+((cnk[14][0][1]*
      ikcnkt[20][1][1])+(cnk[20][0][0]*ikcnkt[20][0][1])))-(mk[15]*(rnk[20][0]*
      rnk[20][1])))+temp[4])));
    temp[6] = ((((cnk[25][0][2]*ikcnkt[25][2][1])+((cnk[24][0][1]*
      ikcnkt[25][1][1])+(cnk[25][0][0]*ikcnkt[25][0][1])))-(mk[20]*(rnk[25][0]*
      rnk[25][1])))+((((Cik[3][0][2]*ikcnkt[24][2][1])+((cnk[24][0][0]*
      ikcnkt[24][0][1])+(cnk[24][0][1]*ikcnkt[24][1][1])))-(mk[19]*(rnk[24][0]*
      rnk[24][1])))+((((cnk[23][0][2]*ikcnkt[23][2][1])+((cnk[21][0][0]*
      ikcnkt[23][0][1])+(cnk[23][0][1]*ikcnkt[23][1][1])))-(mk[18]*(rnk[23][0]*
      rnk[23][1])))+temp[5])));
    icm[0][1] = ((mtot*(com[0]*com[1]))+temp[6]);
    temp[0] = ((((cnk[7][0][2]*ikcnkt[7][2][2])+((Cik[3][0][1]*ikcnkt[7][1][2])+
      (cnk[7][0][0]*ikcnkt[7][0][2])))-(mk[2]*(rnk[7][0]*rnk[7][2])))+((((
      Cik[3][0][2]*ikcnkt[5][2][2])+((Cik[3][0][0]*ikcnkt[5][0][2])+(
      Cik[3][0][1]*ikcnkt[5][1][2])))-(mk[0]*(rnk[5][0]*rnk[5][2])))+(((
      cnk[6][0][2]*ikcnkt[6][2][2])+((Cik[3][0][1]*ikcnkt[6][1][2])+(
      cnk[6][0][0]*ikcnkt[6][0][2])))-(mk[1]*(rnk[6][0]*rnk[6][2])))));
    temp[1] = ((((cnk[8][0][2]*ikcnkt[10][2][2])+((cnk[10][0][0]*
      ikcnkt[10][0][2])+(cnk[10][0][1]*ikcnkt[10][1][2])))-(mk[5]*(rnk[10][0]*
      rnk[10][2])))+((((cnk[9][0][2]*ikcnkt[9][2][2])+((cnk[7][0][0]*
      ikcnkt[9][0][2])+(cnk[9][0][1]*ikcnkt[9][1][2])))-(mk[4]*(rnk[9][0]*
      rnk[9][2])))+((((cnk[8][0][2]*ikcnkt[8][2][2])+((cnk[6][0][0]*
      ikcnkt[8][0][2])+(cnk[8][0][1]*ikcnkt[8][1][2])))-(mk[3]*(rnk[8][0]*
      rnk[8][2])))+temp[0])));
    temp[2] = ((((Cik[3][0][2]*ikcnkt[13][2][2])+((cnk[13][0][0]*
      ikcnkt[13][0][2])+(cnk[13][0][1]*ikcnkt[13][1][2])))-(mk[8]*(rnk[13][0]*
      rnk[13][2])))+((((Cik[3][0][2]*ikcnkt[12][2][2])+((cnk[12][0][0]*
      ikcnkt[12][0][2])+(cnk[12][0][1]*ikcnkt[12][1][2])))-(mk[7]*(rnk[12][0]*
      rnk[12][2])))+((((cnk[9][0][2]*ikcnkt[11][2][2])+((cnk[11][0][0]*
      ikcnkt[11][0][2])+(cnk[11][0][1]*ikcnkt[11][1][2])))-(mk[6]*(rnk[11][0]*
      rnk[11][2])))+temp[1])));
    temp[3] = ((((cnk[16][0][2]*ikcnkt[16][2][2])+((cnk[14][0][1]*
      ikcnkt[16][1][2])+(cnk[16][0][0]*ikcnkt[16][0][2])))-(mk[11]*(rnk[16][0]*
      rnk[16][2])))+((((cnk[15][0][2]*ikcnkt[15][2][2])+((cnk[13][0][0]*
      ikcnkt[15][0][2])+(cnk[15][0][1]*ikcnkt[15][1][2])))-(mk[10]*(rnk[15][0]*
      rnk[15][2])))+((((cnk[14][0][2]*ikcnkt[14][2][2])+((cnk[12][0][0]*
      ikcnkt[14][0][2])+(cnk[14][0][1]*ikcnkt[14][1][2])))-(mk[9]*(rnk[14][0]*
      rnk[14][2])))+temp[2])));
    temp[4] = ((((cnk[19][0][2]*ikcnkt[19][2][2])+((cnk[15][0][1]*
      ikcnkt[19][1][2])+(cnk[19][0][0]*ikcnkt[19][0][2])))-(mk[14]*(rnk[19][0]*
      rnk[19][2])))+((((cnk[18][0][2]*ikcnkt[18][2][2])+((cnk[14][0][1]*
      ikcnkt[18][1][2])+(cnk[18][0][0]*ikcnkt[18][0][2])))-(mk[13]*(rnk[18][0]*
      rnk[18][2])))+((((cnk[17][0][2]*ikcnkt[17][2][2])+((cnk[15][0][1]*
      ikcnkt[17][1][2])+(cnk[17][0][0]*ikcnkt[17][0][2])))-(mk[12]*(rnk[17][0]*
      rnk[17][2])))+temp[3])));
    temp[5] = ((((cnk[22][0][2]*ikcnkt[22][2][2])+((cnk[20][0][0]*
      ikcnkt[22][0][2])+(cnk[22][0][1]*ikcnkt[22][1][2])))-(mk[17]*(rnk[22][0]*
      rnk[22][2])))+((((cnk[21][0][2]*ikcnkt[21][2][2])+((cnk[15][0][1]*
      ikcnkt[21][1][2])+(cnk[21][0][0]*ikcnkt[21][0][2])))-(mk[16]*(rnk[21][0]*
      rnk[21][2])))+((((cnk[20][0][2]*ikcnkt[20][2][2])+((cnk[14][0][1]*
      ikcnkt[20][1][2])+(cnk[20][0][0]*ikcnkt[20][0][2])))-(mk[15]*(rnk[20][0]*
      rnk[20][2])))+temp[4])));
    temp[6] = ((((cnk[25][0][2]*ikcnkt[25][2][2])+((cnk[24][0][1]*
      ikcnkt[25][1][2])+(cnk[25][0][0]*ikcnkt[25][0][2])))-(mk[20]*(rnk[25][0]*
      rnk[25][2])))+((((Cik[3][0][2]*ikcnkt[24][2][2])+((cnk[24][0][0]*
      ikcnkt[24][0][2])+(cnk[24][0][1]*ikcnkt[24][1][2])))-(mk[19]*(rnk[24][0]*
      rnk[24][2])))+((((cnk[23][0][2]*ikcnkt[23][2][2])+((cnk[21][0][0]*
      ikcnkt[23][0][2])+(cnk[23][0][1]*ikcnkt[23][1][2])))-(mk[18]*(rnk[23][0]*
      rnk[23][2])))+temp[5])));
    icm[0][2] = ((mtot*(com[0]*com[2]))+temp[6]);
    icm[1][0] = icm[0][1];
    temp[0] = (((mk[0]*((rnk[5][0]*rnk[5][0])+(rnk[5][2]*rnk[5][2])))+((
      Cik[3][1][2]*ikcnkt[5][2][1])+((Cik[3][1][0]*ikcnkt[5][0][1])+(
      Cik[3][1][1]*ikcnkt[5][1][1]))))+((mk[1]*((rnk[6][0]*rnk[6][0])+(rnk[6][2]
      *rnk[6][2])))+((cnk[6][1][2]*ikcnkt[6][2][1])+((Cik[3][1][1]*
      ikcnkt[6][1][1])+(cnk[6][1][0]*ikcnkt[6][0][1])))));
    temp[1] = (((mk[3]*((rnk[8][0]*rnk[8][0])+(rnk[8][2]*rnk[8][2])))+((
      cnk[8][1][2]*ikcnkt[8][2][1])+((cnk[6][1][0]*ikcnkt[8][0][1])+(
      cnk[8][1][1]*ikcnkt[8][1][1]))))+(((mk[2]*((rnk[7][0]*rnk[7][0])+(
      rnk[7][2]*rnk[7][2])))+((cnk[7][1][2]*ikcnkt[7][2][1])+((Cik[3][1][1]*
      ikcnkt[7][1][1])+(cnk[7][1][0]*ikcnkt[7][0][1]))))+temp[0]));
    temp[2] = (((mk[5]*((rnk[10][0]*rnk[10][0])+(rnk[10][2]*rnk[10][2])))+((
      cnk[8][1][2]*ikcnkt[10][2][1])+((cnk[10][1][0]*ikcnkt[10][0][1])+(
      cnk[10][1][1]*ikcnkt[10][1][1]))))+(((mk[4]*((rnk[9][0]*rnk[9][0])+(
      rnk[9][2]*rnk[9][2])))+((cnk[9][1][2]*ikcnkt[9][2][1])+((cnk[7][1][0]*
      ikcnkt[9][0][1])+(cnk[9][1][1]*ikcnkt[9][1][1]))))+temp[1]));
    temp[3] = (((mk[7]*((rnk[12][0]*rnk[12][0])+(rnk[12][2]*rnk[12][2])))+((
      Cik[3][1][2]*ikcnkt[12][2][1])+((cnk[12][1][0]*ikcnkt[12][0][1])+(
      cnk[12][1][1]*ikcnkt[12][1][1]))))+(((mk[6]*((rnk[11][0]*rnk[11][0])+(
      rnk[11][2]*rnk[11][2])))+((cnk[9][1][2]*ikcnkt[11][2][1])+((cnk[11][1][0]*
      ikcnkt[11][0][1])+(cnk[11][1][1]*ikcnkt[11][1][1]))))+temp[2]));
    temp[4] = (((mk[9]*((rnk[14][0]*rnk[14][0])+(rnk[14][2]*rnk[14][2])))+((
      cnk[14][1][2]*ikcnkt[14][2][1])+((cnk[12][1][0]*ikcnkt[14][0][1])+(
      cnk[14][1][1]*ikcnkt[14][1][1]))))+(((mk[8]*((rnk[13][0]*rnk[13][0])+(
      rnk[13][2]*rnk[13][2])))+((Cik[3][1][2]*ikcnkt[13][2][1])+((cnk[13][1][0]*
      ikcnkt[13][0][1])+(cnk[13][1][1]*ikcnkt[13][1][1]))))+temp[3]));
    temp[5] = (((mk[11]*((rnk[16][0]*rnk[16][0])+(rnk[16][2]*rnk[16][2])))+((
      cnk[16][1][2]*ikcnkt[16][2][1])+((cnk[14][1][1]*ikcnkt[16][1][1])+(
      cnk[16][1][0]*ikcnkt[16][0][1]))))+(((mk[10]*((rnk[15][0]*rnk[15][0])+(
      rnk[15][2]*rnk[15][2])))+((cnk[15][1][2]*ikcnkt[15][2][1])+((cnk[13][1][0]
      *ikcnkt[15][0][1])+(cnk[15][1][1]*ikcnkt[15][1][1]))))+temp[4]));
    temp[6] = (((mk[13]*((rnk[18][0]*rnk[18][0])+(rnk[18][2]*rnk[18][2])))+((
      cnk[18][1][2]*ikcnkt[18][2][1])+((cnk[14][1][1]*ikcnkt[18][1][1])+(
      cnk[18][1][0]*ikcnkt[18][0][1]))))+(((mk[12]*((rnk[17][0]*rnk[17][0])+(
      rnk[17][2]*rnk[17][2])))+((cnk[17][1][2]*ikcnkt[17][2][1])+((cnk[15][1][1]
      *ikcnkt[17][1][1])+(cnk[17][1][0]*ikcnkt[17][0][1]))))+temp[5]));
    temp[7] = (((mk[15]*((rnk[20][0]*rnk[20][0])+(rnk[20][2]*rnk[20][2])))+((
      cnk[20][1][2]*ikcnkt[20][2][1])+((cnk[14][1][1]*ikcnkt[20][1][1])+(
      cnk[20][1][0]*ikcnkt[20][0][1]))))+(((mk[14]*((rnk[19][0]*rnk[19][0])+(
      rnk[19][2]*rnk[19][2])))+((cnk[19][1][2]*ikcnkt[19][2][1])+((cnk[15][1][1]
      *ikcnkt[19][1][1])+(cnk[19][1][0]*ikcnkt[19][0][1]))))+temp[6]));
    temp[8] = (((mk[17]*((rnk[22][0]*rnk[22][0])+(rnk[22][2]*rnk[22][2])))+((
      cnk[22][1][2]*ikcnkt[22][2][1])+((cnk[20][1][0]*ikcnkt[22][0][1])+(
      cnk[22][1][1]*ikcnkt[22][1][1]))))+(((mk[16]*((rnk[21][0]*rnk[21][0])+(
      rnk[21][2]*rnk[21][2])))+((cnk[21][1][2]*ikcnkt[21][2][1])+((cnk[15][1][1]
      *ikcnkt[21][1][1])+(cnk[21][1][0]*ikcnkt[21][0][1]))))+temp[7]));
    temp[9] = (((mk[19]*((rnk[24][0]*rnk[24][0])+(rnk[24][2]*rnk[24][2])))+((
      Cik[3][1][2]*ikcnkt[24][2][1])+((cnk[24][1][0]*ikcnkt[24][0][1])+(
      cnk[24][1][1]*ikcnkt[24][1][1]))))+(((mk[18]*((rnk[23][0]*rnk[23][0])+(
      rnk[23][2]*rnk[23][2])))+((cnk[23][1][2]*ikcnkt[23][2][1])+((cnk[21][1][0]
      *ikcnkt[23][0][1])+(cnk[23][1][1]*ikcnkt[23][1][1]))))+temp[8]));
    icm[1][1] = ((((mk[20]*((rnk[25][0]*rnk[25][0])+(rnk[25][2]*rnk[25][2])))+((
      cnk[25][1][2]*ikcnkt[25][2][1])+((cnk[24][1][1]*ikcnkt[25][1][1])+(
      cnk[25][1][0]*ikcnkt[25][0][1]))))+temp[9])-(mtot*((com[0]*com[0])+(com[2]
      *com[2]))));
    temp[0] = ((((cnk[7][1][2]*ikcnkt[7][2][2])+((Cik[3][1][1]*ikcnkt[7][1][2])+
      (cnk[7][1][0]*ikcnkt[7][0][2])))-(mk[2]*(rnk[7][1]*rnk[7][2])))+((((
      Cik[3][1][2]*ikcnkt[5][2][2])+((Cik[3][1][0]*ikcnkt[5][0][2])+(
      Cik[3][1][1]*ikcnkt[5][1][2])))-(mk[0]*(rnk[5][1]*rnk[5][2])))+(((
      cnk[6][1][2]*ikcnkt[6][2][2])+((Cik[3][1][1]*ikcnkt[6][1][2])+(
      cnk[6][1][0]*ikcnkt[6][0][2])))-(mk[1]*(rnk[6][1]*rnk[6][2])))));
    temp[1] = ((((cnk[8][1][2]*ikcnkt[10][2][2])+((cnk[10][1][0]*
      ikcnkt[10][0][2])+(cnk[10][1][1]*ikcnkt[10][1][2])))-(mk[5]*(rnk[10][1]*
      rnk[10][2])))+((((cnk[9][1][2]*ikcnkt[9][2][2])+((cnk[7][1][0]*
      ikcnkt[9][0][2])+(cnk[9][1][1]*ikcnkt[9][1][2])))-(mk[4]*(rnk[9][1]*
      rnk[9][2])))+((((cnk[8][1][2]*ikcnkt[8][2][2])+((cnk[6][1][0]*
      ikcnkt[8][0][2])+(cnk[8][1][1]*ikcnkt[8][1][2])))-(mk[3]*(rnk[8][1]*
      rnk[8][2])))+temp[0])));
    temp[2] = ((((Cik[3][1][2]*ikcnkt[13][2][2])+((cnk[13][1][0]*
      ikcnkt[13][0][2])+(cnk[13][1][1]*ikcnkt[13][1][2])))-(mk[8]*(rnk[13][1]*
      rnk[13][2])))+((((Cik[3][1][2]*ikcnkt[12][2][2])+((cnk[12][1][0]*
      ikcnkt[12][0][2])+(cnk[12][1][1]*ikcnkt[12][1][2])))-(mk[7]*(rnk[12][1]*
      rnk[12][2])))+((((cnk[9][1][2]*ikcnkt[11][2][2])+((cnk[11][1][0]*
      ikcnkt[11][0][2])+(cnk[11][1][1]*ikcnkt[11][1][2])))-(mk[6]*(rnk[11][1]*
      rnk[11][2])))+temp[1])));
    temp[3] = ((((cnk[16][1][2]*ikcnkt[16][2][2])+((cnk[14][1][1]*
      ikcnkt[16][1][2])+(cnk[16][1][0]*ikcnkt[16][0][2])))-(mk[11]*(rnk[16][1]*
      rnk[16][2])))+((((cnk[15][1][2]*ikcnkt[15][2][2])+((cnk[13][1][0]*
      ikcnkt[15][0][2])+(cnk[15][1][1]*ikcnkt[15][1][2])))-(mk[10]*(rnk[15][1]*
      rnk[15][2])))+((((cnk[14][1][2]*ikcnkt[14][2][2])+((cnk[12][1][0]*
      ikcnkt[14][0][2])+(cnk[14][1][1]*ikcnkt[14][1][2])))-(mk[9]*(rnk[14][1]*
      rnk[14][2])))+temp[2])));
    temp[4] = ((((cnk[19][1][2]*ikcnkt[19][2][2])+((cnk[15][1][1]*
      ikcnkt[19][1][2])+(cnk[19][1][0]*ikcnkt[19][0][2])))-(mk[14]*(rnk[19][1]*
      rnk[19][2])))+((((cnk[18][1][2]*ikcnkt[18][2][2])+((cnk[14][1][1]*
      ikcnkt[18][1][2])+(cnk[18][1][0]*ikcnkt[18][0][2])))-(mk[13]*(rnk[18][1]*
      rnk[18][2])))+((((cnk[17][1][2]*ikcnkt[17][2][2])+((cnk[15][1][1]*
      ikcnkt[17][1][2])+(cnk[17][1][0]*ikcnkt[17][0][2])))-(mk[12]*(rnk[17][1]*
      rnk[17][2])))+temp[3])));
    temp[5] = ((((cnk[22][1][2]*ikcnkt[22][2][2])+((cnk[20][1][0]*
      ikcnkt[22][0][2])+(cnk[22][1][1]*ikcnkt[22][1][2])))-(mk[17]*(rnk[22][1]*
      rnk[22][2])))+((((cnk[21][1][2]*ikcnkt[21][2][2])+((cnk[15][1][1]*
      ikcnkt[21][1][2])+(cnk[21][1][0]*ikcnkt[21][0][2])))-(mk[16]*(rnk[21][1]*
      rnk[21][2])))+((((cnk[20][1][2]*ikcnkt[20][2][2])+((cnk[14][1][1]*
      ikcnkt[20][1][2])+(cnk[20][1][0]*ikcnkt[20][0][2])))-(mk[15]*(rnk[20][1]*
      rnk[20][2])))+temp[4])));
    temp[6] = ((((cnk[25][1][2]*ikcnkt[25][2][2])+((cnk[24][1][1]*
      ikcnkt[25][1][2])+(cnk[25][1][0]*ikcnkt[25][0][2])))-(mk[20]*(rnk[25][1]*
      rnk[25][2])))+((((Cik[3][1][2]*ikcnkt[24][2][2])+((cnk[24][1][0]*
      ikcnkt[24][0][2])+(cnk[24][1][1]*ikcnkt[24][1][2])))-(mk[19]*(rnk[24][1]*
      rnk[24][2])))+((((cnk[23][1][2]*ikcnkt[23][2][2])+((cnk[21][1][0]*
      ikcnkt[23][0][2])+(cnk[23][1][1]*ikcnkt[23][1][2])))-(mk[18]*(rnk[23][1]*
      rnk[23][2])))+temp[5])));
    icm[1][2] = ((mtot*(com[1]*com[2]))+temp[6]);
    icm[2][0] = icm[0][2];
    icm[2][1] = icm[1][2];
    temp[0] = (((mk[0]*((rnk[5][0]*rnk[5][0])+(rnk[5][1]*rnk[5][1])))+((
      Cik[3][2][2]*ikcnkt[5][2][2])+((Cik[3][2][0]*ikcnkt[5][0][2])+(
      Cik[3][2][1]*ikcnkt[5][1][2]))))+((mk[1]*((rnk[6][0]*rnk[6][0])+(rnk[6][1]
      *rnk[6][1])))+((cnk[6][2][2]*ikcnkt[6][2][2])+((Cik[3][2][1]*
      ikcnkt[6][1][2])+(cnk[6][2][0]*ikcnkt[6][0][2])))));
    temp[1] = (((mk[3]*((rnk[8][0]*rnk[8][0])+(rnk[8][1]*rnk[8][1])))+((
      cnk[8][2][2]*ikcnkt[8][2][2])+((cnk[6][2][0]*ikcnkt[8][0][2])+(
      cnk[8][2][1]*ikcnkt[8][1][2]))))+(((mk[2]*((rnk[7][0]*rnk[7][0])+(
      rnk[7][1]*rnk[7][1])))+((cnk[7][2][2]*ikcnkt[7][2][2])+((Cik[3][2][1]*
      ikcnkt[7][1][2])+(cnk[7][2][0]*ikcnkt[7][0][2]))))+temp[0]));
    temp[2] = (((mk[5]*((rnk[10][0]*rnk[10][0])+(rnk[10][1]*rnk[10][1])))+((
      cnk[8][2][2]*ikcnkt[10][2][2])+((cnk[10][2][0]*ikcnkt[10][0][2])+(
      cnk[10][2][1]*ikcnkt[10][1][2]))))+(((mk[4]*((rnk[9][0]*rnk[9][0])+(
      rnk[9][1]*rnk[9][1])))+((cnk[9][2][2]*ikcnkt[9][2][2])+((cnk[7][2][0]*
      ikcnkt[9][0][2])+(cnk[9][2][1]*ikcnkt[9][1][2]))))+temp[1]));
    temp[3] = (((mk[7]*((rnk[12][0]*rnk[12][0])+(rnk[12][1]*rnk[12][1])))+((
      Cik[3][2][2]*ikcnkt[12][2][2])+((cnk[12][2][0]*ikcnkt[12][0][2])+(
      cnk[12][2][1]*ikcnkt[12][1][2]))))+(((mk[6]*((rnk[11][0]*rnk[11][0])+(
      rnk[11][1]*rnk[11][1])))+((cnk[9][2][2]*ikcnkt[11][2][2])+((cnk[11][2][0]*
      ikcnkt[11][0][2])+(cnk[11][2][1]*ikcnkt[11][1][2]))))+temp[2]));
    temp[4] = (((mk[9]*((rnk[14][0]*rnk[14][0])+(rnk[14][1]*rnk[14][1])))+((
      cnk[14][2][2]*ikcnkt[14][2][2])+((cnk[12][2][0]*ikcnkt[14][0][2])+(
      cnk[14][2][1]*ikcnkt[14][1][2]))))+(((mk[8]*((rnk[13][0]*rnk[13][0])+(
      rnk[13][1]*rnk[13][1])))+((Cik[3][2][2]*ikcnkt[13][2][2])+((cnk[13][2][0]*
      ikcnkt[13][0][2])+(cnk[13][2][1]*ikcnkt[13][1][2]))))+temp[3]));
    temp[5] = (((mk[11]*((rnk[16][0]*rnk[16][0])+(rnk[16][1]*rnk[16][1])))+((
      cnk[16][2][2]*ikcnkt[16][2][2])+((cnk[14][2][1]*ikcnkt[16][1][2])+(
      cnk[16][2][0]*ikcnkt[16][0][2]))))+(((mk[10]*((rnk[15][0]*rnk[15][0])+(
      rnk[15][1]*rnk[15][1])))+((cnk[15][2][2]*ikcnkt[15][2][2])+((cnk[13][2][0]
      *ikcnkt[15][0][2])+(cnk[15][2][1]*ikcnkt[15][1][2]))))+temp[4]));
    temp[6] = (((mk[13]*((rnk[18][0]*rnk[18][0])+(rnk[18][1]*rnk[18][1])))+((
      cnk[18][2][2]*ikcnkt[18][2][2])+((cnk[14][2][1]*ikcnkt[18][1][2])+(
      cnk[18][2][0]*ikcnkt[18][0][2]))))+(((mk[12]*((rnk[17][0]*rnk[17][0])+(
      rnk[17][1]*rnk[17][1])))+((cnk[17][2][2]*ikcnkt[17][2][2])+((cnk[15][2][1]
      *ikcnkt[17][1][2])+(cnk[17][2][0]*ikcnkt[17][0][2]))))+temp[5]));
    temp[7] = (((mk[15]*((rnk[20][0]*rnk[20][0])+(rnk[20][1]*rnk[20][1])))+((
      cnk[20][2][2]*ikcnkt[20][2][2])+((cnk[14][2][1]*ikcnkt[20][1][2])+(
      cnk[20][2][0]*ikcnkt[20][0][2]))))+(((mk[14]*((rnk[19][0]*rnk[19][0])+(
      rnk[19][1]*rnk[19][1])))+((cnk[19][2][2]*ikcnkt[19][2][2])+((cnk[15][2][1]
      *ikcnkt[19][1][2])+(cnk[19][2][0]*ikcnkt[19][0][2]))))+temp[6]));
    temp[8] = (((mk[17]*((rnk[22][0]*rnk[22][0])+(rnk[22][1]*rnk[22][1])))+((
      cnk[22][2][2]*ikcnkt[22][2][2])+((cnk[20][2][0]*ikcnkt[22][0][2])+(
      cnk[22][2][1]*ikcnkt[22][1][2]))))+(((mk[16]*((rnk[21][0]*rnk[21][0])+(
      rnk[21][1]*rnk[21][1])))+((cnk[21][2][2]*ikcnkt[21][2][2])+((cnk[15][2][1]
      *ikcnkt[21][1][2])+(cnk[21][2][0]*ikcnkt[21][0][2]))))+temp[7]));
    temp[9] = (((mk[19]*((rnk[24][0]*rnk[24][0])+(rnk[24][1]*rnk[24][1])))+((
      Cik[3][2][2]*ikcnkt[24][2][2])+((cnk[24][2][0]*ikcnkt[24][0][2])+(
      cnk[24][2][1]*ikcnkt[24][1][2]))))+(((mk[18]*((rnk[23][0]*rnk[23][0])+(
      rnk[23][1]*rnk[23][1])))+((cnk[23][2][2]*ikcnkt[23][2][2])+((cnk[21][2][0]
      *ikcnkt[23][0][2])+(cnk[23][2][1]*ikcnkt[23][1][2]))))+temp[8]));
    icm[2][2] = ((((mk[20]*((rnk[25][0]*rnk[25][0])+(rnk[25][1]*rnk[25][1])))+((
      cnk[25][2][2]*ikcnkt[25][2][2])+((cnk[24][2][1]*ikcnkt[25][1][2])+(
      cnk[25][2][0]*ikcnkt[25][0][2]))))+temp[9])-(mtot*((com[0]*com[0])+(com[1]
      *com[1]))));
/*
 Used 0.02 seconds CPU time,
 0 additional bytes of memory.
 Equations contain  948 adds/subtracts/negates
                   1275 multiplies
                      0 divides
                    253 assignments
*/
}

void sdpos(int body,
    double pt[3],
    double loc[3])
{
/*
Return inertial frame location of a point on a body.

*/
    double pv[3];

    if (sdchkbnum(21,body) != 0) {
        return;
    }
    if ((roustate != 2) && (roustate != 3)) {
        sdseterr(21,23);
        return;
    }
    if (body  ==  -1) {
        loc[0] = pt[0];
        loc[1] = pt[1];
        loc[2] = pt[2];
    } else {
        pv[0] = rnb[body][0]+pt[0]*cnb[body][0][0]+pt[1]*cnb[body][0][1]+pt[2]*
          cnb[body][0][2];
        pv[1] = rnb[body][1]+pt[0]*cnb[body][1][0]+pt[1]*cnb[body][1][1]+pt[2]*
          cnb[body][1][2];
        pv[2] = rnb[body][2]+pt[0]*cnb[body][2][0]+pt[1]*cnb[body][2][1]+pt[2]*
          cnb[body][2][2];
        loc[0] = pv[0];
        loc[1] = pv[1];
        loc[2] = pv[2];
    }
}

void sdvel(int body,
    double pt[3],
    double velo[3])
{
/*
Return inertial frame velocity of a point on a body.

*/
    double pv[3];

    if (sdchkbnum(22,body) != 0) {
        return;
    }
    if ((roustate != 2) && (roustate != 3)) {
        sdseterr(22,23);
        return;
    }
    if (body  ==  -1) {
        velo[0] = 0.;
        velo[1] = 0.;
        velo[2] = 0.;
    } else {
        pv[0] = wb[body][1]*pt[2]-wb[body][2]*pt[1];
        pv[1] = wb[body][2]*pt[0]-wb[body][0]*pt[2];
        pv[2] = wb[body][0]*pt[1]-wb[body][1]*pt[0];
        velo[0] = vnb[body][0]+pv[0]*cnb[body][0][0]+pv[1]*cnb[body][0][1]+pv[2]
          *cnb[body][0][2];
        velo[1] = vnb[body][1]+pv[0]*cnb[body][1][0]+pv[1]*cnb[body][1][1]+pv[2]
          *cnb[body][1][2];
        velo[2] = vnb[body][2]+pv[0]*cnb[body][2][0]+pv[1]*cnb[body][2][1]+pv[2]
          *cnb[body][2][2];
    }
}

void sdorient(int body,
    double dircos[3][3])
{
/*
Return orientation of body w.r.t. ground frame.

*/

    if (sdchkbnum(23,body) != 0) {
        return;
    }
    if ((roustate != 2) && (roustate != 3)) {
        sdseterr(23,23);
        return;
    }
    if (body == -1) {
        dircos[0][0] = 1.;
        dircos[0][1] = 0.;
        dircos[0][2] = 0.;
        dircos[1][0] = 0.;
        dircos[1][1] = 1.;
        dircos[1][2] = 0.;
        dircos[2][0] = 0.;
        dircos[2][1] = 0.;
        dircos[2][2] = 1.;
    } else {
        dircos[0][0] = cnb[body][0][0];
        dircos[0][1] = cnb[body][0][1];
        dircos[0][2] = cnb[body][0][2];
        dircos[1][0] = cnb[body][1][0];
        dircos[1][1] = cnb[body][1][1];
        dircos[1][2] = cnb[body][1][2];
        dircos[2][0] = cnb[body][2][0];
        dircos[2][1] = cnb[body][2][1];
        dircos[2][2] = cnb[body][2][2];
    }
}

void sdangvel(int body,
    double avel[3])
{
/*
Return angular velocity of the body.

*/

    if (sdchkbnum(24,body) != 0) {
        return;
    }
    if ((roustate != 2) && (roustate != 3)) {
        sdseterr(24,23);
        return;
    }
    if (body == -1) {
        avel[0] = 0.;
        avel[1] = 0.;
        avel[2] = 0.;
    } else {
        avel[0] = wb[body][0];
        avel[1] = wb[body][1];
        avel[2] = wb[body][2];
    }
}

void sdtrans(int frbod,
    double ivec[3],
    int tobod,
    double ovec[3])
{
/*
Transform ivec from frbod frame to tobod frame.

*/
    double pv[3];

    if (sdchkbnum(25,frbod) != 0) {
        return;
    }
    if (sdchkbnum(25,tobod) != 0) {
        return;
    }
    if ((roustate != 2) && (roustate != 3)) {
        sdseterr(25,23);
        return;
    }
    if (frbod == tobod) {
        sdvcopy(ivec,ovec);
        return;
    }
    if (frbod == -1) {
        sdvcopy(ivec,pv);
        ovec[0] = pv[0]*cnb[tobod][0][0]+pv[1]*cnb[tobod][1][0]+pv[2]*cnb[tobod
          ][2][0];
        ovec[1] = pv[0]*cnb[tobod][0][1]+pv[1]*cnb[tobod][1][1]+pv[2]*cnb[tobod
          ][2][1];
        ovec[2] = pv[0]*cnb[tobod][0][2]+pv[1]*cnb[tobod][1][2]+pv[2]*cnb[tobod
          ][2][2];
        return;
    }
    if (tobod == -1) {
        sdvcopy(ivec,pv);
        ovec[0] = pv[0]*cnb[frbod][0][0]+pv[1]*cnb[frbod][0][1]+pv[2]*cnb[frbod
          ][0][2];
        ovec[1] = pv[0]*cnb[frbod][1][0]+pv[1]*cnb[frbod][1][1]+pv[2]*cnb[frbod
          ][1][2];
        ovec[2] = pv[0]*cnb[frbod][2][0]+pv[1]*cnb[frbod][2][1]+pv[2]*cnb[frbod
          ][2][2];
        return;
    }
    pv[0] = ivec[0]*cnb[frbod][0][0]+ivec[1]*cnb[frbod][0][1]+ivec[2]*cnb[frbod
      ][0][2];
    pv[1] = ivec[0]*cnb[frbod][1][0]+ivec[1]*cnb[frbod][1][1]+ivec[2]*cnb[frbod
      ][1][2];
    pv[2] = ivec[0]*cnb[frbod][2][0]+ivec[1]*cnb[frbod][2][1]+ivec[2]*cnb[frbod
      ][2][2];
    ovec[0] = pv[0]*cnb[tobod][0][0]+pv[1]*cnb[tobod][1][0]+pv[2]*cnb[tobod][2][
      0];
    ovec[1] = pv[0]*cnb[tobod][0][1]+pv[1]*cnb[tobod][1][1]+pv[2]*cnb[tobod][2][
      1];
    ovec[2] = pv[0]*cnb[tobod][0][2]+pv[1]*cnb[tobod][1][2]+pv[2]*cnb[tobod][2][
      2];
}

void sdrel2cart(int coord,
    int body,
    double point[3],
    double linchg[3],
    double rotchg[3])
{
/* Return derivative of pt loc and body orient w.r.t. hinge rate
*/
    int x,i,gnd;
    double lin[3],pv[3];

    if ((coord < 0) || (coord > 25)) {
        sdseterr(59,45);
        return;
    }
    if (sdchkbnum(59,body) != 0) {
        return;
    }
    if ((roustate != 2) && (roustate != 3)) {
        sdseterr(59,23);
        return;
    }
    gnd = -1;
    if (body == gnd) {
        x = -1;
    } else {
        x = firstq[body]+njntdof[body]-1;
    }
    if (x < coord) {
        sdvset(0.,0.,0.,linchg);
        sdvset(0.,0.,0.,rotchg);
        return;
    }
    sddovpk();
    for (i = 0; i < 3; i++) {
        rotchg[i] = Wpk[coord][x][i];
        lin[i] = Vpk[coord][x][i];
    }
    if (body == gnd) {
        sdvcopy(point,pv);
    } else {
        pv[0] = rcom[body][0]+point[0];
        pv[1] = rcom[body][1]+point[1];
        pv[2] = rcom[body][2]+point[2];
    }
    sdvcross(rotchg,pv,linchg);
    sdvadd(linchg,lin,linchg);
}

void sdacc(int body,
    double pt[3],
    double accel[3])
{
/*
Return linear acceleration a point of the specified body.

*/
    double pv[3];

    if (sdchkbnum(32,body) != 0) {
        return;
    }
    if (roustate != 3) {
        sdseterr(32,24);
        return;
    }
    if (body  ==  -1) {
        accel[0] = 0.;
        accel[1] = 0.;
        accel[2] = 0.;
    } else {
        pv[0] = pt[0]*dyad[body][0][0]+pt[1]*dyad[body][0][1]+pt[2]*dyad[body][0
          ][2];
        pv[1] = pt[0]*dyad[body][1][0]+pt[1]*dyad[body][1][1]+pt[2]*dyad[body][1
          ][2];
        pv[2] = pt[0]*dyad[body][2][0]+pt[1]*dyad[body][2][1]+pt[2]*dyad[body][2
          ][2];
        accel[0] = anb[body][0]+pv[0]*cnb[body][0][0]+pv[1]*cnb[body][0][1]+pv[2
          ]*cnb[body][0][2];
        accel[1] = anb[body][1]+pv[0]*cnb[body][1][0]+pv[1]*cnb[body][1][1]+pv[2
          ]*cnb[body][1][2];
        accel[2] = anb[body][2]+pv[0]*cnb[body][2][0]+pv[1]*cnb[body][2][1]+pv[2
          ]*cnb[body][2][2];
    }
}

void sdangacc(int body,
    double aacc[3])
{
/*
Return angular acceleration of the body.

*/

    if (sdchkbnum(33,body) != 0) {
        return;
    }
    if (roustate != 3) {
        sdseterr(33,24);
        return;
    }
    if (body == -1) {
        aacc[0] = 0.;
        aacc[1] = 0.;
        aacc[2] = 0.;
    } else {
        aacc[0] = onb[body][0];
        aacc[1] = onb[body][1];
        aacc[2] = onb[body][2];
    }
}

void sdgrav(double gravin[3])
{

    grav[0] = gravin[0];
    gravq[0] = 3;
    grav[1] = gravin[1];
    gravq[1] = 3;
    grav[2] = gravin[2];
    gravq[2] = 3;
    roustate = 0;
}

void sdmass(int body,
    double massin)
{

    if (sdchkbnum(2,body) != 0) {
        return;
    }
    if (body == -1) {
        sdseterr(2,15);
        return;
    }
    if (mkq[body] != 0) {
        mk[body] = massin;
        mkq[body] = 3;
    } else {
        sdseterr(2,19);
    }
    roustate = 0;
}

void sdiner(int body,
    double inerin[3][3])
{
    int anyques;

    if (sdchkbnum(3,body) != 0) {
        return;
    }
    if (body == -1) {
        sdseterr(3,15);
        return;
    }
    anyques = 0;
    if (ikq[body][0][0]  !=  0) {
        ik[body][0][0] = inerin[0][0];
        ikq[body][0][0] = 3;
        anyques = 1;
    }
    if (ikq[body][0][1]  !=  0) {
        ik[body][0][1] = inerin[0][1];
        ikq[body][0][1] = 3;
        ik[body][1][0] = inerin[0][1];
        ikq[body][1][0] = 3;
        anyques = 1;
    }
    if (ikq[body][0][2]  !=  0) {
        ik[body][0][2] = inerin[0][2];
        ikq[body][0][2] = 3;
        ik[body][2][0] = inerin[0][2];
        ikq[body][2][0] = 3;
        anyques = 1;
    }
    if (ikq[body][1][1]  !=  0) {
        ik[body][1][1] = inerin[1][1];
        ikq[body][1][1] = 3;
        anyques = 1;
    }
    if (ikq[body][1][2]  !=  0) {
        ik[body][1][2] = inerin[1][2];
        ikq[body][1][2] = 3;
        ik[body][2][1] = inerin[1][2];
        ikq[body][2][1] = 3;
        anyques = 1;
    }
    if (ikq[body][2][2]  !=  0) {
        ik[body][2][2] = inerin[2][2];
        ikq[body][2][2] = 3;
        anyques = 1;
    }
    if (anyques == 0) {
        sdseterr(3,19);
    }
    roustate = 0;
}

void sdbtj(int joint,
    double btjin[3])
{
    int anyques;

    if (sdchkjnum(4,joint) != 0) {
        return;
    }
    anyques = 0;
    if (rkq[joint][0]  !=  0) {
        rk[joint][0] = btjin[0];
        rkq[joint][0] = 3;
        anyques = 1;
    }
    if (rkq[joint][1]  !=  0) {
        rk[joint][1] = btjin[1];
        rkq[joint][1] = 3;
        anyques = 1;
    }
    if (rkq[joint][2]  !=  0) {
        rk[joint][2] = btjin[2];
        rkq[joint][2] = 3;
        anyques = 1;
    }
    if (anyques == 0) {
        sdseterr(4,19);
    }
    roustate = 0;
}

void sditj(int joint,
    double itjin[3])
{
    int anyques;

    if (sdchkjnum(5,joint) != 0) {
        return;
    }
    anyques = 0;
    if (riq[joint][0]  !=  0) {
        ri[joint][0] = itjin[0];
        riq[joint][0] = 3;
        anyques = 1;
    }
    if (riq[joint][1]  !=  0) {
        ri[joint][1] = itjin[1];
        riq[joint][1] = 3;
        anyques = 1;
    }
    if (riq[joint][2]  !=  0) {
        ri[joint][2] = itjin[2];
        riq[joint][2] = 3;
        anyques = 1;
    }
    if (anyques == 0) {
        sdseterr(5,19);
    }
    roustate = 0;
}

void sdpin(int joint,
    int pinno,
    double pinin[3])
{
    int anyques,offs;

    if (sdchkjpin(6,joint,pinno) != 0) {
        return;
    }
    anyques = 0;
    offs = firstq[joint]+pinno;
    if (jtype[joint] == 21) {
        offs = offs+3;
    }
    if (jtype[joint] == 11) {
        offs = offs+1;
    }
    if (pinq[offs][0]  !=  0) {
        pin[offs][0] = pinin[0];
        pinq[offs][0] = 3;
        anyques = 1;
    }
    if (pinq[offs][1]  !=  0) {
        pin[offs][1] = pinin[1];
        pinq[offs][1] = 3;
        anyques = 1;
    }
    if (pinq[offs][2]  !=  0) {
        pin[offs][2] = pinin[2];
        pinq[offs][2] = 3;
        anyques = 1;
    }
    if (anyques == 0) {
        sdseterr(6,19);
    }
    roustate = 0;
}

void sdpres(int joint,
    int axis,
    int presin)
{
    int anyques;

    if (sdchkjaxis(37,joint,axis) != 0) {
        return;
    }
    if ((presin != 0) && (presin != 1)) {
        sdseterr(37,20);
    }
    anyques = 0;
    if (presq[sdindx(joint,axis)]  !=  0) {
        if (presin  !=  0) {
            pres[sdindx(joint,axis)] = 1.;
        } else {
            pres[sdindx(joint,axis)] = 0.;
        }
        presq[sdindx(joint,axis)] = 3;
        anyques = 1;
    }
    if (anyques == 0) {
        sdseterr(37,19);
    }
    wwflg = 0;
}

void sdconschg(void)
{

    wwflg = 0;
}

void sdstab(double velin,
    double posin)
{

    stabvel = velin;
    stabvelq = 3;
    stabpos = posin;
    stabposq = 3;
}

void sdgetgrav(double gravout[3])
{

    gravout[0] = grav[0];
    gravout[1] = grav[1];
    gravout[2] = grav[2];
}

void sdgetmass(int body,
    double *massout)
{

    if (sdchkbnum(40,body) != 0) {
        return;
    }
    if (body == -1) {
        sdseterr(40,15);
        return;
    }
    *massout = mk[body];
}

void sdgetiner(int body,
    double inerout[3][3])
{

    if (sdchkbnum(41,body) != 0) {
        return;
    }
    if (body == -1) {
        sdseterr(41,15);
        return;
    }
    inerout[0][0] = ik[body][0][0];
    inerout[0][1] = ik[body][0][1];
    inerout[0][2] = ik[body][0][2];
    inerout[1][0] = ik[body][1][0];
    inerout[1][1] = ik[body][1][1];
    inerout[1][2] = ik[body][1][2];
    inerout[2][0] = ik[body][2][0];
    inerout[2][1] = ik[body][2][1];
    inerout[2][2] = ik[body][2][2];
}

void sdgetbtj(int joint,
    double btjout[3])
{

    if (sdchkjnum(42,joint) != 0) {
        return;
    }
    btjout[0] = rk[joint][0];
    btjout[1] = rk[joint][1];
    btjout[2] = rk[joint][2];
}

void sdgetitj(int joint,
    double itjout[3])
{

    if (sdchkjnum(43,joint) != 0) {
        return;
    }
    itjout[0] = ri[joint][0];
    itjout[1] = ri[joint][1];
    itjout[2] = ri[joint][2];
}

void sdgetpin(int joint,
    int pinno,
    double pinout[3])
{
    int offs;

    if (sdchkjpin(44,joint,pinno) != 0) {
        return;
    }
    offs = firstq[joint]+pinno;
    if (jtype[joint] == 21) {
        offs = offs+3;
    }
    if (jtype[joint] == 11) {
        offs = offs+1;
    }
    pinout[0] = pin[offs][0];
    pinout[1] = pin[offs][1];
    pinout[2] = pin[offs][2];
}

void sdgetpres(int joint,
    int axis,
    int *presout)
{

    if (sdchkjaxis(45,joint,axis) != 0) {
        return;
    }
    if (pres[sdindx(joint,axis)]  !=  0.) {
        *presout = 1;
    } else {
        *presout = 0;
    }
}

void sdgetstab(double *velout,
    double *posout)
{

    *velout = stabvel;
    *posout = stabpos;
}

void sdinfo(int info[50])
{

    info[0] = ground;
    info[1] = nbod;
    info[2] = ndof;
    info[3] = ncons;
    info[4] = nloop;
    info[5] = nldof;
    info[6] = nloopc;
    info[7] = nball;
    info[8] = nlball;
    info[9] = npres;
    info[10] = nuser;
    info[11] = 0;
/* info entries from 12-49 are reserved */
}

void sdjnt(int joint,
    int info[50],
    int tran[6])
{
    int i,offs;

    if (sdchkjnum(48,joint) != 0) {
        return;
    }
    info[0] = jtype[joint];
    info[1] = 0;
    offs = 0;
    info[2] = inb[joint];
    info[3] = outb[joint];
    info[4] = njntdof[joint];
    info[5] = njntc[joint];
    info[6] = njntp[joint];
    info[7] = firstq[joint];
    info[8] = ballq[joint];
    info[9] = firstm[joint];
    info[10] = firstp[joint];
/* info entries from 11-49 are reserved */

    for (i = 0; i <= 5; i++) {
        if (i  <  njntdof[joint]) {
            tran[i] = trans[offs+firstq[joint]+i];
        } else {
            tran[i] = -1;
        }
    }
}

void sdcons(int consno,
    int info[50])
{

    if (sdchkucnum(49,consno) != 0) {
        return;
    }
/* There are no user constraints in this problem. */
}

void sdgentime(int *gentm)
{

    *gentm = 152551;
}
/*
Done. CPU seconds used: 0.17  Memory used: 1703936 bytes.
Equation complexity:
  sdstate:  1596 adds  2032 multiplies     4 divides  1483 assignments
  sdderiv: 11027 adds 12727 multiplies    26 divides  8641 assignments
  sdresid:  3808 adds  3784 multiplies     0 divides  2221 assignments
  sdreac:    900 adds   680 multiplies     0 divides   507 assignments
  sdmom:     629 adds   700 multiplies     0 divides   170 assignments
  sdsys:     948 adds  1275 multiplies     0 divides   253 assignments
*/
