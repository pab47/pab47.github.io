/*****************************************************************************/
/*
  animate.c: animate a data file.
*/

/*****************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include "params.h"

#include "drawstuff.h" /* ODE Graphics stuff */
#include "drawstuff-cga.h" /* CGA stuff to make things clearer */
#include "sdlib.h"
#include "le_ludecomp.c"
#include "useful.c"
//#include "params.h"

#define NPOINTS 10000



// ************ Change this as per the problem being solved *********//
#define DATA_PTS 126 //Set this based on columns in data file
float data[NPOINTS][DATA_PTS]; //Structure that will store the data.
char DATA_FILE[] = "data.txt"; //Data file to read
float STEPS;
int data_points;
//int  COUNTER;

double trans_zz = 0.37;

// **************************************************************** //


static void read_data()
{
    int i, j;
    FILE *fid;
   // int data_points;
    
	fid = fopen(DATA_FILE,"r");
	
//	double dc[3][3];
//    sdang2dc(0,0,0,dc);
//	/* Read file */
//	for (i=0;i<NU;i++)
//	{
//		fscanf(fid,"%f", &link_lengths[i]);
//		printf("%d %f \n",i,link_lengths[i]);
//	}
	
	
    i = 0;
//    fscanf(fid, "%d", &data_points);
//    if (data_points>DATA_POINTS);
//    {
//        printf("Please increase DATA_POINTS  \n");
//        exit(1);
//    }
    
    while(!feof(fid))
    {
        for (j=0;j<DATA_PTS;j++)
            fscanf(fid, "%f", &data[i][j]);
		
		//printf("%d \n",i);
        i = i+1;
		
		if (i>NPOINTS)
		{
			printf("There more simulation steps then alloted memory for data \n");
			printf("Increase NPOINTS  \n");
			exit(1);
		}
    }
    fclose(fid);
    STEPS = i-1;
	
	
	
//	/* For Display only */
//    for (i=0;i<1;i++)
//    {
//        for (j=0;j<DATA_PTS;j++)
//            printf("%1.2f ",data[i][j]);
//        printf("\n");
//    }
}



/*****************************************************************************/

static void start()
{
  // set up view point
		
    //Side view
//	static float xyz[3] = {1.6759,-0.3451,1.0800};
//	static float hpr[3] = {170.5000,-11.0000,0.0000};
//    
    //Top view
//    static float xyz[3] = {0.3400,-0.5899,2.2900};
//	static float hpr[3] = {152.5000,-67.0000,0.0000};
    
    //right side view
//    static float xyz[3] = { 1.3294,0.1563,0.5600};
//	static float hpr[3] = {-173.5000,-0.5000,0.0000};
    
    //front close up view
    static float xyz[3] = { 0.5725,0.0056,0.3900};
    static float hpr[3] = {-178.5000,2.0000,0.0000};
    


	
	dsSetViewpoint (xyz,hpr);
}

/********************************************************************/
// called when a key pressed

static void command (int cmd)
{
  // don't handle user input yet.
  dsPrint ("received command %d (`%c')\n",cmd,cmd);
}

/*****************************************************************************/




//////////////////////////////////////////////////////
static void display (int pause)
{
  //float center[3];
    float RR[12]={0};
	float R[12] = {0};
	float pos1[3], pos2[3], mid_pos[3];
	double dpos[3];
	int ii,i,j; 
	  //float sides[3] = { WIDTH, HEIGHT, LENGTH };

	static int COUNTER = 0;
	
	//printf("%d \n",COUNTER);

	j = 0;
	
	/* NOTE: The R matrix is as follows 
	 R = [ R[0] R[1] R[2]  R[3];
	 R[4] R[5] R[6]  R[7];
	 R[8] R[9] R[10] R[11]];
	 The elements R[3], R[7] and R[11] are not used */
	RR[0] = RR[5] = RR[10] = 1;
	
    //int bodies = data_points/6;
	for (ii=0;ii<NBOD;ii++)
	{
		
//		center[XX] = data[COUNTER][j]+trans_xx; j = j+1;
//		center[YY] = data[COUNTER][j]+trans_yy; j = j+1;
//		center[ZZ] = data[COUNTER][j]+trans_zz; j = j+1;
		
//		for ( i = 0; i < 12; i++ )
//			R[i] = 0;
		
//		R[0] = data[COUNTER][j];  j = j+1;
//		R[1] = data[COUNTER][j];  j = j+1;
//		R[2] = data[COUNTER][j];  j = j+1;
//		R[4] = data[COUNTER][j];  j = j+1;
//		R[5] = data[COUNTER][j];  j = j+1; 
//		R[6] = data[COUNTER][j];  j = j+1;
//		R[8] = data[COUNTER][j];  j = j+1;
//		R[9] = data[COUNTER][j]; j = j+1;
//		R[10] = data[COUNTER][j]; j = j+1;
		
		

		pos1[XX] = data[COUNTER][j]; j = j+1; 
		pos1[YY] = data[COUNTER][j]; j = j+1; 
		pos1[ZZ] = data[COUNTER][j]+ trans_zz; j = j+1;
		
		pos2[XX] = data[COUNTER][j]; j = j+1; 
		pos2[YY] = data[COUNTER][j]; j = j+1; 
		pos2[ZZ] = data[COUNTER][j]+ trans_zz; j = j+1;
		
		
		
		float link_length = sqrt((pos2[0]-pos1[0])*(pos2[0]-pos1[0])+
					  (pos2[1]-pos1[1])*(pos2[1]-pos1[1])+
					  (pos2[2]-pos1[2])*(pos2[2]-pos1[2]));
		
		if (link_length!=0)
		{
			dpos[0] = (pos2[0]-pos1[0])/link_length;
			dpos[1] = (pos2[1]-pos1[1])/link_length;
			dpos[2] = (pos2[2]-pos1[2])/link_length;
		}
		
		
		//A: Get position of mid-point
		//sdvadd(pos1,pos2,mid_pos); sdvmul(0.5,mid_pos,mid_pos);
		for (i=0;i<3;i++)
			mid_pos[i] = 0.5*(pos1[i]+pos2[i]);
		
		//B: Get orientation matrix 
		
// A method to find R matrix between vector along z axis and line joint 2 joints (Rodriguez formulae)
		double zvec[3]={0,0,1}; //already normalized
		
//		% Get the axis and angle
//		1) angle = acos(v1'*v2);
		float theta = acos(dpos[0]*zvec[0]+dpos[1]*zvec[1]+dpos[2]*zvec[2]); //angle between zvector and dpos
//		OR theta = acos((pos2[ZZ]-pos1[ZZ])/length);

//		2) axis = cross(v1,v2)/norm(cross(v1,v2));
		double axis[3];
		sdvcross(zvec,dpos,axis);
		double l_axis =   sqrt(axis[0]*axis[0]+axis[1]*axis[1]+axis[2]*axis[2]);
		if (l_axis!=0) //normalize if length is not equal to zero
		{
			axis[0] = axis[0]/l_axis;
			axis[1] = axis[1]/l_axis;
			axis[2] = axis[2]/l_axis;
		}
						
//		 % A skew symmetric representation of the normalized axis
//		 3) axis_skewed = [ 0 -axis(3) axis(2) ; axis(3) 0 -axis(1) ; -axis(2) axis(1) 0];
		double axis_skewed[3][3]={0};
		axis_skewed[0][1] = -axis[2];
		axis_skewed[0][2] = axis[1];
		axis_skewed[1][0] = axis[2];
		axis_skewed[1][2] = -axis[0];
		axis_skewed[2][0] = -axis[1];
		axis_skewed[2][1] = axis[0];
//		 
//		 % Rodrigues formula for the rotation matrix
//		 4) R = eye(3) + sin(angle)*axis_skewed + (1-cos(angle))*axis_skewed*axis_skewed;
		double I[3][3], r[3][3];
		double A[3][3], B[3][3];
		
		identity(3, &I[0][0]);
		multiplySCALAR2MAT(3, 3, &axis_skewed[0][0], sin(theta), &A[0][0]);
		multiplyMAT2MAT(3, 3, 3, 3, &axis_skewed[0][0], &axis_skewed[0][0], &B[0][0]);
		multiplySCALAR2MAT(3, 3, &B[0][0], (1-cos(theta)), &B[0][0]);
		
		add(3, 3, &I[0][0], &A[0][0], &r[0][0]);
		add(3, 3, &B[0][0], &r[0][0], &r[0][0]);
		
	
		//5) Convert r matrix to something which draw-stuff understands
		for ( i = 0; i < 12; i++ )
			R[i] = 0;

		for ( i = 0; i < 3; i++ )
		{
			R[i] = r[0][i];
			R[i+4] = r[1][i];
			R[i+8] = r[2][i];
		}
		

		//Now draw something 
		
		//Put spheres at the joints
		//dsSetTexture (DS_WOOD);
		//dsSetColor (0,1,0);
		//dsDrawSphere(pos2,RR,0.015);
		
		//Option 1: to use lines
		//		dsSetTexture (DS_WOOD);
		//		dsSetColor (1,0,0);
		//		dsDrawLine(pos1,pos2);

		//Option 2: Use solids (box or capsule)
		dsSetTexture (DS_WOOD);
		//dsSetColor (0,0,0); //black
        dsSetColor (1,1,1); //gray
        
        //printf("%f %f",robot_dim[ii][0],robot_dim[ii][1]);
        
		float dimensions[3] = {robot_dim[ii][0],robot_dim[ii][1],link_length};
		dsDrawBox(mid_pos,R,dimensions);
		//dsDrawCapsule(mid_pos,R,link_length,0.01);
        //dsDrawCylinder(mid_pos,R,link_length,0.01);
		
	}
		
	

	
	// Various geometries that can be animated //
//	switch( STR ) 
//	{
//		case 'b':
//			/* Draw a box */
//			dsSetTexture (DS_WOOD);
//			dsSetColor (0,0,1);
//			dsDrawBox( center, R, sides );
//			break;
//		case 's':
//			/* Draw a sphere */
//			dsSetTexture (DS_WOOD);
//			dsSetColor (0,1,0);
//			dsDrawSphere(center,R,RADIUS);
//			break;
//		case 'c':
//			/* Draw a cylinder */
//			dsSetTexture (DS_WOOD);
//			dsSetColor (1,0,0);
//			dsDrawCylinder(center,R,LENGTH,RADIUS);
//			break;
//		case 'p':	
//			/* Draw a capsule */
//			dsSetTexture (DS_WOOD);
//			dsSetColor (0.5,0.5,0.5);
//			dsDrawCapsule(center,R,LENGTH,RADIUS);
//			break;
//		default :
//			/* Draw a box */
//			dsSetTexture (DS_WOOD);
//			dsSetColor (0,0,1);
//			dsDrawBox( center, R, sides );
//	}

	
	COUNTER+=1;
	
	if(COUNTER>=STEPS)
		COUNTER = 0; //reset counter
	

	/* Delay */
    //double f;
	//for( f = 0.0; f < 2000000.0; f += 0.1 );




}

/*****************************************************************************/
/********************************************************************/

//void
//sduforce(double t, double *q, double *u)
//{}

int main (int argc, char **argv)
{
	
	// Read data and load this into memory
	read_data();

//	printf("/*********************************/");
/*    printf("\nWhich geometry do you want to be animated? \n");
	printf("b = box \ns = sphere \nc = cylinder \np = capsule\n");
	printf("Enter a choice \n");
	scanf("%c",&STR);*/
	
    dsFunctions fn; 
 
  // setup pointers to drawstuff callback functions
  fn.version = DS_VERSION; 
  fn.start = &start; 
  fn.step = &display; 
  fn.command = &command; 
  fn.stop = 0; 
#ifdef WIN32
  fn.path_to_textures = "C:/cga/kdc/sim5/useful/drawstuff-windows/textures";
#else
  //Change to this appropriately
 // fn.path_to_textures = "/Users/pab47/Documents/DISK/template_files/template_C/animation-drawstuff/home_comp/useful/drawstuff-linux/textures";
    fn.path_to_textures = "/Users/pranavb/Documents/2014Backup/template_files/template_C/animation-drawstuff/all_geometries/drawstuff/textures";
//  fn.path_to_textures = "/Users/pranavb/Documents/pranavb-macbook/2014Backup/template_files/template_C/animation-drawstuff/all_geometries/drawstuff/textures";
 //   fn.path_to_textures = "/Users/pranavb/Documents/2014Backup/template_files/template_C/animation-drawstuff/all_geometries/drawstuff/textures";
#endif


  // do display
  dsSimulationLoop( argc, argv, /* command line arguments */
                   2*352, 2*288, /* window size */
                    &fn ); /* callback info */
    

  return 0;
}

/********************************************************************/
