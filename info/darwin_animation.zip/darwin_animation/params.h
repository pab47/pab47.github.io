#define PI 3.141592653589793
//
/////* Body numbers */
//#define BDY_GROUND	(-1)
//#define BDY_BF 0
//#define BDY_BS 1
//#define BDY_BT 2
//#define BDY_BT2 3
//#define BDY_BF2 4
//#define BDY_BS2 5
//#define BDY_BSR 6
//#define BDY_BSL 7
//#define BDY_P  8
//#define BDY_TT 9
//#define BDY_TS 10
//#define BDY_TF 11
//#define BDY_HT 12
//#define BDY_HN 13
//#define BDY_HTLT 14
//#define BDY_LSS 15
//#define BDY_LAF 16
//#define BDY_LAO 17
//#define BDY_LAS 18
//#define BDY_LE  19
//#define BDY_LWT 20
//#define BDY_LWIO 21
//#define BDY_LWFB 22
//#define BDY_RSS 23
//#define BDY_RAF 24
//#define BDY_RAO 25
//#define BDY_RAS 26
//#define BDY_RE  27
//#define BDY_RWT 28
//#define BDY_RWIO 29
//#define BDY_RWFB 30
//
////Define Joints
//#define JNT_BF 0
//#define JNT_BS 1
//#define JNT_BT 2
//#define JNT_BT2 3
//#define JNT_BF2 4
//#define JNT_BS2 5
//#define JNT_BSR 6
//#define JNT_BSL 7
//#define JNT_P  8
//#define JNT_TT 9
//#define JNT_TS 10
//#define JNT_TF 11
//#define JNT_HT 12
//#define JNT_HN 13
//#define JNT_HTLT 14
//#define JNT_LSS 15
//#define JNT_LAF 16
//#define JNT_LAO 17
//#define JNT_LAS 18
//#define JNT_LE  19
//#define JNT_LWT 20
//#define JNT_LWIO 21
//#define JNT_LWFB 22
//#define JNT_RSS 23
//#define JNT_RAF 24
//#define JNT_RAO 25
//#define JNT_RAS 26
//#define JNT_RE  27
//#define JNT_RWT 28
//#define JNT_RWIO 29
//#define JNT_RWFB 30


////Define DOFs
//Need tx ty tz ax ay az
#define TORSO  0
#define R_SHOULDER_PITCH 1
#define L_SHOULDER_PITCH 2
#define R_SHOULDER_ROLL 3
#define L_SHOULDER_ROLL 4
#define R_ELBOW_YAW 5
#define L_ELBOW_YAW 6
#define R_HIP_YAW 7
#define L_HIP_YAW  8
#define R_HIP_ROLL 9
#define L_HIP_ROLL 10
#define R_HIP_PITCH 11
#define L_HIP_PITCH 12
#define R_KNEE_PITCH 13
#define L_KNEE_PITCH 14
#define R_ANKLE_PITCH 15
#define L_ANKLE_PITCH 16
#define R_ANKLE_ROLL 17
#define L_ANKLE_ROLL 18
#define HEAD_YAW  19
#define HEAD_PITCH 20
//#define LWIO 21
//#define LWFB 22
//#define RSS 23
//#define RAF 24
//#define RAO 25
//#define RAS 26
//#define RE  27
//#define RWT 28
//#define RWIO 29
//#define RWFB 30



//length parameters 
//#define LUPPER 0.33f
//#define LLOWER 0.27f
//#define LHAND  0.1f //Need to measure
//#define RADIUS 0.01f 


#define MAXEVALS 1000
#define CTOL 1e-5

#define NQ 27
#define NU 26
#define NJNT 21
#define NBOD 21
#define NSTATE (NQ+NU)
#define dim 3

#define XX 0
#define YY 1
#define ZZ 2

//hand end-effector
#define LH 0.129 
#define L3 0.016

//leg end-effector
#define FX 0.104
#define FY 0.015
#define FZ 0.066

#define LX 0.052
#define LZ 0.023

#define LF 0.0335

//Head end-effector
#define HX 0.0332
#define HY 0.034
#define HZ 0.0225

#define L1 0.016 
#define L2  0.060 
#define L4  0.093 
#define L5  0.093 
#define Lh  0.0505 
#define L0  0.082 
#define Ltx  0.005 
#define Lty  0.01222 
#define Ltz  0.037



//
//double zero_tics[26] = 
//{
//4000,
//2000,
//1900,
//3800,
//2300,
//2100,
//3900,
//1700, //HT
//200,
//920,
//0, //LSS
//4000, //LAF
//4000,
//80,
//4000,
//2900,
//3950,
//3900,
//0, //RSS
//4060, //RAF
//4000,
//3200,
//4000,
//580,
//1870,
//3000,
//};
//
////
//double limits_tics[26][2] =
//{
//{100,        4000}, //BF
//{100 ,       4000},
//{180  ,      3900},
//{0     ,   3800}, //P
//{100   ,     4000},
//{400   ,     3800},
//{300   ,     3900},
//{70    ,    4000}, //HT
//{200   ,     3800},
//{65    ,    3950},
//{100,       4000}, //RSS
//{25    ,    4000}, //RAF
//{60    ,    4000},
//{80    ,    4000},
//{30    ,    4000},
//{0     ,   4000},
//{560   ,     3950},
//{90    ,    3900},
//{100,       4000},  //LSS
//{60    ,    4060}, //LAF
//{100   ,     4000},
//{120   ,     4000},
//{0     ,   4000},
//{150   ,     4050},
//{100   ,     3950},
//{0     ,   4050}
//};
//
////Need to multipy by 0.001
//double scale_tics_to_rad[26] = 
//{
//0.030443844420863, //BF
//0.063583007433414,
//0.237137126629664,
//0.162307188893192,
//0.100874114394927,
//0.173167015350046,
//0.195385016789049,
//0.740518268346166, //HT
//0.199861966498217,
//0.148265428095839,
//    0.01,  //LSS
//0.468271838310079, //LAF
//0.253498431600640,
//0.581776417331443,
//0.382008940030259,
//0.734373510401986,
//0.139626340159546,
//0.201317681046871,
//    0.01, //RSS
//0.511184299747293, //RAF
//0.232710566932577,
//0.606750234270549,
//0.349429460659698,
//0.749481419948047,
//0.152716309549504,
//0.129056036239017,
//};
//
double joint_limits_rad[20][2] = {
    {-4.3633,4.3633},
    {-4.3633,4.3633},
    {-1.7453,1.7453},
    {-1.7453,1.7453},
    {0,2.7925},
    {0,2.7925},
    {-2.618,0.7854},
    {-2.618,0.7854},
    {0,1.0472},
    {0,1.0472},
    {-0.5236,1.7453},
    {-0.5236,1.7453},
    {-2.2689,0},
    {-2.2689,0},
    {-1.0472,1.0472},
    {-1.0472,1.0472},
    {0.5236,-1.0472},
    {0.5236,-1.0472},
    {-2.618,2.618},
    {-1.0472,0.5236},
};

float robot_dim[21][2] = {
    {FX-0.5*LX,2*L0}, //x is approximate
    {2*L3,2*L1}, //R_SHOULDER_PITCH
    {2*L3,2*L1},
    {2*L3,2*L1}, //R_SHOULDER_ROLL
    {2*L3,2*L1}, //4
    {2*L3,1.5*L1}, //R_ELBOW_YAW
    {2*L3,1.5*L1}, //6 last for hand
    {0.75*(FX-0.5*LX),1.2*Ltz}, //R_HIP_YAW
    {0.75*(FX-0.5*LX),1.2*Ltz},
    {0.75*(FX-0.5*LX),1.2*Ltz}, //R_HIP_ROLL
    {0.75*(FX-0.5*LX),1.2*Ltz},
    {0.75*(FX-0.5*LX),1.2*Ltz}, //R_HIP_PITCH
    {0.75*(FX-0.5*LX),1.2*Ltz},
    {0.75*(FX-0.5*LX),1.0*Ltz}, //R_KNEE_PITCH
    {0.75*(FX-0.5*LX),1.0*Ltz},
    {0.75*(FX-0.5*LX),1.0*Ltz}, //R_ANKLE_PITCH
    {0.75*(FX-0.5*LX),1.0*Ltz},
    {FX,FZ}, //R_ANKLE_ROLL
    {FX,FZ}, //Last for leg
    {0.02,0.02}, //HEAD_YAW 
    {2*HY,0.75*2*L0},  //HEAD_PITCH
};
//double joint_limits_rad[26][2] = 
//{
//{-0.118730993241366,                   0},//BF
//{-0.120807714123486,   0.127166014866827},
//{-0.407875857803023,   0.474274253259329},
//{-0.616767317794131,                   0}, //P
//{-0.221923051668838,   0.171485994471375}, 
//{-0.294383926095078,   0.294383926095078},
//{-0.703386060440578,                   0},
//{-1.207044777404250,   1.703192017196181}, //HT
//{0,                    0.719503079393581}, 
//{-0.126766941021943,   0.449244247130393},
//    {0, 0.04}, //LSS (in m) Multiplied by 10 to see animation.
//{-1.861380557282562,                   0}, //LAF
//{-0.998783820506521,                   0}, 
//{0,   2.280563555939257},
//{-1.516575491920128,                   0},
//{-2.129683180165758,   0.807810861442184},
//{-0.473333293140862,                   0},
//{-0.767020364788577,                   0},
//        {0, 0.04}, //RSS (in m)
//{-2.044737198989173,                   0}, //RAF
//{-0.907571211037051,                   0},
//{-1.868790721553291,   0.485400187416439},
//{-1.397717842638792,                   0},
//{-0.322277010577660,   2.600700527219724},
//{-0.270307867902622,   0.317649923862968},
//{-0.387168108717052,   0.135508838050968}
//};
