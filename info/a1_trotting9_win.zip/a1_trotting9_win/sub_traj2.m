
all_legs = [1 2 3 4];
all_legs = [0 1];
all_legs = 0;
%%%%%%%%%%% qref %%%%%%%%%%%


for i=1:length(all_legs)
    leg = all_legs(i);

    if (leg==0)
        figure(fig_no); fig_no = fig_no + 1;
        subplot(3,1,1)
        plot(t(index),qref_FR_hip(index),'r','Linewidth',2); hold on
        plot(t(index),q_FR_hip(index),'k','Linewidth',1); hold on
        legend('ref','act');
        ylabel('ang hip');
        title('FR');

        subplot(3,1,2)
        plot(t(index),qref_FR_thigh(index),'r','Linewidth',2); hold on
        plot(t(index),q_FR_thigh(index),'k','Linewidth',1);
        legend('ref','act');
        ylabel('ang thigh');

        subplot(3,1,3)
        plot(t(index),qref_FR_calf(index),'r','Linewidth',2); hold on
        plot(t(index),q_FR_calf(index),'k','Linewidth',1);
        legend('ref','act');
        ylabel('ang calf');

        figure(fig_no); fig_no = fig_no + 1;
        subplot(3,1,1)
        plot(t(index),uref_FR_hip(index),'r','Linewidth',2); hold on
        plot(t(index),v_FR_hip(index),'k','Linewidth',1); hold on
        legend('ref','act');
        ylabel('vel hip');
         title('FR');

        subplot(3,1,2)
        plot(t(index),uref_FR_thigh(index),'r','Linewidth',2); hold on
        plot(t(index),v_FR_thigh(index),'k','Linewidth',1);
        legend('ref','act');
        ylabel('vel thigh');

        subplot(3,1,3)
        plot(t(index),uref_FR_calf(index),'r','Linewidth',2); hold on
        plot(t(index),v_FR_calf(index),'k','Linewidth',1);
        legend('ref','act');
        ylabel('vel calf');

    end


    if (leg==1)
        figure(fig_no); fig_no = fig_no + 1;
        subplot(3,1,1)
        plot(t(index),qref_FL_hip(index),'r','Linewidth',2); hold on
        plot(t(index),q_FL_hip(index),'k','Linewidth',1); hold on
        legend('ref','act');
        ylabel('ang hip');
        title('FL');

        subplot(3,1,2)
        plot(t(index),qref_FL_thigh(index),'r','Linewidth',2); hold on
        plot(t(index),q_FL_thigh(index),'k','Linewidth',1);
        legend('ref','act');
        ylabel('ang thigh');

        subplot(3,1,3)
        plot(t(index),qref_FL_calf(index),'r','Linewidth',1); hold on
        plot(t(index),q_FL_calf(index),'k','Linewidth',2);
        legend('ref','act');
        ylabel('ang calf');

        figure(fig_no); fig_no = fig_no + 1;
        subplot(3,1,1)
        plot(t(index),uref_FL_hip(index),'r','Linewidth',2); hold on
        plot(t(index),v_FL_hip(index),'k','Linewidth',1); hold on
        legend('ref','act');
        ylabel('vel hip');
        title('FL');

        subplot(3,1,2)
        plot(t(index),uref_FL_thigh(index),'r','Linewidth',2); hold on
        plot(t(index),v_FL_thigh(index),'k','Linewidth',1);
        legend('ref','act');
        ylabel('vel thigh');

        subplot(3,1,3)
        plot(t(index),uref_FL_calf(index),'r','Linewidth',2); hold on
        plot(t(index),v_FL_calf(index),'k','Linewidth',1);
        legend('ref','act');
        ylabel('vel calf');

    end



    if (leg==2)
        figure(fig_no); fig_no = fig_no + 1;
        subplot(3,1,1)
        plot(t(index),qref_RR_hip(index),'r','Linewidth',2); hold on
        plot(t(index),q_RR_hip(index),'k','Linewidth',1); hold on
        legend('ref','act');
        ylabel('ang hip');
        title('RR');

        subplot(3,1,2)
        plot(t(index),qref_RR_thigh(index),'r','Linewidth',2); hold on
        plot(t(index),q_RR_thigh(index),'k','Linewidth',1);
        legend('ref','act');
        ylabel('ang thigh');

        subplot(3,1,3)
        plot(t(index),qref_RR_calf(index),'r','Linewidth',2); hold on
        plot(t(index),q_RR_calf(index),'k','Linewidth',1);
        legend('ref','act');
        ylabel('ang calf');

        figure(fig_no); fig_no = fig_no + 1;
        subplot(3,1,1)
        plot(t(index),uref_RR_hip(index),'r','Linewidth',2); hold on
        plot(t(index),v_RR_hip(index),'k','Linewidth',1); hold on
        legend('ref','act');
        ylabel('vel hip');
         title('RR');

        subplot(3,1,2)
        plot(t(index),uref_RR_thigh(index),'r','Linewidth',2); hold on
        plot(t(index),v_RR_thigh(index),'k','Linewidth',1);
        legend('ref','act');
        ylabel('vel thigh');

        subplot(3,1,3)
        plot(t(index),uref_RR_calf(index),'r','Linewidth',2); hold on
        plot(t(index),v_RR_calf(index),'k','Linewidth',1);
        legend('ref','act');
        ylabel('vel calf');

    end


    if (leg==3)
        figure(fig_no); fig_no = fig_no + 1;
        subplot(3,1,1)
        plot(t(index),qref_RL_hip(index),'r','Linewidth',2); hold on
        plot(t(index),q_RL_hip(index),'k','Linewidth',1); hold on
        legend('ref','act');
        ylabel('ang hip');
        title('RL');

        subplot(3,1,2)
        plot(t(index),qref_RL_thigh(index),'r','Linewidth',2); hold on
        plot(t(index),q_RL_thigh(index),'k','Linewidth',1);
        legend('ref','act');
        ylabel('ang thigh');

        subplot(3,1,3)
        plot(t(index),qref_RL_calf(index),'r','Linewidth',1); hold on
        plot(t(index),q_RL_calf(index),'k','Linewidth',2);
        legend('ref','act');
        ylabel('ang calf');

        figure(fig_no); fig_no = fig_no + 1;
        subplot(3,1,1)
        plot(t(index),uref_RL_hip(index),'r','Linewidth',2); hold on
        plot(t(index),v_RL_hip(index),'k','Linewidth',1); hold on
        legend('ref','act');
        ylabel('vel hip');
        title('RL');

        subplot(3,1,2)
        plot(t(index),uref_RL_thigh(index),'r','Linewidth',2); hold on
        plot(t(index),v_RL_thigh(index),'k','Linewidth',1);
        legend('ref','act');
        ylabel('vel thigh');

        subplot(3,1,3)
        plot(t(index),uref_RL_calf(index),'r','Linewidth',2); hold on
        plot(t(index),v_RL_calf(index),'k','Linewidth',1);
        legend('ref','act');
        ylabel('vel calf');

    end
end
