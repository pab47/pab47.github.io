clear all
clc
close all
filename = 'data.csv';

Fontsize = 22;

T = readtable(filename); %check T.Properties
VariableNames = T.Properties.VariableNames;
Arr = table2array(T);
[m,n] = size(Arr);

%%%% Print Variable names
for i=1:length(VariableNames)
    disp([mat2str(i), ' = ',VariableNames{i}]);
end

for i=1:length(VariableNames)
    tmp_arr = Arr(:,i);
    eval([VariableNames{i},'=tmp_arr;']);
end

[step_no,step_vx] = step_stats(step,[cmd_vx state_vx]);
[step_no,step_vy] = step_stats(step,[cmd_vy state_vy]);
[step_no,step_omega] = step_stats(step,[cmd_omega state_omega]);

m = length(step_no)-1;
data_vx = [step_vx(2:m,2) step_vx(1:m-1,2)  step_vx(1:m-1,1)]; 


%data_vx

%see https://www.mathworks.com/matlabcentral/fileexchange/34765-polyfitn?s_tid=srchtitle
p = polyfitn([data_vx(:,2) data_vx(:,3)],data_vx(:,1),1);
polyn2sympoly(p)

function [step_x,step_y] = step_stats(x,y)
    step_x = unique(x);
    step_y = [];
    for i=1:length(step_x)
        rows = find(x==step_x(i));
        step_y = [step_y; [mean(y(rows,1)), mean(y(rows,2))]];
    end
end
