
//input is time
//output is X and Xdot
//void generate_cart_traj(double ttime,double X[12],double Xdot[12])
void generate_cart_traj(double ttime)
{
  int i;
  double lz0[4] = {0};
    for (i=0;i<nlegs;i++)
    {
        if (fsm[i]==fsm_free2trot)
          {
            // lz0[i] = nominal_height(i);
            //
            // double lz_ = lz0[i];
            // double ldotz_ = abs_ldotz[i];
            // set_command(&lz_,lz[i],lz_min,lz_max,&ldotz_);
            // lz[i] = lz_;
            // ldotz[i]=ldotz_;

            set_command_linear(ttime-t_fsm[i],tt_min[i],tt_max[i],
                              llz_min[i],llz_max[i],&lz[i],&ldotz[i]);
          }

         if (fsm[i] == fsm_stand)
            {
              lz0[i] = nominal_height(i);

              double lz_ = lz0[i];
              double ldotz_ = abs_ldotz[i];
              //set_command(&lz_,lz[i],lz_min,lz_max,&ldotz_);
              lz[i] = lz_;
              ldotz[i]=ldotz_;
          }

        if (fsm[i]==fsm_stance)
          {
            lz0[i] = nominal_height(i);

            lz[i]=lz0[i];
            ldotz[i] = 0;

            // double lx_ = 0.5*xdot_ref*t_step; //target (Forward is negative) #needs value based on globals
            // double ldotx_ = abs_ldotx[i];
            // set_command(&lx_,lx[i],lx_min,lx_max,&ldotx_);
            // lx[i] = lx_;
            // ldotx[i] = -ldotx_; //Motion of the hip is opposite to that of foot hence negative sign

            // double tmp_lx, tmp_ldotx;
            // set_command_linear(ttime-t_fsm[i],tt_min[i],tt_max[i],
            //                   llx_min[i],llx_max[i],&tmp_lx,&tmp_ldotx);
            // printf("before: %f %f \n",lx[i],ldotx[i]);
            // printf("after : %f %f \n",tmp_lx,tmp_ldotx);
            if (use_linear_command==1)
            set_command_linear(ttime-t_fsm[i],tt_min[i],tt_max[i],
                               llx_min[i],llx_max[i],&lx[i],&ldotx[i]);
            else
            set_command_fifth(ttime-t_fsm[i],tt_min[i],tt_max[i],
                                                llx_min[i],llx_max[i],&lx[i],&ldotx[i]);
            ldotx[i] = -ldotx[i];


            // double ly_ = -ydot_ref*t_step; //target (Forward is negative) #needs value based on globals
            // if (i==0 || i==1)
            //     ly_ -= aa*psidot_ref*t_step;
            // else
            //     ly_ += aa*psidot_ref*t_step;
            // ly_ = 0.5*ly_;

            // double ldoty_ = abs_ldoty[i];
            // set_command(&ly_,ly[i],ly_min,ly_max,&ldoty_);
            // ly[i] = ly_;
            // ldoty[i] = ldoty_;

            //printf("before: %f %f \n",ly[i],ldoty[i]);
            if (use_linear_command==1)
            set_command_linear(ttime-t_fsm[i],tt_min[i],tt_max[i],
                               lly_min[i],lly_max[i],&ly[i],&ldoty[i]);
            else
            set_command_fifth(ttime-t_fsm[i],tt_min[i],tt_max[i],
                              lly_min[i],lly_max[i],&ly[i],&ldoty[i]);
            //printf("after: %f %f \n",ly[i],ldoty[i]);
            // ldoty[i] = ldoty[i];

        }

        if (fsm[i]==fsm_swing)
        {
            // lz0[i] = nominal_height(i);
            //
            // double ldotz_ = abs_ldotz[i];
            // double lz_;
            // if (ttime-t_fsm[i]<=0.5*t_step)
            //     lz_ = lz0[i]-hcl;
            // else
            //     lz_ = lz0[i];
            //
            // set_command(&lz_,lz[i],lz_min,lz_max,&ldotz_);
            // lz[i] = lz_;
            // ldotz[i]=-ldotz_; //negative needed because
            //                   //Jacobian model assumes upward is positive
            //                   // while IK model assumes downard is positive.
            //                   //The negative takes care of converting IK vel to jacobian model vel.

            double tmin, tmax;
            double lzmin,lzmax;
            if (ttime-t_fsm[i]<=0.5*t_step)
            {
              tmin = tt_min[i];
              tmax = tt_max[i]/2;
              lzmin = llz_min[i];
              lzmax = llz_max[i];
            }
            else
            {
              tmin = tt_max[i]/2;
              tmax = tt_max[i];
              lzmin = llz_max[i];
              lzmax = llz_min[i];
            }
            // printf("before: %f %f \n",lz[i],ldotz[i]);
            if (use_linear_command==1)
            set_command_linear(ttime-t_fsm[i],tmin,tmax,lzmin,lzmax,&lz[i],&ldotz[i]);
            else
            set_command_fifth(ttime-t_fsm[i],tmin,tmax,lzmin,lzmax,&lz[i],&ldotz[i]);

            ldotz[i] = -ldotz[i];
            // printf("after: %f %f \n",lz[i],ldotz[i]);

            // double lx_ = -0.5*xdot_ref*t_step; //target (Forward is negative) #needs value based on globals
            // double ldotx_ = abs_ldotx[i];
            // set_command(&lx_,lx[i],lx_min,lx_max,&ldotx_);
            // lx[i] = lx_;
            // ldotx[i] = -ldotx_;

            if (use_linear_command==1)
            set_command_linear(ttime-t_fsm[i],tt_min[i],tt_max[i],
                               llx_min[i],llx_max[i],&lx[i],&ldotx[i]);
            else
            set_command_fifth(ttime-t_fsm[i],tt_min[i],tt_max[i],
                               llx_min[i],llx_max[i],&lx[i],&ldotx[i]);

            ldotx[i] = -ldotx[i];

            // double ly_ = ydot_ref*t_step;
            // if (i==0 || i==1)
            //     ly_ += aa*psidot_ref*t_step;
            // else
            //     ly_ -= aa*psidot_ref*t_step;
            // ly_ = 0.5*ly_;

            //
            // double ldoty_ = abs_ldoty[i];
            // set_command(&ly_,ly[i],ly_min,ly_max,&ldoty_);
            // ly[i] = ly_;
            // ldoty[i] = ldoty_;
            //printf("before: %f %f\n",ly_,ldoty_);

            if (use_linear_command==1)
            set_command_linear(ttime-t_fsm[i],tt_min[i],tt_max[i],
                               lly_min[i],lly_max[i],&ly[i],&ldoty[i]);
            else
            set_command_fifth(ttime-t_fsm[i],tt_min[i],tt_max[i],
                                                lly_min[i],lly_max[i],&ly[i],&ldoty[i]);
            // ldoty[i] = ldoty[i];
            //printf("after: %f %f\n",ly[i],ldoty[i]);

        }
   }
}
