void get_bodyVel(double base_quat_mjc[4],double base_vel[3], double body_vel[3])
{
double base_quat[4]={0}; //This is quat in sd (x,y,z,w)
ram_quat_mjc2sd(base_quat_mjc, base_quat);


double base_ang[3]={0};
// double base_dc[3][3]={0};
// ram_quat_mjc2sd(base_quat);
ram_quat2ang(base_quat,base_ang);
// sdquat2dc(base_quat[0],base_quat[1],base_quat[2],base_quat[3],base_dc); sdprinterr(stderr);

// //     base_ang = rot.quat2euler(base_quat)
// // base_mat = rot.quat2mat(base_quat)
//
double Rz[3][3]={0}, RzT[3][3]={0};
ram_Rz(Rz,base_ang[2]);
ram_transpose(&Rz[0][0],3,3,&RzT[0][0]);
// Rz = rot.rotate(base_ang[2],'z')
//   RzT = np.transpose(Rz)

 // double body_dc[3][3]={0};
ram_multMatVec(&RzT[0][0],3,3,&base_vel[0],3,&body_vel[0]);
 // ram_multMatMat(&RzT[0][0],3,3,&base_dc[0][0],3,3,&body_dc[0][0]);
//  ram_multMatMat(&base_dc[0][0],3,3,&RzT[0][0],3,3,&body_dc[0][0]);
 // sddc2ang(body_dc,&body_ang[0],&body_ang[1],&body_ang[2]); sdprinterr(stderr);
  // body_mat = np.matmul(RzT,base_mat)
  // body_ang = rot.mat2euler(body_mat)

}
