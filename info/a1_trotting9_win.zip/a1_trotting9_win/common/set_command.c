
void set_command(double *cmd_des,double cmd_curr,double cmd_min,double cmd_max,double *cmd_rate)
{

    double temp_rate =  (*cmd_des - cmd_curr)/dtime ;
    double abs_rate = fabs(temp_rate);
    double sign_rate;
    if (abs_rate<0.0001 )
        sign_rate = 0;
    else
        sign_rate = temp_rate/abs_rate;

    double rate = ram_min(abs_rate,*cmd_rate);

    double cmd;
    if (cmd_curr > *cmd_des)
        cmd = cmd_curr - rate*dtime;
    else if (cmd_curr < *cmd_des)
        cmd = cmd_curr + rate*dtime;
    else
        cmd = cmd_curr;

    if (cmd > cmd_max)
        cmd = cmd_max;

    if (cmd < cmd_min)
        cmd = cmd_min;

    *cmd_des = cmd;
    *cmd_rate = sign_rate*rate;

}
