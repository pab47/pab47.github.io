
void nominal_forces03(double phi,double theta,double psi,
                      double q01,double q02,double q03,
                      double q31,double q32,double q33,
                      double fx0,double fy0,double fz0,
                      double taux0,double tauy0,double tauz0,
                      double F[6])
                     //double *ptr_F)
{
  // double a,double b,double c,
  // double l1,double l2,
  // double m,double g,
    double a = aa;
    double b=bb;
    double c =cc;
    double l1 = ll;
    double l2 = ll;
    double m = mass;

    int i;

    double A[6][6]={0};
    double B[6]={0};


    A[0][0]=-1;
    A[0][1]=-1;
    A[0][2]=0;
    A[0][3]=0;
    A[0][4]=0;
    A[0][5]=0;
    A[1][0]=0;
    A[1][1]=0;
    A[1][2]=-1;
    A[1][3]=-1;
    A[1][4]=0;
    A[1][5]=0;
    A[2][0]=0;
    A[2][1]=0;
    A[2][2]=0;
    A[2][3]=0;
    A[2][4]=-1;
    A[2][5]=-1;
    A[3][0]=0;
    A[3][1]=0;
    A[3][2]=l1*(cos(q02)*(sin(q01)*(cos(psi)*sin(phi) + cos(phi)*sin(psi)*sin(theta)) - cos(phi)*cos(q01)*cos(theta)) - sin(q02)*(sin(phi)*sin(psi) - cos(phi)*cos(psi)*sin(theta))) + l2*(cos(q03)*(cos(q02)*(sin(q01)*(cos(psi)*sin(phi) + cos(phi)*sin(psi)*sin(theta)) - cos(phi)*cos(q01)*cos(theta)) - sin(q02)*(sin(phi)*sin(psi) - cos(phi)*cos(psi)*sin(theta))) - sin(q03)*(sin(q02)*(sin(q01)*(cos(psi)*sin(phi) + cos(phi)*sin(psi)*sin(theta)) - cos(phi)*cos(q01)*cos(theta)) + cos(q02)*(sin(phi)*sin(psi) - cos(phi)*cos(psi)*sin(theta)))) + a*(sin(phi)*sin(psi) - cos(phi)*cos(psi)*sin(theta)) - b*(cos(psi)*sin(phi) + cos(phi)*sin(psi)*sin(theta)) - c*(cos(q01)*(cos(psi)*sin(phi) + cos(phi)*sin(psi)*sin(theta)) + cos(phi)*cos(theta)*sin(q01));
    A[3][3]=l1*(cos(q32)*(sin(q31)*(cos(psi)*sin(phi) + cos(phi)*sin(psi)*sin(theta)) - cos(phi)*cos(q31)*cos(theta)) - sin(q32)*(sin(phi)*sin(psi) - cos(phi)*cos(psi)*sin(theta))) + l2*(cos(q33)*(cos(q32)*(sin(q31)*(cos(psi)*sin(phi) + cos(phi)*sin(psi)*sin(theta)) - cos(phi)*cos(q31)*cos(theta)) - sin(q32)*(sin(phi)*sin(psi) - cos(phi)*cos(psi)*sin(theta))) - sin(q33)*(sin(q32)*(sin(q31)*(cos(psi)*sin(phi) + cos(phi)*sin(psi)*sin(theta)) - cos(phi)*cos(q31)*cos(theta)) + cos(q32)*(sin(phi)*sin(psi) - cos(phi)*cos(psi)*sin(theta)))) - a*(sin(phi)*sin(psi) - cos(phi)*cos(psi)*sin(theta)) + b*(cos(psi)*sin(phi) + cos(phi)*sin(psi)*sin(theta)) + c*(cos(q31)*(cos(psi)*sin(phi) + cos(phi)*sin(psi)*sin(theta)) + cos(phi)*cos(theta)*sin(q31));
    A[3][4]=b*(cos(phi)*cos(psi) - sin(phi)*sin(psi)*sin(theta)) - a*(cos(phi)*sin(psi) + cos(psi)*sin(phi)*sin(theta)) - l1*(cos(q02)*(sin(q01)*(cos(phi)*cos(psi) - sin(phi)*sin(psi)*sin(theta)) + cos(q01)*cos(theta)*sin(phi)) - sin(q02)*(cos(phi)*sin(psi) + cos(psi)*sin(phi)*sin(theta))) - l2*(cos(q03)*(cos(q02)*(sin(q01)*(cos(phi)*cos(psi) - sin(phi)*sin(psi)*sin(theta)) + cos(q01)*cos(theta)*sin(phi)) - sin(q02)*(cos(phi)*sin(psi) + cos(psi)*sin(phi)*sin(theta))) - sin(q03)*(sin(q02)*(sin(q01)*(cos(phi)*cos(psi) - sin(phi)*sin(psi)*sin(theta)) + cos(q01)*cos(theta)*sin(phi)) + cos(q02)*(cos(phi)*sin(psi) + cos(psi)*sin(phi)*sin(theta)))) + c*(cos(q01)*(cos(phi)*cos(psi) - sin(phi)*sin(psi)*sin(theta)) - cos(theta)*sin(phi)*sin(q01));
    A[3][5]=a*(cos(phi)*sin(psi) + cos(psi)*sin(phi)*sin(theta)) - l1*(cos(q32)*(sin(q31)*(cos(phi)*cos(psi) - sin(phi)*sin(psi)*sin(theta)) + cos(q31)*cos(theta)*sin(phi)) - sin(q32)*(cos(phi)*sin(psi) + cos(psi)*sin(phi)*sin(theta))) - b*(cos(phi)*cos(psi) - sin(phi)*sin(psi)*sin(theta)) - l2*(cos(q33)*(cos(q32)*(sin(q31)*(cos(phi)*cos(psi) - sin(phi)*sin(psi)*sin(theta)) + cos(q31)*cos(theta)*sin(phi)) - sin(q32)*(cos(phi)*sin(psi) + cos(psi)*sin(phi)*sin(theta))) - sin(q33)*(sin(q32)*(sin(q31)*(cos(phi)*cos(psi) - sin(phi)*sin(psi)*sin(theta)) + cos(q31)*cos(theta)*sin(phi)) + cos(q32)*(cos(phi)*sin(psi) + cos(psi)*sin(phi)*sin(theta)))) - c*(cos(q31)*(cos(phi)*cos(psi) - sin(phi)*sin(psi)*sin(theta)) - cos(theta)*sin(phi)*sin(q31));
    A[4][0]=b*(cos(psi)*sin(phi) + cos(phi)*sin(psi)*sin(theta)) - l2*(cos(q03)*(cos(q02)*(sin(q01)*(cos(psi)*sin(phi) + cos(phi)*sin(psi)*sin(theta)) - cos(phi)*cos(q01)*cos(theta)) - sin(q02)*(sin(phi)*sin(psi) - cos(phi)*cos(psi)*sin(theta))) - sin(q03)*(sin(q02)*(sin(q01)*(cos(psi)*sin(phi) + cos(phi)*sin(psi)*sin(theta)) - cos(phi)*cos(q01)*cos(theta)) + cos(q02)*(sin(phi)*sin(psi) - cos(phi)*cos(psi)*sin(theta)))) - a*(sin(phi)*sin(psi) - cos(phi)*cos(psi)*sin(theta)) - l1*(cos(q02)*(sin(q01)*(cos(psi)*sin(phi) + cos(phi)*sin(psi)*sin(theta)) - cos(phi)*cos(q01)*cos(theta)) - sin(q02)*(sin(phi)*sin(psi) - cos(phi)*cos(psi)*sin(theta))) + c*(cos(q01)*(cos(psi)*sin(phi) + cos(phi)*sin(psi)*sin(theta)) + cos(phi)*cos(theta)*sin(q01));
    A[4][1]=a*(sin(phi)*sin(psi) - cos(phi)*cos(psi)*sin(theta)) - l2*(cos(q33)*(cos(q32)*(sin(q31)*(cos(psi)*sin(phi) + cos(phi)*sin(psi)*sin(theta)) - cos(phi)*cos(q31)*cos(theta)) - sin(q32)*(sin(phi)*sin(psi) - cos(phi)*cos(psi)*sin(theta))) - sin(q33)*(sin(q32)*(sin(q31)*(cos(psi)*sin(phi) + cos(phi)*sin(psi)*sin(theta)) - cos(phi)*cos(q31)*cos(theta)) + cos(q32)*(sin(phi)*sin(psi) - cos(phi)*cos(psi)*sin(theta)))) - l1*(cos(q32)*(sin(q31)*(cos(psi)*sin(phi) + cos(phi)*sin(psi)*sin(theta)) - cos(phi)*cos(q31)*cos(theta)) - sin(q32)*(sin(phi)*sin(psi) - cos(phi)*cos(psi)*sin(theta))) - b*(cos(psi)*sin(phi) + cos(phi)*sin(psi)*sin(theta)) - c*(cos(q31)*(cos(psi)*sin(phi) + cos(phi)*sin(psi)*sin(theta)) + cos(phi)*cos(theta)*sin(q31));
    A[4][2]=0;
    A[4][3]=0;
    A[4][4]=a*cos(psi)*cos(theta) - l2*(cos(q03)*(cos(q02)*(cos(q01)*sin(theta) + cos(theta)*sin(psi)*sin(q01)) + cos(psi)*cos(theta)*sin(q02)) - sin(q03)*(sin(q02)*(cos(q01)*sin(theta) + cos(theta)*sin(psi)*sin(q01)) - cos(psi)*cos(q02)*cos(theta))) - l1*(cos(q02)*(cos(q01)*sin(theta) + cos(theta)*sin(psi)*sin(q01)) + cos(psi)*cos(theta)*sin(q02)) - c*(sin(q01)*sin(theta) - cos(q01)*cos(theta)*sin(psi)) + b*cos(theta)*sin(psi);
    A[4][5]=c*(sin(q31)*sin(theta) - cos(q31)*cos(theta)*sin(psi)) - l2*(cos(q33)*(cos(q32)*(cos(q31)*sin(theta) + cos(theta)*sin(psi)*sin(q31)) + cos(psi)*cos(theta)*sin(q32)) - sin(q33)*(sin(q32)*(cos(q31)*sin(theta) + cos(theta)*sin(psi)*sin(q31)) - cos(psi)*cos(q32)*cos(theta))) - l1*(cos(q32)*(cos(q31)*sin(theta) + cos(theta)*sin(psi)*sin(q31)) + cos(psi)*cos(theta)*sin(q32)) - a*cos(psi)*cos(theta) - b*cos(theta)*sin(psi);
    A[5][0]=l1*(cos(q02)*(sin(q01)*(cos(phi)*cos(psi) - sin(phi)*sin(psi)*sin(theta)) + cos(q01)*cos(theta)*sin(phi)) - sin(q02)*(cos(phi)*sin(psi) + cos(psi)*sin(phi)*sin(theta))) + a*(cos(phi)*sin(psi) + cos(psi)*sin(phi)*sin(theta)) - b*(cos(phi)*cos(psi) - sin(phi)*sin(psi)*sin(theta)) + l2*(cos(q03)*(cos(q02)*(sin(q01)*(cos(phi)*cos(psi) - sin(phi)*sin(psi)*sin(theta)) + cos(q01)*cos(theta)*sin(phi)) - sin(q02)*(cos(phi)*sin(psi) + cos(psi)*sin(phi)*sin(theta))) - sin(q03)*(sin(q02)*(sin(q01)*(cos(phi)*cos(psi) - sin(phi)*sin(psi)*sin(theta)) + cos(q01)*cos(theta)*sin(phi)) + cos(q02)*(cos(phi)*sin(psi) + cos(psi)*sin(phi)*sin(theta)))) - c*(cos(q01)*(cos(phi)*cos(psi) - sin(phi)*sin(psi)*sin(theta)) - cos(theta)*sin(phi)*sin(q01));
    A[5][1]=l1*(cos(q32)*(sin(q31)*(cos(phi)*cos(psi) - sin(phi)*sin(psi)*sin(theta)) + cos(q31)*cos(theta)*sin(phi)) - sin(q32)*(cos(phi)*sin(psi) + cos(psi)*sin(phi)*sin(theta))) - a*(cos(phi)*sin(psi) + cos(psi)*sin(phi)*sin(theta)) + b*(cos(phi)*cos(psi) - sin(phi)*sin(psi)*sin(theta)) + l2*(cos(q33)*(cos(q32)*(sin(q31)*(cos(phi)*cos(psi) - sin(phi)*sin(psi)*sin(theta)) + cos(q31)*cos(theta)*sin(phi)) - sin(q32)*(cos(phi)*sin(psi) + cos(psi)*sin(phi)*sin(theta))) - sin(q33)*(sin(q32)*(sin(q31)*(cos(phi)*cos(psi) - sin(phi)*sin(psi)*sin(theta)) + cos(q31)*cos(theta)*sin(phi)) + cos(q32)*(cos(phi)*sin(psi) + cos(psi)*sin(phi)*sin(theta)))) + c*(cos(q31)*(cos(phi)*cos(psi) - sin(phi)*sin(psi)*sin(theta)) - cos(theta)*sin(phi)*sin(q31));
    A[5][2]=c*(sin(q01)*sin(theta) - cos(q01)*cos(theta)*sin(psi)) + l2*(cos(q03)*(cos(q02)*(cos(q01)*sin(theta) + cos(theta)*sin(psi)*sin(q01)) + cos(psi)*cos(theta)*sin(q02)) - sin(q03)*(sin(q02)*(cos(q01)*sin(theta) + cos(theta)*sin(psi)*sin(q01)) - cos(psi)*cos(q02)*cos(theta))) + l1*(cos(q02)*(cos(q01)*sin(theta) + cos(theta)*sin(psi)*sin(q01)) + cos(psi)*cos(theta)*sin(q02)) - a*cos(psi)*cos(theta) - b*cos(theta)*sin(psi);
    A[5][3]=l2*(cos(q33)*(cos(q32)*(cos(q31)*sin(theta) + cos(theta)*sin(psi)*sin(q31)) + cos(psi)*cos(theta)*sin(q32)) - sin(q33)*(sin(q32)*(cos(q31)*sin(theta) + cos(theta)*sin(psi)*sin(q31)) - cos(psi)*cos(q32)*cos(theta))) - c*(sin(q31)*sin(theta) - cos(q31)*cos(theta)*sin(psi)) + l1*(cos(q32)*(cos(q31)*sin(theta) + cos(theta)*sin(psi)*sin(q31)) + cos(psi)*cos(theta)*sin(q32)) + a*cos(psi)*cos(theta) + b*cos(theta)*sin(psi);
    A[5][4]=0;
    A[5][5]=0;

    B[0]=-fx0;
    B[1]=-fy0;
    B[2]=-g*m-fz0;
    B[3]=-taux0;
    B[4]=-tauy0;
    B[5]=-tauz0;

    // double F[6]={0};
    double eps = 1e-3;
    ram_weighted_inverse(&A[0][0],6,6,&B[0],6,&F[0],eps); //invert matrix

    // for (i=0;i<6;i++)
    //   *(ptr_F + i) = F[i];

    // fx0 = F[0];
    // fx3 = F[1];
    // fy0 = F[2];
    // fy3 = F[3];
    // fz0 = F[4];
    // fz3 = F[5];


}
