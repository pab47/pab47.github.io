void estimator(double ttime,
              double quat_act[4],double omega_act[3], double linacc_act[3],
                   double q_act[nact],double u_act[nact],RobotState *modelstate)
{
  int i,j,k;
  double z = 0;
  int count = 0;
  double vel_x = 0, vel_y = 0, vel_z = 0;

 // //This code used accelerometer to compute the linear velocity of the torso
 //  //Get base_dc from quat_act which is in mujoco format
 //  double base_quat_mjc[4] = {quat_act[0],quat_act[1],quat_act[2],quat_act[3]};
 //  ////This is quat in mjc (w,x,y,z)
 //  double base_quat[4]={0}; //This is quat in sd (x,y,z,w)
 //  double base_dc[3][3]={0};
 //  ram_quat_mjc2sd(base_quat_mjc, base_quat);
 //  sdquat2dc(base_quat[0],base_quat[1],base_quat[2],base_quat[3],base_dc); sdprinterr(stderr);
 //  double base_dc_T[3][3]={0};
 //  ram_transpose(&base_dc[0][0], 3, 3,  &base_dc_T[0][0]); //Take transpose of a matrix
 //  //convert linacc_act to world_acc;  world_acc = R_from_quat * linacc_act
 //  double world_acc[3]={0};
 //  ram_multMatVec(&base_dc[0][0],3,3, &linacc_act[0],3,&world_acc[0]); //Multiply matrix to vector
 //  // Substract g from world_acc
 //  world_acc[2] -= g;
 //  //Convert world acc to body_acc
 //  double body_acc[3]={0};
 //  ram_multMatVec(&base_dc_T[0][0],3,3, &world_acc[0],3,&body_acc[0]); //Multiply matrix to vector
 //  get_bodyVel(quat_act,world_acc,body_acc);
 //  //Estimate the velocity
 //  est_vx += body_acc[0]*dtime;
 //  est_vy += body_acc[1]*dtime;
 //  est_vz += body_acc[2]*dtime;




  //This is incorrect (old code)
  // double body_acc[3]={0};
  // // printf("%f \n",linacc_act[2]);
  // get_bodyVel(quat_act,linacc_act,body_acc);
  // est_vx += body_acc[0]*dtime;
  // est_vy += body_acc[1]*dtime;
  // est_vz += (body_acc[2]-g)*dtime;
  //est_z += est_vz*dtime;

  for (i=0;i<nlegs;i++)
  {
    j = 3*i;
    double q[3]={0};
    double qdot[3]={0};
    double X[3]={0}, Xdot[3]={0};
    for (k=0;k<3;k++)
    {
      q[k] = q_act[j+k];
      qdot[k] = u_act[j+k];
    }
    forward_kinematics2(q,qdot,X,Xdot,i);

    if (fsm[i]==fsm_swing) // && t_fsm[i]>=t_step+20*dtime)
      {
        est_lx[i] = X[0]; est_ly[i] = X[1]; est_lz[i] = X[2];
        est_ldotx[i] = Xdot[0]; est_ldoty[i] = Xdot[1]; est_ldotz[i] = Xdot[2];
      }

    if (fsm[i]==fsm_stance) // && t_fsm[i]>=t_step+20*dtime)
      {
        //estimate height
        count += 1;

        est_lx[i] = X[0]; est_ly[i] = X[1]; est_lz[i] = X[2];
        est_ldotx[i] = Xdot[0]; est_ldoty[i] = Xdot[1]; est_ldotz[i] = Xdot[2];

        z += X[2];

        vel_x += -Xdot[0];
        vel_y += -Xdot[1];
        vel_z += -Xdot[2];

        // forward_kinematics(q[0],q[1],q[2],&hx, &hy, &hz);
        // z += hz;

        // get_Jac(i,q,J);
        // ram_multMatVec(&J[0][0],3,3,&qdot[0],3,&Xdot[0]);
        // vel_x += -Xdot[0];
        // vel_y += -Xdot[1];
        // vel_z += -Xdot[2];

        // double X[3]={0};
        // double tmp_Xdot[3]={0};
        // forward_kinematics2(q,qdot,X,tmp_Xdot,i);
        // printf("pos: %f %f %f \n",X[0]-hx,X[1]-hy,X[2]-hz);
        // printf("vel: %f %f %f \n",Xdot[0]-tmp_Xdot[0],Xdot[1]-tmp_Xdot[1],Xdot[2]-tmp_Xdot[2]);
      }
  }

    if (count==0)
    {
      est_z = 0;
      est_vx = 0;
      est_vy = 0;
      est_vz = 0;
    }
    else
    {
      est_z = z/(double) count;
      est_vx = vel_x / (double) count;
      est_vy = vel_y / (double) count;
      est_vz = vel_z / (double) count;
    }

    double ratio = 0.95;
    est_vx  = ratio*prev_est_vx + (1-ratio)*est_vx;
    est_vy  = ratio*prev_est_vy + (1-ratio)*est_vy;
    est_vz  = ratio*prev_est_vz + (1-ratio)*est_vz;

    prev_est_vx = est_vx;
    prev_est_vy = est_vy;
    prev_est_vz = est_vz;

    // if (t_fsm[0]>=t_step+100*dtime)
    // {
    tmp_state_vx = (tmp_state_vx*points + est_vx)/(double)(points+1);
    tmp_state_vy = (tmp_state_vy*points + est_vy)/(double)(points+1);
    tmp_state_omega = (tmp_state_omega*points + omega_act[2])/(double)(points+1);
    points += 1;

    // int val = (int) (0.5*t_step/dtime);
    // printf("val = %d \n", val);
    if (points == (int) (0.5*t_step/dtime) )
      {
        //printf("Hello \n");
        state_vx = tmp_state_vx;
        state_vy = tmp_state_vy;
        state_omega = tmp_state_omega;
      }
    // }



    // //*********************************
    // //uses mujoco values for velocity (comment out if not needed)
    // double body_vel[3]={0};
    // double base_vel[3]={modelstate->bodyWorldVel.x,modelstate->bodyWorldVel.y,modelstate->bodyWorldVel.z};
    // // printf("base_vel = %f %f %f \n",base_vel[0],base_vel[1],base_vel[2]);
    // get_bodyVel(quat_act,base_vel,body_vel);
    // //printf("body_vel = %f %f %f \n",body_vel[0],body_vel[1],body_vel[2]);
    // est_vx = body_vel[0];
    // est_vy = body_vel[1];
    // est_vz = body_vel[2];
    // //printf("est_vel = %f %f %f\n",est_vx,est_vy,est_vz);
    // //*********************************

}
