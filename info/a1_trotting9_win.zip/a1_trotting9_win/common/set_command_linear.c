void set_command_linear(double t, double t_min, double t_max,
                          double cmd_min,  double cmd_max, double *cmd, double *cmd_rate)
{

  if (t<=t_min)
    t = t_min;

  if (t>=t_max)
    t = t_max;

  //cmd = a0 + a1*t;
  double a0 = (cmd_min*t_max - cmd_max*t_min)/(t_max - t_min);
  double a1 = (cmd_max - cmd_min)/(t_max-t_min);
  *cmd = a0+a1*t;
  *cmd_rate = a1;

}
