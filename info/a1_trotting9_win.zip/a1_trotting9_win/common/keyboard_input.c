void keyboard_input_initialize()
{
  // keyboard_Xarm[0] = arm_xdes;
  // keyboard_Xarm[1] = arm_ydes;
  // keyboard_Xarm[2] = arm_zdes;
}

void keyboard_input_cleanup()
{

  // if (state_robot == state_stand)
  // {
  //   if (flag_armIK_error == 1) //reset what was done
  //   {
  //     tmp_arm_rdes -= keyboard_dXarm[0];
  //     tmp_arm_thdes -= keyboard_dXarm[1];
  //     tmp_arm_zdes -= keyboard_dXarm[2];
  //     tmp_arm_angdes -= keyboard_dangdes;
  //     arm_gripper -= keyboard_dgripper;
  //   }
  //
    int i;
    for (i=0;i<3;i++)
       keyboard_dXarm[i] = 0;

    keyboard_dangdes = 0;
    keyboard_dgripper = 0;


  // }
}

void keyboard_input()
{
 int i;
 //state stand
 if (state_robot == state_stand)
 {
   z_ref += keyboard_dh;
   keyboard_dh = 0;
   theta_ref += keyboard_dtheta;
   keyboard_dtheta = 0;


   tmp_arm_rdes += keyboard_dXarm[0];
   tmp_arm_thdes += keyboard_dXarm[1];
   tmp_arm_zdes += keyboard_dXarm[2];
   tmp_arm_angdes += keyboard_dangdes;
   if (flag_mujoco == 1)
   {
    arm_gripper += keyboard_dgripper;
   }
   else
     {
       double temp_arm_gripper = arm_gripper_count + keyboard_dgripper;
       if (temp_arm_gripper > arm_grip_max)
          arm_gripper_count = arm_grip_max;
       else if (temp_arm_gripper < arm_grip_min)
          arm_gripper_count = arm_grip_min;
        else
          arm_gripper_count = temp_arm_gripper;
     }

   // for (i=0;i<3;i++)
   //  keyboard_dXarm[i] = 0;
   //
   // keyboard_dangdes = 0;
   // keyboard_dgripper = 0;

   // tmp_arm_rdes = keyboard_reset*tmp_arm_rdes + (1-keyboard_reset)*arm_rdes0;
   // tmp_arm_thdes = keyboard_reset*tmp_arm_thdes + (1-keyboard_reset)*arm_thdes0;
   // tmp_arm_zdes = keyboard_reset*tmp_arm_zdes + (1-keyboard_reset)*arm_zdes0;
   // tmp_arm_angdes = keyboard_reset*tmp_arm_angdes + (1-keyboard_reset)*arm_angdes0;
   // arm_gripper = keyboard_reset*arm_gripper + (1-keyboard_reset)*arm_gripper0;
   // keyboard_reset = 1;

   qarm_ref[4] = arm_gripper;
   qarm_ref[5] = arm_gripper;

   //printf("%f %f %f \n",arm_rdes,arm_thdes,arm_zdes);

   // printf(arm_xdes)
   // keyboard_reset = 1;

  //  for (i=0;i<narm-2;i++) //0,1,2,3
  //   qarm_ref[i] = keyboard_dth[i];
  //
  // qarm_ref[4] = keyboard_dth[4];
  // qarm_ref[5] = keyboard_dth[4];


 }

//state trot
 if (state_robot==state_trot)
   {
      if (prev_step < step_no)
      {
        prev_step = step_no;

        //change height
        z_ref += keyboard_dh;
        keyboard_dh = 0;
        theta_ref += keyboard_dtheta;
        keyboard_dtheta = 0;

        xdot_ref += keyboard_dvx;
        keyboard_dvx = 0;
        psidot_ref += keyboard_domega;
        keyboard_domega = 0;
        ydot_ref += keyboard_dvy;
        keyboard_dvy = 0;

        xdot_ref = keyboard_reset*xdot_ref;
        psidot_ref = keyboard_reset*psidot_ref;
        keyboard_reset = 1;

        }
     }
   }
