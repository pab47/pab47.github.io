void forward_kinematics(double q0,double q1,double q2, double *lx, double *ly, double *lz)
{

    double l = ll;

    double r = l*sqrt(2*(1+cos(q2)));
    double llx = r*sin(q1+0.5*q2);
    double lly = r*sin(q0);
    double llz = sqrt(r*r - llx*llx - lly*lly);

    *lx = llx;
    *ly = lly;
    *lz = llz;
}
