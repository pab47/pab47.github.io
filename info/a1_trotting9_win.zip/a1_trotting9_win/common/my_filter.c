#define nf 2 //filter order
// double curr_pos[2], curr_vel[2];

// Paste these lines in MATLAB
// format long
// Ns = 1000; N = 10; Wn = N/(Ns/2); order = 2;
//[B,A] = butter(order,Wn)


//N = 20
// double b[] = {0.003621681514929,   0.007243363029857,   0.003621681514929};
// double a[] = {1.000000000000000,  -1.822694925196308,   0.837181651256023};

//N=10
// double b[] = {0.000944691843840,   0.001889383687680,   0.000944691843840};
// double a[] = {1.000000000000000,  -1.911197067426073,   0.914975834801433};

//N=5
// double b[] = {1e-3*0.241359049041983,   1e-3*0.482718098083965,   1e-3*0.241359049041983};
// double a[] = {1.000000000000000,  -1.955578240315035,   0.956543676511203};

//N = 2
double b[]={0.155148423475699*1e-3,   0.310296846951399*1e-3,   0.155148423475699*1e-3};
double a[]={1.000000000000000,  -1.964460580205232,   0.965081173899135};

//N = 0.5
// double b[] = {0.098259168204820*1e-4,   0.196518336409640*1e-4,   0.098259168204820*1e-4};
// double a[] = {1.000000000000000,  -1.991114292201654,   0.991153595868935};


double acc_den[3][nf+1] = {0}; //saves raw observations for nf time steps
double acc_num[3][nf+1] = {0}; //saves filtered observations at nf time steps
double omega_den[3][nf+1] = {0}; //saves raw observations for nf time steps
double omega_num[3][nf+1] = {0}; //saves filtered observations at nf time steps
double rpy_den[3][nf+1] = {0}; //saves raw observations for nf time steps
double rpy_num[3][nf+1] = {0}; //saves filtered observations at nf time steps



void init_filter()
{
  // int i;
  // for (i=0;i<2;i++)
  // {
  //   curr_pos[i] = 0;
  //   curr_vel[i] = 0;
  // }
}

void my_filter(int motiontime,double quat[4], double omega[3], double linacc[3],
                  RobotState *modelstate)
{
  int i;
  double q0, q1, q2, q3, euler[3], dc[3][3]={0};
  q0 = quat[0];
  q1 = quat[1];
  q2 = quat[2];
  q3 = quat[3];
  sdquat2dc(q1, q2, q3, q0,dc); sdprinterr(stderr);
  sddc2ang(dc,&euler[0],&euler[1],&euler[2]); sdprinterr(stderr);

  // double ttime = motiontime*dtime;
  //printf("rpy from quat: %f %f %f \n",ex,ey,ez);


  double temp_acc[3] = {0};
  double temp_omega[3] = {0};
  double temp_rpy[3] = {0};

  //butterworth filter
  for (i=0;i<3;i++)
  {
  //get newest observation
  double acc_new = linacc[i];

  //update previous values
  acc_den[i][0] = acc_den[i][1]; //discard oldest values acc_den[i][0]
  acc_den[i][1] = acc_den[i][2];
  acc_den[i][2] = acc_new;

  acc_num[i][0] = acc_num[i][1]; //discard oldest values acc_num[i][0]
  acc_num[i][1] = acc_num[i][2];

 //update data at the current time
  //   a(1)*y(n) = b(1)*x(n) + b(2)*x(n-1) + ... + b(nb+1)*x(n-nb)
  //                         - a(2)*y(n-1) - ... - a(na+1)*y(n-na)
  acc_num[i][2] = b[0]*acc_den[i][2] + b[1]*acc_den[i][1] + b[2]*acc_den[i][0] - a[1]*acc_num[i][1] - a[2]*acc_num[i][0];
  acc_num[i][2] = (1/a[0])*acc_num[i][2];

  //save data and sending
  temp_acc[i] = acc_num[i][2];

  //work on omega
  double omega_new = omega[i];

  //update previous values
  omega_den[i][0] = omega_den[i][1]; //discard oldest values omega_den[i][0]
  omega_den[i][1] = omega_den[i][2];
  omega_den[i][2] = omega_new;

  omega_num[i][0] = omega_num[i][1]; //discard oldest values omega_num[i][0]
  omega_num[i][1] = omega_num[i][2];

  //update data at the current time
  //   a(1)*y(n) = b(1)*x(n) + b(2)*x(n-1) + ... + b(nb+1)*x(n-nb)
  //                         - a(2)*y(n-1) - ... - a(na+1)*y(n-na)
  omega_num[i][2] = b[0]*omega_den[i][2] + b[1]*omega_den[i][1] + b[2]*omega_den[i][0] - a[1]*omega_num[i][1] - a[2]*omega_num[i][0];
  omega_num[i][2] = (1/a[0])*omega_num[i][2];

  //save data and sending
  temp_omega[i] = omega_num[i][2];

  //
  double rpy_new = euler[i];

  //update previous values
  rpy_den[i][0] = rpy_den[i][1]; //discard oldest values rpy_den[i][0]
  rpy_den[i][1] = rpy_den[i][2];
  rpy_den[i][2] = rpy_new;

  rpy_num[i][0] = rpy_num[i][1]; //discard oldest values rpy_num[i][0]
  rpy_num[i][1] = rpy_num[i][2];

  //update data at the current time
  //   a(1)*y(n) = b(1)*x(n) + b(2)*x(n-1) + ... + b(nb+1)*x(n-nb)
  //                         - a(2)*y(n-1) - ... - a(na+1)*y(n-na)
  rpy_num[i][2] = b[0]*rpy_den[i][2] + b[1]*rpy_den[i][1] + b[2]*rpy_den[i][0] - a[1]*rpy_num[i][1] - a[2]*rpy_num[i][0];
  rpy_num[i][2] = (1/a[0])*rpy_num[i][2];

  //save data and sending
  temp_rpy[i] = rpy_num[i][2];

  }

  for (i=0;i<3;i++)
  {
    modelstate->imu.accelerometer[i] = temp_acc[i];
    modelstate->imu.gyroscope[i] = temp_omega[i];
    modelstate->imu.rpy[i] = temp_rpy[i];

    // linacc[i] = temp_acc[i];
    // omega[i] = temp_omega[i];
    // rpy[i] = temp_rpy;
  }
  // modelstate->est_bodyWorldPos.x = est_pos[0];
  // modelstate->est_bodyWorldPos.y = est_pos[1];
  // modelstate->est_bodyWorldPos.z = 0;
  // modelstate->est_bodyWorldVel.x = est_vel[0];
  // modelstate->est_bodyWorldVel.y = est_vel[1];
  // modelstate->est_bodyWorldVel.z = 0;
  // modelstate->est_accelerometer.x = linacc[0];
  // modelstate->est_accelerometer.y = linacc[1];
  // modelstate->est_accelerometer.z = 0;





}
