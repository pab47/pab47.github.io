
int use_linear_command = 0;

int fsm[4] = {0};
double t_fsm[4]={0};

double lx[4] = {0};
double ly[4] = {0};
double lz[4] = {0};

double tt_min[4] = {0};
double tt_max[4] = {0};
double llx_min[4] = {0};
double llx_max[4] = {0};
double lly_min[4] = {0};
double lly_max[4] = {0};
double llz_min[4] = {0};
double llz_max[4] = {0};

double ldotx[4] = {0};
double ldoty[4] = {0};
double ldotz[4] = {0};
double abs_ldotx[4] = {0};
double abs_ldoty[4] = {0};
double abs_ldotz[4] = {0};
double est_lx[4] = {0};
double est_ly[4] = {0};
double est_lz[4] = {0};
double est_ldotx[4] = {0};
double est_ldoty[4] = {0};
double est_ldotz[4] = {0};
double qarm_ref[narm] = {0};


int use_keyboard_input = 1;

//left side
double joystick_left_x = 0; //horizontal motion of rocker
double joystick_left_y = 0; //vertical motion of rocker
//right side
double joystick_right_x = 0; //horizontal motion of rocker
double joystick_right_y = 0; //vertical motion of rocker

int joystick_button_A = 0;
int joystick_button_B = 0;
int joystick_button_L1 = 0;
int joystick_button_L2 = 0;
int joystick_button_R1 = 0;
int joystick_button_R2 = 0;

int joystick_button_X = 0;
int joystick_button_Y = 0;
int joystick_button_up = 0;
int joystick_button_down = 0;
int joystick_button_left = 0;
int joystick_button_right = 0;
int joystick_button_start = 0;
double joystick_dXarm[3] ={0};
double joystick_dangdes = 0;
double joystick_dgripper = 0;
double joystick_arm_reset = 1;


double keyboard_dh = 0;
double keyboard_dtheta = 0;
double keyboard_domega = 0;
double keyboard_dvx = 0;
double keyboard_dvy = 0;
double keyboard_dth[narm-1] = {0}; //the gripper has only 1 input
double keyboard_dXarm[3] = {0};
double keyboard_dangdes = 0;
double keyboard_dgripper = 0;
double keyboard_reset = 1;
int flag_key[4] = {0};
#define key_none 0
#define key_stand 1
#define key_trot 2


double    x_ref = 0;
double    xdot_ref = 0;
double    y_ref = 0;
double    ydot_ref = 0;
double    z_ref = 0.275;
double    est_z = 0.275;
double    phi_ref = 0;
double    theta_ref = 0;
double    psi_ref = 0;
double    psidot_ref = 0;
double    t_step = 0.2;
double    hcl = 0.1;
double    est_vx = 0, est_vy = 0, est_vz = 0;
double    state_vx = 0, state_vy = 0, state_omega = 0;
double    tmp_state_vx = 0, tmp_state_vy = 0, tmp_state_omega = 0;
double    prev_est_vx = 0, prev_est_vy = 0, prev_est_vz = 0;

//double arm_xdes0 = 0.2739; //0.024+0.124+0.1259
//double arm_ydes0 = 0;
//double arm_zdes0 = 0.205; //0.077+0.128;
double arm_rdes0 = 0.25; //0.024+0.124+0.1259
double arm_thdes0 = 0;
double arm_zdes0 = 0.1; //0.077+0.128;
double arm_angdes0 = 0;

double arm_rdes = 0.25; //arm_rdes0; //0.024+0.124+0.1259
double arm_thdes = 0; //arm_thdes0;
double arm_zdes = 0.1; //arm_zdes0; //0.077+0.128;
double arm_angdes = 0;

double tmp_arm_rdes = 0.25; //arm_rdes;
double tmp_arm_thdes = 0; //arm_thdes;
double tmp_arm_zdes = 0.1; //arm_zdes;
double tmp_arm_angdes = 0;//arm_angdes;

double arm_grip_min = 200;
double arm_grip_max = 1200;
double arm_grip_step = 10;
double arm_grip_step2 = 100;
double arm_dgripper = 0.01;

double arm_gripper = 0; //0.5*(arm_grip_min + arm_grip_max);
double arm_gripper0 = 0;
double arm_gripper_count = 700;
double arm_gripper_count0 = 700;



double arm_drdt = 0.001;
double arm_dthdt = 0.01;
double arm_dzdt = 0.001;
double arm_dangdt = 0.01;

int arm_rate = 10;
double arm_drdes = 0.02;
double arm_dthdes = 0.1;
double arm_dzdes = 0.02;
double arm_dangdes = 0.05;


int    step_no = 0;
int    prev_step = 0;
int    points = 1;


double grf[4][3]={0};


int state_robot = 0;
#define state_free 0
#define state_trot 1
#define state_stand 2

#define fsm_free 0
#define fsm_free2trot 1
#define fsm_stance 2
#define fsm_swing 3
#define fsm_stand 4

double t_free = 1;
double t_free2trot = 1;
double t_delay = 0.5;

double lx_min = -0.5;
double lx_max = 0.5;
double ly_min = -0.2;
double ly_max = 0.2;
double lz_min = 0.0;
double lz_max = 0.35;


double vx_min = -0.5;
double vx_max = 0.5;
double vy_min = -0.2;
double vy_max = 0.2;


double z_ref_min = 0.15;
double z_ref_max = 0.35;
double dz = 0.025;
double dz_stand = 0.5; //speed to change height in stand mode
double dtheta_stand = 0.5;
// double vx_min = -2.0;
// double vx_max = 2.0;
// double vy_min = -1.0;
// double vy_max = 1.0;
double omega_min = -1.0;
double omega_max = 1.0;
double hcl_min = 0.05;
double hcl_max = 0.175;
double theta_min = -0.2;
double theta_max = 0.2;
double tstep_min = 0.2;
double tstep_max = 1;
//double init_fsm[] = {fsm_stance,fsm_stance,fsm_stance,fsm_stance};
double trot_fsm[] = {fsm_stance,fsm_swing,fsm_swing,fsm_stance};
//double stand_fsm[] = {fsm_stand,fsm_stand,fsm_stand,fsm_stand};


double dvx = 0.1;
double dvy = 0.05;
double domega = 0.1;
double dhcl = 0.025;
double dtheta = 0.05;
double dth = 0.1;
double dslide = 0.01;
