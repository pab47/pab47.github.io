void arm_fk2(double *xx, double *zz, double *aang,
            double q0, double q1, double q2, double q3,
            double l0, double l1, double l2, double l3, double beta)
{
      double r = l1*cos(beta-q1) + l2*cos(-q1-q2) + l3*cos(-q1-q2-q3);
      double z = l1*sin(beta-q1) + l2*sin(-q1-q2) + l3*sin(-q1-q2-q3) + l0;
      //double x = cos(q0)*xprime;
      //double y = sin(q0)*xprime;
      double ang = -q1-q2-q3;

      *xx = r;
      *zz = z;
      *aang = ang;
}

void arm_ik2(double q0,double *q1,double *q2,double *q3,
           double l0,double l1,double l2,double l3,double beta,
           double rdes,double zdes,double angdes)
{

  double r = rdes; //sqrt(xdes*xdes + ydes*ydes);
  double  q0des = q0; //atan(ydes/xdes);
  double  x1 = r - l3*cos(angdes);
  double  z1 = zdes - l3*sin(angdes) - l0;
  double  q2des = -beta + acos(  (x1*x1+z1*z1 - l1*l1 - l2*l2) / (2*l1*l2) );
  double  a11 = l1*cos(beta)+l2*cos(q2des);
  double  a12 = l1*sin(beta)-l2*sin(q2des);
  double  a21 = l1*sin(beta)-l2*sin(q2des);
  double  a22 = -(l1*cos(beta)+l2*cos(q2des));
  double  q1des = acos( (a22*x1 - a12*z1) / (a11*a22 - a21*a12) );
  double  q3des = -q1des-q2des-angdes;

  *q1 = q1des;
  *q2 = q2des;
  *q3 = q3des;
}

void generate_arm_traj2(int motiontime, double q_arm[narm],double base_quat[4])
{
  // double euler[3];
  // ram_quat2ang(quat,euler);
  // printf("%f %f %f \n",euler[0],euler[1],euler[2]);
  double body_ang[3]={0};
  double body_quat[4]={0};
  get_bodyAng(base_quat,body_ang,body_quat);
  double pitch = body_ang[1];
  //beta = 0.5*pi - math.atan(0.024/0.128)
  //beta = 0.5*pi - 0.1853
  double beta = 1.3854;

  double l0 = arm_l0;
  double l1 = arm_l1;
  double l2 = arm_l2;
  double l3 = arm_l3;
  double rdes = tmp_arm_rdes;
  //double ydes = tmp_arm_ydes;
  double q0des = tmp_arm_thdes; //is actually thetades
  double zdes = tmp_arm_zdes;


  double angdes = tmp_arm_angdes;
  double q1des, q2des, q3des;


  arm_ik2(q0des,&q1des,&q2des,&q3des,l0,l1,l2,l3,beta,rdes,zdes,angdes);
  //printf("%f %f %f \n",xdes,ydes,zdes);

  double r,z,ang;
  arm_fk2(&r,&z,&ang,q0des, q1des, q2des, q3des,l0,l1,l2,l3,beta);

  double error = sqrt( (r-rdes)*(r-rdes)+(z-zdes)*(z-zdes));

  //double error = 0; %  +(ang-angdes)*(ang-angdes)

  
  // if (motiontime%200 == 0 && 1)
  //   printf("error = %f \n", error);


  if (error < 0.01) //small error
  {
    q3des = -q1des-q2des-angdes-pitch; //changes the gripper orientation based on body pitch
    //flag_armIK_error = 0; //no error
    q_arm[0] = q0des;
    q_arm[1] = q1des;
    q_arm[2] = q2des;
    q_arm[3] = q3des;
    arm_rdes = tmp_arm_rdes;
    arm_thdes = tmp_arm_thdes;
    arm_zdes = tmp_arm_zdes;
    arm_angdes = tmp_arm_angdes;

    if (use_keyboard_input==1)
    {
      arm_rdes = keyboard_reset*arm_rdes + (1-keyboard_reset)*arm_rdes0;
      arm_thdes = keyboard_reset*arm_thdes + (1-keyboard_reset)*arm_thdes0;
      arm_zdes = keyboard_reset*arm_zdes + (1-keyboard_reset)*arm_zdes0;
      arm_angdes = keyboard_reset*arm_angdes + (1-keyboard_reset)*arm_angdes0;
      if (flag_mujoco==1)
        arm_gripper = keyboard_reset*arm_gripper + (1-keyboard_reset)*arm_gripper0;
      else
        arm_gripper_count = keyboard_reset*arm_gripper_count + (1-keyboard_reset)*arm_gripper_count0;
      keyboard_reset = 1;
    }
    else
    {
      arm_rdes = joystick_arm_reset*arm_rdes + (1-joystick_arm_reset)*arm_rdes0;
      arm_thdes = joystick_arm_reset*arm_thdes + (1-joystick_arm_reset)*arm_thdes0;
      arm_zdes = joystick_arm_reset*arm_zdes + (1-joystick_arm_reset)*arm_zdes0;
      arm_angdes = joystick_arm_reset*arm_angdes + (1-joystick_arm_reset)*arm_angdes0;
      //printf("%f %f %f \n",arm_xdes,arm_ydes,arm_zdes);
      joystick_arm_reset = 1;
    }

  }
  else
  {

    // if (flag_armIK_error==0)
    // {
    if (use_keyboard_input==1)
    {
      printf("IK error: Manipulator out of range \n");
    }
    else
    {
      if (motiontime%200 == 0)
        printf("IK error: Manipulator out of range \n");
    }
    //   flag_armIK_error = 1;
    // }
  }
    tmp_arm_rdes = arm_rdes;
    tmp_arm_thdes = arm_thdes;
    tmp_arm_zdes = arm_zdes;
    tmp_arm_angdes = arm_angdes;


}
