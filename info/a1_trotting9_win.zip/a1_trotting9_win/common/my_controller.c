// double setpt[nact]={0};
// int step_no = 0;
// int prev_step = 0;

//#include <sys/time.h>


#include "utility_matrix.c"
#include "control_params.h"
#include "get_bodyAng.c"
#include "get_bodyVel.c"
#include "get_Jac.c"
#include "inverse_kinematics.c"
#include "forward_kinematics2.c"
#include "nominal_height.c"
#include "set_command.c"
#include "set_command2.c"
#include "set_command_linear.c"
#include "set_command_fifth.c"
#include "nominal_forces03.c"
#include "nominal_forces12.c"
#include "get_ground_forces.c"
#include "keyboard_input.c"
#include "joystick_input.c"
#include "robot_behavior_check.c"
#include "state_machine.c"
#include "estimator.c"
#include "generate_cart_traj.c"
#include "generate_joint_traj.c"
#include "generate_arm_traj2.c"
#include "generate_torque.c"


void init_controller(int motiontime, double quat_act[4], double omega_act[3],
                     double q_act[nact], double u_act[nact],
                    double qarm_act[narm],double qarm_ref[narm])
{
  //initialize anything in the controller here.
  keyboard_input_initialize();
  joystick_input_initialize();
  generate_arm_traj2(motiontime,qarm_ref,quat_act);
  // printf("%f\n",57.29*qarm_ref[0]);
  // printf("%f\n",57.29*qarm_ref[1]);
  // printf("%f\n",57.29*qarm_ref[2]);
  // printf("%f\n",57.29*qarm_ref[3]);

}

void my_controller(int motiontime,
                   double quat_act[4], double omega_act[3], double linacc_act[3],
                   double q_act[nact], double u_act[nact], double tau[nact],
                  double Kp[nact],double Kd[nact],
                  double q_ref[nact], double u_ref[nact],double tauEst[nact],
                  uint16_t footForce[4],RobotState *modelstate, double qarm_act[narm],double qarm_ref[narm])
{
  int i,j,k;
  FILE *fid;

  //ram_display_int(&fsm[0],4,1,"fsm");
  // printf("********\n");
  // printf("%d %d %d %d \n ******\n",fsm[0],fsm[1],fsm[2],fsm[3]);


  double ttime = motiontime*dtime;
  //printf("%d \n",motiontime);
  // if ( (int)(ttime/dtime)%1000==0) //flag_debug
  //   {
  //     printf("hello \n");
  //   }

  if (use_keyboard_input)
    keyboard_input();
  else
    joystick_input(motiontime);

  //free/trot/stand
  robot_behavior_check();

  state_machine(ttime,quat_act,omega_act,q_act,u_act);
  //
  estimator(ttime,quat_act,omega_act,linacc_act,q_act,u_act,modelstate);
  // double filtered_acc[3]={modelstate->imu.accelerometer[0],
  //                         modelstate->imu.accelerometer[1],
  //                         modelstate->imu.accelerometer[2]};
  //estimator(ttime,quat_act,omega_act,filtered_acc,q_act,u_act);
  //
  generate_cart_traj(ttime);
  //
  generate_joint_traj(quat_act,q_ref,u_ref);
  //
  // generate_torque(ttime,tau,Kp,Kd,&modelstate);
  generate_torque(ttime,tau,Kp,Kd,quat_act,omega_act,q_ref,u_ref,q_act,u_act,modelstate);

  //
  if (state_robot == state_stand)
  {
    if (use_keyboard_input==1)
    {
      generate_arm_traj2(motiontime,qarm_ref,quat_act);
      if (flag_mujoco!=1)
      {
        fid = fopen("/home/pi/DynamixelSDK/python/tests/motor.txt","w");
        fprintf(fid,"%f\n",57.29*qarm_ref[0]);
        fprintf(fid,"%f\n",57.29*qarm_ref[1]);
        fprintf(fid,"%f\n",57.29*qarm_ref[2]);
        fprintf(fid,"%f\n",57.29*qarm_ref[3]);
        fprintf(fid,"%f\n",arm_gripper_count);
        fprintf(fid,"1\n");
        fclose(fid);
      }
    }
    else
    {
    if (motiontime%arm_rate==0)
      {
      generate_arm_traj2(motiontime,qarm_ref,quat_act);
      if (flag_mujoco!=1)
      {
        //fid = fopen("trotting8/arm.txt","w");
        fid = fopen("/home/pi/DynamixelSDK/python/tests/motor.txt","w");
        fprintf(fid,"%f\n",57.29*qarm_ref[0]);
        fprintf(fid,"%f\n",57.29*qarm_ref[1]);
        fprintf(fid,"%f\n",57.29*qarm_ref[2]);
        fprintf(fid,"%f\n",57.29*qarm_ref[3]);
        fprintf(fid,"%f\n",arm_gripper_count);
        fprintf(fid,"1\n");
        fclose(fid);
      }
      }
    }
  }
  //printf("%f %f %f %f %f",qarm_ref);

  if (use_keyboard_input) //call after generate_arm_traj.
    keyboard_input_cleanup();
  else
    joystick_input_cleanup(motiontime,qarm_ref);



  modelstate->step_no = step_no;
  modelstate->cmd_vx = xdot_ref;
  modelstate->cmd_vy = ydot_ref;
  modelstate->cmd_omega = psidot_ref;
  modelstate->cmd_hcl = hcl;
  modelstate->t_step = t_step;
  modelstate->cmd_theta = theta_ref;
  modelstate->cmd_phi = phi_ref;
  modelstate->cmd_z = z_ref;
  modelstate->est_vx = est_vx;
  modelstate->est_vy = est_vy;
  modelstate->est_vz = est_vz;
  modelstate->est_z = est_z;
  modelstate->state_vx = state_vx;
  modelstate->state_vy = state_vy;
  modelstate->state_omega = state_omega;
  for (i=0;i<4;i++)
  {
    modelstate->lx_ref[i] = lx[i];
    modelstate->ly_ref[i] = ly[i];
    modelstate->lz_ref[i] = lz[i];
    modelstate->ldotx_ref[i] = ldotx[i];
    modelstate->ldoty_ref[i] = ldoty[i];
    modelstate->ldotz_ref[i] = ldotz[i];
    modelstate->lx_act[i] = est_lx[i];
    modelstate->ly_act[i] = est_ly[i];
    modelstate->lz_act[i] = est_lz[i];
    modelstate->ldotx_act[i] = est_ldotx[i];
    modelstate->ldoty_act[i] = est_ldoty[i];
    modelstate->ldotz_act[i] = est_ldotz[i];
  }

  //time starts
  //struct timeval begin, end;
  //gettimeofday(&begin, 0);


  //timer ends
  //gettimeofday(&end, 0);
  //long seconds = end.tv_sec - begin.tv_sec;
  //long microseconds = end.tv_usec - begin.tv_usec;
  //double elapsed = seconds + microseconds*1e-6;
  //printf("Time measured: %.3f milli-seconds.\n", elapsed*1e3);




}
