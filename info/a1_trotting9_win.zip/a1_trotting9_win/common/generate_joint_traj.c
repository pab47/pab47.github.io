//X and Xdot are inputs
//q_ref and u_ref are outputs
// void generate_joint_traj(double quat_act[4],double X[12],double Xdot[12],
//                          double q_ref[12],double u_ref[12])
void generate_joint_traj(double quat_act[4],double q_ref[12],double u_ref[12])
{
    int i,j,k;

    // double body_ang[3], body_quat[4]={0};
    //printf("%f %f %f %f \n",quat_act[0],quat_act[1],quat_act[2],quat_act[3]);
    //get_bodyAng(quat_act,body_ang,body_quat);
    // double phi = body_ang[0];
    // double theta = body_ang[1];
    // double psi = body_ang[2];
    // double ang[3]={0};
    //
    // double phi = body_ang[0];
    // double theta = body_ang[1];
    // double psi = body_ang[2];

    for (i=0;i<nlegs;i++)
    {
        if (fsm[i]==fsm_free2trot || fsm[i]==fsm_swing ||
            fsm[i]==fsm_stance  || fsm[i] == fsm_stand)
        {
            double J[3][3]={0};
            double q_red[3]={0}, u_red[3]={0}, X_red[3]={0}, Xdot_red[3]={0};

            X_red[0] = lx[i]; X_red[1] = ly[i]; X_red[2] = lz[i];
            Xdot_red[0] = ldotx[i]; Xdot_red[1] = ldoty[i]; Xdot_red[2] = ldotz[i];
            inverse_kinematics(X_red,Xdot_red,q_red,u_red,i);

            j = 3*i;
            for (k=0;k<3;k++)
            {
              q_ref[j+k]=q_red[k];
              u_ref[j+k]=u_red[k];
            }

        }
    }

}
