
void nominal_forces12(double phi,double theta,double psi,
                      double q11,double q12,double q13,
                      double q21,double q22,double q23,
                      double fx0,double fy0,double fz0,
                      double taux0,double tauy0,double tauz0,
                      double F[6])
                     //double *ptr_F)
{
  // double a,double b,double c,
  // double l1,double l2,
  // double m,double g,
    double a = aa;
    double b=bb;
    double c =cc;
    double l1 = ll;
    double l2 = ll;
    double m = mass;

    int i;

    double A[6][6]={0};
    double B[6]={0};

    A[0][0]=-1;
      A[0][1]=-1;
      A[0][2]=0;
      A[0][3]=0;
      A[0][4]=0;
      A[0][5]=0;
      A[1][0]=0;
      A[1][1]=0;
      A[1][2]=-1;
      A[1][3]=-1;
      A[1][4]=0;
      A[1][5]=0;
      A[2][0]=0;
      A[2][1]=0;
      A[2][2]=0;
      A[2][3]=0;
      A[2][4]=-1;
      A[2][5]=-1;
      A[3][0]=0;
      A[3][1]=0;
      A[3][2]=l1*(cos(q12)*(sin(q11)*(cos(psi)*sin(phi) + cos(phi)*sin(psi)*sin(theta)) - cos(phi)*cos(q11)*cos(theta)) - sin(q12)*(sin(phi)*sin(psi) - cos(phi)*cos(psi)*sin(theta))) + l2*(cos(q13)*(cos(q12)*(sin(q11)*(cos(psi)*sin(phi) + cos(phi)*sin(psi)*sin(theta)) - cos(phi)*cos(q11)*cos(theta)) - sin(q12)*(sin(phi)*sin(psi) - cos(phi)*cos(psi)*sin(theta))) - sin(q13)*(sin(q12)*(sin(q11)*(cos(psi)*sin(phi) + cos(phi)*sin(psi)*sin(theta)) - cos(phi)*cos(q11)*cos(theta)) + cos(q12)*(sin(phi)*sin(psi) - cos(phi)*cos(psi)*sin(theta)))) + a*(sin(phi)*sin(psi) - cos(phi)*cos(psi)*sin(theta)) + b*(cos(psi)*sin(phi) + cos(phi)*sin(psi)*sin(theta)) + c*(cos(q11)*(cos(psi)*sin(phi) + cos(phi)*sin(psi)*sin(theta)) + cos(phi)*cos(theta)*sin(q11));
      A[3][3]=l1*(cos(q22)*(sin(q21)*(cos(psi)*sin(phi) + cos(phi)*sin(psi)*sin(theta)) - cos(phi)*cos(q21)*cos(theta)) - sin(q22)*(sin(phi)*sin(psi) - cos(phi)*cos(psi)*sin(theta))) + l2*(cos(q23)*(cos(q22)*(sin(q21)*(cos(psi)*sin(phi) + cos(phi)*sin(psi)*sin(theta)) - cos(phi)*cos(q21)*cos(theta)) - sin(q22)*(sin(phi)*sin(psi) - cos(phi)*cos(psi)*sin(theta))) - sin(q23)*(sin(q22)*(sin(q21)*(cos(psi)*sin(phi) + cos(phi)*sin(psi)*sin(theta)) - cos(phi)*cos(q21)*cos(theta)) + cos(q22)*(sin(phi)*sin(psi) - cos(phi)*cos(psi)*sin(theta)))) - a*(sin(phi)*sin(psi) - cos(phi)*cos(psi)*sin(theta)) - b*(cos(psi)*sin(phi) + cos(phi)*sin(psi)*sin(theta)) - c*(cos(q21)*(cos(psi)*sin(phi) + cos(phi)*sin(psi)*sin(theta)) + cos(phi)*cos(theta)*sin(q21));
      A[3][4]=- l1*(cos(q12)*(sin(q11)*(cos(phi)*cos(psi) - sin(phi)*sin(psi)*sin(theta)) + cos(q11)*cos(theta)*sin(phi)) - sin(q12)*(cos(phi)*sin(psi) + cos(psi)*sin(phi)*sin(theta))) - a*(cos(phi)*sin(psi) + cos(psi)*sin(phi)*sin(theta)) - b*(cos(phi)*cos(psi) - sin(phi)*sin(psi)*sin(theta)) - l2*(cos(q13)*(cos(q12)*(sin(q11)*(cos(phi)*cos(psi) - sin(phi)*sin(psi)*sin(theta)) + cos(q11)*cos(theta)*sin(phi)) - sin(q12)*(cos(phi)*sin(psi) + cos(psi)*sin(phi)*sin(theta))) - sin(q13)*(sin(q12)*(sin(q11)*(cos(phi)*cos(psi) - sin(phi)*sin(psi)*sin(theta)) + cos(q11)*cos(theta)*sin(phi)) + cos(q12)*(cos(phi)*sin(psi) + cos(psi)*sin(phi)*sin(theta)))) - c*(cos(q11)*(cos(phi)*cos(psi) - sin(phi)*sin(psi)*sin(theta)) - cos(theta)*sin(phi)*sin(q11));
      A[3][5]=a*(cos(phi)*sin(psi) + cos(psi)*sin(phi)*sin(theta)) - l1*(cos(q22)*(sin(q21)*(cos(phi)*cos(psi) - sin(phi)*sin(psi)*sin(theta)) + cos(q21)*cos(theta)*sin(phi)) - sin(q22)*(cos(phi)*sin(psi) + cos(psi)*sin(phi)*sin(theta))) + b*(cos(phi)*cos(psi) - sin(phi)*sin(psi)*sin(theta)) - l2*(cos(q23)*(cos(q22)*(sin(q21)*(cos(phi)*cos(psi) - sin(phi)*sin(psi)*sin(theta)) + cos(q21)*cos(theta)*sin(phi)) - sin(q22)*(cos(phi)*sin(psi) + cos(psi)*sin(phi)*sin(theta))) - sin(q23)*(sin(q22)*(sin(q21)*(cos(phi)*cos(psi) - sin(phi)*sin(psi)*sin(theta)) + cos(q21)*cos(theta)*sin(phi)) + cos(q22)*(cos(phi)*sin(psi) + cos(psi)*sin(phi)*sin(theta)))) + c*(cos(q21)*(cos(phi)*cos(psi) - sin(phi)*sin(psi)*sin(theta)) - cos(theta)*sin(phi)*sin(q21));
      A[4][0]=- l1*(cos(q12)*(sin(q11)*(cos(psi)*sin(phi) + cos(phi)*sin(psi)*sin(theta)) - cos(phi)*cos(q11)*cos(theta)) - sin(q12)*(sin(phi)*sin(psi) - cos(phi)*cos(psi)*sin(theta))) - l2*(cos(q13)*(cos(q12)*(sin(q11)*(cos(psi)*sin(phi) + cos(phi)*sin(psi)*sin(theta)) - cos(phi)*cos(q11)*cos(theta)) - sin(q12)*(sin(phi)*sin(psi) - cos(phi)*cos(psi)*sin(theta))) - sin(q13)*(sin(q12)*(sin(q11)*(cos(psi)*sin(phi) + cos(phi)*sin(psi)*sin(theta)) - cos(phi)*cos(q11)*cos(theta)) + cos(q12)*(sin(phi)*sin(psi) - cos(phi)*cos(psi)*sin(theta)))) - a*(sin(phi)*sin(psi) - cos(phi)*cos(psi)*sin(theta)) - b*(cos(psi)*sin(phi) + cos(phi)*sin(psi)*sin(theta)) - c*(cos(q11)*(cos(psi)*sin(phi) + cos(phi)*sin(psi)*sin(theta)) + cos(phi)*cos(theta)*sin(q11));
      A[4][1]=a*(sin(phi)*sin(psi) - cos(phi)*cos(psi)*sin(theta)) - l2*(cos(q23)*(cos(q22)*(sin(q21)*(cos(psi)*sin(phi) + cos(phi)*sin(psi)*sin(theta)) - cos(phi)*cos(q21)*cos(theta)) - sin(q22)*(sin(phi)*sin(psi) - cos(phi)*cos(psi)*sin(theta))) - sin(q23)*(sin(q22)*(sin(q21)*(cos(psi)*sin(phi) + cos(phi)*sin(psi)*sin(theta)) - cos(phi)*cos(q21)*cos(theta)) + cos(q22)*(sin(phi)*sin(psi) - cos(phi)*cos(psi)*sin(theta)))) - l1*(cos(q22)*(sin(q21)*(cos(psi)*sin(phi) + cos(phi)*sin(psi)*sin(theta)) - cos(phi)*cos(q21)*cos(theta)) - sin(q22)*(sin(phi)*sin(psi) - cos(phi)*cos(psi)*sin(theta))) + b*(cos(psi)*sin(phi) + cos(phi)*sin(psi)*sin(theta)) + c*(cos(q21)*(cos(psi)*sin(phi) + cos(phi)*sin(psi)*sin(theta)) + cos(phi)*cos(theta)*sin(q21));
      A[4][2]=0;
      A[4][3]=0;
      A[4][4]=c*(sin(q11)*sin(theta) - cos(q11)*cos(theta)*sin(psi)) - l2*(cos(q13)*(cos(q12)*(cos(q11)*sin(theta) + cos(theta)*sin(psi)*sin(q11)) + cos(psi)*cos(theta)*sin(q12)) - sin(q13)*(sin(q12)*(cos(q11)*sin(theta) + cos(theta)*sin(psi)*sin(q11)) - cos(psi)*cos(q12)*cos(theta))) - l1*(cos(q12)*(cos(q11)*sin(theta) + cos(theta)*sin(psi)*sin(q11)) + cos(psi)*cos(theta)*sin(q12)) + a*cos(psi)*cos(theta) - b*cos(theta)*sin(psi);
      A[4][5]=b*cos(theta)*sin(psi) - l2*(cos(q23)*(cos(q22)*(cos(q21)*sin(theta) + cos(theta)*sin(psi)*sin(q21)) + cos(psi)*cos(theta)*sin(q22)) - sin(q23)*(sin(q22)*(cos(q21)*sin(theta) + cos(theta)*sin(psi)*sin(q21)) - cos(psi)*cos(q22)*cos(theta))) - l1*(cos(q22)*(cos(q21)*sin(theta) + cos(theta)*sin(psi)*sin(q21)) + cos(psi)*cos(theta)*sin(q22)) - a*cos(psi)*cos(theta) - c*(sin(q21)*sin(theta) - cos(q21)*cos(theta)*sin(psi));
      A[5][0]=l1*(cos(q12)*(sin(q11)*(cos(phi)*cos(psi) - sin(phi)*sin(psi)*sin(theta)) + cos(q11)*cos(theta)*sin(phi)) - sin(q12)*(cos(phi)*sin(psi) + cos(psi)*sin(phi)*sin(theta))) + a*(cos(phi)*sin(psi) + cos(psi)*sin(phi)*sin(theta)) + b*(cos(phi)*cos(psi) - sin(phi)*sin(psi)*sin(theta)) + l2*(cos(q13)*(cos(q12)*(sin(q11)*(cos(phi)*cos(psi) - sin(phi)*sin(psi)*sin(theta)) + cos(q11)*cos(theta)*sin(phi)) - sin(q12)*(cos(phi)*sin(psi) + cos(psi)*sin(phi)*sin(theta))) - sin(q13)*(sin(q12)*(sin(q11)*(cos(phi)*cos(psi) - sin(phi)*sin(psi)*sin(theta)) + cos(q11)*cos(theta)*sin(phi)) + cos(q12)*(cos(phi)*sin(psi) + cos(psi)*sin(phi)*sin(theta)))) + c*(cos(q11)*(cos(phi)*cos(psi) - sin(phi)*sin(psi)*sin(theta)) - cos(theta)*sin(phi)*sin(q11));
      A[5][1]=l1*(cos(q22)*(sin(q21)*(cos(phi)*cos(psi) - sin(phi)*sin(psi)*sin(theta)) + cos(q21)*cos(theta)*sin(phi)) - sin(q22)*(cos(phi)*sin(psi) + cos(psi)*sin(phi)*sin(theta))) - a*(cos(phi)*sin(psi) + cos(psi)*sin(phi)*sin(theta)) - b*(cos(phi)*cos(psi) - sin(phi)*sin(psi)*sin(theta)) + l2*(cos(q23)*(cos(q22)*(sin(q21)*(cos(phi)*cos(psi) - sin(phi)*sin(psi)*sin(theta)) + cos(q21)*cos(theta)*sin(phi)) - sin(q22)*(cos(phi)*sin(psi) + cos(psi)*sin(phi)*sin(theta))) - sin(q23)*(sin(q22)*(sin(q21)*(cos(phi)*cos(psi) - sin(phi)*sin(psi)*sin(theta)) + cos(q21)*cos(theta)*sin(phi)) + cos(q22)*(cos(phi)*sin(psi) + cos(psi)*sin(phi)*sin(theta)))) - c*(cos(q21)*(cos(phi)*cos(psi) - sin(phi)*sin(psi)*sin(theta)) - cos(theta)*sin(phi)*sin(q21));
      A[5][2]=l2*(cos(q13)*(cos(q12)*(cos(q11)*sin(theta) + cos(theta)*sin(psi)*sin(q11)) + cos(psi)*cos(theta)*sin(q12)) - sin(q13)*(sin(q12)*(cos(q11)*sin(theta) + cos(theta)*sin(psi)*sin(q11)) - cos(psi)*cos(q12)*cos(theta))) - c*(sin(q11)*sin(theta) - cos(q11)*cos(theta)*sin(psi)) + l1*(cos(q12)*(cos(q11)*sin(theta) + cos(theta)*sin(psi)*sin(q11)) + cos(psi)*cos(theta)*sin(q12)) - a*cos(psi)*cos(theta) + b*cos(theta)*sin(psi);
      A[5][3]=c*(sin(q21)*sin(theta) - cos(q21)*cos(theta)*sin(psi)) + l2*(cos(q23)*(cos(q22)*(cos(q21)*sin(theta) + cos(theta)*sin(psi)*sin(q21)) + cos(psi)*cos(theta)*sin(q22)) - sin(q23)*(sin(q22)*(cos(q21)*sin(theta) + cos(theta)*sin(psi)*sin(q21)) - cos(psi)*cos(q22)*cos(theta))) + l1*(cos(q22)*(cos(q21)*sin(theta) + cos(theta)*sin(psi)*sin(q21)) + cos(psi)*cos(theta)*sin(q22)) + a*cos(psi)*cos(theta) - b*cos(theta)*sin(psi);
      A[5][4]=0;
      A[5][5]=0;

      B[0]=-fx0;
      B[1]=-fy0;
      B[2]=-g*m-fz0;
      B[3]=-taux0;
      B[4]=-tauy0;
      B[5]=-tauz0;


    // double F[6]={0};
    double eps = 1e-3;
    ram_weighted_inverse(&A[0][0],6,6,&B[0],6,&F[0],eps); //invert matrix

    // for (i=0;i<6;i++)
    //   *(ptr_F + i) = F[i];

    // fx0 = F[0];
    // fx3 = F[1];
    // fy0 = F[2];
    // fy3 = F[3];
    // fz0 = F[4];
    // fz3 = F[5];


}
