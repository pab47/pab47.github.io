double nominal_height(int leg_no)
{
    int i = leg_no;
    double a = aa;
    double b = bb;
    double c = cc;
    double phi = phi_ref;
    double theta = theta_ref;
    double psi = psi_ref;
    double z = z_ref;
    double lz;

    if (i==0)
        lz=z + a*(sin(phi)*sin(psi) - cos(phi)*cos(psi)*sin(theta)) - b*(cos(psi)*sin(phi) + cos(phi)*sin(psi)*sin(theta));

    if (i==1)
        lz=z + a*(sin(phi)*sin(psi) - cos(phi)*cos(psi)*sin(theta)) + b*(cos(psi)*sin(phi) + cos(phi)*sin(psi)*sin(theta));

    if (i==2)
        lz=z - a*(sin(phi)*sin(psi) - cos(phi)*cos(psi)*sin(theta)) - b*(cos(psi)*sin(phi) + cos(phi)*sin(psi)*sin(theta));

    if (i==3)
        lz=z - a*(sin(phi)*sin(psi) - cos(phi)*cos(psi)*sin(theta)) + b*(cos(psi)*sin(phi) + cos(phi)*sin(psi)*sin(theta));

    return lz;


  }
