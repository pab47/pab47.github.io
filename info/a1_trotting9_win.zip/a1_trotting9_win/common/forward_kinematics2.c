void forward_kinematics2(double q[3],double qdot[3],
                                    double X[3], double Xdot[3],  int leg_no)
{

    double q0=q[0];
    double q1=q[1];
    double q2=q[2];

    double l = ll;

    double r = l*sqrt(2*(1+cos(q2)));
    double llx = r*sin(q1+0.5*q2);
    double lly = r*sin(q0);
    double llz = sqrt(r*r - llx*llx - lly*lly);

    X[0] = llx; X[1] = lly; X[2] = llz;
    double J[3][3]={0};
    get_Jac(leg_no,q,J);
    ram_multMatVec(&J[0][0],3,3,&qdot[0],3,&Xdot[0]);

}
