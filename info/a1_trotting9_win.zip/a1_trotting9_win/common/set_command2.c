

double set_command2(double cmd_des, double cmd_curr, double cmd_min, double cmd_max, double cmd_rate)
{
  double cmd;
  double rate;

  // compute the rate of change of cmd based on current value and desired value.
  double temp_rate = fabs(cmd_des - cmd_curr);
  rate = ram_min(temp_rate,cmd_rate);

  //update cmd
   if (cmd_curr > cmd_des)
     cmd = cmd_curr - rate;
   else if (cmd_curr < cmd_des)
     cmd = cmd_curr + rate;
   else
     cmd = cmd_curr;

  //check bounds
  if (cmd > cmd_max)
    cmd = cmd_max;

  if (cmd < cmd_min)
    cmd = cmd_min;

  return cmd;

}
