void state_machine(double ttime,double quat_act[4],double omega_act[3],
                   double q_act[nact],double u_act[nact])
{
  int i,j;
  //transitions
  for (i=0;i<nlegs;i++)
  {
      if (ttime>=t_fsm[i]+t_free && fsm[i]==fsm_free)
      {
          fsm[i] = fsm_free2trot;
          t_fsm[i] = ttime; //time at transition
          double lz0 = nominal_height(i);

          // lz[i] = 0;
          // abs_ldotz[i] = fabs((lz0-lz[i])/t_free2trot);

          tt_min[i] = 0;
          tt_max[i] = t_free2trot;
          llx_min[i] = 0; llx_max[i]=0;
          lly_min[i] = 0; lly_max[i]=0;
          llz_min[i] = 0; llz_max[i]=lz0;

      }

      if (ttime>=t_fsm[i]+t_free2trot+t_delay && fsm[i]==fsm_free2trot)
      {

          t_fsm[i] = ttime;
          fsm[i] = trot_fsm[i];

          // if (fsm[i]==fsm_swing)
          //     abs_ldotz[i] = fabs(2*hcl/t_step);
          // else
          //     abs_ldotz[i] = 0;

          tt_min[i] = 0;
          tt_max[i] = t_step;
          double lz0 = nominal_height(i);
          if (fsm[i]==fsm_swing)
          {
            llz_min[i] = lz0; llz_max[i]=lz0-hcl;
          }
          else
          {
            llz_min[i] = lz0; llz_max[i]=lz0;
          }

       }

       if (flag_key[i] == key_trot && fsm[i]==fsm_stand)
       {

           t_fsm[i] = ttime;
           fsm[i] = trot_fsm[i];


           // if (fsm[i]==fsm_swing)
           //     abs_ldotz[i] = fabs(2*hcl/t_step);
           // else
           //     abs_ldotz[i] = 0;

           tt_min[i] = 0;
           tt_max[i] = t_step;
           double lz0 = nominal_height(i);
           if (fsm[i]==fsm_swing)
           {
             llz_min[i] = lz0; llz_max[i]=lz0-hcl;
           }
           else
           {
             llz_min[i] = lz0; llz_max[i]=lz0;
           }

        }



       if (ttime>=t_fsm[i]+t_step && fsm[i]==fsm_stance)
       {
            if (i==0 || i==1)
            {
                step_no += 1;
                points = 1;
            }

            t_fsm[i] = ttime; //time at transition

            if (flag_key[i]==key_stand) //temporary condition, can be key press based too.
            {
              fsm[i] = fsm_stand;
              abs_ldotz[i] = 0;
              abs_ldotx[i] = 0;
              abs_ldoty[i] = 0;
              flag_key[i] = key_none;
            }
            else
            {
            fsm[i] = fsm_swing;
            // abs_ldotz[i] = fabs( (2*hcl)/t_step);
            //abs_ldoty[i] = fabs(ydot_ref)+ aa*fabs(psidot_ref);
            // abs_ldotx[i] = fabs(xdot_ref); //rate per second (should be abs value)

            tt_min[i] = 0;
            tt_max[i] = t_step;
            double lz0 = nominal_height(i);
            llz_min[i] = lz0; llz_max[i]=lz0-hcl;
            llx_min[i] = 0.5*xdot_ref*t_step; llx_max[i]=-0.5*xdot_ref*t_step;
            lly_min[i] = -0.5*ydot_ref*t_step; lly_max[i]=0.5*ydot_ref*t_step;
            if (i==0 || i==1)
              { lly_min[i] -= 0.5*aa*psidot_ref*t_step;
                lly_max[i] += 0.5*aa*psidot_ref*t_step;}
            else
              { lly_min[i] += 0.5*aa*psidot_ref*t_step;
                lly_max[i] -= 0.5*aa*psidot_ref*t_step;}
            }

          }

        if (ttime>=t_fsm[i]+t_step && fsm[i]==fsm_swing)
        {
            t_fsm[i] = ttime;
            fsm[i] = fsm_stance;

            // abs_ldotz[i] = 0;
            //abs_ldoty[i] = fabs(ydot_ref)+aa*fabs(psidot_ref);
            // abs_ldotx[i] = fabs(xdot_ref); //rate per second (should be abs value)

            tt_min[i] = 0;
            tt_max[i] = t_step;
            double lz0 = nominal_height(i);
            llz_min[i] = lz0; llz_max[i]=lz0;

            llx_min[i] = -0.5*xdot_ref*t_step; llx_max[i]=0.5*xdot_ref*t_step;
            lly_min[i] = 0.5*ydot_ref*t_step; lly_max[i]= -0.5*ydot_ref*t_step;
            if (i==0 || i==1)
              { lly_min[i] += 0.5*aa*psidot_ref*t_step;
                lly_max[i] -= 0.5*aa*psidot_ref*t_step; }
            else
              { lly_min[i] -= 0.5*aa*psidot_ref*t_step;
                lly_max[i] += 0.5*aa*psidot_ref*t_step;}
        }

  }
}
