void joystick_input_initialize()
{

}

void joystick_input_cleanup(int motiontime,double qarm_ref[narm])
{

  if (state_robot == state_stand)
  {



    //if (motiontime%200==0 && 0)
    //{
    //printf("cart: %f %f %f %f \n",arm_xdes,arm_ydes,arm_zdes,arm_angdes);
    //printf("angs: %f %f %f %f \n", qarm_ref[0],qarm_ref[1],qarm_ref[2],qarm_ref[3]);
    //}


    joystick_dgripper = 0;


  }
}


void joystick_input(int motiontime)
{

 //state stand
  if (state_robot == state_stand)
  {


   if (motiontime%arm_rate==0)
   {
      joystick_dXarm[0] = joystick_left_y*arm_drdt;
      joystick_dXarm[1] = -joystick_left_x*arm_dthdt;
      joystick_dXarm[2] = joystick_right_y*arm_dzdt;
      joystick_dangdes = joystick_right_x*arm_dangdt;

      if (joystick_button_up == 1)
        joystick_dgripper = arm_grip_step;

       if (joystick_button_down == 1)
        joystick_dgripper = -arm_grip_step;


       tmp_arm_rdes += joystick_dXarm[0];
       tmp_arm_thdes += joystick_dXarm[1];
       tmp_arm_zdes += joystick_dXarm[2];
       tmp_arm_angdes += joystick_dangdes;

       //put gripper within bounds (last link)
       double temp_arm_gripper = arm_gripper_count + joystick_dgripper;
       if (temp_arm_gripper > arm_grip_max)
          arm_gripper_count = arm_grip_max;
       else if (temp_arm_gripper < arm_grip_min)
          arm_gripper_count = arm_grip_min;
        else
          arm_gripper_count = temp_arm_gripper;


   }



    if (joystick_button_R1 == 1)
      {
        //void set_command(double *cmd_des,double cmd_curr,double cmd_min,double cmd_max,double *cmd_rate)
        double theta_ref_ = theta_ref - dtheta;
        double dtheta_ref_ = dtheta_stand;
        set_command(&theta_ref_,theta_ref,theta_min,theta_max,&dtheta_ref_);
        theta_ref = theta_ref_;
      }

    if (joystick_button_R2 == 1)
      {
        double theta_ref_ = theta_ref + dtheta;
        double dtheta_ref_ = dtheta_stand;
        set_command(&theta_ref_,theta_ref,theta_min,theta_max,&dtheta_ref_);
        theta_ref = theta_ref_;
      }

    if (joystick_button_L1 == 1)
      {
        //void set_command(double *cmd_des,double cmd_curr,double cmd_min,double cmd_max,double *cmd_rate)
        double z_ = z_ref+dz;
        double dz_ = dz_stand;
        set_command(&z_,z_ref,z_ref_min,z_ref_max,&dz_);
        z_ref = z_;
      }

    if (joystick_button_L2 == 1)
      {
        double z_ = z_ref-dz;
        double dz_ = dz_stand;
        set_command(&z_,z_ref,z_ref_min,z_ref_max,&dz_);
        z_ref = z_;
      }
  }


//state trot
  if (state_robot==state_trot)
  {
    if (prev_step < step_no)
    {
    prev_step = step_no;

      double vx_ = joystick_left_y*vx_max;
      xdot_ref = set_command2(vx_,xdot_ref,vx_min,vx_max,dvx);
      //printf("xdot_ref = %f \n",xdot_ref);

      double vy_ = -joystick_right_x*vy_max;
      ydot_ref = set_command2(vy_,ydot_ref,vy_min,vy_max,dvy);
      //printf("%f \n",ydot_ref);

      double omega_ = -joystick_left_x*omega_max;
      psidot_ref = set_command2(omega_,psidot_ref,omega_min,omega_max,domega);
      //printf("%f \n",psidot_ref);

      double theta_ = joystick_right_y*theta_max;
      theta_ref = set_command2(theta_,theta_ref,theta_min,theta_max,dtheta);
      //theta_ref = joystick_right_y*theta_max;


      if (joystick_button_up == 1)
        {
          double z_ = z_ref+dz;
          z_ref = set_command2(z_,z_ref,z_ref_min,z_ref_max,dz);
        }

      if (joystick_button_down == 1)
        {
          double z_ = z_ref-dz;
          z_ref = set_command2(z_,z_ref,z_ref_min,z_ref_max,dz);
        }


    }
  }



}
