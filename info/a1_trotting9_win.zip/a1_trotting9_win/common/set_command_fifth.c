void set_command_fifth(double t, double t_min, double t_max,
                          double cmd_min,  double cmd_max, double *cmd, double *cmd_rate)
{

  if (t<=t_min)
    t = t_min;

  if (t>=t_max)
    t = t_max;

  //From derive_trajectory in master_notes.
  // ccode(A\b) gave these results
  //cmd = c0 + c1*t + c2*t^2 + c3*t^3 + c4*t^4 + c5*t^5;

  double t0 = t_min;
  double tf = t_max;
  double s0 = cmd_min;
  double sf = cmd_max;
  double v0 = 0;
  double vf = 0;
  double a0 = 0;
  double af = 0;

  double c0= 1.0/pow(t0-tf,5.0)*(s0*(tf*tf*tf*tf*tf)*2.0-sf*(t0*t0*t0*t0*t0)*2.0-s0*t0*(tf*tf*tf*tf)*1.0E+1+sf*(t0*t0*t0*t0)*tf*1.0E+1-t0*(tf*tf*tf*tf*tf)*v0*2.0+(t0*t0*t0*t0*t0)*tf*vf*2.0+a0*(t0*t0)*(tf*tf*tf*tf*tf)-a0*(t0*t0*t0)*(tf*tf*tf*tf)*2.0+a0*(t0*t0*t0*t0)*(tf*tf*tf)-af*(t0*t0*t0)*(tf*tf*tf*tf)+af*(t0*t0*t0*t0)*(tf*tf*tf)*2.0-af*(t0*t0*t0*t0*t0)*(tf*tf)+s0*(t0*t0)*(tf*tf*tf)*2.0E+1-sf*(t0*t0*t0)*(tf*tf)*2.0E+1+(t0*t0)*(tf*tf*tf*tf)*v0*1.0E+1-(t0*t0*t0)*(tf*tf*tf)*v0*8.0+(t0*t0*t0)*(tf*tf*tf)*vf*8.0-(t0*t0*t0*t0)*(tf*tf)*vf*1.0E+1)*(-1.0/2.0);
  double c1 = (1.0/pow(t0-tf,5.0)*((t0*t0*t0*t0*t0)*vf*2.0-(tf*tf*tf*tf*tf)*v0*2.0+a0*t0*(tf*tf*tf*tf*tf)*2.0-af*(t0*t0*t0*t0*t0)*tf*2.0+t0*(tf*tf*tf*tf)*v0*1.0E+1-(t0*t0*t0*t0)*tf*vf*1.0E+1-a0*(t0*t0)*(tf*tf*tf*tf)-a0*(t0*t0*t0)*(tf*tf*tf)*4.0+a0*(t0*t0*t0*t0)*(tf*tf)*3.0-af*(t0*t0)*(tf*tf*tf*tf)*3.0+af*(t0*t0*t0)*(tf*tf*tf)*4.0+af*(t0*t0*t0*t0)*(tf*tf)+s0*(t0*t0)*(tf*tf)*6.0E+1-sf*(t0*t0)*(tf*tf)*6.0E+1+(t0*t0)*(tf*tf*tf)*v0*1.6E+1-(t0*t0*t0)*(tf*tf)*v0*2.4E+1+(t0*t0)*(tf*tf*tf)*vf*2.4E+1-(t0*t0*t0)*(tf*tf)*vf*1.6E+1))/2.0;
  double c2 = 1.0/pow(t0-tf,5.0)*(a0*(tf*tf*tf*tf*tf)-af*(t0*t0*t0*t0*t0)+a0*t0*(tf*tf*tf*tf)*4.0+a0*(t0*t0*t0*t0)*tf*3.0-af*t0*(tf*tf*tf*tf)*3.0-af*(t0*t0*t0*t0)*tf*4.0+s0*t0*(tf*tf)*6.0E+1+s0*(t0*t0)*tf*6.0E+1-sf*t0*(tf*tf)*6.0E+1-sf*(t0*t0)*tf*6.0E+1+t0*(tf*tf*tf)*v0*3.6E+1-(t0*t0*t0)*tf*v0*2.4E+1+t0*(tf*tf*tf)*vf*2.4E+1-(t0*t0*t0)*tf*vf*3.6E+1-a0*(t0*t0)*(tf*tf*tf)*8.0+af*(t0*t0*t0)*(tf*tf)*8.0-(t0*t0)*(tf*tf)*v0*1.2E+1+(t0*t0)*(tf*tf)*vf*1.2E+1)*(-1.0/2.0);
  double c3 = (1.0/pow(t0*tf*-2.0+t0*t0+tf*tf,2.0)*(a0*(t0*t0*t0*t0)+a0*(tf*tf*tf*tf)*3.0-af*(t0*t0*t0*t0)*3.0-af*(tf*tf*tf*tf)+s0*(t0*t0)*2.0E+1+s0*(tf*tf)*2.0E+1-sf*(t0*t0)*2.0E+1-sf*(tf*tf)*2.0E+1-(t0*t0*t0)*v0*8.0-(t0*t0*t0)*vf*1.2E+1+(tf*tf*tf)*v0*1.2E+1+(tf*tf*tf)*vf*8.0+a0*(t0*t0*t0)*tf*4.0-af*t0*(tf*tf*tf)*4.0+t0*(tf*tf)*v0*2.8E+1-(t0*t0)*tf*v0*3.2E+1+t0*(tf*tf)*vf*3.2E+1-(t0*t0)*tf*vf*2.8E+1-a0*(t0*t0)*(tf*tf)*8.0+af*(t0*t0)*(tf*tf)*8.0+s0*t0*tf*8.0E+1-sf*t0*tf*8.0E+1))/(t0*2.0-tf*2.0);
  double c4 = ((s0*t0*3.0E+1+s0*tf*3.0E+1-sf*t0*3.0E+1-sf*tf*3.0E+1+a0*(t0*t0*t0)*2.0+a0*(tf*tf*tf)*3.0-af*(t0*t0*t0)*3.0-af*(tf*tf*tf)*2.0-(t0*t0)*v0*1.4E+1-(t0*t0)*vf*1.6E+1+(tf*tf)*v0*1.6E+1+(tf*tf)*vf*1.4E+1-a0*t0*(tf*tf)*4.0-a0*(t0*t0)*tf+af*t0*(tf*tf)+af*(t0*t0)*tf*4.0-t0*tf*v0*2.0+t0*tf*vf*2.0)*(-1.0/2.0))/((t0-tf)*((t0*t0)*(tf*tf)*6.0-t0*(tf*tf*tf)*4.0-(t0*t0*t0)*tf*4.0+t0*t0*t0*t0+tf*tf*tf*tf));
  double c5 = (1.0/pow(t0-tf,2.0)*(s0*1.2E+1-sf*1.2E+1-t0*v0*6.0-t0*vf*6.0+tf*v0*6.0+tf*vf*6.0+a0*(t0*t0)+a0*(tf*tf)-af*(t0*t0)-af*(tf*tf)-a0*t0*tf*2.0+af*t0*tf*2.0))/(t0*(tf*tf)*6.0-(t0*t0)*tf*6.0+(t0*t0*t0)*2.0-(tf*tf*tf)*2.0);


  *cmd = c0+c1*t+c2*(t*t)+c3*(t*t*t)+c4*(t*t*t*t)+c5*(t*t*t*t*t);
  *cmd_rate = c1+c2*t*2.0+c3*(t*t)*3.0+c4*(t*t*t)*4.0+c5*(t*t*t*t)*5.0;
  //*cmd_rate2 = c2*2.0+c3*t*6.0+c4*(t*t)*1.2E+1+c5*(t*t*t)*2.0E+1;


}
