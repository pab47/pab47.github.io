int robot_behavior_check()
{

if (fsm[0]==fsm_free && fsm[1]==fsm_free && fsm[2]==fsm_free && fsm[3]==fsm_free )
  state_robot = state_free;
else if ( fsm[0]==fsm_stand && fsm[1]==fsm_stand && fsm[2]==fsm_stand && fsm[3]==fsm_stand)
    state_robot = state_stand;
else if (
            (fsm[0]==fsm_swing && fsm[3]==fsm_swing && fsm[1] == fsm_stance && fsm[2] == fsm_stance)
                  ||
            (fsm[0]==fsm_stance && fsm[3]==fsm_stance && fsm[1] == fsm_swing && fsm[2] == fsm_swing)
        )
    state_robot = state_trot;

return 0;

}
