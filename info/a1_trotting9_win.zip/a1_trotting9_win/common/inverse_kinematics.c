void inverse_kinematics(double X[3],double Xdot[3],
                                    double q[3], double qdot[3],  int leg_no)
{

  double l = ll;

  double l_x = X[0];
  double l_y = X[1];
  double l_z = X[2];

  double r = sqrt(l_z*l_z+l_x*l_x+l_y*l_y);

  //hack to avoid singularity
  if (r<0.001)
    r = 0.001;

  double q0 = asin(l_y/r);
  double q1_temp1 = asin(l_x/r);
  double q2_temp = acos( (2*l*l-r*r)/ (2*l*l) );
  double q1_temp2 = 0.5*(pi-q2_temp);

  double  q1 =  q1_temp1+q1_temp2;
  double  q2 = -pi+q2_temp;

  q[0] = q0;
  q[1] = q1;
  q[2] = q2;

  double J[3][3]={0};
  get_Jac(leg_no,q,J);
  double Jinv[3][3]={0};
  ram_inverse(&J[0][0],3,3,&Jinv[0][0]);

  double XXdot[]={Xdot[0],Xdot[1],Xdot[2]};

  ram_multMatVec(&Jinv[0][0],3,3,&XXdot[0],3,&qdot[0]);


}
