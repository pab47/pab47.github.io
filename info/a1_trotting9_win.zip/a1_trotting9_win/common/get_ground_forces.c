void get_ground_forces(int leg_no, double base_quat[4],double imu_vel[3],
                       double q[nact],double u[nact], RobotState *modelstate)
{
  int i,j;

  //not needed
  double x=0; double x_ref=0;
  double y=0; double y_ref=0;
  double psi_ref = 0;

  // printf("%f %f %f %f \n",base_quat[0],base_quat[1],base_quat[2],base_quat[3]);
  // ram_quat_mjc2sd(base_quat);
  // printf("%f %f %f %f \n",base_quat[0],base_quat[1],base_quat[2],base_quat[3]);
  // printf("******\n");


  //double body_vel[3]={est_vx,est_vy,est_vz};
  // double ratio = 0.95;
  // est_vx  = ratio*prev_est_vx + (1-ratio)*est_vx;
  // est_vy  = ratio*prev_est_vy + (1-ratio)*est_vy;
  // est_vz  = ratio*prev_est_vz + (1-ratio)*est_vz;
  //
  // prev_est_vx = est_vx;
  // prev_est_vy = est_vy;
  // prev_est_vz = est_vz;


  // printf("%f %f %f \n",body_vel[0],body_vel[1],body_vel[2]);
  //printf("est_vel = %f %f %f \n",est_vx, est_vy, est_vz);
  // printf("********\n");

  //*********************************
  //uses mujoco values for velocity (comment out if not needed)
  // double body_vel[3]={0};
  // double base_vel[3]={modelstate->bodyWorldVel.x,modelstate->bodyWorldVel.y,modelstate->bodyWorldVel.z};
  // get_bodyVel(base_quat,base_vel,body_vel);
  // est_vx = body_vel[0];
  // est_vx = body_vel[1];
  // est_vz = body_vel[2];
  //*********************************

  double xdot = est_vx;
  double ydot = est_vy;
  double zdot = est_vz;
  //double z = modelstate->bodyWorldPos.z;
  double z = est_z;
  //printf("%f %f \n",z,est_z);
  //double z_ref = 0.5*(hF+hR);

  // double base_ang[3]={0};
  // ram_quat2ang(base_quat,base_ang);
  //printf("%f %f %f %f \n",base_quat[0],base_quat[1],base_quat[2],base_quat[3]);


  double body_ang[3]={0};
  double body_quat[4]={0};
  get_bodyAng(base_quat,body_ang,body_quat);
  // printf("%f %f %f \n",base_ang[0],base_ang[1],base_ang[2]);
  // printf("%f %f %f \n",body_ang[0],body_ang[1],body_ang[2]);
  // printf("*********\n");

  double phi = body_ang[0];
  double theta = body_ang[1];
  double psi = body_ang[2];
  // double phi = body_quat[0];
  // double theta = body_quat[1];
  // double psi = body_quat[2];
  // double phi = base_ang[0];
  // double theta = base_ang[1];
  // double psi = base_ang[2];

  double phidot = imu_vel[0];
  double thetadot = imu_vel[1];
  double psidot = imu_vel[2];

  // double phi_ref = 0;
  // double theta_ref = 0;
  // double psi_ref = 0;

  // double psidot_ref = 0;

  // double tmp_quat[4]={ 0.070621, -0.0705648, 0.703294, 0.7038543 };
  // get_bodyAng(tmp_quat,body_ang);
  // ram_display(&tmp_quat[0],4,1,"quat");
  // ram_display(&body_ang[0],3,1,"body_ang");
  // printf("****** \n");


  double q01,q02,q03;
  double q31,q32,q33;
  double q11,q12,q13;
  double q21,q22,q23;

  i = 0;
  q01 = q[i]; i+=1;
  q02 = q[i]; i+=1;
  q03 = q[i]; i+=1;
  q11 = q[i]; i+=1;
  q12 = q[i]; i+=1;
  q13 = q[i]; i+=1;
  q21 = q[i]; i+=1;
  q22 = q[i]; i+=1;
  q23 = q[i]; i+=1;
  q31 = q[i]; i+=1;
  q32 = q[i]; i+=1;
  q33 = q[i]; i+=1;



  double fx0 =0;
  double fy0 =0;
  double fz0 =0;
  double taux0  =0;
  double tauy0  =0;
  double tauz0  =0;

  double gain1= 100;
  double gain2 = 100;
  double gain_trans = 0;
  double gain3 = 100;
  double gain_trans_zdot = 1;
  double gain4 = 50; //250*0;
  double gain5 = 50; //250*0;
  double gain6 = 100;
  double gain_psi = 0;

  // printf("%f \n",xdot);
  fx0 = gain1*(-10*gain_trans*(x-x_ref)-0.5*(xdot-xdot_ref));
  fy0 = gain2*(-10*gain_trans*(y-y_ref)-0.5*(ydot-ydot_ref));
  fz0 = gain3*(-10*(z-z_ref)-0.5*gain_trans_zdot*zdot);
  taux0 = -gain4*(10*(phi-phi_ref)+0.5*phidot);
  tauy0 = -gain5*(10*(theta-theta_ref)+0.5*thetadot);
  tauz0 = -gain6*(10*gain_psi*(psi-psi_ref)+0.5*(psidot-psidot_ref));

   // printf("%f %f %f \n",phi,phi_ref,phidot);
   // printf("%f %f %f \n",theta,theta_ref,thetadot);
   //
   // printf("%f %f %f \n",base_ang[0],base_ang[1],base_ang[2]);
   // printf("%f %f %f \n",body_ang[0],body_ang[1],body_ang[2]);
   // printf("%f %f %f %f\n",base_quat[0],base_quat[1],base_quat[2],base_quat[3]);
   // printf("%f %f %f %f\n",body_quat[0],body_quat[1],body_quat[2],base_quat[3]);

  // printf("forces: %1.2f %1.2f %1.2f \n",fx0,fy0,fz0);
  // printf("torques: %1.2f %1.2f %1.2f \n",taux0,tauy0,tauz0);
  // printf("*******\n");


  if (leg_no==0)
  {
    double forces_FR_RL[6]={0};

    nominal_forces03( phi, theta, psi,
                   q01, q02, q03,q31, q32, q33,
                  fx0,fy0,fz0,taux0,tauy0,tauz0,
                   forces_FR_RL);

     grf[0][0] = forces_FR_RL[0];
     grf[0][1] = forces_FR_RL[2];
     grf[0][2] = forces_FR_RL[4];

     grf[3][0] = forces_FR_RL[1];
     grf[3][1] = forces_FR_RL[3];
     grf[3][2] = forces_FR_RL[5];

     i = 1;
     for (j=0;j<3;j++)
      grf[i][j] = 0;

     i = 2;
     for (j=0;j<3;j++)
       grf[i][j] = 0;

  }

 if (leg_no==1)
 {
   double forces_FL_RR[6]={0};

   nominal_forces12( phi, theta, psi,
                  q11, q12, q13,q21, q22, q23,
                 fx0,fy0,fz0,taux0,tauy0,tauz0,
                  forces_FL_RR);

      grf[1][0] = forces_FL_RR[0];
      grf[1][1] = forces_FL_RR[2];
      grf[1][2] = forces_FL_RR[4];

      grf[2][0] = forces_FL_RR[1];
      grf[2][1] = forces_FL_RR[3];
      grf[2][2] = forces_FL_RR[5];

      i = 0;
      for (j=0;j<3;j++)
       grf[i][j] = 0;

      i = 3;
      for (j=0;j<3;j++)
        grf[i][j] = 0;


  }







}
