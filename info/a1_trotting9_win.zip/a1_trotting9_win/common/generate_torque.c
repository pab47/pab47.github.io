void generate_torque(double ttime,double tau[nact],double Kp[nact],double Kd[nact],
                     double quat_act[4], double omega_act[3],
                     double q_ref[nact], double u_ref[nact],
                     double q_act[nact], double u_act[nact],
                     RobotState *modelstate)

{
  int i,j,k;

  for (i=0;i<nlegs;i++)
  {
    if (fsm[i]==fsm_free)
    {
        j = 3*i;
        for (k=0;k<3;k++)
          {tau[j+k]=0; Kp[j+k]=0; Kd[j+k]=0;}
    }

   if (fsm[i]==fsm_free2trot || fsm[i] == fsm_stand)
    {
      double F[3]={0};
      double q_red[3]={0}, tau_red[3]={0};
      double J[3][3]={0}; double JT[3][3]={0};

      //Use this for for static force based compensation
      F[0] = 0; F[1] = 0;
      F[2] = 0.25*mass*g;

      j = 3*i;

      for (k=0;k<3;k++)
        {q_red[k]=q_ref[j+k]; }
      get_Jac(i, q_red,J);
      ram_transpose(&J[0][0], 3, 3,  &JT[0][0]);
      ram_multMatVec(&JT[0][0],3,3,&F[0],3,&tau_red[0]);
      for (k=0;k<3;k++)
        tau_red[k] = -tau_red[k];

      j = 3*i;
      double gain_p = 50;
      double gain_v = 5; //sqrt(gain_p);


      for (k=0;k<3;k++)
        {
          tau[j+k]=tau_red[k];
          Kp[j+k]=gain_p;
          Kd[j+k]=gain_v;
        }

      //old code (not feedforward)
      // j = 3*i;
      // double gain_p = 50;
      // double gain_v = 5;
      // for (k=0;k<3;k++)
      //   {tau[j+k]=0; Kp[j+k]=gain_p; Kd[j+k]=gain_v;}
    }

    if (fsm[i]==fsm_swing)
     {

       j = 3*i;
       double gain_p = 25;
       double gain_v = 2;


       // tau[j]   =  (-gain_p*(q_act[j]-q_ref[j])-gain_v*(u_act[j]-u_ref[j]));
       // tau[j+1] =  (-gain_p*(q_act[j+1]-q_ref[j+1])-gain_v*(u_act[j+1]-u_ref[j+1]));
       // tau[j+2] =  (-gain_p*(q_act[j+2]-q_ref[j+2])-gain_v*(u_act[j+2]-u_ref[j+2]));

       for (k=0;k<3;k++)
       {
         tau[j+k]=0;
         Kp[j+k]=gain_p;
         Kd[j+k]=gain_v;
       }
         // {tau[j+k]=0; Kp[j+k]=gain_p; Kd[j+k]=gain_v;}


         // j = 3*i;
         // k = 0;
         // if (i==1)
         // {
         //  printf("In torque \n");
         // printf("%f %f %f \n", tau[j+k],q_ref[j+k]-q_act[j+k],u_ref[j+k]-u_act[j+k]); k+=1;
         // printf("%f %f %f \n", tau[j+k],q_ref[j+k]-q_act[j+k],u_ref[j+k]-u_act[j+k]); k+=1;
         // printf("%f %f %f \n", tau[j+k],q_ref[j+k]-q_act[j+k],u_ref[j+k]-u_act[j+k]); k+=1;
         // printf("*******\n");
         // }

     }

     if (fsm[i]==fsm_stance)
      {
        double F[3]={0};
        double q_red[3]={0}, tau_red[3]={0};
        double J[3][3]={0}; double JT[3][3]={0};

        //Use this for forces for DBFC (Ben Stephens)
        if (i==0 || i==1)
          get_ground_forces(i, quat_act,omega_act,q_ref,u_ref,modelstate);


        for (k=0;k<3;k++)
          F[k] = grf[i][k];

        //Use this for for static force based compensation
        // F[0] = 0; F[1] = 0;
        // F[2] = 0.5*mass*g;

        j = 3*i;

        for (k=0;k<3;k++)
          {q_red[k]=q_ref[j+k]; }
        get_Jac(i, q_red,J);
        ram_transpose(&J[0][0], 3, 3,  &JT[0][0]);
        ram_multMatVec(&JT[0][0],3,3,&F[0],3,&tau_red[0]);
        for (k=0;k<3;k++)
          tau_red[k] = -tau_red[k];


        j = 3*i;
        double gain_p = 50;
        double gain_v = 5; //sqrt(gain_p);


        // tau[j]   = tau_red[0] + (-gain_p*(q_act[j]-q_ref[j])-gain_v*(u_act[j]-u_ref[j]));
        // tau[j+1] = tau_red[1] + (-gain_p*(q_act[j+1]-q_ref[j+1])-gain_v*(u_act[j+1]-u_ref[j+1]));
        // tau[j+2] = tau_red[2] + (-gain_p*(q_act[j+2]-q_ref[j+2])-gain_v*(u_act[j+2]-u_ref[j+2]));

        // for (k=0;k<3;k++)
        //   { Kp[j+k]=0; Kd[j+k]=0;}
        for (k=0;k<3;k++)
          {
            tau[j+k]=tau_red[k];
            Kp[j+k]=gain_p;
            Kd[j+k]=gain_v;
          }
          //{tau[j+k]=0; Kp[j+k]=gain_p; Kd[j+k]=gain_v;}

      }

  }

}
