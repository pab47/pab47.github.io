[step_no,step_vx] = step_stats(step,[cmd_vx est_vx]);
[step_no,step_vy] = step_stats(step,[cmd_vy est_vy]);
[step_no,step_omega] = step_stats(step,[cmd_omega wz]);

fig_no = 1;
figure(fig_no); fig_no = fig_no + 1;
subplot(3,1,1);
stairs(step_no,step_vx(:,1),'k','Linewidth',1); hold on
stairs(step_no,step_vx(:,2),'r','Linewidth',2); hold on
ylabel('step vx');

subplot(3,1,2);
stairs(step_no,step_vy(:,1),'k','Linewidth',1); hold on
stairs(step_no,step_vy(:,2),'r','Linewidth',2); hold on
ylabel('step vy');

subplot(3,1,3);
stairs(step_no,step_omega(:,1),'k','Linewidth',1); hold on
stairs(step_no,step_omega(:,2),'r','Linewidth',2); hold on
ylabel('step omega');

function [step_x,step_y] = step_stats(x,y)
    step_x = unique(x);
    step_y = [];
    for i=1:length(step_x)
        rows = find(x==step_x(i));
        step_y = [step_y; [mean(y(rows,1)), mean(y(rows,2))]];
    end
end