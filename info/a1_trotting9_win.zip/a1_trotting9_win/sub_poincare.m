
fig_no = 1;
figure(fig_no); fig_no = fig_no + 1;
subplot(3,1,1);
stairs(step,cmd_vx,'k','Linewidth',1); hold on
stairs(step,state_vx,'r','Linewidth',2); hold on
legend('ref','act');
ylabel('step vx');

subplot(3,1,2);
stairs(step,cmd_vy,'k','Linewidth',1); hold on
stairs(step,state_vy,'r','Linewidth',2); hold on
legend('ref','act');
ylabel('step vy');

subplot(3,1,3);
stairs(step,cmd_omega,'k','Linewidth',1); hold on
stairs(step,state_omega,'r','Linewidth',2); hold on
legend('ref','act');
ylabel('step omega');