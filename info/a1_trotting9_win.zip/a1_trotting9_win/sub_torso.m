figure(fig_no); fig_no = fig_no + 1;

%x_var = step(index);
x_var = t(index);

subplot(3,1,1);
plot(x_var,eulerX(index),'k','Linewidth',1); hold on
plot(x_var,cmd_phi(index),'r','Linewidth',1); hold on
ylabel('eulerX');

subplot(3,1,2);
plot(x_var,eulerY(index),'k','Linewidth',1); hold on
plot(x_var,cmd_theta(index),'r','Linewidth',1); hold on
ylabel('eulerY');

subplot(3,1,3);
plot(x_var,est_z(index),'k','Linewidth',1); hold on
plot(x_var,cmd_z(index),'r','Linewidth',1); hold on
ylabel('height');

figure(fig_no); fig_no = fig_no + 1;

subplot(3,1,1);
plot(x_var,est_vx(index),'k','Linewidth',1); hold on
plot(x_var,state_vx(index),'b','Linewidth',1); hold on
plot(x_var,cmd_vx(index),'r','Linewidth',1); hold on
ylabel('vx');

subplot(3,1,2);
plot(x_var,est_vy(index),'k','Linewidth',1); hold on
plot(x_var,state_vy(index),'b','Linewidth',1); hold on
plot(x_var,cmd_vy(index),'r','Linewidth',1); hold on
ylabel('vy');

subplot(3,1,3);
plot(x_var,wz(index),'k','Linewidth',1); hold on
plot(x_var,state_omega(index),'b','Linewidth',1); hold on
plot(x_var,cmd_omega(index),'r','Linewidth',1); hold on
ylabel('psidot');


