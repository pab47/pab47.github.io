clc
clear all
close all

%%%%%% training 
% cmd_vx = [0,0,0];
% cmd_vx = [cmd_vx, 0:0.1:1.2];
% cmd_vx = [cmd_vx, 1.1:-0.1:0];
% cmd_vx = [cmd_vx, 0.05:0.1:1.25];
% cmd_vx = [cmd_vx, 1.15:-0.1:0.0];
% 
% cmd_vx = [cmd_vx, 0:0.2:1.2];
% cmd_vx = [cmd_vx, 1.2:-0.2:0];
% cmd_vx = [cmd_vx, 0.05:0.2:1.25];
% cmd_vx = [cmd_vx, 1.25:-0.2:0.0];

% testing
cmd_vx = [0,0,0];
cmd_vx = [cmd_vx, 0:0.1:0.8];
cmd_vx = [cmd_vx, 0.8:-0.1:0];
% cmd_vx = [cmd_vx, 0.05:0.1:1.25];
% cmd_vx = [cmd_vx, 1.15:-0.1:0.0];
% 
% cmd_vx = [cmd_vx, 0:0.2:1.2];
% cmd_vx = [cmd_vx, 1.2:-0.2:0];
% cmd_vx = [cmd_vx, 0.05:0.2:1.25];
% cmd_vx = [cmd_vx, 1.25:-0.2:0.0];



m = length(cmd_vx);
cmd = [cmd_vx' zeros(m,2)];

no_cmd = 3;
disp('double control[][no_cmd]={');
for i=1:m
    disp(['{',num2str(cmd(i,1)),',',num2str(cmd(i,2)),',',num2str(cmd(i,3)),'},'])
end
disp('};');

