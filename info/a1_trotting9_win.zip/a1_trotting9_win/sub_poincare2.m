[step_no,step_vx] = step_stats(step,[cmd_vx state_vx]);
[step_no,step_vy] = step_stats(step,[cmd_vy state_vy]);
[step_no,step_omega] = step_stats(step,[cmd_omega state_omega]);

%x_k+1, x_k, u_k
m = length(step_no)-1;
data_vx = [step_vx(2:m,2) step_vx(1:m-1,2)  step_vx(1:m-1,1)]; 



fig_no = 1;
figure(fig_no); fig_no = fig_no + 1;
subplot(3,1,1);
stairs(step_no,step_vx(:,1),'k','Linewidth',1); hold on
stairs(step_no,step_vx(:,2),'r','Linewidth',2); hold on
ylabel('step vx');
legend('cmd','state');

subplot(3,1,2);
stairs(step_no,step_vy(:,1),'k','Linewidth',1); hold on
stairs(step_no,step_vy(:,2),'r','Linewidth',2); hold on
ylabel('step vy');
legend('cmd','state');


subplot(3,1,3);
stairs(step_no,step_omega(:,1),'k','Linewidth',1); hold on
stairs(step_no,step_omega(:,2),'r','Linewidth',2); hold on
ylabel('step omega');
legend('cmd','state');

[step_no,step_vx2] = step_stats(step,[state_vx_ref state_vx]);

figure(fig_no); fig_no = fig_no + 1;
stairs(step_vx2(:,1),'k','Linewidth',1); hold on
stairs(step_vx2(2:end,2),'r','Linewidth',2); 
legend('ref','act');

function [step_x,step_y] = step_stats(x,y)
    step_x = unique(x);
    step_y = [];
    for i=1:length(step_x)
        rows = find(x==step_x(i));
        step_y = [step_y; [mean(y(rows,1)), mean(y(rows,2))]];
    end
end