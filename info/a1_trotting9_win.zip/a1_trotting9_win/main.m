
%common stuff starts *
clear all
clc
close all
filename = 'data.csv';
%filename = 'data_expt.csv';

Fontsize = 22;

T = readtable(filename); %check T.Properties
VariableNames = T.Properties.VariableNames;
Arr = table2array(T);
[m,n] = size(Arr);

%%%% Print Variable names
for i=1:length(VariableNames)
    disp([mat2str(i), ' = ',VariableNames{i}]);
end

for i=1:length(VariableNames)
    tmp_arr = Arr(:,i);
    eval([VariableNames{i},'=tmp_arr;']);
end

index_start = 2;
index_end = length(t);

%code to plot for a given time windows t_start to t_end
%code to plot for a given time windows t_start to t_end
t_start = 3;
t_end = t(end);
[index_start, ~] = get_time_indices(t,t_start,t_end);


index = index_start:index_end;
fig_no = 1;

%common stuff ends **

%sub_traj
%sub_traj2
sub_traj3
%sub_torso
%sub_steplevel
% sub_poincare
%sub_poincare2

%sub_estimate
%sub_waypoint
%sub_lowlevel
%sub_torso_filter
% sub_rpy_filter
% sub_omega_filter
% sub_acc_filter

%Ns = 1000; N = 5; Wn = N/(Ns/2); order = 2;
%[B,A] = butter(order,Wn)

function [index_start, index_end] = get_time_indices(t,t_start,t_end) 
    for i=1:length(t)
        if (t(i)< t_start)
            index_start = i;
        else
            break;
        end
    end

    index_end = [];
    if (nargout>2)
        for i=length(t):-1:1
            if (t(i) > t_end)
                index_end = i;
            else
                break;
            end
        end
    end
end

% function index = get_index(VariableNames,index_names)
%     index = [];
%     for i=1:length(index_names)
%         for j=1:length(VariableNames)
%             if (strcmp(index_names{i},VariableNames{j}))
%                 index = [index,j];
%                 break;
%             end
%         end
%     end
% end
