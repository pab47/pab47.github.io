
%%%%%%%%%%% qref %%%%%%%%%%%
% leg = 0;

all_legs = [1 2 3 4];
all_legs = [0 1];
all_legs = 0;

for i=1:length(all_legs)

    leg = all_legs(i);
    
    if (leg==0)
        figure(fig_no); fig_no = fig_no + 1;
        subplot(3,1,1)
        plot(t(index),lx_ref_FR(index),'r','Linewidth',2); hold on
        plot(t(index),lx_act_FR(index),'k','Linewidth',1); hold on
        legend('ref','act');
        ylabel('x');
        title('FR');

        subplot(3,1,2)
        plot(t(index),ly_ref_FR(index),'r','Linewidth',2); hold on
        plot(t(index),ly_act_FR(index),'k','Linewidth',1);
        legend('ref','act');
        ylabel('y');

        subplot(3,1,3)
        plot(t(index),lz_ref_FR(index),'r','Linewidth',2); hold on
        plot(t(index),lz_act_FR(index),'k','Linewidth',1);
        legend('ref','act');
        ylabel('z');

        figure(fig_no); fig_no = fig_no + 1;
        subplot(3,1,1)
        plot(t(index),ldotx_ref_FR(index),'r','Linewidth',2); hold on
        plot(t(index),ldotx_act_FR(index),'k','Linewidth',1); hold on
        legend('ref','act');
        ylabel('xdot');
         title('FR');

        subplot(3,1,2)
        plot(t(index),ldoty_ref_FR(index),'r','Linewidth',2); hold on
        plot(t(index),ldoty_act_FR(index),'k','Linewidth',1);
        legend('ref','act');
        ylabel('ydot');

        subplot(3,1,3)
        plot(t(index),ldotz_ref_FR(index),'r','Linewidth',2); hold on
        plot(t(index),ldotz_act_FR(index),'k','Linewidth',1);
        legend('ref','act');
        ylabel('zdot');

    end

    % leg = 1;

    if (leg==1)
         figure(fig_no); fig_no = fig_no + 1;
        subplot(3,1,1)
        plot(t(index),lx_ref_FL(index),'r','Linewidth',2); hold on
        plot(t(index),lx_act_FL(index),'k','Linewidth',1); hold on
        legend('ref','act');
        ylabel('x');
        title('FL');

        subplot(3,1,2)
        plot(t(index),ly_ref_FL(index),'r','Linewidth',2); hold on
        plot(t(index),ly_act_FL(index),'k','Linewidth',1);
        legend('ref','act');
        ylabel('y');

        subplot(3,1,3)
        plot(t(index),lz_ref_FL(index),'r','Linewidth',2); hold on
        plot(t(index),lz_act_FL(index),'k','Linewidth',1);
        legend('ref','act');
        ylabel('z');

        figure(fig_no); fig_no = fig_no + 1;
        subplot(3,1,1)
        plot(t(index),ldotx_ref_FL(index),'r','Linewidth',2); hold on
        plot(t(index),ldotx_act_FL(index),'k','Linewidth',1); hold on
        legend('ref','act');
        ylabel('xdot');
         title('FL');

        subplot(3,1,2)
        plot(t(index),ldoty_ref_FL(index),'r','Linewidth',2); hold on
        plot(t(index),ldoty_act_FL(index),'k','Linewidth',1);
        legend('ref','act');
        ylabel('ydot');

        subplot(3,1,3)
        plot(t(index),ldotz_ref_FL(index),'r','Linewidth',2); hold on
        plot(t(index),ldotz_act_FL(index),'k','Linewidth',1);
        legend('ref','act');
        ylabel('zdot');
    end

    % leg = 2;

    if (leg==2)
           figure(fig_no); fig_no = fig_no + 1;
        subplot(3,1,1)
        plot(t(index),lx_ref_RR(index),'r','Linewidth',2); hold on
        plot(t(index),lx_act_RR(index),'k','Linewidth',1); hold on
        legend('ref','act');
        ylabel('x');
        title('RR');

        subplot(3,1,2)
        plot(t(index),ly_ref_RR(index),'r','Linewidth',2); hold on
        plot(t(index),ly_act_RR(index),'k','Linewidth',1);
        legend('ref','act');
        ylabel('y');

        subplot(3,1,3)
        plot(t(index),lz_ref_RR(index),'r','Linewidth',2); hold on
        plot(t(index),lz_act_RR(index),'k','Linewidth',1);
        legend('ref','act');
        ylabel('z');

        figure(fig_no); fig_no = fig_no + 1;
        subplot(3,1,1)
        plot(t(index),ldotx_ref_RR(index),'r','Linewidth',2); hold on
        plot(t(index),ldotx_act_RR(index),'k','Linewidth',1); hold on
        legend('ref','act');
        ylabel('xdot');
         title('RR');

        subplot(3,1,2)
        plot(t(index),ldoty_ref_RR(index),'r','Linewidth',2); hold on
        plot(t(index),ldoty_act_RR(index),'k','Linewidth',1);
        legend('ref','act');
        ylabel('ydot');

        subplot(3,1,3)
        plot(t(index),ldotz_ref_RR(index),'r','Linewidth',2); hold on
        plot(t(index),ldotz_act_RR(index),'k','Linewidth',1);
        legend('ref','act');
        ylabel('zdot');

    end

    % leg = 3;

    if (leg==3)
           figure(fig_no); fig_no = fig_no + 1;
        subplot(3,1,1)
        plot(t(index),lx_ref_RL(index),'r','Linewidth',2); hold on
        plot(t(index),lx_act_RL(index),'k','Linewidth',1); hold on
        legend('ref','act');
        ylabel('x');
        title('RL');

        subplot(3,1,2)
        plot(t(index),ly_ref_RL(index),'r','Linewidth',2); hold on
        plot(t(index),ly_act_RL(index),'k','Linewidth',1);
        legend('ref','act');
        ylabel('y');

        subplot(3,1,3)
        plot(t(index),lz_ref_RL(index),'r','Linewidth',2); hold on
        plot(t(index),lz_act_RL(index),'k','Linewidth',1);
        legend('ref','act');
        ylabel('z');

        figure(fig_no); fig_no = fig_no + 1;
        subplot(3,1,1)
        plot(t(index),ldotx_ref_RL(index),'r','Linewidth',2); hold on
        plot(t(index),ldotx_act_RL(index),'k','Linewidth',1); hold on
        legend('ref','act');
        ylabel('xdot');
         title('RL');

        subplot(3,1,2)
        plot(t(index),ldoty_ref_RL(index),'r','Linewidth',2); hold on
        plot(t(index),ldoty_act_RL(index),'k','Linewidth',1);
        legend('ref','act');
        ylabel('ydot');

        subplot(3,1,3)
        plot(t(index),ldotz_ref_RL(index),'r','Linewidth',2); hold on
        plot(t(index),ldotz_act_RL(index),'k','Linewidth',1);
        legend('ref','act');
        ylabel('zdot');

    end
end


