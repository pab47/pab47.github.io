void get_state(int motiontime, const LowState *state, double quat[4], double omega[3],
             double linacc[3],double q_act[nact],double u_act[nact],uint16_t footForce[4],
             double qarm_act[narm],const LowState *armstate)
{
    int i;

    for (i=0;i<4;i++)
      quat[i]= state->imu.quaternion[i];

    for (i=0;i<3;i++)
      omega[i]= state->imu.gyroscope[i];

    for (i=0;i<3;i++)
      linacc[i]= state->imu.accelerometer[i];


    for (i=0;i<nact;i++)
    {
      q_act[i] = state->motorState[i].q ;
      u_act[i] = state->motorState[i].dq ;
    }

    for (i=0;i<narm;i++)
    {
      qarm_act[i] = armstate->motorState[i].q ;
    }

    for (i=0;i<4;i++)
    {
      footForce[i] = state->footForce[i];
    }

    //printf("  %f %f %f %f\n",state->imu.rpy[0],state->imu.rpy[1],omega[0],omega[1]);

}
