qref = 1;
uref = 0;
q = 1;
u = 0;

%%%%%%%%%%% qref %%%%%%%%%%%
if (qref==1)
figure(fig_no); fig_no = fig_no + 1;
subplot(2,1,1)
plot(t(index),qref_FR_hip(index),'r','Linewidth',2); hold on
plot(t(index),qref_RL_hip(index),'b-.','Linewidth',2);
legend('FR','RL');
ylabel('hip');
title('qref')
subplot(2,1,2)
plot(t(index),qref_FL_hip(index),'r','Linewidth',2); hold on
plot(t(index),qref_RR_hip(index),'b-.','Linewidth',2);
legend('FL','RR');
ylabel('hip');

figure(fig_no); fig_no = fig_no + 1;
subplot(2,1,1)
plot(t(index),qref_FR_thigh(index),'r','Linewidth',2); hold on
plot(t(index),qref_RL_thigh(index),'b-.','Linewidth',2);
legend('FR','RL');
ylabel('thigh');
title('qref')
subplot(2,1,2)
plot(t(index),qref_FL_thigh(index),'r','Linewidth',2); hold on
plot(t(index),qref_RR_thigh(index),'b-.','Linewidth',2);
legend('FL','RR');
ylabel('thigh');


figure(fig_no); fig_no = fig_no + 1;
subplot(2,1,1)
plot(t(index),qref_FR_calf(index),'r','Linewidth',2); hold on
plot(t(index),qref_RL_calf(index),'b-.','Linewidth',2);
legend('FR','RL');
ylabel('calf');
title('qref')
subplot(2,1,2)
plot(t(index),qref_FL_calf(index),'r','Linewidth',2); hold on
plot(t(index),qref_RR_calf(index),'b-.','Linewidth',2);
legend('FL','RR');
ylabel('calf');
end

%%%%%%%%%%%% uref %%%%%%%%%%%%
if (uref==1)
title('uref')
figure(fig_no); fig_no = fig_no + 1;
subplot(2,1,1)
plot(t(index),uref_FR_hip(index),'r','Linewidth',2); hold on
plot(t(index),uref_RL_hip(index),'b-.','Linewidth',2);
legend('FR','RL');
ylabel('hip');
title('uref')
subplot(2,1,2)
plot(t(index),uref_FL_hip(index),'r','Linewidth',2); hold on
plot(t(index),uref_RR_hip(index),'b-.','Linewidth',2);
legend('FL','RR');
ylabel('hip');

figure(fig_no); fig_no = fig_no + 1;
subplot(2,1,1)
plot(t(index),uref_FR_thigh(index),'r','Linewidth',2); hold on
plot(t(index),uref_RL_thigh(index),'b-.','Linewidth',2);
legend('FR','RL');
ylabel('thigh');
title('uref')
subplot(2,1,2)
plot(t(index),uref_FL_thigh(index),'r','Linewidth',2); hold on
plot(t(index),uref_RR_thigh(index),'b-.','Linewidth',2);
legend('FL','RR');
ylabel('thigh');


figure(fig_no); fig_no = fig_no + 1;
subplot(2,1,1)
plot(t(index),uref_FR_calf(index),'r','Linewidth',2); hold on
plot(t(index),uref_RL_calf(index),'b-.','Linewidth',2);
legend('FR','RL');
ylabel('calf');
title('uref')
subplot(2,1,2)
plot(t(index),uref_FL_calf(index),'r','Linewidth',2); hold on
plot(t(index),uref_RR_calf(index),'b-.','Linewidth',2);
legend('FL','RR');
ylabel('calf');
end

%%%%%%%%%%%%%%%%%% q %%%%%%%%%%
if (q==1)
title('q')
figure(fig_no); fig_no = fig_no + 1;
subplot(2,1,1)
plot(t(index),q_FR_hip(index),'r','Linewidth',2); hold on
plot(t(index),q_RL_hip(index),'b-.','Linewidth',2);
legend('FR','RL');
ylabel('hip');
title('q')
subplot(2,1,2)
plot(t(index),q_FL_hip(index),'r','Linewidth',2); hold on
plot(t(index),q_RR_hip(index),'b-.','Linewidth',2);
legend('FL','RR');
ylabel('hip');

figure(fig_no); fig_no = fig_no + 1;
subplot(2,1,1)
plot(t(index),q_FR_thigh(index),'r','Linewidth',2); hold on
plot(t(index),q_RL_thigh(index),'b-.','Linewidth',2);
legend('FR','RL');
ylabel('thigh');
title('q')
subplot(2,1,2)
plot(t(index),q_FL_thigh(index),'r','Linewidth',2); hold on
plot(t(index),q_RR_thigh(index),'b-.','Linewidth',2);
legend('FL','RR');
ylabel('thigh');


figure(fig_no); fig_no = fig_no + 1;
subplot(2,1,1)
plot(t(index),q_FR_calf(index),'r','Linewidth',2); hold on
plot(t(index),q_RL_calf(index),'b-.','Linewidth',2);
legend('FR','RL');
ylabel('calf');
title('q')
subplot(2,1,2)
plot(t(index),q_FL_calf(index),'r','Linewidth',2); hold on
plot(t(index),q_RR_calf(index),'b-.','Linewidth',2);
legend('FL','RR');
ylabel('calf');
end

%%%%%%%%%%%% u %%%%%%%%%%%%
if (u==1)
title('u')
figure(fig_no); fig_no = fig_no + 1;
subplot(2,1,1)
plot(t(index),u_FR_hip(index),'r','Linewidth',2); hold on
plot(t(index),u_RL_hip(index),'b-.','Linewidth',2);
legend('FR','RL');
ylabel('hip');
title('u')
subplot(2,1,2)
plot(t(index),u_FL_hip(index),'r','Linewidth',2); hold on
plot(t(index),u_RR_hip(index),'b-.','Linewidth',2);
legend('FL','RR');
ylabel('hip');

figure(fig_no); fig_no = fig_no + 1;
subplot(2,1,1)
plot(t(index),u_FR_thigh(index),'r','Linewidth',2); hold on
plot(t(index),u_RL_thigh(index),'b-.','Linewidth',2);
legend('FR','RL');
ylabel('thigh');
title('u')
subplot(2,1,2)
plot(t(index),u_FL_thigh(index),'r','Linewidth',2); hold on
plot(t(index),u_RR_thigh(index),'b-.','Linewidth',2);
legend('FL','RR');
ylabel('thigh');


figure(fig_no); fig_no = fig_no + 1;
subplot(2,1,1)
plot(t(index),u_FR_calf(index),'r','Linewidth',2); hold on
plot(t(index),u_RL_calf(index),'b-.','Linewidth',2);
legend('FR','RL');
ylabel('calf');
title('u')
subplot(2,1,2)
plot(t(index),u_FL_calf(index),'r','Linewidth',2); hold on
plot(t(index),u_RR_calf(index),'b-.','Linewidth',2);
legend('FL','RR');
ylabel('calf');
end
