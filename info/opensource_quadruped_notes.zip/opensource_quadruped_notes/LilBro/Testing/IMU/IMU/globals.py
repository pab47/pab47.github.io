def initialize():
    global rollImu
    rollImu = 1
    global pitchImu
    pitchImu = 2
