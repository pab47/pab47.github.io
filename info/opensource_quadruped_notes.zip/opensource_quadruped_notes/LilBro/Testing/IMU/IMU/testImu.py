from lib import imuClass
import globals 
import threading 
import time

globals.initialize()

imuTest = imuClass.imu()

imuThrd = threading.Thread(target=imuTest.imuData)
imuThrd.daemon = True 
imuThrd.start()

while True:
    print(globals.rollImu)




