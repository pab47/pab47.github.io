def initialize():
    global reqState
    reqState = 1
    global mode
    mode = 0

    global modeStat 
    modeStat = 0

    global dataOn
    dataOn = 0
    global startTime
    startTime = 0

    global sweepOn
    sweepOn = 0

    global gainInc
    gainInc = 0

    global armed
    armed = 0

    global error
    error = 0

    global modeStatus
    modeStatus = 1
    
    global modeNum
    modeNum = 3

    global decMode
    decMode = 4

    global l1
    l1 = 0.1

    global l2
    l2 = 0.22

