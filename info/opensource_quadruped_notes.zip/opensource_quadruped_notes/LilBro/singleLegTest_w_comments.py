import time as time
import os, struct, array
from fcntl import ioctl
import robot
import math
import numpy as np
import odrive
import globals
import sys
import threading
import leds
import matplotlib.pyplot as plt

print('Finding drivers...')

globals.initialize()
lilbro = robot.robot()

my_driver = odrive.find_any('usb','388937803437') #the big number is specific to the drive

# This function, along with getPath_Trot (used below), give the foot trajectory
lilbro.setFootTrajectory(0.165,0.135/0.165,15,0.4) #maximum length of virtual link, %clearance, sweep angle, duration

# This should = 1 if you want to plot positions of motors for the walking foot trajectory
plotOn = 1

#angle for sweep from -pi/6 to pi/6 with 15 points 
sweepAngle = np.linspace(-(math.pi/6),(math.pi/6),15)

alpha1 = []
legParms = []

theta1 = []
theta2 = []

#length of upper/lower leg and virtual leg (imaginary link from hip to foot)
l1 = 0.1
l2 = 0.22 
lmf = 0.17

# These are the gains to tune for positon control. These should not be changed unless you understand what each of them does. Refer to odrive documentation.
posGain = 85
velGain = 0.00055
velIntGain = 0.5*100*velGain

lilbro.setPGain(my_driver,posGain)
lilbro.setVelGain(my_driver,velGain)
lilbro.setVelIntGain(my_driver,velIntGain)

# These numbers are the offset for each motor from the vertical. This is used to symmetrize all the legs. [driver1-->driver4]
offset = [31,18,64.5,40.5,61,14.5,80,56]


#Set motors to closed loop 
# 1 - idle 
# 2 - closed looop 
my_driver.axis0.requested_state = 8
my_driver.axis1.requested_state = 8


#------------------------first position (standing)-----------------------------------
my_driver.axis0.controller.move_to_pos(lilbro.toMotor(lilbro.toCount(-50+offset[0])))
my_driver.axis1.controller.move_to_pos(lilbro.toMotor(lilbro.toCount(-50+offset[1])))
print("standing position")
time.sleep(3)


#------------------------sweep motion-------------------------------------------------

print("starting sweep")
for j in range(len(sweepAngle)-1):
    alpha2 = math.acos((((l1**2)+(lmf**2)-(l2**2))/(2*l1*lmf)))
    alpha1.append(sweepAngle[j] - math.pi/2)
    legParms.append(lilbro.symmetric(alpha1[j],alpha2,l1,l2))
    theta1.append(math.atan2(-legParms[j][1][0],legParms[j][1][1]))
    theta2.append(math.atan2(legParms[j][2][0],legParms[j][2][1]))

    posOne = lilbro.toMotor(lilbro.toCount(math.degrees(theta1[j])+offset[0]))
    posTwo = lilbro.toMotor(lilbro.toCount(math.degrees(theta2[j])+offset[1]))   

    my_driver.axis0.controller.move_to_pos(posOne)
    my_driver.axis1.controller.move_to_pos(posTwo)   
    time.sleep(0.05)

time.sleep(2)

print("starting trot")
#---------------trotting path from robot class------------------------------------------
footTraj = lilbro.getPath_Trot()

numOfPoints = 12

n = 0
start = time.time()
trajTime = []
motor1 = []
motor2 = []

while(n < 3):

    for i in range(numOfPoints):
        posOne = lilbro.toMotor(lilbro.toCount(-math.degrees(footTraj[1][0][i])+offset[0]))
        posTwo = lilbro.toMotor(lilbro.toCount(-math.degrees(footTraj[0][0][i])+offset[1]))   
        
        my_driver.axis0.controller.move_to_pos(posOne)
        my_driver.axis1.controller.move_to_pos(posTwo)
        
        trajTime.append(time.time() - start)
        motor1.append(lilbro.toLeg(lilbro.toDeg(my_driver.axis0.encoder.pos_estimate)))
        motor2.append(lilbro.toLeg(lilbro.toDeg(my_driver.axis1.encoder.pos_estimate)))
        
        time.sleep(0.05)
    n = n + 1

np.savetxt('Trajectory positions vs. Time.txt',np.c_[trajTime,motor1,motor2],fmt="%.3f %.3f %.3f")

if(plotOn == 1):
    fig, (ax1,ax2) = plt.subplots(1,2)
    ax1.plot(trajTime,motor1)
    ax2.plot(trajTime,motor2)

    ax1.set(xlabel = 'Time (s)', ylabel = 'Position (degrees)', title = 'Motor1 Angle vs. Time')
    ax2.set(xlabel = 'Time (s)', ylabel = 'Position (degrees)', title = 'Motor2 Angle vs. Time')
    
    plt.show()

my_driver.axis0.requested_state = 1
my_driver.axis1.requested_state = 1


