function InvPendAnimation( t, y,Save )
%Animation of Inverted Pendulum 

fps = 25;
tspan = linspace(t(1),t(end),fps*(t(end) - t(1)));
theta = interp1(t, y(:,2),tspan);
x_cart = interp1(t, y(:,1),tspan);
TimeDelay = 0.1;
L = 1;


if (Save == 1)
    mov = VideoWriter('InvertedPendulum.avi');
    open(mov);
end

for i = 1:length(theta)
    
    clf
   
    Pend_Pos_x = x_cart(i) + L*cos(pi/2 - theta(i));
    Pend_Pos_y = L*sin(pi/2 - theta(i));
    Cart_Pos_x = x_cart(i);
    

    

    % Cart Position
    plot3(Cart_Pos_x,0,0,'o','MarkerSize',10,'MarkerFaceColor','black');
    
    % Line between cart and tip of pendulum
    line([Cart_Pos_x Pend_Pos_x], [0 Pend_Pos_y], [0 0], 'LineWidth',5,'Color','red');
    axis('equal');
    xlim([-3 3]);
    ylim([-0.5 2]);
    zlim([-3 3]);
    view(2);
    
    if(Save == 1)
        axis off
        set(gcf,'Color',[1,1,1]);
        currFrame = getframe;
        writeVideo(mov,currFrame)
    end
    
    
    pause(TimeDelay);
     
end

if(Save == 1)
    close(mov);
end

end

