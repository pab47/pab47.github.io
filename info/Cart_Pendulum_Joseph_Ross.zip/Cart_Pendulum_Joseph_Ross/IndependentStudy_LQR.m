%% Independent Study - Inverted Pendulum - LQR
clear all; clf; close all; clc;

%% Physical Constants
Mp = 0.226796; Mc = 0.1; L = 0.0762; mu = 0.1; g = 9.81; I = Mp*L^2;

%% Stuff for Simulations/Animations
t = 0:0.01:4;
u = 2*ones(size(t));

%% State-Space Matricies
A = [0 1 0 0;0 -((I+Mp*L^2)*mu)/(I*(Mc+Mp)+Mc*Mp*L^2) ...
    (Mp^2*g*L^2)/(I*(Mc+Mp)+Mc*Mp*L^2) 0; 0 0 0 1; ...
    0 -(Mp*L*mu)/(I*(Mc+Mp)+Mc*Mp*L^2) (Mp*g*L*(Mp+Mc))/(I*(Mc+Mp)+Mc*Mp*L^2) 0];

B = [0; (I+Mp*L^2)/(I*(Mc+Mp)+Mc*Mp*L^2); 0; (Mp*L)/(I*(Mc+Mp)+Mc*Mp*L^2)];

C = [1 0 0 0; 0 0 1 0];

D = [0;0];

%% Open Loop State-Space System
sys = ss(A,B,C,D);
Poles = eig(A);                     
CO = ctrb(sys);                     %Determines if system is controlable
Controllability = rank(CO);


%% LQR
%[X, L, G] = dare(A,B,Q,R);      % Discrete Algebraic Riccati Equation
%K1 = inv(R+transpose(B)*X*B)*transpose(B)*X*A;

% Using Swection 2 of Ref [5]. 
% 20cm error ok for cart displacement
% 1/50rad error ok for pendulum orientation
R = 1;
Q = [(1/.2)^2 0 0 0; 0 0 0 0; 0 0 (50)^2 0; 0 0 0 0];
K = lqr(sys, Q, R);

Afb = [A - B*K];
Bfb = B;
Cfb = C;
Dfb = D;

sys_lqr = ss(Afb, Bfb, Cfb, Dfb);

[y,t,x] = lsim(sys_lqr, u, t);

%% Simulation & Animation
Save = 1;           % Set 1 to save animation

figure(1)
hold on
plot(t,y(:,1),'Color','Red')
plot(t,y(:,2),'Color','Blue')
legend('Displacement of Cart','Angle of Pendulum')

figure(2)
InvPendAnimation(t,y,Save)


%% Discrete Time Transfer Fucntion
%[num, den] = ss2tf(Afb, Bfb, Cfb, Dfb);
%ZPend = c2d(Pend_tf, 0.1);

Zpend2 = c2d(sys_lqr, 0.1);





%% References
% [1] http://www.ece.rutgers.edu/~gajic/psfiles/chap5traCO.pdf
% [2] http://ocw.mit.edu/courses/mechanical-engineering/2-154-maneuvering-and-control-of-surface-and-underwater-vehicles-13-49-fall-2004/lecture-notes/lec19.pdf
% [3] http://www.uz.zgora.pl/~wpaszke/materialy/kss/lqrnotes.pdf
% [4] **http://teal.gmu.edu/ececourses/ece521/labtutorials/LQR/lqrdesign.html**
% [5] ***http://www.cds.caltech.edu/~murray/courses/cds110/wi06/lqr.pdf***



    