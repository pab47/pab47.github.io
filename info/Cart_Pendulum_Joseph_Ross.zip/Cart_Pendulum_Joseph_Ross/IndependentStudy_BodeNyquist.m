%% Independent Study - Inverted Pendulum - Bode/Nyquist
clf; close all; clear all; clc

%% Physical Constants
Mp = 0.5; Mc = 0.2; L = 0.3; mu = 0.1; g = 9.81; I = 0.005;


w = logspace(-1,3,100);
Z = 0;
P = 0;

%% Transfer Function
s = tf('s');
A = (Mp*L*s/((Mc+Mp)*(I+Mp*L^2)-(Mp*L)^2));
B = (s^3 + (mu*(I + Mp*L^2))*s^2 ...
    /((Mc+Mp)*(I+Mp*L^2)-(Mp*L)^2) - ((Mc + Mp)*Mp*g*L)*s/((Mc+Mp)*(I+Mp*L^2) ...
    -(Mp*L)^2) - mu*Mp*g*L/((Mc+Mp)*(I+Mp*L^2)-(Mp*L)^2)); 

O_Loop = A/B;
C_Loop = feedback(O_Loop,1);
[OL_num, OL_den] = tfdata(O_Loop, 'v');
OL_Poles = roots(OL_den);
OL_Zeros = roots(OL_num);
[CL_num, CL_den] = tfdata(C_Loop, 'v');
CL_Poles = roots(CL_den);
CL_Zeros = roots(CL_num);

[Re, Im] = nyquist(O_Loop,w);

i1 = find(w==0.1);
i2 = find(w==1);
i3 = find(w==10);

for i = 1:3;
    if sign(real(CL_Poles(i))) == 1
        Z = Z + 1;
    end
end
for i = 1:3;
    if sign(real(OL_Poles(i))) == 1
        P = P + 1;
    end
end
[Gm,Pm,Wgm,Wpm] = margin(O_Loop);
% This should have given real values but for some reason, it says that the
% closed-loop system is unstable. Go back and figure out why system is
% showing as unstable. Check to make sure it has been input correctly and
% provide more realistic values for physical parameters. 



%% Refrences
% http://www.freestudy.co.uk/control/t7.pdf
% http://www.ece.rutgers.edu/~gajic/psfiles/nyquist.pdf




