%% Independent Study - Inverted Pendulum - Rool Locus
clf; close all; clear all; clc

%% Physical Constants
Mp = 0.5; Mc = 0.2; L = 0.3; mu = 0.1; g = 9.8; I = 0.006;


%% Transfer Function

s = tf('s');
A = (Mp*L*s/((Mc+Mp)*(I+Mp*L^2)-(Mp*L)^2));
B = (s^3 + (mu*(I + Mp*L^2))*s^2/((Mc+Mp)*(I+Mp*L^2)-(Mp*L)^2) -  ... 
    ((Mc + Mp)*Mp*g*L)*s/((Mc+Mp)*(I+Mp*L^2)-(Mp*L)^2) - mu*Mp*g*L/ ... 
    ((Mc+Mp)*(I+Mp*L^2)-(Mp*L)^2)); 
Pend_tf = A/B;



%% Root Locus
rlocus(Pend_tf)
title('Root Locus of Inverted Pendulum TF')
z = [-3,-4];
p = 0;
k = 1;
C = zpk(z,p,k);

rlocfind(Pend_tf*C)
Zeros = zero(C*Pend_tf)
Poles = pole(C*Pend_tf)
