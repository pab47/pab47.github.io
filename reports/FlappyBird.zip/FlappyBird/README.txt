Author: Shane Klimas

This ai uses deep-q learning to train itself to play flappybird.

To load conda environment from yml use
conda env create -f dqnenv.yml
in conda prompt with appropriate path, or use anaconda navigator to backup from dqnenv.yml
Then to train model use
python agent.py flappybird1 --train
To run the trained ai just exclude the "--train" parameter
in trained folder there is a well trained ai
