#include <boost/filesystem.hpp>
#include <flann/flann.h>
#include <flann/io/hdf5.h>
#include <iostream>
#include <pcl/common/centroid.h>
#include <pcl/common/common.h>
#include <pcl/common/time.h>
#include <pcl/common/transforms.h>
#include <pcl/console/parse.h>
#include <pcl/console/print.h>
#include <pcl/features/crh.h>
#include <pcl/features/normal_3d_omp.h>
#include <pcl/features/vfh.h>
#include <pcl/filters/extract_indices.h>
#include <pcl/filters/filter.h>
#include <pcl/filters/voxel_grid.h>
#include <pcl/io/pcd_io.h>
#include <pcl/kdtree/kdtree.h>
#include <pcl/keypoints/uniform_sampling.h>
#include <pcl/ModelCoefficients.h>
#include <pcl/point_types.h>
#include <pcl/point_cloud.h>
#include <pcl/recognition/hv/hv_go.h>
#include <pcl/registration/icp.h>
#include <pcl/recognition/crh_alignment.h>
#include <pcl/sample_consensus/method_types.h>
#include <pcl/sample_consensus/model_types.h>
#include <pcl/segmentation/sac_segmentation.h>
#include <pcl/segmentation/extract_clusters.h>
#include <pcl/visualization/pcl_visualizer.h>
#include <pcl/visualization/histogram_visualizer.h>


typedef pcl::Histogram<90> CRH90;
typedef std::pair<std::string, std::vector<float> > vfh_model;
typedef pcl::visualization::PointCloudColorHandlerCustom<pcl::PointNormal> ColorHandlerT;

inline void
nearestKSearch (flann::Index<flann::ChiSquareDistance<float> > &index, const vfh_model &model, int k, flann::Matrix<int> &indices, flann::Matrix<float> &distances)
{
  // Query point
  flann::Matrix<float> p = flann::Matrix<float>(new float[model.second.size ()], 1, model.second.size ());
  memcpy (&p.ptr ()[0], &model.second[0], p.cols * p.rows * sizeof (float));

  indices = flann::Matrix<int>(new int[k], 1, k);
  distances = flann::Matrix<float>(new float[k], 1, k);
  index.knnSearch (p, indices, distances, k, flann::SearchParams (512));
  delete[] p.ptr();
}

bool
loadFileList (std::vector<vfh_model> &models, const std::string &filename)
{
  ifstream fs;
  fs.open (filename.c_str ());
  if (!fs.is_open () || fs.fail ())
    return (false);

  std::string line;
  while (!fs.eof ())
  {
    getline (fs, line);
    if (line.empty ())
      continue;
    vfh_model m;
    m.first = line;
    models.push_back (m);
  }
  fs.close ();
  return (true);
}


int
main(int argc, char** argv)
{
	pcl::console::print_highlight ("Loading\n");
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// Loading
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// Load Model Database

	std::vector<pcl::PointCloud<pcl::VFHSignature308>::Ptr, Eigen::aligned_allocator<pcl::VFHSignature308> > object_vfh;
	std::vector<pcl::PointCloud<pcl::PointNormal>::Ptr, Eigen::aligned_allocator<pcl::PointNormal> > CAD_models;
	std::vector<std::string> file;

	for(int i=0; i<80;++i)
	{
		pcl::PointCloud<pcl::VFHSignature308>::Ptr object_histogram(new pcl::PointCloud<pcl::VFHSignature308>);
		pcl::PointCloud<pcl::PointNormal>::Ptr object_view(new pcl::PointCloud<pcl::PointNormal>);
		pcl::io::loadPCDFile<pcl::PointNormal>("Tide_80_SDC/Tide_"+boost::to_string(i)+".pcd", *object_view); // Load all database point clouds for use pose estimation
		CAD_models.push_back(object_view);
		file.push_back("Tide_80_SDC/Tide_"+boost::to_string(i)); // save name of point cloud for matching
	}

	
	//Load Scene
	pcl::PointCloud<pcl::PointNormal>::Ptr sceneRaw(new pcl::PointCloud<pcl::PointNormal>);
	if(pcl::io::loadPCDFile<pcl::PointNormal>(argv[1], *sceneRaw) != 0)
	{
		return -1;
	} 

 	std::string kdtree_idx_file_name = "kdtree.idx";
	std::string training_data_h5_file_name = "training_data.h5";
	std::string training_data_list_file_name = "training_data.list";

	std::vector<vfh_model> models;
	flann::Matrix<int> k_indices;
	flann::Matrix<float> k_distances;
	flann::Matrix<float> data;
	// Check if the data has already been saved to disk
  if (!boost::filesystem::exists("training_data.h5") || !boost::filesystem::exists("training_data.list"))
	{
	  pcl::console::print_error ("Could not find training data models files %s and %s!\n", training_data_h5_file_name.c_str (), training_data_list_file_name.c_str());
	  return(-1);
	}
  else
	{
	  loadFileList(models, training_data_list_file_name);
	  flann::load_from_file(data, training_data_h5_file_name, "training_data");
	  pcl::console::print_highlight("Training data found. Loaded %d VFH models from %s/%s.\n", (int)data.rows, training_data_h5_file_name.c_str(), training_data_list_file_name.c_str());
	}

	if (!boost::filesystem::exists(kdtree_idx_file_name))
	{
	  pcl::console::print_error("Could not find kd-tree index in file %s!", kdtree_idx_file_name.c_str());
	  return (-1);
	}
	flann::Index<flann::ChiSquareDistance<float> > index(data, flann::SavedIndexParams("kdtree.idx"));
	index.buildIndex();
	int objectStart=clock();
	

  /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// Cluseter Extraction
	/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	pcl::console::print_highlight ("Cluster Extraction\n");
	std::vector<pcl::PointCloud<pcl::PointNormal>::Ptr > scene_object;
	double leaf = 0.003;

  {
    pcl::ScopeTime t("Cluster");
    pcl::PointCloud<pcl::PointNormal>::Ptr scene_f(new pcl::PointCloud<pcl::PointNormal>);
 		std::cout << "PointCloud before filtering has: " << sceneRaw->points.size () << " data points." << std::endl; //*
    pcl::VoxelGrid<pcl::PointNormal> vg_cluster;
    pcl::PointCloud<pcl::PointNormal>::Ptr scene(new pcl::PointCloud<pcl::PointNormal>);
    vg_cluster.setInputCloud(sceneRaw);
    vg_cluster.setLeafSize (leaf, leaf, leaf);
    vg_cluster.filter(*scene);
    std::cout << "PointCloud after filtering has: " << scene->points.size ()  << " data points." << std::endl; //*
    
    // Create the segmentation object for the planar model and set all the parameters
    pcl::SACSegmentation<pcl::PointNormal> seg;
    pcl::PointIndices::Ptr inliers(new pcl::PointIndices);
    pcl::ModelCoefficients::Ptr coefficients(new pcl::ModelCoefficients);
    pcl::PointCloud<pcl::PointNormal>::Ptr scene_plane(new pcl::PointCloud<pcl::PointNormal> ());
    seg.setOptimizeCoefficients(true);
    seg.setModelType(pcl::SACMODEL_PLANE);
    seg.setMethodType(pcl::SAC_RANSAC);
    seg.setMaxIterations(100);
    seg.setDistanceThreshold(0.02);

    int i=0, nr_points = (int) scene->points.size ();
    while(scene->points.size() > 0.3 * nr_points)
    {
      // Segment the largest planar component from the remaining cloud
      seg.setInputCloud(scene);
      seg.segment(*inliers, *coefficients);
      if(inliers->indices.size() == 0)
      {
        break;
      }

      // Extract the planar inliers from the input cloud
      pcl::ExtractIndices<pcl::PointNormal> extract;
      extract.setInputCloud(scene);
      extract.setIndices(inliers);
      extract.setNegative(false);

      // Get the points associated with the planar surface
      extract.filter(*scene_plane);

      // Remove the planar inliers, extract the rest
      extract.setNegative(true);
      extract.filter(*scene_f);
      *scene = *scene_f;
    }
    
    // Creating the KdTree object for the search method of the extraction
    pcl::search::KdTree<pcl::PointNormal>::Ptr tree_cluster(new pcl::search::KdTree<pcl::PointNormal>);
    tree_cluster->setInputCloud(scene);

    std::vector<pcl::PointIndices> scene_indices;
    pcl::EuclideanClusterExtraction<pcl::PointNormal> ec;
    ec.setClusterTolerance(0.02); // 2cm
    ec.setMinClusterSize(1500);
    ec.setMaxClusterSize(25000);
    ec.setSearchMethod(tree_cluster);
    ec.setInputCloud(scene);
    ec.extract(scene_indices);
 		
    
    int j = 0;
    for(std::vector<pcl::PointIndices>::const_iterator it = scene_indices.begin(); it != scene_indices.end(); ++it)
    {
      pcl::PointCloud<pcl::PointNormal>::Ptr scene_cluster(new pcl::PointCloud<pcl::PointNormal>);
      for(std::vector<int>::const_iterator pit = it->indices.begin(); pit != it->indices.end(); ++pit)
			{
        scene_cluster->points.push_back(scene->points[*pit]); 
			}
      scene_cluster->width = scene_cluster->points.size();
      scene_cluster->height = 1;
      scene_cluster->is_dense = true;
      scene_object.push_back(scene_cluster);
    }
  } 
  std::cout << "Number of clusters: " << scene_object.size() << std::endl;
  
  //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  // Object Normals
  ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  
  // surface normal estimation for each object found by segmentation

  {
  	pcl::ScopeTime t("Scene Normals");
  	for(int i = 0; i < scene_object.size(); ++i)
  	{
	  	pcl::NormalEstimationOMP<pcl::PointNormal, pcl::PointNormal> normalEstimation;
			pcl::search::KdTree<pcl::PointNormal>::Ptr kdtree_scene_normal(new pcl::search::KdTree<pcl::PointNormal>);
			normalEstimation.setInputCloud(scene_object[i]);
			normalEstimation.setRadiusSearch(0.01);
			normalEstimation.setSearchMethod(kdtree_scene_normal);
			normalEstimation.compute(*scene_object[i]);
			std::vector<int> mapping;
			pcl::removeNaNNormalsFromPointCloud(*scene_object[i], *scene_object[i], mapping);
  	}
  }


  //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  // Object VFH
  ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

  // VFH estimation for each object found by segmentation

  std::vector<pcl::PointCloud<pcl::VFHSignature308>::Ptr, Eigen::aligned_allocator<pcl::VFHSignature308> > scene_object_vfh;
 {
  	pcl::ScopeTime t("Scene VFH");
  	for(int i = 0; i < scene_object.size(); ++i)
  	{
	  	pcl::VFHEstimation<pcl::PointNormal, pcl::PointNormal, pcl::VFHSignature308> vfh;
	  	pcl::PointCloud<pcl::VFHSignature308>::Ptr segmented_object_vfh(new pcl::PointCloud<pcl::VFHSignature308>);
			pcl::search::KdTree<pcl::PointNormal>::Ptr kdtree_VFH(new pcl::search::KdTree<pcl::PointNormal>);
			vfh.setInputCloud(scene_object[i]);
			vfh.setInputNormals(scene_object[i]);
			vfh.setSearchMethod(kdtree_VFH);
			vfh.setNormalizeBins(true);
			vfh.setNormalizeDistance(true);
			vfh.setFillSizeComponent(true);
			vfh.compute(*segmented_object_vfh);
			scene_object_vfh.push_back(segmented_object_vfh);
  	}
  }

	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// Matching 
	/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	// Find best match in database for each object cluster

	// i = object cluster,  j = database match

	int k = 20;  // number of nearest matches
	double thresh = DBL_MAX;  // No threshold, disabled by default
	std::string found_name[scene_object.size()][k];
	float found_distance[scene_object.size()][k];
	int found_index[scene_object.size()][k];
	{
		pcl::ScopeTime t("Matching");
	 	for(int i = 0; i < scene_object_vfh.size(); ++i)
	 	{
	 		vfh_model histogram;
		  histogram.second.resize(308);
		  for(size_t j = 0 ; j < 308 ; ++j)
		  {
		  	histogram.second[j] = scene_object_vfh[i]->points[0].histogram[j]; 
		  }
		  histogram.first = "";
		  nearestKSearch (index, histogram, k, k_indices, k_distances);


		  for (int j = 0; j < k; ++j)
		  {
		  	found_name[i][j] = models.at(k_indices[0][j]).first.c_str();
		  	found_distance[i][j] = k_distances[0][j];
		  	std::string cloud_name = models.at(k_indices[0][j]).first;
 				boost::replace_last(cloud_name, "_vfh.pcd", "");

 				
 				found_index[i][j] = find(file.begin(),file.end(),cloud_name)-file.begin();
    		//pcl::console::print_info ("    %d - %s (%d) with a distance of: %f\n", i, models.at(k_indices[0][j]).first.c_str (), k_indices[0][j], k_distances[0][j]);
		  }
	 	}
	}

	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// Object Stuff
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	// This section can be by adding all the information to the database

	// i = object cluster,  j = database match

	std::vector<std::vector<pcl::PointCloud<pcl::PointNormal>::Ptr, Eigen::aligned_allocator<pcl::PointNormal> > > object_full_down;
	std::vector<std::vector<Eigen::Vector4f> >object_centroids;
	std::vector<std::vector<pcl::PointCloud<CRH90>::Ptr, Eigen::aligned_allocator<CRH90> > > object_down_full_CRH;
	{
		pcl::ScopeTime t("Object Processing");

		for(int i = 0; i < scene_object.size(); ++i)
		{
			std::vector<pcl::PointCloud<pcl::PointNormal>::Ptr, Eigen::aligned_allocator<pcl::PointNormal> > object_row;
			std::vector<Eigen::Vector4f> object_centroids_row;
			std::vector<pcl::PointCloud<CRH90>::Ptr, Eigen::aligned_allocator<CRH90> > object_CRH_row;
			for(int j = 0; j < k; ++j)
			{
				pcl::PointCloud<pcl::PointNormal>::Ptr object_down(new pcl::PointCloud<pcl::PointNormal>);
		    pcl::copyPointCloud(*CAD_models[found_index[i][j]],*object_down);

    		// Normals
    		pcl::NormalEstimationOMP<pcl::PointNormal, pcl::PointNormal> object_normalEstimation;
				pcl::search::KdTree<pcl::PointNormal>::Ptr kdtree_object_normal(new pcl::search::KdTree<pcl::PointNormal>);
				object_normalEstimation.setInputCloud(object_down);
				object_normalEstimation.setRadiusSearch(0.01);
				object_normalEstimation.setSearchMethod(kdtree_object_normal);
				object_normalEstimation.compute(*object_down);

				std::vector<int> mapping;
				pcl::removeNaNNormalsFromPointCloud(*object_down, *object_down, mapping);
				//CRH
				pcl::CRHEstimation<pcl::PointNormal, pcl::PointNormal, CRH90> crh_object;
				pcl::PointCloud<CRH90>::Ptr object_down_CRH(new pcl::PointCloud<CRH90>);
				crh_object.setInputCloud(object_down);
				crh_object.setInputNormals(object_down);
				Eigen::Vector4f object_down_centroid;
				pcl::compute3DCentroid(*object_down, object_down_centroid);
				crh_object.setCentroid(object_down_centroid);
				crh_object.compute(*object_down_CRH);

				object_row.push_back(object_down);
				object_centroids_row.push_back(object_down_centroid);
				object_CRH_row.push_back(object_down_CRH);
			}
			object_full_down.push_back(object_row);
			object_centroids.push_back(object_centroids_row);
			object_down_full_CRH.push_back(object_CRH_row);
		}	
	}

	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// Scene CRH
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


	std::vector<pcl::PointCloud<CRH90>::Ptr, Eigen::aligned_allocator<CRH90> > scene_CRH_full;
	std::vector<Eigen::Vector4f> scene_centroids;
	{
		pcl::ScopeTime t("Scene CRH");
		for(int i = 0; i < scene_object.size(); ++i)
		{
			pcl::CRHEstimation<pcl::PointNormal, pcl::PointNormal, CRH90> crh;
			pcl::PointCloud<CRH90>::Ptr scene_object_CRH(new pcl::PointCloud<CRH90>);
			Eigen::Vector4f scene_object_centroid;
			crh.setInputCloud(scene_object[i]);
			crh.setInputNormals(scene_object[i]);
			pcl::compute3DCentroid(*scene_object[i], scene_object_centroid);
			crh.setCentroid(scene_object_centroid);
			crh.compute(*scene_object_CRH);

			scene_CRH_full.push_back(scene_object_CRH);
			scene_centroids.push_back(scene_object_centroid);
		}
	}

	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// Method #1
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	cout << "Clusters: " << scene_object.size() << endl;
	{
		pcl::ScopeTime t("Alignment and Verification");

		for(int i = 0; i < scene_object.size(); ++i)
		{
			
			cout << "\nScene Object: " << i <<"\n"<< endl;
			if(found_distance[i][0]<250)
			{
				for(int j = 0; j < k; ++j)
				{
					///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
					// CRH Alignment
					///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

					// i = object cluster,  j = database match

					pcl::CRHAlignment<pcl::PointNormal, 90> alignment;
					alignment.setInputAndTargetView(object_full_down[i][j], scene_object[i]);
					Eigen::Vector3f object_centroid3f(object_centroids[i][j][0], object_centroids[i][j][1], object_centroids[i][j][2]);
					Eigen::Vector3f scene_centroid3f(scene_centroids[i][0], scene_centroids[i][1], scene_centroids[i][2]);
					std::vector<Eigen::Matrix4f, Eigen::aligned_allocator< Eigen::Matrix4f> > transform;
					alignment.setInputAndTargetCentroids(object_centroid3f, scene_centroid3f);
					alignment.align(*object_down_full_CRH[i][j], *scene_CRH_full[i]);
					alignment.getTransforms(transform);

					///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
					// Transformation
					///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
					pcl::PointCloud<pcl::PointNormal>::Ptr objectTrans(new pcl::PointCloud<pcl::PointNormal>);
					if (transform.size() > 0)
					{
						// a = CRH transform
						for (int a = 0; a < transform.size(); a++)
						{
							pcl::PointCloud<pcl::PointNormal>::Ptr objectTrans (new pcl::PointCloud<pcl::PointNormal> ());
			 				pcl::transformPointCloud (*object_full_down[i][j], *objectTrans, transform[a]);

			 				////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
							// Scene Down
							////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
			 				double down_leaf = 0.005;
			 				pcl::PointCloud<pcl::PointNormal>::Ptr scene_down(new pcl::PointCloud<pcl::PointNormal>);
			 				pcl::PointCloud<pcl::PointNormal>::Ptr object_down(new pcl::PointCloud<pcl::PointNormal>);
					   	pcl::VoxelGrid<pcl::PointNormal> vg_object;
					   	vg_object.setLeafSize (down_leaf, down_leaf, down_leaf);
					   	vg_object.setInputCloud(scene_object[i]);					   		
					   	vg_object.filter(*scene_down);
			 				vg_object.setInputCloud(objectTrans);
					   	vg_object.setLeafSize (down_leaf, down_leaf, down_leaf);
					   	vg_object.filter(*object_down);
					   	pcl::copyPointCloud(*scene_down, *scene_object[i]);
					   	pcl::copyPointCloud(*object_down, *objectTrans);

							////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
							// ICP
							////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
							pcl::PointCloud<pcl::PointNormal>::Ptr finalCloud(new pcl::PointCloud<pcl::PointNormal>);
							pcl::IterativeClosestPoint<pcl::PointNormal, pcl::PointNormal> registration;
							Eigen::Matrix4f ICP_trans;
							registration.setInputSource(objectTrans);
							registration.setInputTarget(scene_object[i]);

							registration.setTransformationEpsilon (1e-8);
							registration.setMaximumIterations(100);
							{
				   		 	pcl::ScopeTime t("ICP Alignment");
				    		registration.align(*finalCloud);
				 			}
		    			
				 			///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
				 			// Hypothesis Verification
				 			///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		    			//cout << "--- Hypotheses Verification ---" << endl;
							float hv_clutter_reg_ (5.0f);
							float hv_inlier_th_ (down_leaf*1.5);
							float hv_occlusion_th_ (0.99);
							float hv_rad_clutter_ (0.03f);
							float hv_regularizer_ (3.0f);
							float hv_rad_normals_ (0.05);
							bool hv_detect_clutter_ (true);
						 	std::vector<bool> hypotheses_mask;  // Mask Vector to identify positive hypotheses

						 	pcl::PointCloud<pcl::PointXYZ>::Ptr objectGHV(new pcl::PointCloud<pcl::PointXYZ>);
						 	pcl::PointCloud<pcl::PointXYZ>::Ptr sceneGHV(new pcl::PointCloud<pcl::PointXYZ>);
						 	pcl::copyPointCloud(*finalCloud,*objectGHV);
						 	pcl::copyPointCloud(*scene_object[i],*sceneGHV);


						  pcl::GlobalHypothesesVerification<pcl::PointXYZ, pcl::PointXYZ> GoHv;
						  std::vector<pcl::PointCloud<pcl::PointXYZ>::ConstPtr> registered_instances;
						  registered_instances.push_back(objectGHV);


						  GoHv.setSceneCloud(sceneGHV);  // Scene Cloud
						  GoHv.addModels(registered_instances, true);  //Models to verify

						  GoHv.setInlierThreshold(hv_inlier_th_);
						  GoHv.setOcclusionThreshold(hv_occlusion_th_);
						  GoHv.setRegularizer(hv_regularizer_);
						  GoHv.setRadiusClutter(hv_rad_clutter_);
						  GoHv.setClutterRegularizer(hv_clutter_reg_);
						  GoHv.setDetectClutter(hv_detect_clutter_);
						  GoHv.setRadiusNormals(hv_rad_normals_);
						  {
				   		 	pcl::ScopeTime t("Hypothesis Verification");
						  	GoHv.verify();
						  }
						  GoHv.getMask(hypotheses_mask);
						  
						  if (hypotheses_mask[0])
					    {
					      cout << "Instance is GOOD! <---" << endl;
					      pcl::visualization::PCLVisualizer visu("Alignment");
					      visu.setBackgroundColor (1.0, 1.0, 1.0);
								visu.addPointCloud (scene_object[i], ColorHandlerT (scene_object[i], 0.0, 0.0, 0.0), "scene2");
								visu.addPointCloud (finalCloud, ColorHandlerT (finalCloud, 255.0, 0.0, 0.0), "scene4");
			    			visu.spin ();
					      goto loop;
					    }
					    else
					    {
					    	cout << "Instance is bad!" << endl;
					      /*pcl::visualization::PCLVisualizer visu("Alignment");
								visu.setBackgroundColor (1.0, 1.0, 1.0);
								visu.addPointCloud (scene_object[i], ColorHandlerT (scene_object[i], 0.0, 0.0, 0.0), "scene2");
								visu.addPointCloud (finalCloud, ColorHandlerT (finalCloud, 255.0, 0.0, 0.0), "scene4");
			    			visu.spin ();*/
					    }
					    
						}

					}

				}

			}
			loop:;
		}
		int objectEnd=clock();
		cout << "time: " << (objectEnd-objectStart)/double(CLOCKS_PER_SEC) << endl;
		// end of method #1
	}
	// end of main
}	