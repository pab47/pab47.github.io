clc
clear all
close all

x = linspace(0,2*pi);
y = sin(x);

plot(x,y); 
hold on;

for i=1:length(x)
    plot(x(i),y(i),'ro');
    h=plot(x(i),y(i),'go','MarkerFacecolor','g');
    pause(0.1);
    delete(h);
end
