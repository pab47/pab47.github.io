clc %clears the screen
clear all %clears all variables
close all %closes all figures

x = linspace(0,2*pi);
y = x.^2;

plot(x,y,'rx')