clc
clear all
close all

writeMovie = 0;

if (writeMovie)
    mov = VideoWriter('face.avi'); 
    open(mov);
end

n = 100;
theta = linspace(0,2*pi,n);
theta_half = linspace(-pi,0,n);

x_face = 5*cos(theta);
y_face = 5*sin(theta);

x_leye = 2+1*cos(theta);
y_leye = 2+1*sin(theta);

x_leye_inside = 2+0.75*cos(theta);
y_leye_inside = 2+0.75*sin(theta);

x_reye = -2+1*cos(theta);
y_reye = 2+1*sin(theta);

x_reye_inside = -2+0.75*cos(theta);
y_reye_inside = 2+0.75*sin(theta);

%x_nose = [0 0];
%y_nose = [1 -1];
x_nose = [-1 1 0 -1];
y_nose = [-1 -1 1 -1];

x_mouth = 0+1.5*cos(theta_half);
y_mouth = -2+1.5*sin(theta_half);

x_smile = [-1.5 1.5];
y_smile = [-2 -2];

for i=1:length(theta)
    pause(0.01);
    
    plot(x_face,y_face,'k'); hold on;
     plot(x_leye,y_leye,'k'); 
     plot(x_reye,y_reye,'k'); 
     patch(x_nose,y_nose,'k');
    
%     %line(x_nose,y_nose,'Linewidth',2);
     line(x_smile,y_smile,'Color','red','Linewidth',10);
    if (mod(i,10)<5)
        patch(x_mouth,y_mouth,[255,192,203]/255);
    end
    plot(x_leye_inside(i),y_leye_inside(i),'bo','Markerfacecolor','b','Markersize',20);
    plot(x_reye_inside(i),y_reye_inside(i),'bo','Markerfacecolor','b','Markersize',20);
    
    hold off
    axis('equal');
    
  if (writeMovie)
        axis off %does not show axis
        set(gcf,'Color',[1,1,1]) %set background to white
        writeVideo(mov,getframe);
  end
end

if (writeMovie)
    close(mov);
end