clc
clear all

% Equations of motion of a two-link manipulator
% <<two_link.png>>

%define symbolic quantities
syms l1 l2 m1 m2 I1 I2 g real %parameters
syms T1 T2 real %external torques on joints
syms theta1 theta2 theta1dot theta2dot theta1ddot theta2ddot real

%Compute jacoboians
s1 = sin(theta1); s12 = sin(theta1+theta2);
c1 = cos(theta1); c12 = cos(theta1+theta2);

Jvc1 = [-l1*s1/2 0; l1*c1/2 0; 0 0];
Jvc2 = [-l1*s1-l2*s12/2 -l2*s12/2; l1*c1+l2*c12/2 l2*c12/2; 0 0];

Jwc1 = [0 0; 0 0; 1 0];
Jwc2 = [0 0; 0 0; 1 1];

X = [theta1 theta2]';
Xdot = [theta1dot theta2dot]';
K = 0.5*Xdot'*(m1*(Jvc1'*Jvc1) + m2*(Jvc2'*Jvc2) + (Jwc1'*(I1*eye(3))*Jwc1)+I2*(Jwc2'*(I2*eye(3))*Jwc2))*Xdot;
P = m1*g*l1*s1/2 + m2*g*(l1*s1+l2*s12/2);
L = K - P


%%% Since there are two generalized co-ordinates, theta1 & theta2, we will have two equations.
dLdXdot(1) = diff(L,Xdot(1));
ddt_dLdXdot(1) = diff(dLdXdot(1),theta1)*theta1dot+...
                 diff(dLdXdot(1),theta2)*theta2dot+...
                 diff(dLdXdot(1),theta1dot)*theta1ddot+...
                 diff(dLdXdot(1),theta2dot)*theta2ddot;
dLdX(1) = diff(L,X(1));
             
dLdXdot(2) = diff(L,Xdot(2));
ddt_dLdXdot(2) = diff(dLdXdot(2),theta1)*theta1dot+...
                 diff(dLdXdot(2),theta2)*theta2dot+...
                 diff(dLdXdot(2),theta1dot)*theta1ddot+...
                 diff(dLdXdot(2),theta2dot)*theta2ddot;
dLdX(2) = diff(L,X(2));

EOM1 = ddt_dLdXdot(1) - dLdX(1) - T1
EOM2 = ddt_dLdXdot(2) - dLdX(2) - T2
%EOM1 looks like this 
%              M11(X)*theta1ddot+M12(X)*theta2ddot+C1(X,Xdot)*Xdot+G1(X) = 0 
%Similarly EOM2 looks like this 
%              M21(X)*theta1ddot+M22(X)*theta2ddot+C2(X,Xdot)*Xdot+G2(X) = 0  


%Finally, we will simplify the expression.

%To get G1 and G2, we put Xdot, Xddot to zero.
G1 = subs(EOM1,[theta1ddot theta2ddot theta1dot theta2dot],[0 0 0 0]); 
G1 = simplify(G1);
G2 = subs(EOM2,[theta1ddot theta2ddot theta1dot theta2dot],[0 0 0 0]); 
G2 = simplify(G2);

%Display for easy copy-paste
disp(['G1 = ', char(G1),';']);
disp(['G2 = ', char(G2),';']);

%To get C terms, we put theta1ddot theta2ddot each equal to zero and subtract from G
C1 = subs(EOM1,[theta1ddot theta2ddot],[0 0])-G1; 
C1 = simplify(C1);

C2 = subs(EOM2,[theta1ddot theta2ddot],[0 0])-G2; 
C2 = simplify(C2);

%Display for easy copy-paste
disp(['C1 = ', char(C1),';']);
disp(['C2 = ', char(C2),';']);

%Finally to get M, we subtract C and G from EOM 
M1 = EOM1 - C1 - G1; %M1; = M11(X)*theta1ddot+M12(X)*theta2ddot
M2 = EOM2 - C2 - G2; %M2; = M21(X)*theta1ddot+M22(X)*theta2ddot

%Now we will extract M11, M12, M21, M22 by putting various values for theta1ddot and theta2ddot
M11 = subs(M1,[theta1ddot theta2ddot],[1 0]); M11 = simplify(M11);
M12 = subs(M1,[theta1ddot theta2ddot],[0 1]); M12 = simplify(M12);
M21 = subs(M2,[theta1ddot theta2ddot],[1 0]); M21 = simplify(M21);
M22 = subs(M2,[theta1ddot theta2ddot],[0 1]); M22 = simplify(M22);
disp(['M11 = ', char(M11),';']);
disp(['M12 = ', char(M12),';']);
disp(['M21 = ', char(M21),';']);
disp(['M22 = ', char(M22),';']);

disp('Equations solved');
disp('Copy paste Ms, Cs, and Gs');

%Extra for J and Jdot for end-effector 
J = [-l1*s1-l2*s12 -l2*s12; l1*c1+l2*c12 l2*c12; 0 0];
J = J(1:2,1:2)
Jdot(1,1) = simplify(diff(J(1,1),theta1)*theta1dot+diff(J(1,1),theta2)*theta2dot);
Jdot(1,2) = simplify(diff(J(1,2),theta1)*theta1dot+diff(J(1,2),theta2)*theta2dot);
Jdot(2,1) = simplify(diff(J(2,1),theta1)*theta1dot+diff(J(2,1),theta2)*theta2dot);
Jdot(2,2) = simplify(diff(J(2,2),theta1)*theta1dot+diff(J(2,2),theta2)*theta2dot);


disp(' ');
disp('Copy paste in jacobian_endeffector.m');
disp(['J(1,1) = ', char(J(1,1)),';']);
disp(['J(1,2) = ', char(J(1,2)),';']);
disp(['J(2,1) = ', char(J(2,1)),';']);
disp(['J(2,2) = ', char(J(2,2)),';']);
disp(' ');
disp('Copy paste in jacobiandot_endeffector.m');
disp(['Jdot(1,1) = ', char(Jdot(1,1)),';']);
disp(['Jdot(1,2) = ', char(Jdot(1,2)),';']);
disp(['Jdot(2,1) = ', char(Jdot(2,1)),';']);
disp(['Jdot(2,2) = ', char(Jdot(2,2)),';']);
