clc
clear all

%Equations of motion of a body falling under gravity

%Define symbolic quantities
syms m g y ydot y2dot f real

%Get K, P and L
K = 0.5*m*ydot*ydot;
P = m*g*y;
L = K - P;

%Derive equations of motion
dLdydot = diff(L,ydot);
ddt_dLdydot = diff(dLdydot,y)*ydot + diff(dLdydot,ydot)*y2dot;
dLdy = diff(L,y);

%Equation of motion
EOM = ddt_dLdydot - dLdy - f


