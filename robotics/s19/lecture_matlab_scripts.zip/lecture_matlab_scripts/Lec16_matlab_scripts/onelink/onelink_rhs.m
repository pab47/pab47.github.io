function xdot=onelink_rhs(t,x,parms)           

theta1 = x(1);                          
theta1dot = x(2);  

m1 = parms.m1;
l1 = parms.a1;
I1 = parms.I1;
g = parms.g;

T1 = 0; %zero torques for unactuated system
%T1 = -0.1*theta1dot; %viscous friction

theta1ddot = (1/(I1+(m1*l1*l1/4)))*(T1 - m1*g*l1*cos(theta1));

xdot = [theta1dot theta1ddot]'  ;            
