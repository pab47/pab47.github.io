function diff_drive_main

clc
clear 
close all

t0 = 0;
tend = 20;
t_scale = 0.8;
phi_scale = 1/t_scale;
phidot = 200;
fps = 10; %adjust number of frames per second
parms.delay = 0.001; %adjust the delay in the animation
t = linspace(t0,tend,100*tend);

parms.writeMovie = 0; %set to 1 to get a movie output
parms.nameMovie = 'car.avi';


phiRdot = zeros(length(t),1);
phiLdot = zeros(length(t),1);

z0 = [2 2 pi]; %x, y, theta
for i=1:length(t)
    if (t(i)<3.15*t_scale)  %draw C
        diff = 0.95;
        [phiLdot(i), phiRdot(i)] = turnCCW(phi_scale*phidot,diff); 
    elseif (t(i)<= 4*t_scale) %horizontal line
        [phiLdot(i), phiRdot(i)] = Straight(phi_scale*phidot);
    elseif (t(i)<= 4.06*t_scale) %start A
        [phiLdot(i), phiRdot(i)] = turnCCW(phi_scale*phidot,0);
    elseif (t(i)<= 6.06*t_scale)
        [phiLdot(i), phiRdot(i)] = Straight(phi_scale*phidot);
    elseif (t(i)<= 6.18*t_scale) 
        [phiLdot(i), phiRdot(i)] = turnCW(phi_scale*phidot,0);
    elseif (t(i)<= 8.2*t_scale)
        [phiLdot(i), phiRdot(i)] = Straight(phi_scale*phidot);
    elseif (t(i)<= 8.26*t_scale) 
        [phiLdot(i), phiRdot(i)] = turnCCW(phi_scale*phidot,0);
    elseif (t(i)<= 9.26*t_scale) %horizontal line
        [phiLdot(i), phiRdot(i)] = Straight(phi_scale*phidot);
    elseif (t(i)<= 9.3421*t_scale)  %start R
        [phiLdot(i), phiRdot(i)] = turnCCW(phi_scale*phidot,0);
    elseif (t(i)<= 11.15*t_scale)
        [phiLdot(i), phiRdot(i)] = Straight(phi_scale*phidot);
    elseif (t(i)<= 11.20*t_scale)  
        [phiLdot(i), phiRdot(i)] = turnCW(phi_scale*phidot,0);
    elseif (t(i)<= 13.50*t_scale)  
        diff = 0.91;
        [phiLdot(i), phiRdot(i)] = turnCW(phi_scale*phidot,diff);
    elseif (t(i)<= 13.675*t_scale)  
        [phiLdot(i), phiRdot(i)] = turnCW(phi_scale*phidot,0);
    elseif (t(i)<= 15.00*t_scale)
        [phiLdot(i), phiRdot(i)] = Straight(phi_scale*phidot);
    else
        phiRdot(i) = 0; phiLdot(i) = 0;
    end
end

parms.r = 0.01; %radius of wheels
parms.w = 0.05; %width of the robot
parms.l = 0.25; %length of the robot

z = z0;
for i=1:length(t)-1
    u = [phiLdot(i) phiRdot(i)];
    zz = ode4(@differential_drive,[t(i) t(i+1)],z0,parms,u);
    z0 = zz(end,:);
    z = [z; z0];
end


%%%%%% get coarse data for animation
t_interp = linspace(t0,tend,fps*tend);
[m,n] = size(z);
for i=1:n
    z_interp(:,i) = interp1(t,z(:,i),t_interp);
end

figure(1)
animation(t_interp,z_interp,parms);

function [phiLdot,phiRdot] = Straight(phidot)
phiLdot = phidot; phiRdot = phidot; 

function [phiLdot,phiRdot] = turnCW(phidot,diff)
if (diff>1 || diff < 0)
    error('diff should be between 0 and 1');
end
phiLdot = phidot; phiRdot = diff*phidot; %diff = 0 is sharp CW turn

function [phiLdot,phiRdot] = turnCCW(phidot,diff)
if (diff>1 || diff < 0)
    error('diff should be between 0 and 1');
end
phiLdot = diff*phidot; phiRdot = phidot; %diff = 0 is sharp CCW turn


function zdot = differential_drive(t,z,parms,u)
r = parms.r; w = parms.w;
phiLdot = u(1); phiRdot = u(2);

%x = z(1);
%y = z(2);
theta = z(3);
R = rotation(theta);
v = [0.5*r*(phiRdot + phiLdot); ...
     0; ...
     0.5*(r/w)*(phiRdot - phiLdot)];
 zdot = R*v;

function R = rotation(theta)
R = [cos(theta) -sin(theta) 0; ...
     sin(theta) cos(theta) 0; ...
     0 0 1];


function animation(t,z,parms)

w = parms.w;
l = parms.l;
triangle = [0  l 0 0 ; %x-coordinate of vertices
            -w 0 w -w]; %y-coorindate of vertices
[mm,nn] = size(triangle); 

if (parms.writeMovie)
    mov = VideoWriter(parms.nameMovie); 
    open(mov);
end

n = length(t);
for i = 1:n
        pause(parms.delay)
            
        theta=z(i,3);
        R = [cos(theta) -sin(theta); %rotation matrix
             sin(theta) cos(theta)];
         newbox = R*triangle; %rotate the vertices of the box
         
         offset = [z(i,1) z(i,2)]'; %offset is the point about which the circle will move
         offsetmat= repmat(offset,1,nn); %creates nn copies of offset to be added to the vertices of the box.
         
         newbox = newbox + offsetmat; %rotate + translate
         
         plot(z(1:i,1),z(1:i,2),'r','Linewidth',2); hold on;
         patch(newbox(1,:), newbox(2,:),'blue'); hold off; %patch can be used to put color
              
          axis('equal');
          grid on;
%          axis([-2 2 -2 2]); %manually increase the display size
           min_x = min(z(:,1));
           max_x = max(z(:,1));
           min_y = min(z(:,2));
           max_y = max(z(:,2));
           mean_x = mean([min_x max_x]);
           mean_y = mean([min_y max_y]);
           width_x = max_x - mean_x;
           width_y = max_y - mean_y;
           axis([(mean_x-width_x) (mean_x+width_x) ...
                  (mean_y-width_y) (mean_y+width_y)]);
           if (parms.writeMovie)
            axis off %does not show axis
            set(gcf,'Color',[1,1,1]) %set background to white
            writeVideo(mov,getframe);
           end
end % end for loop


if (parms.writeMovie)
    close(mov);
end

