function diff_drive_ode4_main

clc
clear 
close all

t0 = 0;
tend = 20;
fps = 10; %adjust number of frames per second
parms.delay = 0.01; %adjust the delay in the animation
t = linspace(t0,tend,100*tend);

parms.writeMovie = 0; %set to 1 to get a movie output
parms.nameMovie = 'car.avi';


phiLdot = zeros(length(t),1);
phiRdot = zeros(length(t),1);

for i=1:length(t)
    if (t(i)<=5)
        phiLdot(i) = 10; phiRdot(i) = 10;
    elseif (t(i)<=15)
        phiLdot(i) = 10; phiRdot(i) = 11;
    else
        phiLdot(i) = 10; phiRdot(i) = 10;
    end
end

parms.r = 0.01; %radius of wheels
parms.w = 0.05; %width of the robot
parms.l = 0.25; %length of the robot

z0 = [0 0 0]; %x, y, theta
z = z0;
for i=1:length(t)-1
    u = [phiLdot(i) phiRdot(i)];
    zz = ode4(@differential_drive,[t(i) t(i+1)],z0,parms,u);
    z0 = zz(end,:);
    z = [z; z0];
end


%%%%%% get coarse data for animation
t_interp = linspace(t0,tend,fps*tend);
[m,n] = size(z);
for i=1:n
    z_interp(:,i) = interp1(t,z(:,i),t_interp);
end

figure(1)
animation(t_interp,z_interp,parms);



function zdot = differential_drive(t,z,parms,u)
r = parms.r; w = parms.w;
phiLdot = u(1); phiRdot = u(2);

%x = z(1);
%y = z(2);
theta = z(3);
R = rotation(theta);
v = [0.5*r*(phiLdot + phiRdot); ...
     0; ...
     0.5*(r/w)*(phiRdot - phiLdot)];
 zdot = R*v;

function R = rotation(theta)
R = [cos(theta) -sin(theta) 0; ...
     sin(theta) cos(theta) 0; ...
     0 0 1];


function animation(t,z,parms)

w = parms.w;
l = parms.l;
triangle = [0  l 0 0 ; %x-coordinate of vertices
            -w 0 w -w]; %y-coorindate of vertices
[mm,nn] = size(triangle); 

if (parms.writeMovie)
    mov = VideoWriter(parms.nameMovie); 
    open(mov);
end

n = length(t);
for i = 1:n
        pause(parms.delay)
            
        theta=z(i,3);
        R = [cos(theta) -sin(theta); %rotation matrix
             sin(theta) cos(theta)];
         newbox = R*triangle; %rotate the vertices of the box
         
         offset = [z(i,1) z(i,2)]'; %offset is the point about which the circle will move
         offsetmat= repmat(offset,1,nn); %creates nn copies of offset to be added to the vertices of the box.
         
         newbox = newbox + offsetmat; %rotate + translate
         
         plot(z(1:i,1),z(1:i,2),'r','Linewidth',2); hold on;
         %plot(newbox(1,:), newbox(2,:),'b','LineWidth',2); hold off; %plots the box
         patch(newbox(1,:), newbox(2,:),'blue'); hold off; %patch can be used to put color
              
          axis('equal');
          grid on;
%          axis([-2 2 -2 2]); %manually increase the display size
           span = max([-min(min(z(:,1:2))) max(max(z(:,1:2)))]);
           span = max([span 2]);
           axis([-span span -span span]);
%           axis([min(min(z(:,1:2)))-max([l w]) max(max(z(:,1:2)))+max([l w]) ...
%                 min(min(z(:,1:2)))-max([l w]) max(max(z(:,1:2)))+max([l w])]); 
           if (parms.writeMovie)
            axis off %does not show axis
            set(gcf,'Color',[1,1,1]) %set background to white
            writeVideo(mov,getframe);
           end
end % end for loop


if (parms.writeMovie)
    close(mov);
end

