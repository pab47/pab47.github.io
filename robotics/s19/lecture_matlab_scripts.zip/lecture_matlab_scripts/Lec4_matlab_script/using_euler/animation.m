function animation(t,z,parms)

w = parms.w;
l = parms.l;
triangle = [0  l 0 ; %x-coordinate of vertices
            -w 0 w ]; %y-coorindate of vertices
[mm,nn] = size(triangle); 

if (parms.writeMovie)
    mov = VideoWriter(parms.nameMovie); 
    open(mov);
end

n = length(t);
for i = 1:n
       
        pause(parms.delay)
            
        theta=z(i,3);
        R = [cos(theta) -sin(theta); %rotation matrix
             sin(theta) cos(theta)];
         newbox = R*triangle; %rotate the vertices of the box
         
         offset = [z(i,1) z(i,2)]'; %offset is the point about which the circle will move
         offsetmat= repmat(offset,1,nn); %creates nn copies of offset to be added to the vertices of the box.
         
         newbox = newbox + offsetmat; %rotate + translate
         
         plot(z(1:i,1),z(1:i,2),'r','Linewidth',2); hold on;
         %plot(newbox(1,:), newbox(2,:),'b','LineWidth',2); hold off; %plots the box
         patch(newbox(1,:), newbox(2,:),'blue'); hold off; %patch can be used to put color
              
          axis('equal');
          
%          axis([-2 2 -2 2]); %manually increase the display size
           span = max([-min(min(z(:,1:2))) max(max(z(:,1:2)))]);
           span = max([span 2]);
           axis([-span span -span span]);
             grid on;

           if (parms.writeMovie)
            axis off %does not show axis
            set(gcf,'Color',[1,1,1]) %set background to white
            writeVideo(mov,getframe);
           end
end % end for loop

if (parms.writeMovie)
    close(mov);
end


