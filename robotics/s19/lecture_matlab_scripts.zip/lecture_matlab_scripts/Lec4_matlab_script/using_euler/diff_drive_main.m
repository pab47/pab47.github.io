%%% simulation of a robot car with a differential drive %%%
clc
clear 
close all

parms.writeMovie = 0; %set to 1 to get a movie output
parms.nameMovie = 'car.avi';


t0 = 0;
tend = 20;
fps = 10; %adjust number of frames per second
parms.delay = 0.01; %adjust the delay in the animation
t = linspace(t0,tend,100*tend);


phi_l_dot = zeros(length(t),1);
phi_r_dot = zeros(length(t),1);

for i=1:length(t)
    if (t(i)<=5)
        phi_l_dot(i) = 10; phi_r_dot(i) = 10;
    elseif (t(i)<=15)
        phi_l_dot(i) = 12; phi_r_dot(i) = 10;
    else
        phi_l_dot(i) = 10; phi_r_dot(i) = 10;
    end
end

parms.r = 0.01; %radius of wheels
parms.w = 0.05; %width of the robot
parms.l = 0.25; %length of the robot

z0 = [0 0 0]; %start position of the robot car 
z = z0;
for i=1:length(t)-1
    u = [phi_l_dot(i) phi_r_dot(i)];
    zz = euler_integration([t(i) t(i+1)],z0,parms,u);
    z0 = zz(end,:);
    z = [z; z0];
end


%%%%%% get coarse data for animation
t_interp = linspace(t0,tend,fps*tend);
[m,n] = size(z);
for i=1:n
    z_interp(:,i) = interp1(t,z(:,i),t_interp);
end

figure(1)
animation(t_interp,z_interp,parms);



