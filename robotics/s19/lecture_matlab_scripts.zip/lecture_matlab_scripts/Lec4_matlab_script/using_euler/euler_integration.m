function z2 = euler_integration(t,z1,parms,u)
r = parms.r; w = parms.w;
phi_l_dot = u(1); phi_r_dot = u(2);
h = t(2)-t(1);

x1 = z1(1);
y1 = z1(2);
theta1 = z1(3);

R = [cos(theta1) -sin(theta1) 0; ...
     sin(theta1) cos(theta1) 0; ...
     0 0 1];
vel_local = [0.5*r*(phi_r_dot + phi_l_dot); ...
             0; ...
     0.5*(r/w)*(phi_r_dot - phi_l_dot)];
vel_global = R*vel_local;

x2 = x1 + vel_global(1,1)*h;
y2 = y1 + vel_global(2,1)*h;
theta2 = theta1 + vel_global(3,1)*h;

z2 = [x2, y2, theta2];