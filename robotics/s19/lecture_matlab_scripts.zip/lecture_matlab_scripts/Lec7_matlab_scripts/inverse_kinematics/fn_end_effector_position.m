function X = fn_end_effector_position(theta)

global a1 alpha1 d1 a2 alpha2 d2 %these are defined in inverse_kinematics
global x_des y_des z_des

% Get individual theta's from input
theta1 = theta(1);
theta2 = theta(2);

%D-H for link 1
A01 = DH(a1,alpha1,d1,theta1); %A^0_1

%D-H for link 2
A12 = DH(a2,alpha2,d2,theta2); %A^1_2

% Location of end of link 2 (Origin of 02x2y2) wrt frame 0
A02 = A01*A12;
endOfLink2 = A02(1:3,4);

%x,y,z of end of link2, X is the output
X = [endOfLink2(1)-x_des; endOfLink2(2)-y_des; endOfLink2(3)-z_des]; 