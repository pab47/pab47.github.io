clc
clear all
close all

%%% This example shows how to do the inverse kinematics for a 2 link manipulator and do an animation.
% <<two_link.png>>

%% Specify DH parameters
global a1 alpha1 d1 a2 alpha2 d2 %the function end_effector will use these 
                                 %variables so we make them globals
global x_des y_des z_des %where you want the end-effector

%D-H for links. Theta's are not set, because we need to find them.
a1 = 1; alpha1 = 0; d1=0;
a2 = 1; alpha2 = 0; d2=0;

delay = 0.01;


%%% parameters of the circle
x_center = 0.5; y_center = 0.5; r = 0.5;

%%%% theta is the parameteric to describe the circle
theta = linspace(0,2*pi,51);
n = length(theta);
x_des_all = x_center+r*cos(theta); 
y_des_all = y_center+r*sin(theta);
z_des_all = zeros(1,n);

theta10 = 0.5; %0.5*ones(n,1);
theta20 = 0.5; %0.5*ones(n,1);
%Try both these. They give different solutions. 
%theta1 = 0.5; theta2 = 0.5; %initial guess for angles 
%theta1 = -0.5; theta2 = -0.5; %initial guess for angles
%theta1 = -pi/2; theta2 = -pi/2; %initial guess for angles
%theta1 = 0.1; theta2 = 0;

%% Solve for the values of theta that give the required end-effector pose.
%fsolve solves for the roots for the equation X-XDES
for i=1:n
    x_des = x_des_all(1,i);
    y_des = y_des_all(1,i);
    z_des = z_des_all(1,i);
    
    [X,FVAL,EXITFLAG] = fsolve('fn_end_effector_position',[theta10,theta20]);
    theta1(i,1) = X(1);
    theta2(i,1) = X(2);
    
    theta10 = X(1);
    theta20 = X(2);
    disp(['Exitflag after running fsolve = ', num2str(EXITFLAG) ]) %Tells if fsolve converged or not
                   %1 means converged else not converged
                   %Type help fsolve to know more about what different 
                   %EXITFLAG mean.
end               
%disp(['theta1 = ',num2str(theta1),'; theta2 = ',num2str(theta2)]);
 
figure(1)
plot(theta1,'r'); hold on
plot(theta2,'b');
% %% Now visualize the results 

figure(2)
%plot3(x_des_all,y_des_all,z_des_all,'o','MarkerSize',10,'MarkerFaceColor','black');
   
x_drawn = [];
y_drawn = [];
z_drawn = [];
for i=1:n
  
   
% Now let us plot the results.
    A01 = DH(a1,alpha1,d1,theta1(i,1)); %A^0_1
    A12 = DH(a2,alpha2,d2,theta2(i,1)); %A^1_2

    %Location of joint 1
    endOfLink1 = A01(1:3,4);

    %Location of joint 2
    A02 = A01*A12;
    endOfLink2 = A02(1:3,4);
    
    %Save the figure drawn so far
%     x_drawn(i,1) = endOfLink2(1);
%     y_drawn(i,1) = endOfLink2(2);
%     z_drawn(i,1) = endOfLink2(3);
    x_drawn = [x_drawn; endOfLink2(1)];
    y_drawn = [y_drawn; endOfLink2(2)];
    z_drawn = [z_drawn; endOfLink2(3)];
    
    %Plot the point where we want the end-effector
    plot3(x_drawn(1:i),y_drawn(1:i),z_drawn(1:i),'k'); hold on;

    %Draw line from origin to end of link 1
    h1= line([0 endOfLink1(1)],[0 endOfLink1(2)],[0 endOfLink1(3)],....
          'LineWidth',5,'Color','green');  %hold on; %Ensures that dot on screen does not dissappear
 
    %Draw line from end of link 1 to end of link 2
    h2 = line([endOfLink1(1) endOfLink2(1)],...
         [endOfLink1(2) endOfLink2(2)],...
         [endOfLink1(3) endOfLink2(3)],...
         'LineWidth',5,'Color','magenta');  
    xlabel('x');
    ylabel('y');
    zlabel('z');
    grid on; %if you want the grid to show up.
    %axis('equal'); %make the axis equal, to avoid scaling effect
      
    view([0,90]); %top view (for 2-d plot). Comment out if you want a 3-d plot
    
    
    %These set the x and y limits for the axis (will need adjustment)
    xlim([-2 2]); 
    ylim([-2 2]);
    zlim([-2 2]);
    
    pause(delay);
    delete(h1);
    delete(h2); 
    
   
end
