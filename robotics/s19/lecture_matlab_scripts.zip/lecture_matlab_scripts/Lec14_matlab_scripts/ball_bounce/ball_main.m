clc
close all

ball.g = 9.81;
ball.e = 0.9;
ball.ground = 0; %ground is at y co-ordinate equal to ball.ground
ball.c = 0.0;

ball.movieWrite = 0; %set to 1 to output a movie file
ball.moviePause = 0.05; %delay for the movie
ball.movieFps = 20; %frames per second. Ensures that same number of frames are there every second.
ball.movieName = 'bouncing_ball.avi';

%x0 = 0; x0dot = 1; y0 = 5; y0dot = 0;
x0 = 0; x0dot = 5; y0 = 0; y0dot = x0dot*tan(pi/3);
qstart = [x0 x0dot y0 y0dot];

t0 = 0; tend = 5;
tstart = t0;

t_all = tstart; q_all = qstart;
while(t0<tend)
    options = odeset('Abstol',1e-6,'Reltol',1e-6,'Events',@ball_contact);%ball contact stops integration 
                                                                         %once ground is detected
    [t,q]=ode45(@ball_rhs,[t0 tend],qstart,options,ball);
    
    t_all = [t_all; t(2:end)];
    q_all = [q_all; q(2:end,:)];
    
    t0 = t(end);
    qstart(1,1) = q(end,1);
    qstart(1,2) = q(end,2);
    qstart(1,3) = q(end,3);
    qstart(1,4) = -ball.e*q(end,4);
end


figure(1)
subplot(2,2,1);
plot(t_all,q_all(:,1),'r');
ylabel('Position x');
subplot(2,2,2);
plot(t_all,q_all(:,3),'r');
ylabel('Position y');
subplot(2,2,3);
plot(t_all,q_all(:,2),'b');
ylabel('Velocity x');
subplot(2,2,4);
plot(t_all,q_all(:,4),'b');
ylabel('Velocity y');
xlabel('Time');

figure(2)
ball_animation(t_all,q_all,ball)

