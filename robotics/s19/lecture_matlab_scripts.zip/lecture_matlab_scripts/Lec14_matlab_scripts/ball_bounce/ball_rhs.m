function dqdt = ball_rhs(t,q,ball)

%x = q(1);
vx = q(2);
%y = q(3);
vy = q(4);
v = sqrt(vx^2+vy^2);

%%%% drag is prop to v^2
dragX = ball.c*v*vx;
dragY = ball.c*v*vy;

%%%% net acceleration %%%
ax = 0-dragX;
ay = -ball.g-dragY;

dqdt = [vx ax vy ay]';

