clc
close all

root_finder_ON = 0; %set to 0 if you want to try different q_guess and animate
                     %set to 1 if you want to turn the root finder ON.
                     
hopper.g = 10;
hopper.ground = 0; %ground is at y co-ordinate equal to robot.ground
hopper.l0 = 1;
hopper.m = 1;
hopper.k = 100;
hopper.theta  = 10*(pi/180); %pi/4; %pi/6; %angle between leg and vertical
hopper.bounces = 5;


hopper.movieWrite = 0; %set to 1 to output a movie file
hopper.moviePause = 0.01; %delay for the movie
hopper.movieFps = 60; %frames per second. Ensures that same number of frames are there every second.
hopper.movieName = 'hopper.avi';

x0dot = 1; y0 = 1.2; %best guess
q_guess = [x0dot y0]; q_sol = q_guess; 

if (root_finder_ON == 1)
    options = optimset('TolFun',1e-10,'TolX',1e-10,'Display','iter');
    disp('Computing fixed point');
    %optimoptions(@fsolve,'Display','iter','TolFun',1e-10,'TolX',1e-10); %another way of specifying options
    [q_sol,fval,exitflag] = fsolve('hopper_periodic',q_guess,options,hopper);
    disp(q_sol);
    disp('Convergence given by exitflag = ...');
    disp(exitflag)

    J=hopper_jacobian(q_sol,hopper);
    disp('Eigenvalues of fixed point');
    eig(J)
end

x0 = 0; y0dot = 0;
q0 = [x0 q_sol(1,1) q_sol(1,2) y0dot]; 
t_all = [];
q_all = [];
tf = 0;
for i=1:hopper.bounces
    [q,t] = hopper_one_bounce(q0,hopper);
    
    
    q0 = q(end,1:4); %set new initial condition
    t = t+tf; %add saved end time, tf, to all data points.
    t_all = [t_all; t(2:end)];  %start from 2nd entry to prevent repeating times which will affect interpolant in animation
    q_all = [q_all; q(2:end,:)];
    tf = t_all(end); %update end time
    
end

figure(1)
subplot(2,2,1);
plot(t_all,q_all(:,1),'r');
ylabel('Position x');
subplot(2,2,2);
plot(t_all,q_all(:,3),'r');
ylabel('Position y');
subplot(2,2,3);
plot(t_all,q_all(:,2),'b');
ylabel('Velocity x');
subplot(2,2,4);
plot(t_all,q_all(:,4),'b');
ylabel('Velocity y');
xlabel('Time');

figure(2)
hopper_animation(t_all,q_all,hopper)


