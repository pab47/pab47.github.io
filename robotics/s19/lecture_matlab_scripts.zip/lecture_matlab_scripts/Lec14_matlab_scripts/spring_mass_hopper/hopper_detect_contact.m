function [gstop, isterminal,direction]=hopper_detect_contact(t,q,hopper)

gstop = q(3) - hopper.l0*cos(hopper.theta); %position is 0;
direction = -1; %negative direction goes from + to -
isterminal = 1;  %1 is stop the integration