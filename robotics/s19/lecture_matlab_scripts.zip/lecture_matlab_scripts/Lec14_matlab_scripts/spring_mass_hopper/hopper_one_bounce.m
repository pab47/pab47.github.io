function [q,t] = hopper_one_bounce(q0,hopper)

%%% Use only if q0 = [x0dot y0]; 
[m,n] = size(q0);
if(n==2) %then q0 = [x0dot y0]; used by fsolve 
    xdot0 = q0(1);
    y0 = q0(2); 
    x0 = 0;
    ydot0 = 0;
    q0 = [x0 xdot0 y0 ydot0];
end


%%%%% flight phase 1 %%%%%%%
t0 = 0; 
tend = 2; %tend should be big enough that atleast one bounce is possible.

t = t0; 
q = [q0 ...
     q0(1)+hopper.l0*sin(hopper.theta) ... %x position of the foot
     q0(3)-hopper.l0*cos(hopper.theta)];   %y position of the foot
options1 = odeset('Abstol',1e-12,'Reltol',1e-12,'Events',@hopper_detect_contact);%hopper contact stops integration                                                                  %once ground is detected
[t1,q1]=ode45(@hopper_flight,[t0 tend],q0,options1,hopper);

q1 = [q1 ...
      q1(:,1)+hopper.l0*sin(hopper.theta) ...
      q1(:,3)-hopper.l0*cos(hopper.theta) ...
      ];
  


%%%%% stance phase 1 %%%%%%%
t0 = t1(end);
tend = t0+2;
q0 = [-hopper.l0*sin(hopper.theta) q1(end,2) q1(end,3) q1(end,4)]; %the x position is relative to contact point   
options2 = odeset('Abstol',1e-12,'Reltol',1e-12,'Events',@hopper_release_contact);%hopper contact stops integration                                                                  %once ground is detected
[t2,q2]=ode45(@hopper_stance,[t0 tend],q0,options2,hopper);

%%%% calculate the correct body position for animation %%%
xBody = q1(end,1) + ... %position at the end of stance phase
        q2(:,1) + hopper.l0*sin(hopper.theta); %add hopper.l0*sin(theta) to position because subtracted this term in the initial condition
%%% calculate the position of the foot during stance. This is going to be the same for entire stance phase
xFoot = (q1(end,1) + hopper.l0*sin(hopper.theta))*ones(length(q2),1); 
yFoot = hopper.ground*ones(length(q2),1);
    
q2 = [xBody ...
      q2(:,2) q2(:,3) q2(:,4) ...
      xFoot yFoot ...
      ];

  
%%%%%%  flght phase 2 to apex
t0 = t2(end);
tend = t0+2;
q0 = q2(end,1:4);
options = odeset('Abstol',1e-12,'Reltol',1e-12,'Events',@hopper_apex);%hopper contact stops integration                                                                  %once ground is detected
[t3,q3]=ode45(@hopper_flight,[t0 tend],q0,options,hopper);

q3 = [q3 ...
      q3(:,1)+hopper.l0*sin(hopper.theta) ...
      q3(:,3)-hopper.l0*cos(hopper.theta) ...
      ];
%%%%%% Ignore time stamps for heelstrike and first integration point to avoid repeated entries   
t = [t; t1(2:end); t2(2:end); t3(2:end)];
q = [q; q1(2:end,:); q2(2:end,:); q3(2:end,:)];

if (nargout==1) %if only q is the output then send only the end state of q. 
                %This is because fsolve is calling this function.
    xdot0 = q3(end,2);
    y0 = q3(end,3);
    q = [xdot0 y0]; %return only the x velocity and apex height
end