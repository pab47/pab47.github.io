function dqdt = hopper_stance(t,q,hopper)

x = q(1); 
vx = q(2);
y = q(3); 
vy = q(4);

l = sqrt(x^2+y^2);
F_spring = hopper.k*(hopper.l0-l);
Fx_spring =  F_spring*(x/l);
Fy_spring = F_spring*(y/l);
Fy_gravity = hopper.m*hopper.g;
ax = (1/hopper.m)*(Fx_spring);
ay = (1/hopper.m)*(-Fy_gravity+Fy_spring);
dqdt = [vx ax vy ay]';