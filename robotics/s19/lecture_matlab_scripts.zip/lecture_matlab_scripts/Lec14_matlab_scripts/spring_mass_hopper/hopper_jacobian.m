%===================================================================
function J=hopper_jacobian(q0,hopper)
%===================================================================
pert=1e-5;

n = length(q0);
J = zeros(n,n);

%%% Using central difference, accuracy quadratic %%%
for i=1:n
    qtemp1=q0; qtemp2=q0;
    qtemp1(i)=qtemp1(i)+pert; 
    qtemp2(i)=qtemp2(i)-pert; 
    J(:,i)=(hopper_one_bounce(qtemp1,hopper)-hopper_one_bounce(qtemp2,hopper))';
end
J=J/(2*pert);