function error = hopper_periodic(q0,hopper)

x0dot = q0(1);
y0 = q0(2);
q1 = hopper_one_bounce(q0,hopper);

% xfdot = q1(end,2);
% yf = q1(end,3);

xfdot = q1(1);
yf = q1(2);

error = [xfdot-x0dot yf-y0];