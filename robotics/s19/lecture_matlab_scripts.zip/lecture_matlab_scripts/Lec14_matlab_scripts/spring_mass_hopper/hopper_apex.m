function [gstop, isterminal,direction]=hopper_apex(t,q,hopper)

ydot = q(4);
gstop = ydot - 0; %vertical velocity is zero
direction = 0; %negative direction goes from + to -
isterminal = 1;  %1 is stop the integration

