function hopper_animation(t_all,q_all,hopper)

%%% interpolate for animation %%
tstart = t_all(1); 
tend = t_all(end);
tinterp = linspace(tstart,tend,hopper.movieFps*(tend-tstart));
[m,n]=size(q_all);
for i=1:n
    qinterp(:,i) = interp1(t_all,q_all(:,i),tinterp);
end

if (hopper.movieWrite)
    mov = VideoWriter(hopper.movieName); 
    open(mov);
end

for i=1:length(tinterp)
    plot(qinterp(i,1),qinterp(i,3),'ro','MarkerEdgeColor','r', 'MarkerFaceColor','r','MarkerSize',20);  hold on
    line([qinterp(i,1) qinterp(i,5)],[qinterp(i,3) qinterp(i,6)],'Color','g','LineWidth',5); 
    %line([min(qinterp(:,1)) max(qinterp(:,1))],[hopper.ground hopper.ground],'Linewidth',2)
    axis([-0.5 max(qinterp(:,1))+1 0 max(qinterp(:,3))+0.2]); %axis([xmin xmax ymin ymax]); 
    plot(qinterp(1:i,1),qinterp(1:i,3),'k'); %trajectory
    
    if (hopper.movieWrite)
        axis off %does not show axis
        set(gcf,'Color',[1,1,1]) %set background to white
        writeVideo(mov,getframe);
    end
    
    pause(hopper.moviePause);
    hold off
end

if (hopper.movieWrite)
    close(mov);
end
