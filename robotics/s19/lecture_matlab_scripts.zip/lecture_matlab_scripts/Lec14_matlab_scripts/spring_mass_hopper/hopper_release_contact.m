function [gstop, isterminal,direction]=hopper_release_contact(t,q,hopper)

y = q(3);
gstop = y - hopper.l0*cos(hopper.theta); %position is 0;
direction = 1; %negative direction goes from + to -
isterminal = 1;  %1 is stop the integration
