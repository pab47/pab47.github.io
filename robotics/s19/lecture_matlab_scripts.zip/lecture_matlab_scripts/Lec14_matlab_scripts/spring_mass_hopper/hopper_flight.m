function dqdt = hopper_flight(t,q,hopper)

vx = q(2);
vy = q(4);
ax = 0;
ay = -hopper.g;

dqdt = [vx ax vy ay]';
