function diff_drive_main

clc
clear 
close all

parms.r = 0.01; %radius of wheels
parms.w = 0.2; %width of the robot
parms.l = 0.4; %length of the robot
parms.lx = parms.l;  %x-location of the pen from mid-point
parms.ly = 0;        %y-location of the pen from mid-point
parms.Kp = 100; %gain for controller

parms.writeMovie = 0; %set to 1 to get a movie output
parms.nameMovie = 'car_drawing.avi';

t0 = 0;
tend = 10;
fps = 10; %adjust number of frames per second
parms.delay = 0.001; %adjust the delay in the animation
t = t0:0.01:tend;

%%% circle %%%
%x_ref = 1*cos(2*pi*t/tend); y_ref = 1*sin(2*pi*t/tend);

%%% astroid %%
x_center = 0; y_center = 0; a = 1;
x_ref = x_center+a*cos(2*pi*t/tend).^3; y_ref = y_center+a*sin(2*pi*t/tend).^3

theta0 = 0; %guessed to be zero. Can be made better by specifying a better value based on the specific curve
[x0,y0] = marker2midpoint(x_ref(1),y_ref(1),theta0,parms); %given the x_ref(1) and y_ref(1) (position of E at start) this step computes the correct starting position for the car (i.e., point P)
z0 = [x0 y0 theta0]; %x, y, theta at the start for point P
z = z0;
e = [0 0];
phiRdot = 0;
phiLdot = 0;

for i=1:length(t)-1
    
    % 1. get x,y position
    x = z(end,1); y = z(end,2); theta = z(end,3);
    
    % 2. get xe, ye from x,y 
    [xe,ye] = midpoint2marker(x,y,theta,parms);
    
    % 3. get error = xe-x_ref and ye-y_ref
    error = [x_ref(i+1)-xe y_ref(i+1)-ye];
    e = [e; error];
   
    %4. get xedot = [xedot, yedot] = Kp*e (controller)
    xedot = [parms.Kp*error(1); parms.Kp*error(2)];
    c = cos(theta); s = sin(theta);
    lx = parms.lx; ly = parms.ly;
    A  = [c -lx*s-ly*c; s lx*c-ly*s];
    U  = A\xedot; %U = [v, omega]

    % 5. get v, omega
    v = U(1); omega = U(2);
    
    % 6. get phiLdot and phiRdot
    w = parms.w; r = parms.r;
    phiRdot_current = (v + omega*w)/r;
    phiLdot_current = (v - omega*w)/r;
    phiRdot = [phiRdot; phiRdot_current];
    phiLdot = [phiLdot; phiLdot_current];
    
    % 7. now control the car based on phiRdot and phiLdot
    u = [phiLdot_current phiRdot_current];
    zz = ode4(@differential_drive,[t(i) t(i+1)],z0,parms,u);
    z0 = zz(end,:);
    z = [z; z0];
end


%%%%%% get coarse data for animation
t_interp = linspace(t0,tend,fps*tend);
[m,n] = size(z);
for i=1:n
    z_interp(:,i) = interp1(t,z(:,i),t_interp);
end

figure(1)
animation(t_interp,z_interp,parms);

figure(2)
subplot(2,1,1)
plot(t,phiRdot,'m'); hold on
plot(t,phiLdot,'c');
ylabel('Velocity');
legend('phiRdot','phiLdot','Location','Best');
subplot(2,1,2)
plot(t,e(:,1),'r'); hold on
plot(t,e(:,2),'b'); 
legend('error x','error y','Location','Best');
ylabel('error');
xlabel('time');


function zdot = differential_drive(t,z,parms,u)
r = parms.r; w = parms.w;
phiLdot = u(1); phiRdot = u(2);

%x = z(1);
%y = z(2);
theta = z(3);
R = rotation(theta);
v = [0.5*r*(phiRdot + phiLdot); ...
     0; ...
     0.5*(r/w)*(phiRdot - phiLdot)];
 zdot = R*v;

function R = rotation(theta)
R = [cos(theta) -sin(theta) 0; ...
     sin(theta) cos(theta) 0; ...
     0 0 1];


function animation(t,z,parms)

w = parms.w;
l = parms.l;

rectangle = [0  l l 0 ; %x-coordinate of vertices
            -w/2 -w/2 w/2 w/2]; %y-coorindate of vertices
        [mm,nn] = size(rectangle); 

if (parms.writeMovie)
    mov = VideoWriter(parms.nameMovie); 
    open(mov);
end

%%%%%%% get the position of the marker and store in the variable ze
n = length(t);
for i = 1:n
    x = z(i,1); y = z(i,2); theta = z(i,3);
    [xe,ye] = midpoint2marker(x,y,theta,parms);
    ze(i,:) = [xe ye];
end
           
for i = 1:n
        pause(parms.delay)
            
        theta=z(i,3);
        R = [cos(theta) -sin(theta); %rotation matrix
             sin(theta) cos(theta)];
         newbox = R*rectangle; %rotate the vertices of the box
         
         offset = [z(i,1) z(i,2)]'; %offset is the point about which the circle will move
         offsetmat= repmat(offset,1,nn); %creates nn copies of offset to be added to the vertices of the box.
         
         newbox = newbox + offsetmat; %rotate + translate
         
         plot(ze(1:i,1),ze(1:i,2),'r','Linewidth',2); hold on;
         if (i<n)
         patch(newbox(1,:), newbox(2,:),'blue'); hold off; %patch can be used to put color
         end
              
          axis('equal');
          grid on;
          axis([-2 2 -2 2]); %manually increase the display size
           if (parms.writeMovie)
            axis off %does not show axis
            set(gcf,'Color',[1,1,1]) %set background to white
            writeVideo(mov,getframe);
           end
end % end for loop


if (parms.writeMovie)
    close(mov);
end

function [xe,ye] = midpoint2marker(x,y,theta,parms)

c = cos(theta); s = sin(theta); 
l = [parms.lx; parms.ly];
Xe = [c -s; s c]*l + [x; y];
xe = Xe(1); ye = Xe(2);

function [x,y] = marker2midpoint(xe,ye,theta,parms)
c = cos(theta); s = sin(theta); 
l = [parms.lx; parms.ly];
X = -[c -s; s c]*l + [xe; ye];
x = X(1); y = X(2);