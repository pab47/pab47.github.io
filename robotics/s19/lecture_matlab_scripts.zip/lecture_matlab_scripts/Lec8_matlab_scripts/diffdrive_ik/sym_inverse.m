syms lx ly theta real
A = [cos(theta) -lx*sin(theta)-ly*cos(theta); ...
     sin(theta)  lx*cos(theta)-ly*sin(theta)];
 
 simplify(inv(A))