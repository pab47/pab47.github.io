function F = fn_nonlinear(x)

%F = exp(x).*(x.^3 - 2*x.^2 - 2*x + 3);
F = (x.^3 - 2*x.^2 - 2*x + 3);