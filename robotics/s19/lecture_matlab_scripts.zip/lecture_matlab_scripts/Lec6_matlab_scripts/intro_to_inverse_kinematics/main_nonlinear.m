

%% plot the function to get sense of the roots
clc
close all

x = linspace(-2,3);
F = fn_nonlinear(x);
plot(x,F);
grid on;

%% solving the equation %%
x0 = 4; %-1, 1, 2
options = optimoptions('fsolve','Display','iter','MaxIter',100,'MaxFunEval',300);
[x,fval,exitflag] = fsolve('fn_nonlinear',x0,options)

%fn_nonlinear(x)
