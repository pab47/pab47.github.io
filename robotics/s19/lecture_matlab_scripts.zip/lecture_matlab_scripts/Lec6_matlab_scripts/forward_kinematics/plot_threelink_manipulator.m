clc
clear all
close all
%%% This example does an animation of a three link manipulator with 1 rotational and two prismatic joint
% <<three_link_2sliders_1rot.png>>

%%% Specify parameters and get transformation matrices
%D-H for link 1
a1 = 0; alpha1 = 0; d1=0.5; theta1 = pi/2;
A01 = DH(a1,alpha1,d1,theta1); %A^0_1

%D-H for link2
a2 = 0; alpha2 = -pi/2; d2=0.2; theta2 = 0;
A12 = DH(a2,alpha2,d2,theta2); %A^1_2

%D-H for link3
a3 = 0; alpha3 = 0; d3=0.2; theta3 = 0;
A23 = DH(a3,alpha3,d3,theta3); %A^2_3

%%% Get locations of joints
%Location of joint 1
endOfLink1 = A01(1:3,4);

%Location of joint 2
A02 = A01*A12;
endOfLink2 = A02(1:3,4);

%Location of joint 3
A03 = A01*A12*A23;
endOfLink3 = A03(1:3,4);

%end-effector position and orientation.
position_of_end_effector = A03(1:3,4)
orientation_of_end_effector = A03(1:3,1:3)


%%% Draw lines from one joint to another 
%Draw line from origin to end of link 1
line([0 endOfLink1(1)],[0 endOfLink1(2)],[0 endOfLink1(3)],....
      'LineWidth',5,'Color','red');

%Draw line from end of link 1 to end of link 2
line([endOfLink1(1) endOfLink2(1)],...
     [endOfLink1(2) endOfLink2(2)],...
     [endOfLink1(3) endOfLink2(3)],...
     'LineWidth',5,'Color','blue');
 
%Draw line from end of link 2 to end of link 3
line([endOfLink2(1) endOfLink3(1)],...
     [endOfLink2(2) endOfLink3(2)],...
     [endOfLink2(3) endOfLink3(3)],...
     'LineWidth',5,'Color','cyan');


xlabel('x');
ylabel('y');
zlabel('z');
grid on; %if you want the grid to show up.
axis('equal'); %make the axis equal, to avoid scaling effect
 
% These set the x and y limits for the axis (will need adjustment)
xlim([-1 1]); 
ylim([-1 1]);
zlim([-1 1]);

view(3);
view(-37.5,30);
