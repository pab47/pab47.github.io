function error = projectile_constraints(q0,projectile)

q = projectile_sim(q0,projectile);
x = q(end,1); y = q(end,3);
error = [x - projectile.xTarget, y-projectile.yTarget];