
clc
close all
clear all

%Initialize parameters
%properties of the manipulator, mass, inertia, etc. .
parms.m  =  1;   
parms.c  = 1;
parms.k  =  10; 

%proportional, derivative controllers0
parms.kp = 1; %vary from 0 to 1000 and see resonse q vs t
parms.kd = 1*(-parms.c+2*sqrt(parms.m*(parms.k+parms.kp))); 

%set the time
h = 0.001; %step size for integration
t0 = 0;     %start time
tN = 10;     %end time
N = (tN-t0)/h;
t = linspace(t0,tN,N);

% initial conditions
q    = 0.5; 
qdot    = 0;          
x0=[q qdot]';

%integrate equations of motion
x = ode4('smd_rhs',t,x0,parms);


%our goal is to reach q=0 as soon as possible
figure(1) 
plot(t,x(:,1),'b'); grid on;
xlabel('time');
ylabel('position');

