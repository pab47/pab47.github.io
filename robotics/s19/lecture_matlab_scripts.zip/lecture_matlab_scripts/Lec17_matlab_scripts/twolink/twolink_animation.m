function twolink_animation(t,x,parms)

%downsample data for animation
tspan = linspace(t(1),t(end),parms.framespersec*(t(end)-t(1)));
x = interp1(t,x,tspan); %down-sample x to enable animation

for i=1:length(x) %plot in a loop.
    
    clf %clear figure axis. This ensures the old plot is erased completely.
    
    %%% Specify parameters and get transformation matrices
    %D-H for link 1
    a1 = parms.a1; alpha1 = parms.alpha1; d1=parms.d1; 
    A01 = DH(a1,alpha1,d1,x(i,1)); %A^0_1
    
    %D-H for link 2
    a2 = parms.a2; alpha2 = parms.alpha2; d2=parms.d2; 
    A12 = DH(a2,alpha2,d2,x(i,2)); %A^1_2

    %%% Get locations of joints
    %Location of joint 1
    endOfLink1 = A01(1:3,4);
    
    %Location of joint 2
    A02 = A01*A12;
    endOfLink2 = A02(1:3,4);

    %Plot the hinge point at 0,0,0.
    plot3(0,0,0,'o','MarkerSize',10,'MarkerFaceColor','black'); hold on;

    %%% Draw lines from one joint to another 
    %Draw line from origin to end of link 1
    line([0 endOfLink1(1)],[0 endOfLink1(2)],[0 endOfLink1(3)],....
          'LineWidth',5,'Color','red');
      
    %Draw line from end of link 1 to end of link 2
     line([endOfLink1(1) endOfLink2(1)],...
     [endOfLink1(2) endOfLink2(2)],...
     [endOfLink1(3) endOfLink2(3)],...
     'LineWidth',5,'Color',[0 0.6 0.3]); %[0 0.6 0.3] are rgb values as fractions --> [red green blue]
      
    axis('equal');
    
    % These set the x,y,z limits for the axis (will need adjustment)
    xlim([-2 2]); 
    ylim([-2 2]);
    zlim([-2 2]);
    view(2) %for a 2-d animation
    %view(3) %for a 3-d animaton
    %view([-12,20]); %gives you more control over a 3d animation (type help view for more info)
    
    pause(parms.time_delay); %pause for sometime (will need adjustment depending on the problem)
end