%% Rowdy
clc
clear
close all

G = imread('rowdy.png'); %read the png file
figure
imshow(G); %show the unaltered image

I = im2bw(G,0.8); %convert any colors that aren't white to black
BW = edge(I,'canny'); %trace the borders of the new bw image

figure
imshow(I); % show the converted bw image from above

[B,L] = bwboundaries(BW,'noholes');% convert the border to white data points on the image
figure
imshow(BW); %show the new white data points

dim = size(BW); %find the dimensions of the image
col = round(dim(2)/2)-90; %choose column value
row = min(find(BW(:,col))); %choose a corresponding row value

boundary = bwtraceboundary(BW,[row, col],'N'); %trace the boundary of the image

figure
imshow(I) %show the bw image
hold on;
plot(boundary(:,2),boundary(:,1),'g','LineWidth',3); %show the boundary

columns = boundary(:,2); %new values for the boundary columns in x
rows = boundary(:,1); %new values for the boundary rows in y

figure
plot(columns,rows)

t_simple = linspace(0,60*pi,length(rows))'; %timesteps for parametrization
Mc = max(columns); %find max column value
Mr = max(rows); %find min column value
mc = min(columns); %find max row value
mr = min(rows); %find min row value

difc = (Mc - mc)/2; %find the middle column
difr = Mr - mr; %find the middle row

columns = columns - difc; %adjust the column data around the origin
rows = rows - difr; %adjust the row data around the origin


figure
plot(columns,-rows); %verify that the data is adjusted

[theta,rho] = cart2pol(rows,columns); %convert x-y to polar

figure
polarplot(theta,rho);

theta = theta-pi/2; %rotate the data to reflect the original image
hold on;
figure
polarplot(theta,rho,'g'); %plot the new polar rowdy

figure
plot(t_simple,theta);

figure
plot(t_simple,rho);


theta_xls = xlsread('rowdy_polar.xlsx','A1:A2410'); %import ordered data
rho_xls = xlsread('rowdy_polar.xlsx','B1:B2410'); %import ordered data

t_adj = linspace(0,2*pi,length(rho_xls))'; %new time for parametrics

figure
plot(t_adj,theta_xls);

figure
plot(rho_xls);



rho_adj = rho_xls/20; %scale down the radius

figure
polarplot(theta_xls,rho_xls); %show the original imported data
hold on
polarplot(theta_xls,rho_adj,'r'); %show the scaled imported data

t = t_adj;

e_r = 11.6780633156058 + 5.25737866674741.*sin(0.379873080930965.*t.^2 - 0.410797114659848.*t) + -15.0338841955986.*sin(9.01717345398399.*t)./(18.4868878908716 + 9.01717345398399.*cos(t) + t.*sin(9.01717345398399.*t)) + atan(9.01717345398399.*cos(t)) - asin(cos(7.9712359849161.*t));

e_th = 0.556738090065424.*atan(t) + 0.010487943000249.*t.^3.*sin(t) + sqrt(0.010487943000249.*t).*cos(5.95913927067941 + 8.19679130439689.*t) - 1.77704993174192 - 0.195473619171639.*cos(5.95913927067941 + 8.19679130439689.*t) - 1.83359205127117.*atan(11.1783053639771 - 2.75262576041691.*t);

%above are the equations from eureqa
figure
polarplot(e_th,e_r); %plot of the parametric equations

figure
polarplot(e_th,e_r,'b');
hold on
polarplot(theta_xls,rho_adj,'r'); %plot of original rowdy data
legend('using equations','actual outline');
