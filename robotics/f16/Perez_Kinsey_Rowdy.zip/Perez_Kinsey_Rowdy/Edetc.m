clf
clc
clear all

%Transform .png to a gray scale 
RGB = imread('RSiloInv.png');
I = rgb2gray(RGB);

%Edge function only reads gray scale 
BW = edge(I,'Canny');
figure(1)
imshow(BW)

%find the x and y values of the binary image 
[y, x] = find(BW);

%Check if the x, y points are correct
figure(2)
plot(x,y);

u = transpose(y);
v = transpose(x);

figure(3)
scatter(v, u, 5, 'filled');

Lu = length(u);
Lv = length(v);
j = 1;
b = 1;
c = 1;
d = 1;

%rearrange the order of the points 
for i = 1:2:Lu
    u21(1,j) = u(1,i);
    j = j + 1;
end

for i = 2:2:Lu
    u22(1,b) = u(1,i);
    b = b+1;
end

for i = 1:2:Lv
    v21(1,c) = v(1,i);
    c = c + 1;
end

for i = 2:2:Lv
    v22(1,d) = v(1,i);
    d = d+1;
end

u2 = [u21 u22];
v2 = [v21 v22];

%Rearrange data points to follow the nearest neighboor
[Xout,Yout]=points2contour(u2, v2,1,'cw');

F1 = [Yout-179; Xout-116].';
F2 = csaps(Yout,Xout);
F = transpose(F1);
FO = fit(transpose(Yout),transpose(Xout),'smoothingspline');

figure(4)
t=linspace(0,pi,1000);
X = 369.289952366726 + 868.097877893622.*t.^2 + 355.885451199134.*sin(1.80851770543267.*t) + 1.80851770543267.*exp(t).*sin(1.01940232088457 + 14.9409026016358.*t - 1.80851770543267.*sin(1.80851770543267.*t)) - 1050.6292596086.*t - 229.582690842127.*exp(t) - 24.3720475907521.*sin(1.01940232088457 + 14.9409026016358.*t - 1.80851770543267.*sin(1.80851770543267.*t));
Y = 197.771135039485.*sin(t) + 12.2725932807796.*sin(4.55931255905606.*t) + 0.000353251212376122.*sin(t).*exp(10.6716820645944.*sin(t)).*sin(5.64900764980555 + 11.4302916545718.*t) - 7.12454145678416 - 111.322673046081.*t.*sin(t) - 8.71761475813689.*sin(5.64900764980555 + 11.4302916545718.*t);
plot(X,Y,'b','Linewidth',2)
axis('equal')
axis off
set(gcf,'Color',[1,1,1])
hold on
plot(Yout-179, Xout-116, 'r:','LineWidth',4);
lgd = legend('Fit','Original','Location','Best');
lgd.FontSize = 26;
%xlswrite('vars.xlsx', v2, 1);
%xlswrite('vars.xlsx', u2, 2);
%xlswrite('BW.xlsx',I,1);
