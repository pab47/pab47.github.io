clc
clear all
close all

sim=remApi('remoteApi'); % using the prototype file (remoteApiProto.m)
sim.simxFinish(-1); % just in case, close all opened connections
clientID=sim.simxStart('127.0.0.1',19999,true,true,5000,5);
sim.simxStartSimulation(clientID,sim.simx_opmode_oneshot);

tstart = tic;
total = 4;%end time
if (clientID>-1)
      disp('Connected to remote API server');
       %[number returnCode,number handle]=simxGetObjectHandle(number clientID,string objectName,number operationMode)
       [r,projectile]=sim.simxGetObjectHandle(clientID,'Projectile',sim.simx_opmode_blocking);
       
       %[number returnCode]=simxSetArrayParameter(number clientID,number paramIdentifier,array paramValues,number operationMode)
       sim.simxSetArrayParameter(clientID,sim.sim_arrayparam_gravity,[0 0 -9.81],sim.simx_opmode_oneshot);
       
       %%%%% send multiple data streams by halting communication and resuming
       %https://www.coppeliarobotics.com/helpFiles/en/remoteApiFunctionsMatlab.htm#simxPauseCommunication
       sim.simxPauseCommunication(clientID,1);
       %[number returnCode,array outInts,array outFloats,string outStrings,array outBuffer]
       %=simxCallScriptFunction
       %(number clientID,string scriptDescription,number scriptHandleOrType,string functionName,array inInts,array inFloats,string inStrings,array inBuffer,number operationMode)
       [res retInts retFloats retStrings retBuffer]=sim.simxCallScriptFunction(clientID,'Projectile',sim.sim_scripttype_childscript,'User_resetDynamicObject',[],[],[],[],sim.simx_opmode_oneshot);
        sim.simxSetObjectFloatParameter(clientID,projectile,3000,1,sim.simx_opmode_oneshot);
        sim.simxSetObjectFloatParameter(clientID,projectile,3001,0,sim.simx_opmode_oneshot);
        sim.simxSetObjectFloatParameter(clientID,projectile,3002,1,sim.simx_opmode_oneshot);
        sim.simxPauseCommunication(clientID,0);
        [returnCode,linearVelocity,angularVelocity]=sim.simxGetObjectVelocity(clientID,projectile,sim.simx_opmode_streaming);
            
       while(1) 
            [returnCode,linearVelocity,angularVelocity]=sim.simxGetObjectVelocity(clientID,projectile,sim.simx_opmode_buffer);
            c = 0.25;
            vx = linearVelocity(1);
            vy = linearVelocity(2);
            vz = linearVelocity(3);
            v = sqrt(vx^2+vy^2+vz^2);
            Fx = -c*vx*v;
            Fy = -c*vy*v;
            Fz = -c*vz*v;
            force = [Fx,Fy,Fz];
            [res retInts retFloats retStrings retBuffer]=sim.simxCallScriptFunction(clientID,'Projectile',sim.sim_scripttype_childscript,'User_addForceTorque',[],force,[],[],sim.simx_opmode_blocking); 
            if (toc(tstart)>total)
                break;
            end
        end
       %%%%%%%%%%%%% 
 
else
     disp('Failed connecting to remote API server');
end
  
sim.simxStopSimulation(clientID,sim.simx_opmode_oneshot)
sim.simxSetArrayParameter(clientID,sim.sim_arrayparam_gravity,[0 0 0],sim.simx_opmode_oneshot); 

sim.delete(); % call the destructor!
       
disp('Program ended');

