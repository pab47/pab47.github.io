close all
clf
clear all

figh = figure(1)
img1=imread('Picture3.png');
imagesc(img1);
text(45,550, 'being thirsty and hot, Surely I must soon die  for not having water', 'color','b');
pause(.25)

% figh = figure(1);
% plot(1:10,1:10)
pos = get(figh,'position');

% figure
% set(figh,'position',[pos(1:2)/2 pos(3:4)*2])
% figure
set(gcf,'position',[10 60 1200 1500])
% figure
% set(figh,'position',[pos(1:2)/4 pos(3:4)*4])

