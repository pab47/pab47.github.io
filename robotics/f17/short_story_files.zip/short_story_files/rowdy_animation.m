close all
clear all
clc
r=12;
n=10;  % number of iteration for flying time
i=1;
vp=1 % pause time 
% axis([-250 950 -150 830]);
% hold on
theta=linspace(-pi,pi,50);
theta2=linspace(-pi,pi/2,50);
[X,Y] = rowdy_data;

% for wings
x_wings=[-25 -27 -54 -12 -3 5 -25 ];
y_wings=[0 23 40 35 25 0 0];
% x_wings=r*cos(theta2);
% y_wings=2*r*cos(theta)
% eyes
x_eye=50+r*cos(theta);
y_eye=-10+r*sin(theta);
x_eye_inside=50+r*.75*cos(theta);
y_eye_inside=-10+r*.75*sin(theta);
% legs
x_leg=[-10 -27 -18];
y_leg=[-80 -100 -115];

video=1;
if (video==1)
    mov=VideoWriter('G:\Animation2');
    open(mov);
end


% line(x_wings,y_wings,'Color','r','Linewidth',10)
c=0;
txx={'Water','I am thirsty ','Help please','I am going to die..', 'water'};
for i=1:.02:n
    pause(.2);
%     axis([min(X)-60 max(X)+50 min(Y)-30 max(Y)+30])
    q1=plot(X+i,Y+i);
    hold on
    q2=patch(X+i,Y+i,[.5 .5 .5]);
    if (mod(i+.8,1)==0)
%         pause(.01)
        as=text(80+i,-70+i,txx(randi(length(txx))),'color','b','FontSize',15)
        pause(4)
        if(video==1)
           axis off
           set(gcf, 'color', [1 1 1]);
           writeVideo(mov, getframe);
          end  
        
    end
    
    q3=plot(x_eye+i,y_eye+i,'k');
    q4=patch (x_eye_inside+i,y_eye_inside+i,'ko','markerfacecolor','b');
    q5=line(x_leg+i,y_leg+i,'Color',[.5 .5 .5],'Linewidth',3);
    q6=line(x_leg-13+i,y_leg+i,'Color',[.5 .5 .5],'Linewidth',3);
    q7=patch(x_wings+i,y_wings+i,[.5 .5 .5]);
%     pause(.2)
%     axis([-400 400 -400 400]);
    if (mod(i,10)<8)
        q8=patch(x_wings+i,y_wings+i,[.5 .5 .5]);
        y_wings=-y_wings;
        pause(.1)
%         patch(x_wings,y_wings,'r');
%         hold off
    end
%     c=c+i;
%     X=X+i;
%     Y=Y+i;
%     x_eye=x_eye+i;
%     y_eye=y_eye+i;
%     x_eye_inside=x_eye_inside+i;
%     y_eye_inside=y_eye_inside+i;
%     x_wings=x_wings+i;
%     y_wings=y_wings+i;
%     x_leg=x_leg+i;
%     y_leg=y_leg+i; 
hold off
if(video==1)
    axis off
    set(gcf, 'color', [1 1 1]);
    writeVideo(mov, getframe);
end   

end
hold on
% set(gcf,'position',[10 60 1200 1500])
%  rectangle('position',[50 -120 50 50],'curvature',[1 1]);

pause(.04)
% Drawing  a Pitcher / jar
f=5; % a factor to make the pitcher bigger / smaller
x_jar=i+180+5*f*cos(theta);  % ellipse for pitcher / jar
y_jar=i+1*f*sin(theta)-60;    % ellipse for jar
y_jarb=i+1*f*sin(theta)-120;   % ellipse for jar at bottom 
p=plot(x_jar,y_jar,'b',x_jar,y_jarb,'b','linewidth',2);

jar_xl=i+180+[-5*f -5*f ];
jar_yl=i+[0 -60 ]-60;
line(jar_xl,jar_yl,'linewidth',2,'color','b'),
jar_xr=i+180+[ 5*f 5*f];
jar_yr=i+[-60 0]-60;
line(jar_xr,jar_yr,'linewidth',2,'color','b');


% i=in;
% pebble
m=4; % a factor for sizing the pebbles in jar
ra=[1  4 -17 17  7  9 - 3  -5  -7  -9  11  13 -11  -13 15 -15];

co={'b','r','[.5 .5 .5]','c','o'};   % color pebbles 
nm=30;  % number  of pebbles in jar at the end
t=1;
xp=[i+180-5*f  i+180-5*f i+180+5*f i+180+5*f];
yp=[2*t+i+1*f-120 i+1*f-130 i+1*f-130 2*t+i+1*f-120];
patch(xp,yp,'b');
wp=[];

tp2=text(-20+i,70+i,sprintf('There I can see some pebbles.\n I can drop them  in the pitcher. '),'FontSize',13);
pause(3)
if(video==1)
    axis off
    set(gcf, 'color', [1 1 1]);
    writeVideo(mov, getframe);
end

for t=1:nm
pause(.05);
tx=randi(length(ra));
pos=ra(tx);         % position for dropping pebbles in the pitcher
px=i+m*cos(theta);   % drawing   pebbles 
py=i+m*sin(theta);
yp=[2*t/4+i+1*f-120 i+1*f-130 i+1*f-130 2*t/4+i+1*f-120];

% yp=[2*t+i+1*f-120 i+1*f-130 i+1*f-130 2*t+i+1*f-120];
wp(t)=patch(xp,yp,'b');
plot(px+180+pos, py-c-115+t/10);   % plot pebbles in the jar
if(video==1)
    axis off
    set(gcf, 'color', [1 1 1]);
    writeVideo(mov, getframe);
end
% tf=t;
end
% set(tp2, 'Visible', 'Off');
pause(5);
delete(tp2);
% drawnow 
%  guide 
% figure
% th2=linspace(-pi/3, pi/3, 30);
% water=sin(th2)
% plot(th2,water);
t
% for another rowdy using rotation matrix 
X=X+i;
Y=Y+i;

p=[X'; Y'];
thetar=-pi/12;
R=[cos(thetar) -sin(thetar)
    sin(thetar) cos(thetar)];
nX=R*p;

% for wings
r_wings=[x_wings+i; y_wings+i];
% eye
r_eye= [x_eye+i ; y_eye+i];
r_eye_in=[x_eye_inside+i; y_eye_inside+i];
% legs
r_leg=[x_leg+i ; y_leg+i];

rr_wings=R*r_wings;
rr_eye=R*r_eye;
rr_eye_in=R*r_eye_in;
rr_leg=R*r_leg;

pause(.05)
delete(as);
set(q1,'Visible','off'); set(q2,'Visible','off'); set(q3,'Visible','off'); 
set(q4,'Visible','off'); set(q5,'Visible','off'); set(q6,'Visible','off');
set(q7,'Visible','off'); set(q8,'Visible','off');

% 
% if(video==1)
%     axis off
%     set(gcf, 'color', [1 1 1]);
%     writeVideo(mov, getframe);
% end

% pause(vp)
% delete(p1);
% delete(p2);
% delete(p3);
% delete(p7);
% delete(p8);
% delete(p5);
nX=nX+20;
% nX()
pause(.05)
h1=plot(nX(1,:), nX(2,:));
h2=patch(nX(1,:), nX(2,:), [.5 .5 .5]);
h3=patch(rr_wings(1,:),rr_wings(2,:),[.5 .5 .5]);
h4=plot(r_eye(1,:),r_eye(2,:),'k');
h5=patch(rr_eye_in(1,:),rr_eye_in(2,:),'ko');
h6=plot(rr_leg(1,:),rr_leg(2,:)-15,'k');
h7=plot(rr_leg(1,:)+13,rr_leg(2,:)-15,'k');
if(video==1)
    axis off
%     set(gcf, 'color', [1 1 1]);
    writeVideo(mov, getframe);
end

% move pitcher close to rowdy
% Drawing  a Pitcher / jar
% f=5; % a factor to make the pitcher bigger / smaller
% mv=0;
% x_jar=i+mv+180+5*f*cos(theta);  % ellipse for pitcher / jar
% y_jar=i+mv+1*f*sin(theta)-60;    % ellipse for jar
% y_jarb=i+mv+1*f*sin(theta)-120;   % ellipse for jar at bottom 
% p=plot(x_jar,y_jar,'b',x_jar,y_jarb,'b','linewidth',2);
% % set(p,100,-10);
% jar_xl=i+mv+180+[-5*f -5*f ];
% jar_yl=i+mv+[0 -60 ]-60;
% line(jar_xl,jar_yl,'linewidth',2,'color','b'),
% jar_xr=i+mv+180+[ 5*f 5*f];
% jar_yr=i+mv+[-60 0]-60;
% line(jar_xr,jar_yr,'linewidth',2,'color','b')

% nm=30;  % number  of pebbles in jar

xp=[i+180-5*f  i+180-5*f i+180+5*f i+180+5*f];
x_straw=[170+i 180+i];
y_straw=[-65+i -115+i];
line(x_straw, y_straw, 'color', 'b','linewidth',3);
t1=text(40+i,70+i, sprintf('Oh! I have got a straw. \n I can take water with this.'),'FontSize',12);
pause(3)
if(video==1)
    axis off
    set(gcf, 'color', [1 1 1]);
    writeVideo(mov, getframe);
end
for t=nm:-1:7
   
% tx=randi(length(ra));
% pos=ra(tx);         % position for dropping p[ebbles in the pitcher
% px=i+m*cos(theta);   % drawing   pebbles 
% py=i+m*sin(theta);
% plot(px+180+pos, py+c-115+t*3)   % plot pebbles in the jar

pause(.05);
yp=[2*t/4+i+1*f-120 i+1*f-130 i+1*f-130 2*t/4+i+1*f-120];

delete (wp(t));
if(video==1)
    axis off
%     set(gcf, 'color', [1 1 1]);
    writeVideo(mov, getframe);
end

% patch(xp,yp,[1 1 1]);
tf=t;
end
pause(.05)
set(h1,'Visible','off'); set(h2,'Visible','off'); set(h3,'Visible','off'); 
set(h4,'Visible','off'); set(h5,'Visible','off');
delete(h6);
delete(h7);
pause(1)
delete(t1);
pause(.05)
set(q1,'Visible','on'); set(q2,'Visible','on'); set(q3,'Visible','on');
set(q4,'Visible','on'); set(q5,'Visible','on'); set(q6,'Visible','on');
set(q7,'Visible','on'); set(q8,'Visible','on');

pause(.1)
text(-100+i,75+i,'Necessity is the mother of invention','FontSize',15, 'color','b');
pause(3)

if(video==1)
    axis off
    set(gcf, 'color', [1 1 1]);
    writeVideo(mov, getframe);
end

% 
% figure
% img1=imread('Picture3.png');
% imagesc(img1);
% text(45,550, 'being thirsty and hot, Surely I must soon die  for not having water', 'color','b');
% pause(.25)
% 
% figure
% img=imread('Picture2.jpg');
% imagesc((img));
% text(5,520, sprintf('Thirsty roadrunner now disapppointed to see \n water is so little that her beck can barely reach it'));
% pause(.25)
% 
% figure
% img=imread('Picture4.jpg');
% imagesc((img));
% text(5,400,'The moral Roadrunner teaches us ''Necessity Is the mother of invention''');
% pause(.25)
% 
% figure
% img=imread('Picture1.png');
% imagesc((img));
% text(100,60,'Happy ..Ha ..Ha .. Ha.')

if(video==1)
   close(mov);
end

   % figure
% [ax,ay,az]=sphere(25);
% surf(ax+100,ay-100,az)
% set(g, 'color', 'b')
% water=
% [gx,gy,gz]=cylinder(25);
% surf(gx,gy,gz);
% view(3)
%  axis([min(X)-60 max(X)+50 min(Y)-100 max(Y)+30]);