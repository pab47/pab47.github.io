close all
clear all
clc
i=25;

theta=linspace(-pi,pi,50);
theta2=linspace(-pi,pi/2,50);
[X,Y] = rowdy_data;
p=[X'; Y'];
thetar=-pi/12;
R=[cos(thetar) -sin(thetar)
    sin(thetar) cos(thetar)];

nX=R*p;

axis([100 300 -150 30]);
hold on;

% Drawing  a Pitcher / jar
f=5; % a factor to make the pitcher bigger / smaller
x_jar=i+180+5*f*cos(theta);  % ellipse for pitcher / jar
y_jar=i+1*f*sin(theta)-60;    % ellipse for jar
y_jarb=i+1*f*sin(theta)-120;   % ellipse for jar at bottom 
p=plot(x_jar,y_jar,'b',x_jar,y_jarb,'b','linewidth',2);
xp=[i+180-5*f  i+180-5*f i+180+5*f i+180+5*f];
% yp=[10+i+1*f-120 i+1*f-130 i+1*f-130 10+i+1*f-120];
% patch(xp,yp,'b')
% plot(x_jar+55,'k')
% set(p,100,-10);
jar_xl=i+180+[-5*f -5*f ];
jar_yl=i+[0 -60 ]-60;
line(jar_xl,jar_yl,'linewidth',2,'color','b'),
jar_xr=i+180+[ 5*f 5*f];
jar_yr=i+[-60 0]-60;
line(jar_xr,jar_yr,'linewidth',2,'color','b'),
% pebble
m=8; % a factor for sizing the pebbles in jar
ra=[5 9 -11  14 6 -7 -11 8 3  -10 12 ];
co={'b','r','[.5 .5 .5]','c','o'};   % color pebbles 
nm=15;  % number  of pebbles in jar
c=0;
for t=1:nm
tx=randi(length(ra));
pos=ra(tx);         % position for dropping p[ebbles in the pitcher
px=i+m*cos(theta);   % drawing   pebbles 
py=i+m*sin(theta);
hold on;
plot(px+180+pos, py+c-115+t*3)   % plot pebbles in the jar
% y_jar=i+1*f*sin(theta)-60;    % ellipse for jar
% y_jarb=i+1*f*sin(theta)-120;   % ellipse for jar at bottom
% patch(y_jar,y_jarb,'b' )
pause(.2)
yp=[2*t+i+1*f-120 i+1*f-130 i+1*f-130 2*t+i+1*f-120];
patch(xp,yp,'b');



tf=t;
end