function dx=odes(t,x)
%%% parameters of hand
%======================
L1=0.31;L2=0.27;L3=0.15;
I1=0.0141;I2=0.0120;I3=0.001;
m1=1.93;m2=1.32;m3=0.35;
d1=0.165;d2=0.135;d3=0.075;
%%% Insertion of each muscle
%======================
r1=0.055;r2=0.055;
r3=0.03;r4=0.03;
r5=0.035;r6=0.050;
s1=0.08;s2=0.08;
s3=0.12;s4=0.12;
s5=0.22;s6=0.25;
%%% length of each muscle
%======================
l1=(r1^2+s1^2+2*r1*s1.*cos(x(1)).^2).^(0.5);
l2=(r2^2+s2^2-2*r2*s2.*cos(x(1)).^2).^(0.5);
l3=(r3^2+s3^2+2*r3*s3.*cos(x(2)).^2).^(0.5);
l4=(r4^2+s4^2-2*r4*s4.*cos(x(2)).^2).^(0.5);
l5=(r5^2+s5^2-2*r5*s5.*cos(x(3)).^2).^(0.5);
l6=(r6^2+s6^2-2*r6*s6.*cos(x(3)).^2).^(0.5);
l=[l1 l2 l3 l4 l5 l6];
%%%e Jacobian matrix from the joint space to the muscle space
%======================
q11=-r1*s1.*sin(x(1))./(r1^2+s1^2+2*r1*s1.*cos(x(1)).^2).^(0.5);
q12=r2*s2.*sin(x(1))./(r2^2+s2^2-2*r2*s2.*cos(x(1)).^2).^(0.5);
q23=-r3*s3.*sin(x(2))./(r3^2+s3^2+2*r3*s3.*cos(x(2)).^2).^(0.5);
q24=r4*s4.*sin(x(2))./(r4^2+s4^2-2*r4*s4.*cos(x(2)).^2).^(0.5);
q35=-r5*s5.*sin(x(2))./(r5^2+s5^2+2*r5*s5.*cos(x(3)).^2).^(0.5);
q36=r6*s6.*sin(x(2))./(r6^2+s6^2-2*r6*s6.*cos(x(3)).^2).^(0.5);
W=[q11,q12,0,0,0,0;
   0,0,q23,q24,0,0;
   0,0,0,0,q35,q36];
Wplus=W'/(W*W');
%%% Jacobian matrix from the task space to the joint space 
%======================
J(1,1)=-L1*sin(x(1))-L2*sin(x(1)+x(2))-L3*sin(x(1)+x(2)+x(3));
J(1,2)=-L2*sin(x(1)+x(2))-L3*sin(x(1)+x(2)+x(3));
J(1,3)=-L3*sin(x(1)+x(2)+x(3));
J(2,1)=L1*cos(x(1))+L2*cos(x(1)+x(2))+L3*cos(x(1)+x(2)+x(3));
J(2,2)=L2*cos(x(1)+x(2))+L3*cos(x(1)+x(2)+x(3));
J(2,3)=L3*cos(x(1)+x(2)+x(3));

 

%%% *desired path and controller parameters*
% %========================================*
Xd=-0.1935+0.10*cos(t*0.2);Yd=0.5549+0.10*sin(t*0.2);
Kp=25*diag(ones(1,2));Ke=20*ones(6,1);


%%% controller configuration on hill muscle model
%========================================
X=L1*cos(x(1))+L2*cos(x(1)+x(2))+L3*cos(x(1)+x(2)+x(3));
Y=L1*sin(x(1))+L2*sin(x(1)+x(2))+L3*sin(x(1)+x(2)+x(3));
alpha=-Wplus*J'*Kp*[X-Xd;Y-Yd]+(eye(6,6)-Wplus*W)*Ke;
alpha(alpha<0)=0;
A=diag(alpha);
U=ones(1,6)';
B=diag(ones(1,6)*10);
B0=diag(ones(1,6)*10);
F=A*U-(A*B+B0)*W'*[x(4);x(5);x(6)];
T(1:3)=W*F;
%%% dynamics equation+ ode's
%========================================
M(1,1)=m1*d1^2+I1+m2*(L1^2+d2^2+2*L1*d2.*cos(x(2)))+I2+...
    m3*(L1^2+L2^2+d3^2+2*L1*L2.*cos(x(2))+2*L1*d3*cos(x(2)+x(3))+2*L2*d3*cos(x(3)))+I3;
M(1,2)=m2*(d2^2+L1*d2*cos(x(2)))+I2+m3*(L2^2+d3^2+L1*L2*cos(x(2))...
       +L1*d3*cos(x(2)+x(3))+2*L2*d3*cos(x(3)))+I3;
M(1,3)=m3*(d3^2+L1*d3*cos(x(2)+x(3))+L2*d3*cos(x(3)))+I3;
M(2,1)=m2*(d2^2+L1*d2*cos(x(2)))+I2...
       +m3*(L2^2+d3^2+L1*L2*cos(x(2))+2*L2*d3*cos(x(3))+L1*d3*cos(x(2)+x(3)))+I3;
M(2,2)=m2*d2^2+I2+m3*(L2^2+d3^2+L2*d3*cos(x(3)))+I3;
M(2,3)=m3*(d3^2+L2*d3*cos(x(3)))+I3;
M(3,1)=m3*(d3^2+L1*d3*cos(x(2)+x(3))+L2*d3*cos(x(3)))+I3;
M(3,2)=m3*(d3^2+L2*d3*cos(x(3)))+I3;
M(3,3)=m3*d3^2+I3;
C(1)=-((m2*L1*d2+m3*L1*L2)*sin(x(2))+m3*L1*d3*sin(x(2)+x(3)))*(2*x(4)*x(5)+x(5)^2)...
       -(m3*L1*d3*sin(x(2)+x(3))+m3*L2*d3*sin(x(3)))*(2*x(4)*x(6)+2*x(5)*x(6)+x(6)^2);
C(2)=((m3*L1*L2+m2*d2*L1)*sin(x(2))+m3*d3*L1*sin(x(2)+x(3)))*x(4)^2 ...
      -m3*d3*L2*sin(x(3))*(2*x(4)*x(6)+2*x(5)*x(6)+x(6)^2);
C(3)=(m3*L1*d3*sin(x(3)+x(4))+m3*L2*d3*sin(x(3)))*x(4)^2 ...
    +m3*L2*d3*sin(x(3))*(2*x(4)*x(5)+x(5)^2);

dx(1)=x(4);
dx(2)=x(5);
dx(3)=x(6);
dx(4:6)=M\(T'-C');
dx(7:12)=F;
dx=dx';
end