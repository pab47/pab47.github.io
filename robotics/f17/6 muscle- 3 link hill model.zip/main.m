clc;clear all;close all
T_time=10*pi; %% total time of simulation
init_cond=[pi/3 pi/3 pi/3];  %%initial angles if shoulder, elbow and wrist
options = odeset('RelTol',1e-4);
[t,state] = ode45(@odes,[0 T_time],[init_cond(1) init_cond(2) init_cond(3)...
                  0 0 0 0 0 0 0 0 0],options);

%%%%%% plot trajectory and desired path  
%==================
figure(1)

T=0:0.1:T_time;
Xd=-0.1935+0.10*cos(T*0.2);Yd=0.5549+0.10*sin(T*0.2);%% desired path
L1=0.31;L2=0.27;L3=0.15;
x3=L1*cos(state(:,1))+L2*cos(state(:,1)+state(:,2))+L3*cos(state(:,1)+state(:,2)+state(:,3));
y3=L1*sin(state(:,1))+L2*sin(state(:,1)+state(:,2))+L3*sin(state(:,1)+state(:,2)+state(:,3));
plot(Xd,Yd,'-.',x3,y3)
legend('desired path','Trajectory of hand')
xlabel('x(m)')
ylabel('y(m)')
hold off;
%%%%%%% animation play
%==================
r1=0.055;r2=0.055;
r3=0.03;r4=0.03;
r5=0.035;r6=0.050;
s1=0.08;s2=0.08;
s3=0.12;s4=0.12;
s5=0.22;s6=0.25;
w1=0.04;w2=0.05;
for i=1:35:length(t)
    figure(2)
    L1=0.31;L2=0.27;L3=0.15;
    x0=0;y0=0;  %%shoulder position
    %%% elbow position
    x1=L1*cos(state(i,1));x11=L1*cos(state(i,1))-w1*cos(state(i,1)+state(i,2));
    y1=L1*sin(state(i,1));y11=L1*sin(state(i,1))-w1*sin(state(i,1)+state(i,2)); 
    %%% wirst position
    x2=L1*cos(state(i,1))+L2*cos(state(i,1)+state(i,2));
    x22=L1*cos(state(i,1))+L2*cos(state(i,1)+state(i,2))-w2*cos(state(i,1)+state(i,2)+state(i,3));
    y22=L1*sin(state(i,1))+L2*sin(state(i,1)+state(i,2))-w2*sin(state(i,1)+state(i,2)+state(i,3));
    y2=L1*sin(state(i,1))+L2*sin(state(i,1)+state(i,2));
    %%% hand position
    x3=L1*cos(state(i,1))+L2*cos(state(i,1)+state(i,2))+L3*cos(state(i,1)+state(i,2)+state(i,3));
    y3=L1*sin(state(i,1))+L2*sin(state(i,1)+state(i,2))+L3*sin(state(i,1)+state(i,2)+state(i,3));
    
    %%% desired path
    T=0:0.1:T_time;
    Xd=-0.1935+0.10*cos(T*0.2);Yd=0.5549+0.10*sin(T*0.2);
    plot(Xd,Yd,'-.')
    
    hold on
    plot([x0,x1,x11,x2,x22,x3],[y0,y1,y11,y2,y22,y3],'b','LineWidth',4);
    circle([x0,y0],0.01)
    hold on
    circle([x1,y1],0.01)
    hold on
    circle([x2,y2],0.01)
    hold on
    circle([x3,y3],0.005)
    hold on
    
    %%muscle 1
    M1_r=[-r1,0];M1_s=[s1*cos(state(i,1)),s1*sin(state(i,1))];
    plot([M1_r(1),M1_s(1)],[M1_r(2),M1_s(2)],'r')
    hold on;
    %%muscle 2
    M1_r=[r2,0];M1_s=[s2*cos(state(i,1)),s2*sin(state(i,1))];
    plot([M1_r(1),M1_s(1)],[M1_r(2),M1_s(2)],'r')
    hold on;
    %%muscle 3
    M1_r=[(L1-s3)*cos(state(i,1)),(L1-s3)*sin(state(i,1))];
    M1_s=[L1*cos(state(i,1))+r3*cos(state(i,1)+state(i,2)),...
          L1*sin(state(i,1))+r3*sin(state(i,1)+state(i,2))];
    plot([M1_r(1),M1_s(1)],[M1_r(2),M1_s(2)],'r')
    hold on;
    %%muscle 4
    M1_r=[(L1-s4)*cos(state(i,1)),(L1-s4)*sin(state(i,1))];
    M1_s=[x1-r4*cos(state(i,1)+state(i,2)),...
          y1-r4*sin(state(i,1)+state(i,2))];
    plot([M1_r(1),M1_s(1)],[M1_r(2),M1_s(2)],'r')
    hold on;
    %%muscle 5
    M1_r=[x1+(L2-s5)*cos(state(i,1)+state(i,2)),...
         y1+(L2-s5)*sin(state(i,1)+state(i,2))];
    M1_s=[x2+r5*cos(state(i,1)+state(i,2)+state(i,3)),...
          y2+r5*sin(state(i,1)+state(i,2)+state(i,3))];
    plot([M1_r(1),M1_s(1)],[M1_r(2),M1_s(2)],'r')
    hold on;
    %%muscle 6
    M1_r=[x1+(L2-s6)*cos(state(i,1)+state(i,2)),...
         y1+(L2-s6)*sin(state(i,1)+state(i,2))];
    M1_s=[x2-r6*cos(state(i,1)+state(i,2)+state(i,3)),...
          y2-r6*sin(state(i,1)+state(i,2)+state(i,3))];
    plot([M1_r(1),M1_s(1)],[M1_r(2),M1_s(2)],'r')
    hold on;
    
    xlim([-0.4,0.3])
    ylim([-0.05,0.8])
    xlabel('x(m)')
    ylabel('y(m)')
    pause(0.05)
    hold off
end
%%%%%% muscle forces plot
%=======================
figure(3)
subplot(3,2,1)
plot(t,state(:,7)./t,'r','LineWidth',1.5);
xlabel('t(sec)');ylabel('N')
title('Muscle 1')
subplot(3,2,2)
plot(t,state(:,8)./t,'r','LineWidth',1.5);
xlabel('t(sec)');ylabel('N')
title('Muscle 2')
subplot(3,2,3)
plot(t,state(:,9)./t,'r','LineWidth',1.5);
xlabel('t(sec)');ylabel('N')
title('Muscle 3')
subplot(3,2,4)
plot(t,state(:,10)./t,'r','LineWidth',1.5);
xlabel('t(sec)');ylabel('N')
title('Muscle 4')
subplot(3,2,5)
plot(t,state(:,11)./t,'r','LineWidth',1.5);
xlabel('t(sec)');ylabel('N')
title('Muscle 5')
subplot(3,2,6)
plot(t,state(:,12)./t,'r','LineWidth',1.5);
xlabel('t(sec)');ylabel('N')
title('Muscle 6')
