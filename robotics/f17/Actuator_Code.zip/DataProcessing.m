clc
close all
clear all

trial = 1;

dataSet = 'DAQ_raw_data';
load(dataSet);
dataSet = 'Motor and Eff Pos';
load(dataSet);

n = find(dataDAQ(1,:)>2. & dataDAQ(1,:)<2.1,1);

t = dataDAQ(1,1:n);
effVar = dataExport(1,1:n)*pi/360;
motPos = (pi/360)*dataExport(2,1:n)/11.37;
effPos = motPos + effVar;
trial = num2str(trial);
P = num2str(dataDAQ(4,1));
I = num2str(dataDAQ(4,2));
D = num2str(dataDAQ(4,3));
goalPos = (pi/360)*dataDAQ(4,4)/11.37;

[y,i] = max(effPos);

if y > goalPos
    overShoot = 100*((y - goalPos)/goalPos);
else
    overShoot = 0;
end

riseTime = .9*t(i) - .1*t(i);
M = 5500;
t_con = t(:,M:M:end);
effPos_con = effPos(:,M:M:end);
test = 1;
for i = 2:(length(t_con - 1))
    if abs(effPos_con(1,i)) < abs(effPos_con(1,i-1)) + abs(.00027*effPos_con(1,i-1)) &&...
        abs(effPos_con(1,i)) > abs(effPos_con(1,i-1)) - abs(.00027*effPos_con(1,i-1))
        settleTime = t_con(i);
        break
    end    
end 
Position = [t; effPos; motPos;];
performance = [riseTime settleTime overShoot];

save(strcat('Theta PID(',P,',',I,',',D,') #',trial),'Position');
save(strcat('Performance of PID(',P,',',I,',',D,') #',trial),'performance');

%% Plotting

figure()
effVar = Position(3,:) + Position(2,:);
plot(Position(1,:),effVar)
title('Step Response')
ylabel('Output Angle Variance From Motor (rad)')
xlabel('Time (Seconds)')

figure()
plot(Position(1,:),Position(2,:))
line([Position(1,1) Position(1,length(Position))],[goalPos goalPos],'LineStyle','--')
title('Step Response')
ylabel('End Effector Postion (rad)')
xlabel('Time (Seconds)')

