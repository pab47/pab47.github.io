function [ data ] = thetaConverter( posData )
%THETACONVERTER Summary of this function goes here
%   posData needs

    encoderCPR = 2500;

    data = zeros(length(posData),2);
    Data = zeros(length(posData),4);

    Pos = 0;
    for i = 1:length(posData)
        data(i,1) = posData(1,i);
        Data(i,1) = posData(2,i);
        Data(i,2) = posData(3,i);
    end  

    for i = 1:length(posData)
        if Data(i,1)>5
            Data(i,3) = 1;
        else 
            Data(i,3) = 0;
        end

        if Data(i,2)>5
            Data(i,4) = 1;
        else 
            Data(i,4) = 0;
        end
    end    
    for i = 1:length(posData)-1
        An = Data(i,3);
        An1 = Data(i+1,3);
        Bn = Data(i,4);
        Bn1 = Data(i+1,4);
        if ~An == An1
            if (An1 > An && Bn == 1) || (An1 < An && Bn == 0)
                Pos = Pos + .5*360/encoderCPR;
            end
            if (An1 > An && Bn == 0) || (An1 < An && Bn == 1)
                Pos = Pos - .5*360/encoderCPR;
            end
        end
        data(i,2) = Pos;
    end
end

