clc
close all
clear all
%% Initilize Dynamixel
PORTNUM = 3;  %Current dynamixel2USB com port
BAUDNUM = 1;  %1Mbps
P = 62;
I = 2;
D = 0;

ID = 1;
id = ID;
P_GOAL_POSITION = 30;
CURRENT_POS = 36;
RAM_DERIVATIVE_GAIN = 26;
RAM_INTERGRAL_GAIN = 27;
RAM_PROPORTIONAL_GAIN = 28;
res = 0;
GoalPos = 800; %goal position given in integer ranges from 0 to 4096
MX_64A_Pos = zeros(1,50);


%initialize libraries and open serial port
if ~libisloaded('dynamixel')
   loadlibrary('dynamixel','dynamixel.h')
   res = calllib('dynamixel','dxl_initialize',PORTNUM,BAUDNUM);
end

if libisloaded('dynamixel')
    fprintf('Librarys succesfully loaded\n')
end

if res == 1
   fprintf('Serial port %d to MX64 succesfully opened\n',PORTNUM)
   calllib('dynamixel','dxl_write_byte',ID,RAM_DERIVATIVE_GAIN,D);
   calllib('dynamixel','dxl_write_byte',ID,RAM_INTERGRAL_GAIN,I);
   calllib('dynamixel','dxl_write_byte',ID,RAM_PROPORTIONAL_GAIN,P);
   MX_64A_pos = calllib('dynamixel','dxl_read_word',ID,CURRENT_POS);
end

if res == 0
    calllib('dynamixel','dxl_terminate')
    unloadlibrary dynamixel
    error('Serial port failed to initilize')
end
  
%% Initilize data aquisition
fid1 = fopen('log.bin','w');
daqreset
s = daq.createSession('ni');
s.IsContinuous = true;

s.addAnalogInputChannel('myDAQ1','ai0', 'Voltage');
s.addAnalogInputChannel('myDAQ1','ai1', 'Voltage');
s.Rate = 200000;

lh = addlistener(s,'DataAvailable',@(src, event)logData(src, event, fid1));
prepare(s);
disp('Starting Data Aquisition')
tic
startBackground(s)
beep on
beep
%% Perform operations
if res == 1
    i = 1;
    disp('Moving Dynamixel');
    calllib('dynamixel','dxl_write_word',ID,P_GOAL_POSITION,GoalPos)
    while MX_64A_pos < GoalPos - 55
        MX_64A_pos = calllib('dynamixel','dxl_read_word',ID,CURRENT_POS);
        MX_64A_Pos(1,i) =  MX_64A_pos;
        MX_64A_Pos(2,i) = toc;
        i = i +1;
    end
    MX_64A_Pos(1,i) = calllib('dynamixel','dxl_read_word',ID,CURRENT_POS);
    MX_64A_Pos(2,i) = toc;
    pause(2)
end
%% Stop data aquisition and save data
s.stop;
disp('Stopping Data Aquisition');
%MX_64A_Pos = calllib('dynamixel','dxl_read_word',ID,CURRENT_POS)
delete(lh);
fclose(fid1);

fid2 = fopen('log.bin','r');
[dataDAQ,count] = fread(fid2,[3,inf],'double');
dataDAQ(4,1) = P;
dataDAQ(4,2) = I;
dataDAQ(4,3) = D;
dataDAQ(4,4) = GoalPos;
fclose(fid2);
save('DAQ_raw_data','dataDAQ');
%% Fill in and save motor position data
motorStopTime_Index = find(dataDAQ(1,:)>.5820 & dataDAQ(1,:)<.5821,1);
[Y,I] = max(MX_64A_Pos(1,:));
motorStopTime = MX_64A_Pos(2,I);
MX64pos(1,:) = linspace(0,motorStopTime,motorStopTime_Index);
j = 1;
for i = 1:I
    MX64pos(2,j) = MX_64A_Pos(1,i);
    j = j + -ceil(-motorStopTime_Index/I);
    if j > motorStopTime_Index
       j = motorStopTime_Index;
    end   
end
MX64pos(2,motorStopTime_Index) = MX_64A_Pos(1,I);
MX64pos(2,:) = interp1(MX_64A_Pos(2,1:I),MX_64A_Pos(1,1:I),MX64pos(1,:));
MX64pos(isnan(MX64pos)) = 0;
motorEnd_interp = max(max(MX64pos));
for i = 1:length(dataDAQ)
    if i < length(MX64pos)
        dataDAQ(5,i) = MX64pos(2,i);
    else
        dataDAQ(5,i) = motorEnd_interp;
    end    
end
EEFpos = thetaConverter(dataDAQ);
dataExport(1,:) = EEFpos(:,2);
dataExport(2,:) = dataDAQ(5,:);
save('Motor and Eff Pos','dataExport');
%% Return to initial position, unload libraries and terminate connection
calllib('dynamixel','dxl_write_word',ID,P_GOAL_POSITION,0)

calllib('dynamixel','dxl_terminate')

if libisloaded('dynamixel')
   unloadlibrary dynamixel
end

if ~libisloaded('dynamixel')
      fprintf('\nLibrarys succesfully unloaded\n')
end