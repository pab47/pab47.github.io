clc
close all

ms = MultiStart('UseParallel', true);

NUM = [0,0,0,617300000000.000,1772900000000.00,1221800000000.00,0];
DEN = [1,5245064.27929688,45561815124.3514,597117771613.757,2081474480439.27,1221818088828.15,-44450.8991809386];

[A, B, C, D] = tf2ss(NUM,DEN);

Kp = 1.989;
Ki = 31.19;
Kd = .01325;
Tf = .01944;

PID = pid(Kp,Ki,Kd,Tf);

R = 43500000;
Q = transpose(C)*C
N = 0;

[K,S,e]=lqr(A,B,Q,R,N)
sys=ss(A,B,C,D)

n=length(K);
AA=A - B * K
for i=1:n
    BB(:,i)=B * K(i);
end
display(BB)
CC=C
DD=D
for i=1:n
     sys(:,i)=ss(AA,BB(:,i),CC,DD);
end
sys_LQ = series(pid,sys(:,2));
step(sys_LQ)
stepinfo(sys_LQ)
grid on

I = tf(1,[1 1])
R = 43500000;