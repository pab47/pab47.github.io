clc

r_s = .2;
m_s = 2;
m_L = 5;
L_L = .5;

J_L = (1/3)*m_L*L_L^2 + (2/5)+m_s*r_s^2 + m_s*(L_L + r_s)^2;

y_Set = ThetaVariance.signals.values(160,1)
stepinfo(ThetaVariance.signals.values,tout,y_Set)

figure()
plot(ThetaVariance.time,ThetaVariance.signals.values)
grid on
title('Step Response')
ylabel('Angle (rad)')
xlabel('Time (seconds)')


