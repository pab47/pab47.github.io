tic
clc

ms = MultiStart('UseParallel', true);

Tr_des = 1;
Ts_des = 1;
OS_des = 10;
Vals = zeros(1000,6);

% Kp = 20.11;
% Ki = 13.86;
% Kd = 7;

To = 2;

r_e = .2;
m_e = 2;
m_s = .01; 
m_L = .5;
L_L = .2;
r_s = .015;

Js = .5*m_s*r_s^2;
Jl = (1/3)*m_L*L_L^2 + (2/5)+m_e*r_e^2 + m_e*(L_L + r_e)^2;
Ds = 5;
Ks = 7;

A =[0, 1 0 0;...
    -Ks/Js -Ds/Js Ds/Js 0;...
    0 Ds/Jl  -Ds/Jl 0;...
    0 0 1 0];
      
    
B = [0;...
    (To/Js);...
    0 ;...
    0 ];

C = [0 0 0 1];
D = 0;

% i = 1;
% for Kp = .1:.1:20
%     if Kp == .2
%         Kp
%     end
%     for Ki = .1:.1:20
%         for Kd = .1:.1:20
%             PID = pid(Kp, Ki, Kd);
% 
%             sys = ss(A,B,C,D);
%             sys_Feed = feedback(sys,1);
% 
% 
%             sys_pi = feedback(series(PID,sys),1);
% 
% 
%             [NUM_p, DEN_p] = tfdata(sys_pi);
%             [Ap, Bp, Cp, Dp] = tf2ss(NUM_p{1,1}, DEN_p{1,1});
%             INFO = stepinfo(sys_pi);
% 
%             TR_comp = INFO.RiseTime;
%             TS_comp = INFO.SettlingTime;
%             OS_comp = INFO.Overshoot;
%             
%             if TR_comp <= Tr_des && TS_comp <= Ts_des && OS_comp <= OS_des
%                 Vals(i,1) = Kp;
%                 Vals(i,2) = Kp;
%                 Vals(i,3) = Kp;
%                 Vals(i,4) = TR_comp;
%                 Vals(i,5) = TS_comp;
%                 Vals(i,6) = OS_comp;
%                 i = i + 1;
%             end
%             Kd
%         end
%         Ki
%     end
%     Kp
%end    



[NUM,DEN] = ss2tf(A,B,C,D);
sys = tf(NUM,DEN);
sys_Feed = feedback(sys,1);

sysStable = isstable(sys)
sysStable_Feed = isstable(sys_Feed)

[step_Open,T_Open] = step(sys);
[step_Close,T_Close] = step(sys_Feed);

figure()
plot(T_Open,step_Open)

figure()
plot(T_Close,step_Close)
toc

stepinfo(sys)

stepinfo(sys_Feed)



