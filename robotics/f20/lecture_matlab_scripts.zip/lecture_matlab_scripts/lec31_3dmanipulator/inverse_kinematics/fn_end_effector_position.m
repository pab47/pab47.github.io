function X = fn_end_effector_position(X0)

global d1 a1 alpha1 
global d2 a2 alpha2
global a3 alpha3 theta3
global d4 a4 alpha4 
global d5 a5 alpha5
global d6 a6 alpha6
global x_des y_des z_des
global phi_des theta_des psi_des 

% Get individual theta's from input
theta1=X0(1); theta2=X0(2); d3=X0(3); theta4=X0(4); theta5=X0(5); theta6=X0(6);

%%%%%%%%%%%% DH formulae %%%%%
H01 = DH(a1,alpha1,d1,theta1); 
H12 = DH(a2,alpha2,d2,theta2); 
H23 = DH(a3,alpha3,d3,theta3); 
H34 = DH(a4,alpha4,d4,theta4);
H45 = DH(a5,alpha5,d5,theta5);
H56 = DH(a6,alpha6,d6,theta6);

%Location of joint 1
%endOfLink1 = H01(1:3,4);

%Location of joint 2
H02 = H01*H12;
%endOfLink2 = H02(1:3,4);

%Location of joint 3
H03 = H02*H23;
%endOfLink3 = H03(1:3,4);

%Location of joint 4
H04 = H03*H34;
%endOfLink4 = H04(1:3,4);

%Location of joint 5
H05 = H04*H45;
%endOfLink5 = H05(1:3,4);

%Location of joint 6
H06 = H05*H56;
endOfLink6 = H06(1:3,4);

R = H06(1:3,1:3);
theta=asin(-R(3,1));
phi=asin(R(3,2)/cos(theta));
psi=asin(R(2,1)/cos(theta));

X = [endOfLink6(1)-x_des; endOfLink6(2)-y_des; endOfLink6(3)-z_des;...
     phi_des-phi; theta_des-theta; psi_des-psi]; 