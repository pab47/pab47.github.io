clc
close all

projectile.g = 9.81;
projectile.ground = 0; %ground is at y co-ordinate equal to projectile.ground
projectile.c = 0.05; %0.7;
projectile.m = 2;
projectile.T = 2; 
projectile.x0 = 0;
projectile.y0 = 0;
projectile.xTarget = 5;
projectile.yTarget = 10; 

projectile.movieWrite = 0; %set to 1 to output a movie file
projectile.moviePause = 0.01; %delay for the movie
projectile.movieFps = 30; %frames per second. Ensures that same number of frames are there every second.
projectile.movieName = 'projectile.avi';

x0dot = 5*cos(pi/3); %50
y0dot = 5*sin(pi/3);
q_guess = [x0dot y0dot];
options = optimoptions(@fsolve,'Display','iter','MaxFunEvals',1000); 
q0 = fsolve('projectile_constraints',q_guess,options,projectile)

[q_all,t_all] = projectile_sim(q0,projectile);

figure(1)
subplot(2,2,1);
plot(t_all,q_all(:,1),'r');
ylabel('Position x');
subplot(2,2,2);
plot(t_all,q_all(:,3),'r');
ylabel('Position y');
subplot(2,2,3);
plot(t_all,q_all(:,2),'b');
ylabel('Velocity x');
subplot(2,2,4);
plot(t_all,q_all(:,4),'b');
ylabel('Velocity y');
xlabel('Time');

figure(2)
projectile_animation(t_all,q_all,projectile)
