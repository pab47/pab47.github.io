function example_roots
clc
close all
clear all

x = linspace(-6,6);
y = x.^2-x-2;

plot(x,y,'r');
grid on
    
x = fsolve(@myfun,-3,optimoptions('fsolve','Display','iter'))
 
function F = myfun(x)
F = x.^2-x-2;