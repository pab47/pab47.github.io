function example_jacobian

clc
clear all

syms x y real
z = [x y];
z0 = [1 2];

f = fn(z);

%%%% symbolic jacobian %%
J = jacobian(f,z)

%%%% finding numerical value by substituting values %%s
J_sym = subs(J,z,z0)

%%%%%% numerical jacobian %%%
J_num = jacob(@fn,z0)

function f = fn(z)
x = z(1); 
y = z(2);
f = [x^2+y^2 2*x+3*y+5];

function J = jacob(F,z)
pert = 1e-5;

for i=1:2
    ztemp1 = z;
    ztemp1(i) = ztemp1(i) - pert;
    F1 = F(ztemp1);
    
    ztemp2 = z;
    ztemp2(i) = ztemp2(i) + pert;
    F2 = F(ztemp2);
    
    J(:,i) = (F2-F1)/(2*pert);
end
    