clc
clear all

a = [1 1 3 4];


total_sum = 0;

for i=1:length(a)
    total_sum = total_sum + a(i);
end

total_sum
