clc
clear all

a = [1 1 3 4];
b = [6 5 7]; 
c = [10 1 5 6 7];

sum_a = my_sum(a)
sum(a)

sum_b = my_sum(b)
sum(b)

sum_c = my_sum(c)
sum(c)



