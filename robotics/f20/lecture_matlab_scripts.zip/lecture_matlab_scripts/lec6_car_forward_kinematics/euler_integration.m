function z1 = euler_integration(t,z0,u)


v = u(1);
omega = u(2);
h = t(2)-t(1);

x_t0 = z0(1);
y_t0 = z0(2);
theta_t0 = z0(3);

xdot_c = v*cos(theta_t0);
ydot_c = v*sin(theta_t0);
thetadot = omega;

%%%%% all in frame 0 %%%
x_t1 = x_t0 + xdot_c*h;
y_t1 = y_t0 + ydot_c*h;
theta_t1 = theta_t0 + thetadot*h;

z1 = [x_t1, y_t1, theta_t1];