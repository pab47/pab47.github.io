clc
clear all
close all

%%%%%%% symbolic variables %%%%
syms x y real
syms xdot ydot real
syms xddot yddot real
syms m g c real

%%%%% 1) position and velocity %%%
%%% x and y 
%%% xdot and ydot 
%%% are defined 

%%%% 2) Kinetic, potential energy, Lagrangian %%
T = 0.5*m*(xdot^2+ydot^2);
V = m*g*y;
L = T-V;

%%%% 3) Euler-Lagrange Equation %%%
Fx = -c*xdot*sqrt(xdot^2+ydot^2); %see notes
Fy = -c*ydot*sqrt(xdot^2+ydot^2); %see notes

%%%%% Method1: manually defining terms %%
%%% EOM = ddt (dL/dqdot) - dL/dq - Q = 0 %%
dLdx = diff(L,x);
dLdxdot = diff(L,xdot);
ddt_dLdxdot = diff(dLdxdot,x)*xdot + diff(dLdxdot,xdot)*xddot + ...
              diff(dLdxdot,y)*ydot + diff(dLdxdot,ydot)*yddot;
EOM1 = ddt_dLdxdot - dLdx - Fx; %checks with notes

dLdy = diff(L,y);
dLdydot = diff(L,ydot);
ddt_dLdydot = diff(dLdydot,x)*xdot + diff(dLdydot,xdot)*xddot + ...
              diff(dLdydot,y)*ydot + diff(dLdydot,ydot)*yddot;
EOM2 = ddt_dLdydot - dLdy - Fy; %checks with notes

%%%%% Method2: automation.
q = [x y]; %position 
qdot = [xdot ydot]; %velocity 
qddot = [xddot yddot]; %acceleration
F = [Fx Fy];

for ii=1:2
    dLdqdot(ii) = diff(L,qdot(ii));
    ddt_dLdqdot(ii) = diff(dLdqdot(ii),q(1))*qdot(1)+ ...
                      diff(dLdqdot(ii),qdot(1))*qddot(1)+...
                     diff(dLdqdot(ii),q(2))*qdot(2)+ ...
                     diff(dLdqdot(ii),qdot(2))*qddot(2);
    dLdq(ii) = diff(L,q(ii));

    EOM(ii) = ddt_dLdqdot(ii) - dLdq(ii) - F(ii);
end    

EOM1
EOM(1)

EOM2
EOM(2)