clc
clear all

%%%%% define symbolic variables %%
syms x xdot xddot real

%%%%%%% f1 = sin(x(t)) %%%
f1 = sin(x);
df1dt = diff(f1,x)*xdot %xdot = dxdt

%%%%% f2 = x*xdot %%%
f2 = x*xdot
df2dt = diff(f2,x)*xdot + diff(f2,xdot)*xddot
