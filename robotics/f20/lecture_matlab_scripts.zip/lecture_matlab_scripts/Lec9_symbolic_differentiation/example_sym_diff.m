clc
clear all

%%%%% symbolic differentiation %%
syms x real

f0 = x^2+2*x+1;
df0dx = diff(f0,x)

xval = 1;
subs(df0dx,xval)