function example_diff_num
clc
clear all
format long

%%%%% numeric differentiation %%%
%f = fun(0)
xval = 1;

%%%%% forward difference %%%
pert = 1e-4;
x0 = xval;
x1 = xval+pert;
F0 = fun(x0);
F1 = fun(x1);
df0dx = (F1-F0)/(x1-x0)

%%%%% central difference %%

F1 = fun(xval-pert);
F2 = fun(xval+pert);
df0dx = (F2-F1)/(2*pert)





function f = fun(x)
f = x^2+2*x+1;