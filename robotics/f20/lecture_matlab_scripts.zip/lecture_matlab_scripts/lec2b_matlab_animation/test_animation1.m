clc %clear the screen
clear all %clear all variables
close all %close all figures

t = linspace(0,2*pi,100);
y = sin(t);

plot(t,y,'k'); %plot
hold on;

for i=1:length(y)
    h=plot(t(i),y(i),'ro','Markersize',10,'MarkerFaceColor','r');
    pause(0.1);
    delete(h);
end


