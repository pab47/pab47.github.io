clc
clear all
close all

%%% This example shows how to do the inverse kinematics for a 2 link manipulator and do an animation.

%% Specify DH parameters
global d1 a1 alpha1 
global d2 a2 alpha2
global a3 alpha3 theta3
global d4 a4 alpha4 
global d5 a5 alpha5
global d6 a6 alpha6
global x_des y_des z_des %where you want the end-effector
global phi_des theta_des psi_des %orientation of end-effector


%%%%% set parameters %%%
% d1_= 0.25;
% d2_ = 0.25;
% d4_ = 0.25;
% d6_ = 0.25;

d1_ = 1.3;
d2_ = 1.4;
d4_ = 0.9;
d6_ = 0.4;


%D-H for links. Theta's are not set, because we need to find them. 
d1=d1_; a1=0;  alpha1=-pi/2; % theta1
d2=d2_; a2=0; alpha2=pi/2; % theta2
        a3=0; alpha3=0; theta3=-pi/2;
d4=d4_; a4=0; alpha4=-pi/2; %theta4
d5=0;   a5=0; alpha5=pi/2; %theta5
d6=d6_; a6=0; alpha6=0; %theta6


%Location where we want the end-effector to be
x_des = 1.5; y_des = 0.5; z_des = 1.5;
phi_des=0; theta_des=0; psi_des=0;

%%%%%%%%% initial guess
theta1=pi/2; theta2=0; d3=0.5; theta4=0; theta5=0; theta6=0;

X0 = [theta1, theta2, d3, theta4, theta5, theta6];


disp('init position');
figure(1)
animate(X0)


%% Solve for the values of theta that give the required end-effector pose.
%fsolve solves for the roots for the equation X-XDES
[X,FVAL,EXITFLAG] = fsolve('fn_end_effector_position',X0);
theta1 = X(1);
theta2 = X(2);
d3 = X(3);
theta4 = X(4);
theta5 = X(5);
theta6 = X(6);
disp(['Exitflag after running fsolve = ', num2str(EXITFLAG) ]) %Tells if fsolve converged or not
               %1 means converged else not converged
               %Type help fsolve to know more about what different 
               %EXITFLAG mean.
              
 X
 FVAL
%% Now visualize the results 
%close all %close all plots before starting
X_des = [x_des y_des,z_des];
disp('final position');
figure(2)
animate(X,X_des)