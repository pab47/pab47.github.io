function animate(X0,X_des)

theta1=X0(1); theta2=X0(2); d3=X0(3); theta4=X0(4); theta5=X0(5); theta6=X0(6);

global d1 a1 alpha1 
global d2 a2 alpha2
global a3 alpha3 theta3
global d4 a4 alpha4 
global d5 a5 alpha5
global d6 a6 alpha6

% Now let us plot the results.
H01 = DH(a1,alpha1,d1,theta1); 
H12 = DH(a2,alpha2,d2,theta2); 
H23 = DH(a3,alpha3,d3,theta3); 
H34 = DH(a4,alpha4,d4,theta4);
H45 = DH(a5,alpha5,d5,theta5);
H56 = DH(a6,alpha6,d6,theta6);

%Location of joint 1
endOfLink1 = H01(1:3,4);

%Location of joint 2
H02 = H01*H12;
endOfLink2 = H02(1:3,4);

%Location of joint 3
H03 = H02*H23;
endOfLink3 = H03(1:3,4);

%Location of joint 4
H04 = H03*H34;
endOfLink4 = H04(1:3,4);

%Location of joint 5
H05 = H04*H45;
endOfLink5 = H05(1:3,4);

%Location of joint 6
H06 = H05*H56;
endOfLink6 = H06(1:3,4);

if (nargin>1) 
    x_des = X_des(1);
    y_des = X_des(2);
    z_des = X_des(3);
    %Plot the point where we want the end-effector
    plot3(x_des,y_des,z_des,'o','MarkerSize',10,'MarkerFaceColor','black');
    hold on; %Ensures that dot on screen does not dissappear
end


%Draw line from origin to end of link 1
line([0 endOfLink1(1)],[0 endOfLink1(2)],[0 endOfLink1(3)],....
      'LineWidth',5,'Color','red');

%Draw line from end of link 1 to end of link 2
line([endOfLink1(1) endOfLink2(1)],...
     [endOfLink1(2) endOfLink2(2)],...
     [endOfLink1(3) endOfLink2(3)],...
     'LineWidth',5,'Color','blue');
 
%Draw line from end of link 2 to end of link 3
line([endOfLink2(1) endOfLink3(1)],...
     [endOfLink2(2) endOfLink3(2)],...
     [endOfLink2(3) endOfLink3(3)],...
     'LineWidth',5,'Color','green');
 
%Draw line from end of link 3 to end of link 4
line([endOfLink3(1) endOfLink4(1)],...
     [endOfLink3(2) endOfLink4(2)],...
     [endOfLink3(3) endOfLink4(3)],...
     'LineWidth',5,'Color','yellow');
 
%Draw line from end of link 4 to end of link 5
line([endOfLink4(1) endOfLink5(1)],...
     [endOfLink4(2) endOfLink5(2)],...
     [endOfLink4(3) endOfLink5(3)],...
     'LineWidth',5,'Color',[255,165,0]/255);
 
%Draw line from end of link 5 to end of link 6
line([endOfLink5(1) endOfLink6(1)],...
     [endOfLink5(2) endOfLink6(2)],...
     [endOfLink5(3) endOfLink6(3)],...
     'LineWidth',5,'Color','red');
 
 
xlabel('x');
ylabel('y');
zlabel('z');
grid on; %if you want the grid to show up.
axis('equal'); %make the axis equal, to avoid scaling effect

view([148,10]); %top view (for 2-d plot). Comment out if you want a 3-d plot
%view([90,0]);

%These set the x and y limits for the axis (will need adjustment)
xlim([-2 2]); 
ylim([-2 2]);
zlim([-2 2]);

