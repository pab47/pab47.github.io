clc
clear all
close all 

%%%%%% generate data for a circle %%%
theta = linspace(0,2*pi);
x_circle = 5*cos(theta);
y_circle = 5*sin(theta);

patch(x_circle,y_circle,'r'); hold on;
axis('equal');

%%%%%%% generate a rectangle %%%
x_rectangle = [0 2 2 0];
y_rectangle = [0 0 1 1];

mov = VideoWriter('test_animation3.avi'); 
open(mov);

%%%% get the rectangle coordinate as it moves along the circle %%%%
for i=1:length(theta)
    x_moving_rectangle = x_circle(i) + x_rectangle;
    y_moving_rectangle = y_circle(i) + y_rectangle;
    h = patch(x_moving_rectangle,y_moving_rectangle,'b');
    axis('equal');
    axis([-7 7 -7 7]);
    writeVideo(mov,getframe);
    pause(0.1);
    delete(h);
end

close(mov);