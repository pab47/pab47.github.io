clc
clear all
close all 

%%%%%% generate data for a circle %%%
theta = linspace(0,2*pi);
x_circle = cos(theta);
y_circle = sin(theta);

patch(x_circle,y_circle,'r'); hold on;
axis('equal');

%%%% generare data for a rectangle %%%%
%(0,0)
%(2,0)
%(2,1)
%(0,1);
x_rectangle = 2+[0 2 2 0];
y_rectangle = 3+[0 0 1 1];
patch(x_rectangle,y_rectangle,'b');