function test_fminunc1

clc
clear all
close all

x0 = [0 0];
options = optimoptions('fminunc','Display','iter','MaxFunctionEvaluations',1000);
[X,fval,exitflag] = fminunc(@myfun,x0,options)

function F = myfun(x)
x1 = x(1);
x2 = x(2);
F = 100*(x2-x1^2)^2 + (1-x1)^2;