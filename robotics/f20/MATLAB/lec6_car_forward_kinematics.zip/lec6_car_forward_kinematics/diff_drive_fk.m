%%% simulation of a robot car with a differential drive %%%
clc
clear 
close all

parms.writeMovie = 0; %set to 1 to get a movie output
parms.nameMovie = 'car.avi';

%%%%%%%% car parameters %%%%%%%
parms.R = 0.1; %radius of the chassis (only used for animation)

%%%%%% initialize time and robot state %%%%%%% 
fps = 10; %adjust number of frames per second
parms.delay = 0.2; %adjust the delay in the animation
z0 = [0 0 -pi/2]; %start position of the robot car [x0, y0, theta0]

% %%%%%%%% initialize the left and right wheel controls %%%%%
h = 0.1;

%%%%% the controls are v = speed and omega = direction
%%%%%% v = 0.5r(phidot_r + phidot_l)
%%%%%% omega = 0.5 (r/b)*(phitdot_r - phidot_l)
%%%%%% these are set below %%%%%%
%%%%%%% writing letters %%%%%%%
t1 = 0:h:1;
speed1 = ones(1,length(t1));
direction1 = zeros(1,length(t1)); 

t2 = 1+h:h:2;
speed2 = zeros(1,length(t2));
direction2 = pi/2*ones(1,length(t2)); 

t3 = 2+h:h:3;
speed3 = ones(1,length(t3));
direction3 = zeros(1,length(t3)); 

t =[t1 t2 t3];
speed = [speed1 speed2 speed3];
direction = [direction1 direction2 direction3];


%%%%%%%%%% simulate %%%%%%%%%
z = z0;
for i=1:length(t)-1
    u = [speed(i) direction(i)];
    zz = euler_integration([t(i) t(i+1)],z0,u);
    z0 = zz(end,:);
    z = [z; z0];
end

%%%%%% Downsizing the data for animation %%%%%%%%%%%
%%%%%%% Reason: The integration above gives too many data points 
%%%%% THis corresponds to too many frames in the animation
%%%%%% This slows down the animation 
%%%%% Using liner interpolation (interp1), we downsize the data
t_interp = linspace(0,t(end),fps*t(end));
[m,n] = size(z);
for i=1:n
    z_interp(:,i) = interp1(t,z(:,i),t_interp);
end

%%%%%% animate %%%%%
figure(1)
animation(t_interp,z_interp,parms);



