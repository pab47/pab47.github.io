function total_sum = my_sum(M) %total_sum is the output
                               %M is the input

total_sum = 0;

for i=1:length(M)
    total_sum = total_sum + M(i);
end