clc
clear all
close all

%%%%%%%%% define parameters %%%%%
l1 = 1; l2 = 1;
theta1 = 0.5; theta2 = pi/2;

%%%% origin of the world/fixed frame %%%
x_O0 = 0; y_O0 = 0;

%%%%%%% end of link1 or elbow in world frame %%%
x_P = l1*cos(theta1); y_P = l1*sin(theta1);

%%%% end of link2 or tip of hand in world frame %%%
x_Q = l1*cos(theta1)+l2*cos(theta1+theta2);
y_Q = l1*sin(theta1)+l2*sin(theta1+theta2);

%%%%%%%% draw line to generate the manipulator
line([x_O0 x_P],[y_O0 y_P],'Linewidth',5,'Color',[192,192,192]/255);
line([x_P x_Q],[y_P y_Q],'Linewidth',5,'Color','g');

axis('equal');
%axis([-2 2 -2 2]);
xlabel('x');
ylabel('y');
title('Forward kinematics');
