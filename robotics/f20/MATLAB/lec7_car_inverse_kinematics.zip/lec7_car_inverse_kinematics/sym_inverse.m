syms px py theta real
A = [cos(theta) -px*sin(theta)-py*cos(theta); ...
     sin(theta)  px*cos(theta)-py*sin(theta)];
 
 simplify(inv(A))