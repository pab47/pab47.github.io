function [q, t] = projectile_sim(q_init,projectile)

q0 = [projectile.x0 q_init(1,1) projectile.y0 q_init(1,2)];
t0 = 0; tend = projectile.T ; %long enough time
options = odeset('Abstol',1e-12,'Reltol',1e-12);
[t,q]=ode45(@projectile_rhs,[t0 tend],q0,options,projectile);

    