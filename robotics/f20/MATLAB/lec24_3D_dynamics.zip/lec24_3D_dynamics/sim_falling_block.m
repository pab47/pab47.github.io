function sim_falling_block
clc
clear all
close all

%%%% initialize parameters
params.m = 10;
params.Ixx = 2;
params.Iyy = 3;
params.Izz = 5;
params.g = 9.8;

%%%%%% just for animation %%%
lx = 0.1;  %along x
ly = 0.05; %along y 
lz = 0.02; %along z
l =[lx ly lz];

%initialize position and velocity
x0 = 0;
y0 = 0;
z0 = 0;
vx0 = 0;
vy0 = 0;
vz0 = 5;
	
%initialize euler angles and rates
phi0 = 0;
theta0 = 0;
psi0 = 0;
phidot0 = 1;
thetadot0 = -2; 
psidot0 = 5;

%%%%%%% integrate with ode45 %%%%%%%
tspan = linspace(0,1);
Z0=[x0 y0 z0 phi0 theta0 psi0 vx0 vy0 vz0 phidot0 thetadot0 psidot0]';
options=odeset('abstol',1e-12,'reltol',1e-12);

[T Z] = ode45(@eom,tspan,Z0,options,params);


for i=1:length(T)
    x = Z(i,1); y = Z(i,2); z = Z(i,3);
    phi = Z(i,4); theta = Z(i,5); psi = Z(i,6);
    vx = Z(i,7); vy = Z(i,8); vz = Z(i,9);
    phidot = Z(i,10); thetadot = Z(i,11); psidot = Z(i,12); 
    Ixx = params.Ixx; Iyy = params.Iyy; Izz = params.Izz; g=params.g; m = params.m;
    KE(i) = (m*vx^2)/2 + (m*vy^2)/2 + (m*vz^2)/2 + Ixx*(phidot - psidot*sin(theta))*(phidot/2 - (psidot*sin(theta))/2) + Iyy*(thetadot*cos(phi) + psidot*cos(theta)*sin(phi))*((thetadot*cos(phi))/2 + (psidot*cos(theta)*sin(phi))/2) + Izz*(thetadot*sin(phi) - psidot*cos(phi)*cos(theta))*((thetadot*sin(phi))/2 - (psidot*cos(phi)*cos(theta))/2);
    PE(i) = g*m*z;
    TE(i) = KE(i)+PE(i);
    
    R_we(1,1)=cos(psi)*cos(theta);
    R_we(1,2)=-sin(psi);
    R_we(1,3)=0;
    R_we(2,1)=cos(theta)*sin(psi);
    R_we(2,2)=cos(psi);
    R_we(2,3)=0;
    R_we(3,1)=-sin(theta);
    R_we(3,2)=0;
    R_we(3,3)=1;
    omega = R_we*[phidot; thetadot; psidot];
    omega_x(i) = omega(1); omega_y(i) = omega(2); omega_z(i) = omega(3);
    
    R_be(1,1)=1;
    R_be(1,2)=0;
    R_be(1,3)=-sin(theta);
    R_be(2,1)=0;
    R_be(2,2)=cos(phi);
    R_be(2,3)=cos(theta)*sin(phi);
    R_be(3,1)=0;
    R_be(3,2)=-sin(phi);
    R_be(3,3)=cos(phi)*cos(theta);
    omega_body = R_be*[phidot; thetadot; psidot];
    omega_body_x(i) = omega_body(1); omega_body_y(i) = omega_body(2); omega_body_z(i) = omega_body(3);
end

figure(1)
positions = Z(:,1:3);
angles = Z(:,4:6);
animate(positions,angles,l)


figure(2)
plot(T,Z);
legend('x','y','z','$\phi$','$\theta$','$\psi$','$\dot{x}$','$\dot{y}$','$\dot{z}$','$\dot{\phi}$','$\dot{\theta}$','$\dot{\psi}$','Interpreter','latex','Fontsize',12)


figure(3)
plot(T,KE,'r'); hold on;
plot(T,PE,'b'); hold on;
plot(T,TE,'k'); 
legend('KE','PE','TE');

figure(4) 
plot(T,omega_x); hold on
plot(T,omega_y);
plot(T,omega_z);
plot(T,omega_body_x); hold on
plot(T,omega_body_y);
plot(T,omega_body_z);
legend('$\omega_x$','$\omega_y$','$\omega_z$','$\omega^b_x$','$\omega^b_y$','$\omega^b_z$','Interpreter','latex','Fontsize',12);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Zdot = eom(t,Z,params)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

m = params.m;
Ixx = params.Ixx;
Iyy = params.Iyy;
Izz = params.Izz;
g = params.g;


x = Z(1); y = Z(2); z = Z(3);
phi = Z(4); theta = Z(5); psi = Z(6);
vx = Z(7); vy = Z(8); vz = Z(9);
phidot = Z(10); thetadot = Z(11); psidot = Z(12);


%%%%% copy pasted from running equations_falling_block.m %%
A(1,1)=m;
A(1,2)=0;
A(1,3)=0;
A(1,4)=0;
A(1,5)=0;
A(1,6)=0;
A(2,1)=0;
A(2,2)=m;
A(2,3)=0;
A(2,4)=0;
A(2,5)=0;
A(2,6)=0;
A(3,1)=0;
A(3,2)=0;
A(3,3)=m;
A(3,4)=0;
A(3,5)=0;
A(3,6)=0;
A(4,1)=0;
A(4,2)=0;
A(4,3)=0;
A(4,4)=Ixx;
A(4,5)=0;
A(4,6)=-Ixx*sin(theta);
A(5,1)=0;
A(5,2)=0;
A(5,3)=0;
A(5,4)=0;
A(5,5)=Iyy - Iyy*sin(phi)^2 + Izz*sin(phi)^2;
A(5,6)=cos(phi)*cos(theta)*sin(phi)*(Iyy - Izz);
A(6,1)=0;
A(6,2)=0;
A(6,3)=0;
A(6,4)=-Ixx*sin(theta);
A(6,5)=cos(phi)*cos(theta)*sin(phi)*(Iyy - Izz);
A(6,6)=Ixx*sin(theta)^2 + Izz*cos(phi)^2*cos(theta)^2 + Iyy*cos(theta)^2*sin(phi)^2;
 
b(1,1)=0;
b(2,1)=0;
b(3,1)=-g*m;
b(4,1)=(Izz*thetadot^2*sin(2*phi))/2 - (Iyy*thetadot^2*sin(2*phi))/2 + Ixx*psidot*thetadot*cos(theta) - Iyy*psidot*thetadot*cos(theta) + Izz*psidot*thetadot*cos(theta) + Iyy*psidot^2*cos(phi)*cos(theta)^2*sin(phi) - Izz*psidot^2*cos(phi)*cos(theta)^2*sin(phi) + 2*Iyy*psidot*thetadot*cos(phi)^2*cos(theta) - 2*Izz*psidot*thetadot*cos(phi)^2*cos(theta);
b(5,1)=(Ixx*psidot^2*sin(2*theta))/2 - Ixx*phidot*psidot*cos(theta) + Iyy*phidot*thetadot*sin(2*phi) - Izz*phidot*thetadot*sin(2*phi) - Izz*psidot^2*cos(phi)^2*cos(theta)*sin(theta) - Iyy*psidot^2*cos(theta)*sin(phi)^2*sin(theta) - Iyy*phidot*psidot*cos(phi)^2*cos(theta) + Izz*phidot*psidot*cos(phi)^2*cos(theta) + Iyy*phidot*psidot*cos(theta)*sin(phi)^2 - Izz*phidot*psidot*cos(theta)*sin(phi)^2;
b(6,1)=Ixx*phidot*thetadot*cos(theta) + Iyy*phidot*thetadot*cos(theta) - Izz*phidot*thetadot*cos(theta) - Ixx*psidot*thetadot*sin(2*theta) + Iyy*psidot*thetadot*sin(2*theta) + Iyy*thetadot^2*cos(phi)*sin(phi)*sin(theta) - Izz*thetadot^2*cos(phi)*sin(phi)*sin(theta) - 2*Iyy*phidot*thetadot*cos(phi)^2*cos(theta) + 2*Izz*phidot*thetadot*cos(phi)^2*cos(theta) - 2*Iyy*phidot*psidot*cos(phi)*cos(theta)^2*sin(phi) + 2*Izz*phidot*psidot*cos(phi)*cos(theta)^2*sin(phi) - 2*Iyy*psidot*thetadot*cos(phi)^2*cos(theta)*sin(theta) + 2*Izz*psidot*thetadot*cos(phi)^2*cos(theta)*sin(theta);
 
X = A\b;

Zdot = [vx vy vz phidot thetadot psidot X(1) X(2) X(3) X(4) X(5) X(6)]'; 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function animate(positions,angles,l)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
lx = l(1); 
ly = l(2);
lz = l(3);

dmax = max( max(positions));

vertex(1,:) = [ lx  ly -lz];
vertex(2,:) = [ lx -ly -lz];
vertex(3,:) = [ lx -ly  lz];
vertex(4,:) = [ lx  ly  lz];
vertex(5,:) = [-lx  ly -lz];
vertex(6,:) = [-lx -ly -lz];
vertex(7,:) = [-lx -ly  lz];
vertex(8,:) = [-lx  ly  lz];

face = [ 1 2 3 4 ;
         5 6 7 8 ;
         2 6 7 3 ;
         1 5 8 4 ;
         3 7 8 4 ;
         2 6 5 1 ];

[m,n] = size(vertex);
[mm,nn] = size(angles);

for ii=1:mm
    x = positions(ii,1);
    y = positions(ii,2);
    z = positions(ii,3);
    phi = angles(ii,1); 
    theta = angles(ii,2);
    psi = angles(ii,3);
    R = get_rotation(phi,theta,psi);
    
    for i=1:m
        r_body = vertex(i,:)';
        r_world = R*r_body;
        new_vertex(i,:) = r_world'; 
    end
    new_vertex = [x y z] + new_vertex;

    h=patch('Vertices',new_vertex,'Faces',face,'FaceColor','green');
    axis(1.2*[-dmax dmax -dmax dmax -dmax dmax]);
    xlabel('x'); ylabel('y'); zlabel('z');
    view(-15,42)
    pause(0.05)
    if (ii~=mm)
        delete(h);
    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function R = get_rotation(phi,theta,psi)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%% uses 3-2-1 euler angles
R_x = [1    0       0; ...
       0  cos(phi) -sin(phi); ...
       0  sin(phi) cos(phi)];
   
R_y = [cos(theta)  0   sin(theta); ...
       0           1         0; ...
      -sin(theta) 0   cos(theta)]; 
   
R_z = [cos(psi) -sin(psi)  0; ...
       sin(psi)  cos(psi)  0; ...
       0           0       1];  
R = R_z*R_y*R_x;
