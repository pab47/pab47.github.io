function dqdt = projectile_rhs(t,q,projectile)

g = projectile.g;
m = projectile.m;
c = projectile.c; 

%x = q(1);
xdot = q(2);
%y = q(3);
ydot = q(4);
v = sqrt(xdot^2+ydot^2);

%%%% drag is prop to v^2
dragX = c*v*xdot;
dragY = c*v*ydot;

%%%% net acceleration %%%
ax = 0-(dragX/m);
ay = -g-(dragY/m);


dqdt = [xdot ax ydot ay]';

