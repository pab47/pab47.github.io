function score=cost(x)

global N p_goal
A = x(1:N);
p = x(N+1:2*N);

score = 0;
for i=1:N 
    score = score + A(i)^2 + (p(i)-p_goal)^2;
end
