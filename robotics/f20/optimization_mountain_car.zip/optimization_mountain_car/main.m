
%%%%%%% optimization of sutton's mountain car (see sutton's book)
%%%%% caveats: (1) control (a) is continuous between -1 and 1
%%%%           (2) the grid size (equal to time span) needs to be specified
clc
clear all
close all

global N;
global p_goal p_init;
N = 120; %grid points
%%% the curve is given by (p,sin(3*p)), p = x_t and pdot = xdot_t
p_min = -1.2;
p_max = 0.5;
pdot_min = -0.07;
pdot_max =  0.07;
p_goal =  0.5;
p_init = -0.4; %initial

%%%%%%% initialize optimization parameters
A0= 0.5*ones(1,N); %controls
p0 = linspace(p_init,p_goal,N);
pdot0 = zeros(1,N);

x0 = [A0, p0, pdot0]; %initial guess
options = optimset('MaxFunEvals',100000,'Display','iter');
LB = [-ones(1,N) p_min*ones(1,N) pdot_min*ones(1,N)]; 
UB = [ ones(1,N) p_max*ones(1,N) pdot_max*ones(1,N)];
[x_sol,FVAL,EXITFLAG,OUTPUT] = fmincon(@cost,x0,[],[],[],[],LB,UB,@constraints,options)
EXITFLAG
%x_sol'

%%% get data 
A = x_sol(1:N);
p = x_sol(N+1:2*N);
pdot = x_sol(2*N+1:3*N);

%%% post processing
figure(1)
subplot(3,1,1);
plot(p)
subplot(3,1,2);
plot(pdot);
subplot(3,1,3);
plot(A);


figure(2)
pp = linspace(p_min,p_max);
plot(pp,sin(3*pp)); hold on; %this is the curve
for i=1:length(p)
    h=plot(p(i),sin(3*p(i)),'ro');
    pause(0.1);
    if (i<length(p))
        delete(h);
    end
end

