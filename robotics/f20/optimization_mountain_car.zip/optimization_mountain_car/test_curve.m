clc
close all
clear all

p_min = -1.2;
p_max = 0.5;
p = linspace(p_min,p_max);
plot(p,sin(3*p)); hold on;
p_init = -0.4; %initial points -0.4 to -0.6
plot(p_init,sin(3*p_init),'ro');
p_goal = 0.5;
plot(p_goal,sin(3*p_goal),'bo','MarkerFaceColor','b');
p_deadend = -1.2; %velocity re-set to zero
plot(p_deadend,sin(3*p_deadend),'gs','MarkerFaceColor','g');
