function [c,ceq] = constraints(x)

global p_goal;
global p_init;

global N
A = x(1:N);
p = x(N+1:2*N);
pdot = x(2*N+1:3*N);

for i=1:N-1
    defect_p(i) = p(i+1) -  p(i) - pdot(i+1) ;
    defect_pdot(i) = pdot(i+1) - pdot(i) - 0.001*A(i) + 0.0025*cos(3*p(i));
end

c = []; %no inequality constraints
%%% first two are dynamics, next two are start and goal position, final two are start and goal velocity
ceq = [ defect_p defect_pdot p(1)-p_init p(end)-p_goal pdot(1) pdot(end)];

