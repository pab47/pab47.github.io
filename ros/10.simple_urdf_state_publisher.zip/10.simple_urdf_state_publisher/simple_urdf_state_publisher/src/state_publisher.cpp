#include <string>
#include <ros/ros.h>
#include <sensor_msgs/JointState.h>

int main(int argc, char** argv) {
    ros::init(argc, argv, "state_publisher");
    ros::NodeHandle n;
    ros::Publisher joint_pub = n.advertise<sensor_msgs::JointState>("joint_states", 1);
    ros::Rate loop_rate(30);


    // initialize robot state
    double theta1 = 0., theta2 = 0;
    double theta1_inc = 0.01, theta2_inc = 0.025;

    // message declarations
    sensor_msgs::JointState joint_state;

    while (ros::ok()) {
        //update joint_state
        joint_state.header.stamp = ros::Time::now();
        joint_state.name.resize(2);
        joint_state.position.resize(2);
        joint_state.name[0] ="base_to_link1";
        joint_state.position[0] = theta1;
        joint_state.name[1] ="link1_to_link2";
        joint_state.position[1] = theta2;

	// Theta1 //
	theta1 += theta1_inc;
	if (theta1>=3.14)
	{
	   theta1 = 3.14;
	   theta1_inc = -theta1_inc;
	}
	if (theta1<=-3.14)
	{
	   theta1 = -3.14;
           theta1_inc = -theta1_inc;
	}

 
	// Theta2 //
	theta2 += theta2_inc;
	if (theta2>=3.14/2)
	{
	   theta2 = 3.14/2;
	   theta2_inc = -theta2_inc;
	}
	if (theta2<=-3.14/2)
	{
	   theta2 = -3.14/2;
           theta2_inc = -theta2_inc;
	}

        //send the joint state and transform
        joint_pub.publish(joint_state);

        // This will adjust as needed per iteration
        loop_rate.sleep();
    }


    return 0;
}
